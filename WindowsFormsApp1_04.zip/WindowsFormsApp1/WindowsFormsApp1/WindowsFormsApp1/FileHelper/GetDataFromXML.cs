﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Collections.Specialized;
using System.Configuration;
using System.Xml;
using System.Windows.Forms;


namespace AHDP
{
    public class GetDataFromXML
    {
        public static NameValueCollection AppConfig = ConfigurationManager.AppSettings;
        public static string EditorSQLPath1 = Environment.CurrentDirectory + @"\Login.xml";
        public static string EditorLOGINpath = Environment.CurrentDirectory + @"\Login_user.xml";
        public static string EditorSQLPath = @"D:\TEAL\TLA\DLL\ConnectionDetails.Xml";
        public static string DeviceSettingFile = Environment.CurrentDirectory + @"\Device.txt";
        public static string AllCmdPath = Environment.CurrentDirectory + @"\command.txt";
        public static string AlarmlogPath = @"D:\Nova\Alarm_Log\";//D:/Nova/logs
        public static string Runninglog = @"D:\Nova\Running_Log\";//D:/Nova/logs
        public static string PLC_Address = string.Empty;
        public static string LaserIP_Address = string.Empty;
        public static string LaserPort_Address = string.Empty;
        public static string LogFilePath = string.Empty;
        public static string PLC_Rack = string.Empty;
        public static string PLC_Slot = string.Empty;
        public static int ReturnValue;
        public static string INSTANCE_NAME = string.Empty;
        public static string DATABASE_NAME = string.Empty;
        public static string AUTHENTICATION = string.Empty;
        public static string USER_NAME ="sa";
        public static string PASSWORD = "Titan@123";
        public static string LOGIN_USER_NAME = string.Empty;
        public static string LOGIN_PASSWORD = string.Empty;
        public static string Error_Log_Path = string.Empty;
        public static string LaserConn_Path = string.Empty;
        public static string LaserMarkingName = string.Empty;


        public void Get_Data_FromXML()
        {

            LoadValues1();
        }

        public static bool LoadValues()
        {
            try
            {
                if (File.Exists(EditorSQLPath))
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(EditorSQLPath);
                    XmlNodeList nodes = xmlDoc.DocumentElement.SelectNodes("/Login");
                    foreach (XmlNode node in nodes)
                    {
                        INSTANCE_NAME = node.SelectSingleNode("Instance").InnerText;
                        DATABASE_NAME = node.SelectSingleNode("Database").InnerText;
                        AUTHENTICATION = node.SelectSingleNode("Authentication").InnerText;
                        if (AUTHENTICATION.ToUpper() == "SQL AUTHENTICATION")
                        {
                            USER_NAME = node.SelectSingleNode("UserName").InnerText;
                            PASSWORD = node.SelectSingleNode("Password").InnerText;
                        }
                    }
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public static bool LOGINDETAILS()
        {
            try
            {
                XmlDocument xmlDocument = new XmlDocument();
                xmlDocument.Load(EditorLOGINpath);
                foreach (XmlNode parentNode in xmlDocument.DocumentElement.ParentNode)
                {
                    // foreach (XmlNode childNode in parentNode.ChildNodes)
                    //{
                    if (parentNode.Name == "USER")
                    {


                        LOGIN_USER_NAME = parentNode["USERNAME"].InnerText;
                        LOGIN_PASSWORD = parentNode["PWD"].InnerText;
                        Error_Log_Path = parentNode["ErrorLogPath"].InnerText;
                        Logger._dirPath = Error_Log_Path;
                        LaserConn_Path = parentNode["LaserConnectionDetails"].InnerText;
                        LaserMarkingName = parentNode["LMName"].InnerText;
                    }

                    // }
                }
                return true;
            }
            catch (Exception es)
            {
                return false;
            }

        }

        public void BindConnectionDetails(string ConnectionStr, string path)
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(path);
            foreach (XmlNode parentNode in xmlDocument.DocumentElement.ParentNode)
            {
                foreach (XmlNode childNode in parentNode.ChildNodes)
                {
                    if (childNode.Name == ConnectionStr)
                    {
                        LaserIP_Address = childNode["ServerIPAddress"].InnerText;
                        LaserPort_Address = childNode["PortNumber"].InnerText;
                        LogFilePath = childNode["LogFilePath"].InnerText;
                        //MessageBox.Show(childNode["ServerIPAddress"].InnerText);
                    }
                }
            }
        }
        public void BindConnectionDetails_PLC(string Plc)
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(Environment.CurrentDirectory + @"\PLC_Configuration.xml");
            foreach (XmlNode parentNode in xmlDocument.DocumentElement.ParentNode)
            {
                //foreach (XmlNode childNode in parentNode.ChildNodes)
                //{
                if (parentNode.Name == "PLC_Configuration")
                {
                    PLC_Address = parentNode["IP_Address"].InnerText;
                    PLC_Rack = parentNode["Rack"].InnerText;
                    PLC_Slot = parentNode["Slot"].InnerText;
                    //MessageBox.Show(childNode["ServerIPAddress"].InnerText);
                }
                //}
            }
        }
        public static bool LoadValues1()
        {
            try
            {
                XmlDocument xmlDocument = new XmlDocument();
                xmlDocument.Load(EditorSQLPath1);
                foreach (XmlNode parentNode in xmlDocument.DocumentElement.ParentNode)
                {
                    // foreach (XmlNode childNode in parentNode.ChildNodes)
                    //{
                    if (parentNode.Name == "LOGIN")
                    {
                        INSTANCE_NAME = parentNode["INSTANCE_NAME"].InnerText;
                        DATABASE_NAME = parentNode["DATABASE_NAME"].InnerText;
                        AUTHENTICATION = parentNode["AUTHENTICATION"].InnerText;
                        //MessageBox.Show(childNode["ServerIPAddress"].InnerText);
                        if (AUTHENTICATION.ToUpper() == "SQL AUTHENTICATION")
                        {
                            USER_NAME = parentNode.SelectSingleNode("UserName").InnerText;
                            PASSWORD = parentNode.SelectSingleNode("Password").InnerText;
                        }
                    }

                    // }
                }
                return true;
            }
            catch (Exception es)
            {
                return false;
            }

        }
        //public static bool LoadValues1()
        //{
        //    try
        //    {
        //        if (File.Exists(EditorSQLPath1))
        //        {
        //            XmlDocument xmlDoc = new XmlDocument();
        //            xmlDoc.Load(EditorSQLPath);
        //            XmlNodeList nodes = xmlDoc.DocumentElement.SelectNodes("/LOGIN");
        //            foreach (XmlNode node in nodes)
        //            {
        //                INSTANCE_NAME = node.SelectSingleNode("Instance").InnerText;
        //                DATABASE_NAME = node.SelectSingleNode("Database").InnerText;
        //                AUTHENTICATION = node.SelectSingleNode("Authentication").InnerText;
        //                if (AUTHENTICATION == "SQL Server Authentication")
        //                {
        //                    USER_NAME = node.SelectSingleNode("UserName").InnerText;
        //                    PASSWORD = node.SelectSingleNode("Password").InnerText;
        //                }
        //            }
        //            return true;
        //        }
        //        else
        //            return false;
        //    }
        //    catch (Exception ex)
        //    {
        //        return false;
        //    }
        //}

        public void SetValues()
        {
            try
            {
                XmlWriter writer = XmlWriter.Create("PLC_Configuration.xml");

                writer.WriteStartElement("PLC_Configuration");

                writer.WriteStartElement("IP_Address");
                writer.WriteString(PLC_Address);
                writer.WriteEndElement();

                writer.WriteStartElement("Rack");
                writer.WriteString(PLC_Rack);
                writer.WriteEndElement();

                writer.WriteStartElement("Slot");
                writer.WriteString(PLC_Slot);
                writer.WriteEndElement();

                writer.WriteEndElement();

                writer.Close();
                writer.Dispose();
            }
            catch (Exception es)
            {

            }


        }


      

    }
}
