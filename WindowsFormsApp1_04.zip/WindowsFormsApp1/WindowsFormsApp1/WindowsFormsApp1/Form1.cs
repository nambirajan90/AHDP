﻿using AHDP.UIScreens.GeneralScreens;
using AHDP.UIScreens.IO_Screens;
using AHDP.UIScreens.Manual_Screen;
using AHDP.UIScreens.ParameterSetting_Screens;
using AHDP.UIScreens.Report_Screens;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP
{
    public partial class Form1 : Form
    {
        //Added//
        public GroupBox box;
        Boolean AlarmBit;
        Boolean MachineRunning;
        Boolean MachinePause;
        Boolean MachineStop;
        //private Worker worker = new Worker();
        public static double Xpos = 0.0;
        public static double Ypos = 0.0;
        public static Queue VisionRecieve_Q = new Queue();
        public static Queue VisionRecieve_Q_TFC = new Queue();
        // public static string Login_user_mode = string.Empty;
        public static bool Login_valditation = false;
        public static System.Threading.Timer Foam_Presence_Sensor_read;
        public static bool glb_initialize = false;

        //Newly declared
        private Receipe recipe;
        private System.Threading.Timer _timer;
        //AlarmLiveScreen alarmLiveScreen = new AlarmLiveScreen();
        //Newly declared
        //Added//

        public Form1()
        {
            InitializeComponent();  //calls the UI function
                                    //menubuttonshow();
                                    //05112024enablehomeicons();
            disablehomeicons();//at start of of the executable code all the icons will be disabled
                                    //box.Enabled = true;

            // this.MouseMove += Form1_MouseMove;
            //if (Login == "Yes")
            //{

            //    InitializeComponent();
            //    //menubuttonshow();
            //    enablehomeicons();
            //    //box.Enabled = true;
            //} 
            //else
            //{
            //    InitializeComponent();
            menubuttonshow();  //all menu button will be showed

            //    //disablehomeicons();
            //}

            //Newly declared
            //Calling Recipe Functions to load all the data to a variable
            //recipe = new Receipe();
            //LoadRecipeDataAsync();
            //End
            timer1.Interval = 1000;
            timer1.Start();
            LeadShineInterface.Connect_PCIeCard();
            //Newly declared
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();
            }        
            Form form_home = new Home();
            Panel_add(form_home);


        }

        //Added//

        public static bool Alarmbit = false;
        private const int idle_time_threshold = 60000;
        public static DateTime lastEngineeringactivity;
        public static DateTime lastoperatorctivity;
        public static bool isengineeringmode = false;
        //Added//

        private void NoAlarm_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();
            }
            Form form_alarmscreen = new AlarmScreen();
            Panel_add(form_alarmscreen);


        }

        public void RE_Initialization()
        {
            glb_initialize = true;
            //Device_Initialization deviceReInitialize = new Device_Initialization();


        }
        private void ControlConfig_MouseMove(object sender, MouseEventArgs e)
        {
            if (isengineeringmode)
            {
                lastEngineeringactivity = DateTime.Now;
            }

        }
        //private void Settings_MouseMove(object sender, MouseEventArgs e)
        //{
        //    if (isengineeringmode)
        //    {
        //        lastEngineeringactivity = DateTime.Now;
        //    }
        //}
        //Mod0612
        private void Settings_MouseMove(object sender, MouseEventArgs e)
        {
            if (isengineeringmode)
            {
                lastEngineeringactivity = DateTime.Now;

}
        }


        private void btnHome_MouseClick(object sender, MouseEventArgs e)
        {
            if (isengineeringmode)
            {
                lastEngineeringactivity = DateTime.Now;
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        public static bool convrun = false;
        public static bool auto = false;
        public static bool autostop = false;

        private void CameraVision_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();
            }

            Form form_modeofoperation = new modeofoperations();
           form_modeofoperation.MdiParent = this;
            form_modeofoperation.Show();
            //if (previousform != null)
            //    previousform.Close();
            //previousform = form_modeofoperation;

            Form Home = new Home();
            Home.Close();
            Form AlarmScreen = new AlarmScreen();
            AlarmScreen.Close();
        }

        public static bool application_Onload = false;
        static bool application_Start = false;
        public static bool Onload_rotoryinit = false;
        private void Form1_Load_1(object sender, EventArgs e)
        {
            Form1.Login_valditation = true;
            Globalvariable.ReadRetentiveFromIni();
            //btnHome.Enabled = false;
            // Login_user_mode = "PRODUCTION";
            // ButtonCondition();
            //Onload_rotoryinit = true;
            //  AutoSequence.post_check_Delay = 150;
            //  GlobalVar.Gantry_X_GearRatio = 1;
            //  GlobalVar.Gantry_Y_GearRatio = 1;
            //  AutoSequence.Preinspection_re_try_cnt =7;
            //Initialize_the_functions();
            //  ToRetain.Read_Post_check_cordinates();
            //  AutoSequence.Nozzle_Active[1] = true;
            //  AutoSequence.Nozzle_Active[2] = true;
            //  AutoSequence.Nozzle_Active[3] = true;
            //  AutoSequence.Nozzle_Active[4] = true;
            //  //GlobalVar.PulseMode = 0;
            //  //GlobalVar.PulseLogic = 0;
            //  //disablehomeicons();
            //  AutoSequence.Dry_cycle = false;
            ////  System.Threading.Timer t = new System.Threading.Timer(TimerCallback, null, 0, 1000);
            //  // AutoSequence at = new AutoSequence();
            //  //FoamFeederProcess.LH_Feeder_Health_State = false;
            //  //FoamFeederProcess.RH_Feeder_Health_State = true;
            //  AutoSequence.FF_Start_operation = true;
            //  GlobalVar.Nozzle_Z_Homeposs = AutoSequence.Nozzle_UP_After_Foam_Pick;
            //  GlobalVar.Shift = "A";
            //  AutoSequence.tot_cavt_num = 52;
            //  //AutoSequence.Cavity_number=AutoSequence.Process_Curr_comp_no;

            //  start_Thread_Foam_Read_Sensor();
            StopActive.Visible = false;
            StopNonactive.Visible = true;

            PauseActive.Visible = false;
            PauseNonActive.Visible = true;

            RunActive.Visible = true;
            RunNonActive.Visible = false;

            PLC.connect_plc();
            PLC.start_Thread_PLC_IO();
            //cmd priya
            //SocketClient.Connect_Robo();
            //SocketClient.Connect_Vision();
            //SocketClient.Connect_Scnr();

            Form ModeSelection = new ModeSelection();
            ModeSelection.TopMost= true;
            ModeSelection.Show();
            PLC.WRITE_DO_TO_PLC(0, 0);
            //PLC.WRITE_DO_TO_PLC(Variables.Reset_light, 0);
            //PLC.WRITE_DO_TO_PLC(Variables.Start_ligt, 1);
            //PLC.WRITE_DO_TO_PLC(Variables.Intermediate_flowline_HSG_jacket_cyl_extend, 0);
            
            //PLC.WRITE_DO_TO_PLC(Variables.Intermediate_flowline_HSG_jacket_cyl_retracted, 1);
            Globalvariable.Battery_Place_Completed = true;

            //robo
            //PLC.WRITE_DO_TO_PLC(Variables.Program_selection_input_signal7_or_Denso_cmd_area2, 0);


            //Receipe obj = new Receipe();

            //obj.XY_Gantry_Save();
            //obj.XY_Gantry_DownloadData();

        }


        private void TimerCallback(Object o)
        {


        }
        public static void Nozzle_blowout()
        {

        }

        public static void Load_Q_for_conv()
        {
            //    bool process = false;
            //    process = Stepper.m_SCLLibHelper.WriteQueueLoadAndExecute(GlobalVar.Output_Conv_mot1_nodeid, 1);

            //    process = Stepper.m_SCLLibHelper.WriteQueueLoadAndExecute(GlobalVar.Output_Conv_mot2_nodeid, 1);
            //    process = Stepper.m_SCLLibHelper.WriteQueueLoadAndExecute(GlobalVar.process_Conv_mot1_nodeid, 1);

            //    process = Stepper.m_SCLLibHelper.WriteQueueLoadAndExecute(GlobalVar.process_Conv_mot2_nodeid, 1);
            //    process = Stepper.m_SCLLibHelper.WriteQueueLoadAndExecute(GlobalVar.Input_Conv_mot1_nodeid, 1);

            //    process = Stepper.m_SCLLibHelper.WriteQueueLoadAndExecute(GlobalVar.Input_Conv_mot2_nodeid, 1);
        }
        public static void Kill_Q_conv()
        {
            //    bool process = false;
            //    process = Stepper.m_SCLLibHelper.WriteQueueKill(GlobalVar.Output_Conv_mot1_nodeid);

            //    process = Stepper.m_SCLLibHelper.WriteQueueKill(GlobalVar.Output_Conv_mot2_nodeid);
            //    process = Stepper.m_SCLLibHelper.WriteQueueKill(GlobalVar.process_Conv_mot1_nodeid);

            //    process = Stepper.m_SCLLibHelper.WriteQueueKill(GlobalVar.process_Conv_mot2_nodeid);
            //    process = Stepper.m_SCLLibHelper.WriteQueueKill(GlobalVar.Input_Conv_mot1_nodeid);

            //    process = Stepper.m_SCLLibHelper.WriteQueueKill(GlobalVar.Input_Conv_mot2_nodeid);
        }
        public void Initialize_the_functions()
        {
            // ToRetain.Read_Device_Set();
            // Load_Devices();
            // AutoSequence.start_Thread_IO();

            // //box.Enabled = false;
            // progressBar1.Value = 0;                    
            // AutoSequence.Comp_odd_pos = true;
            // AutoSequence.autoStep = 0;
            // AlrmDesc_getdatafromSql();
            // Open_Datalog_EXE();
            // progressBar1.Value = 20;
            // ToRetain.Read_manual_sett();

            // progressBar1.Value = 40;
            // Initialiaze_reciepe_variables();
            // Load_Retained_Variables(); //--Angu
            // Auto_initialize();
            // progressBar1.Value = 60;
            // Rotory_Initialization();
            // //FoamFeederProcess.LH_Feeder_Active_State = true;
            // AutoSequence.Continous_cycle = true;
            // DIOConfig.WriteOPS(true, DIOConfig.O_WC_Conv_Mtr_Restart);
            // Thread.Sleep(2000);

            // ToRetain.Read_Project_path();
            // application_Onload = true;
            // DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Gn);
            // DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Rd);
            // DIOConfig.WriteOPS(true, DIOConfig.O_WC_TL_Ye);
            // ToRetain.Read_offset_Val();

            // Thread.Sleep(100);
            // //IO_Status();
            // if (DIOConfig.DI[DIOConfig.I_WC_Plt_Lift_Cyl_Up])
            // {
            //     DIOConfig.WriteOPS(true, DIOConfig.O_WC_Plt_Lift_Cyl_Up);
            //     DIOConfig.WriteOPS(false, DIOConfig.O_WC_Plt_Lift_Cyl_Dn);
            // }
            // else
            // {
            //     DIOConfig.WriteOPS(false, DIOConfig.O_WC_Plt_Lift_Cyl_Up);
            //     DIOConfig.WriteOPS(true, DIOConfig.O_WC_Plt_Lift_Cyl_Dn);

            // }
            // var lines22 = File.ReadAllLines(Environment.CurrentDirectory+ @"\RS485_Port.txt");
            // Stepper.Commport_485 = lines22[0].ToString();
            // Stepper.OpenPort();
            // Thread.Sleep(1500);
            // Load_Q_for_conv();
            // progressBar1.Value = 100;
            // progressBar1.Visible = false;
            // Interface.ResetAxisError(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
            //  Interface.ServoOn(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
            // //AxisConfig.Interpolation_Configuration();
            // string currentTime = DateTime.Now.ToString("HH:mm:ss");
            // if (currentTime == "00:00")
            // {
            //     AutoSequence.Tray_cnt = 1;
            //     AutoSequence.Cycle_Number = 1;
            //     ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg);
            // }
            // SqlParameter[] cmdmodel = {
            //         new SqlParameter("CURRENT_TIME", currentTime)};
            //// DataSet ds = AHDP.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_SHIFT_ID", cmdmodel);
            // //if (ds.Tables[0].Rows.Count > 0)
            // //{
            // //    AHDP.GlobalVar.Shift = ds.Tables[0].Rows[0]["shift_id"].ToString();
            // //    lblShift.Text = ds.Tables[0].Rows[0]["shift_id"].ToString();
            // //    GlobalVar.Shift = ds.Tables[0].Rows[0]["shift_id"].ToString();

            // //    Invoke(new MethodInvoker(delegate
            // //    {
            // //        lblShift.Text = ds.Tables[0].Rows[0]["shift_id"].ToString();
            // //        lblDatetime.Text = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");
            // //    }));

            // //}
            // ToRetain.Read_Ai_Slope();
            // GlobalVar.Machine_state_strt_dt = DateTime.Now;
            // GlobalVar.Machine_sts = true;
            // Get_Running_Tray_Cavity_Status();
            // //LoadQ();
        }
        public static DataTable Tray_Cavity = new DataTable();

        public static void Get_Running_Tray_Cavity_Status()
        {
            try
            {
                DataSet RDS = null;
                string get_query = "select tray_id, status, x_gap, y_gap, angle_gap, nozzle_num, place_datetime from running_tray_cavity_live_status";
                // RDS = AHDP.SQLHelper.GetData(get_query);
                if (RDS != null)
                {
                    if (RDS.Tables[0].Rows.Count > 0)
                    {
                        Tray_Cavity = RDS.Tables[0];
                    }
                }
            }
            catch (Exception es)
            {

            }

        }
        public static bool Cavity_Refresh = false;

        public static void Update_Tray_Cavity_Status_old(int Cavitynum, int Nozzlenum, int Status, double Xgap, Double Ygap, Double AngGap, string Placedt)
        {
            Cavity_Refresh = true;
            try
            {

                string filter = $"tray_id = 'lblCavity_{Cavitynum.ToString()}'";
                DataRow[] foundRows = Tray_Cavity.Select(filter); // Example condition: ID = 1

                // Check if the row exists
                if (foundRows.Length > 0)
                {
                    // Assuming there's only one row matching the condition (ID = 1)
                    DataRow rowToUpdate = foundRows[0];

                    // Modify values in the row
                    if (Nozzlenum > 0)
                    {
                        rowToUpdate["status"] = Status.ToString();
                        rowToUpdate["x_gap"] = Xgap.ToString();
                        rowToUpdate["y_gap"] = Ygap.ToString();
                        rowToUpdate["angle_gap"] = AngGap.ToString();
                        rowToUpdate["place_datetime"] = Placedt.ToString();
                        rowToUpdate["nozzle_num"] = Nozzlenum.ToString();
                    }
                    else
                    {
                        rowToUpdate["status"] = Status.ToString();
                        rowToUpdate["x_gap"] = Xgap.ToString();
                        rowToUpdate["y_gap"] = Ygap.ToString();
                        rowToUpdate["angle_gap"] = AngGap.ToString();
                    }


                    // Commit changes back to the DataTable
                    // If you're using a DataTable from a DataSet, you may not need this step,
                    // as changes might be automatically committed when using a DataAdapter.
                    // If you're using a standalone DataTable, you might need to update it explicitly.
                    // dataTable.AcceptChanges(); // Uncomment if needed

                    // Alternatively, if you want to keep track of changes for potential rollback:
                    rowToUpdate.AcceptChanges();
                }
                else
                {
                    // Handle the case where the row is not found

                }

            }
            catch (Exception es)
            {

            }
            Cavity_Refresh = false;
        }

        public static void Update_Tray_Cavity_Status(int Cavitynum, int Nozzlenum, int Status, double Xgap, Double Ygap, Double AngGap, string Placedt)
        {
            //Cavity_Refresh = true;
            //try
            //{
            //    Home.Cavity_update[Cavitynum] = Status.ToString();

            //    //string filter = $"tray_id = 'lblCavity_{Cavitynum.ToString()}'";
            //    //DataRow[] foundRows = Tray_Cavity.Select(filter); // Example condition: ID = 1

            //    //// Check if the row exists
            //    //if (foundRows.Length > 0)
            //    //{
            //    //    // Assuming there's only one row matching the condition (ID = 1)
            //    //    DataRow rowToUpdate = foundRows[0];

            //    //    // Modify values in the row
            //    //    if(Nozzlenum>0)
            //    //    {
            //    //        rowToUpdate["status"] = Status.ToString();
            //    //        rowToUpdate["x_gap"] = Xgap.ToString();
            //    //        rowToUpdate["y_gap"] = Ygap.ToString();
            //    //        rowToUpdate["angle_gap"] = AngGap.ToString();
            //    //        rowToUpdate["place_datetime"] = Placedt.ToString();
            //    //        rowToUpdate["nozzle_num"] = Nozzlenum.ToString();
            //    //    }
            //    //    else
            //    //    {
            //    //        rowToUpdate["status"] = Status.ToString();
            //    //        rowToUpdate["x_gap"] = Xgap.ToString();
            //    //        rowToUpdate["y_gap"] = Ygap.ToString();
            //    //        rowToUpdate["angle_gap"] = AngGap.ToString();
            //    //    }


            //    // Commit changes back to the DataTable
            //    // If you're using a DataTable from a DataSet, you may not need this step,
            //    // as changes might be automatically committed when using a DataAdapter.
            //    // If you're using a standalone DataTable, you might need to update it explicitly.
            //    // dataTable.AcceptChanges(); // Uncomment if needed

            //    // Alternatively, if you want to keep track of changes for potential rollback:
            ////    rowToUpdate.AcceptChanges();

            ////}
            ////}
            ////    else
            ////    {
            ////        // Handle the case where the row is not found

            ////    }

            //}
            //catch(Exception es)
            //{

            //}
            //Cavity_Refresh = false;
        }

        public static void start_Thread_Foam_Read_Sensor()
        {
           
        }
        static bool Foam_Sensor_read_th = false;
        public static bool Manual_On = false;

        public static void Dispose_Thread_Foam_sensor_read()
        {
            Foam_Presence_Sensor_read.Dispose();

        }
        public static void Stop_Thread_Foam_sensor_read()
        {
            try
            {
                Foam_Sensor_read_th = false;
                if (Foam_Presence_Sensor_read != null)
                {
                  //  Foam_Presence_Sensor_read.Change(Timeout.Infinite, Timeout.Infinite);

                    Dispose_Thread_Foam_sensor_read();

                    //Current_thread_running = false;
                    Task<bool> Log_task = Logger.WriteLog_1("Form1", "Stop_Thread_Foam_sensor_read()", "", "Success", "Thread Stops Successfully");
                }
            }
            catch (Exception es)
            {
                Task<bool> Log_task = Logger.WriteLog_1("Form1", "Stop_Thread_Foam_sensor_read()", "", "Exception Error", es.ToString());

            }
        }

        private void ControlConfig_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();
            }
            Form Manualscreen = new Manual_Screen();
            Panel_add(Manualscreen);
            // Replace YourNewForm with the actual form class name
            //Manualscreen.MdiParent = this; // Set the MDI parent to the current form
            //Manualscreen.Show();
            //if (previousform != null)
            //    previousform.Close();
            //previousform = Manualscreen;
        }

        private void DataReview_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();
            }

            Form reportForm = new MachineProductionReport();
            Panel_add(reportForm);
            // Replace YourNewForm with the actual form class name
            //reportForm.MdiParent = this; // Set the MDI parent to the current form
            //reportForm.Show();
            //if (previousform != null)
            //    previousform.Close();
            //previousform = reportForm;
        }
        //Mod0612
        private void Settings_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();
            }

            Form io_diagnosis = new io_diagnostics();
            Panel_add(io_diagnosis);
            //io_diagnosis.MdiParent = Form1.ActiveForm;
            //io_diagnosis.Show();
            //if (previousform != null)
            //    previousform.Close();
            //previousform = io_diagnosis;
        }

        private void Manual_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();
            }

            Form Receipe = new Receipe();
            Panel_add(Receipe);
            //Creates an Instance
            //Receipe.MdiParent = this;
            //Receipe.Show();
            //if (previousform != null)
            //    previousform.Close();
            //previousform = Receipe;
        }

        private void RunActive_Click(object sender, EventArgs e)
        {

            if (Globalvariable.Fault_reset)
            {

                //if (Globalvariable.XY_Homing_done && Globalvariable.Roller_Homing_done && Globalvariable.FI_Homing_done)
                //{
                    DialogResult result = MessageBox.Show("Do want start the auto process", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                    if (result == DialogResult.OK)
                    {
                        if(Globalvariable.Manual_Pause || Globalvariable.Manual_Stop)
                        {
                            Globalvariable.Fault_reset = true;
                            Globalvariable.Manual_Pause = false;
                            Globalvariable.Manual_Stop = false;
                        }
                        else
                        {
                            Globalvariable.Fault_reset = false;
                        }
                        

                        Globalvariable.Alarm_Pause = false;
                        Globalvariable.Alarm_Stop = false;
                        StopActive.Visible = true;
                        StopNonactive.Visible = false;

                        PauseActive.Visible = true;
                        PauseNonActive.Visible = false;

                        RunActive.Visible = true;
                        RunNonActive.Visible = false;

                    //XY_Gantry.start_Thread_XY_Gantry_prcss();
                    //PeelOffSticker.start_Thread_Peel_off_prcss();
                    //Roller.start_Thread_Roller_prcss();
                    //FinalInspection.start_Thread_FI_prcss();
                    //Streamline2.start_Thread_Streamline2_prcss();
                    //Streamline2.start_Thread_Streamline2_prcss();
                    //if (Globalvariable.Manual_Pause || Globalvariable.Manual_Stop)
                    //{
                    //PLC.WRITE_DO_TO_PLC(Variables.Streamline_1_High_speed, 0);
                    //PLC.WRITE_DO_TO_PLC(Variables.Streamline_2_High_speed, 0);
                    //PLC.WRITE_DO_TO_PLC(Variables.Streamline_3_High_speed, 0);

                    //PLC.WRITE_DO_TO_PLC(Variables.Program_selection_input_signal7_or_Denso_cmd_area2, 1);
                    //PLC.WRITE_DO_TO_PLC(Variables.Operation_right_input3_or_Denso_data_area1, 1);
                    //PLC.WRITE_DO_TO_PLC(Variables.Start_input2_or_Denso_data_area0, 0);
                    //PLC.WRITE_DO_TO_PLC(Variables.Stop_input0_or_Denso_step_stop, 1);
                    //PLC.WRITE_DO_TO_PLC(Variables.Program_reset_input1, 1);
                    //PLC.WRITE_DO_TO_PLC(Variables.Stop_input0_or_Denso_step_stop, 0);
                    //PLC.WRITE_DO_TO_PLC(Variables.Program_reset_input1, 0);
                    //PLC.WRITE_DO_TO_PLC(Variables.Start_input2_or_Denso_data_area0, 1);

                    //PLC.WRITE_DO_TO_PLC(Variables.Three_color_green_light, 1);
                    //PLC.WRITE_DO_TO_PLC(Variables.Three_color_red_light, 0);
                    //PLC.WRITE_DO_TO_PLC(Variables.Three_color_yellow_light, 0);
                    //PLC.WRITE_DO_TO_PLC(Variables.Reset_light, 0);
                    //Streamline1.start_Thread_Streamline1_prcss();
                  
                   // XY_Gantry.start_Thread_XY_Gantry_prcss();
                    //}

                }


                    else
                    {


                        if (result == DialogResult.OK)
                        {
                            Globalvariable.XY_Gantry_Homing_stepcount = 1;
                            Globalvariable.Roller_Homing_stepcount = 1;
                            Globalvariable.FI_Homing_stepcount = 1;
                            Globalvariable.XY_gantry_Homing();
                            Globalvariable.Roller_Homing();
                            Globalvariable.FI_Homing();
                            Globalvariable.Homing_done = false;
                            Globalvariable.Homing_check();
                        }
                        else if (result == DialogResult.Cancel)
                        {

                            MessageBox.Show("Homing Process Cancelled !");
                        }
                    }
                //}
            }
            else
            {
                DialogResult result = MessageBox.Show("Reset Fault Not Done!", "Confirmation", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        
        
        

        }

        private void PauseActive_Click(object sender, EventArgs e)
        {
            Globalvariable.Manual_Pause=true;
            StopActive.Visible = true ;
            StopNonactive.Visible = false;

            PauseActive.Visible = false ;
            PauseNonActive.Visible = true; 

            RunActive.Visible = true ;
            RunNonActive.Visible = false ;

        }

        private void StopActive_Click(object sender, EventArgs e)
        {


           // PLC.WRITE_DO_TO_PLC(Variables.Stop_input0_or_Denso_step_stop, 1);
            //Streamline1.Streamline_1_prcss_Stop();
         
            //XY_Gantry.XY_Gantry_prcss_Stop();

            //Interface.Kill_All_Motions();
            Globalvariable.Manual_Stop = true;
            StopActive.Visible = false;
            StopNonactive.Visible = true;

            PauseActive.Visible = false;
            PauseNonActive.Visible = true;

            RunActive.Visible = true;
            RunNonActive.Visible = false;


            //////AutoSequence.autoProcess = false;
        }
        //bool timer1_lock = false;
        //public void timer1_Tick(object sender, EventArgs e)
        //{
        //    if (!timer1_lock)
        //    {
        //        timer1_lock = true;
        //        try
        //        {

        //            textBox1.Text = DateTime.Now.ToString();
        //            string connectionString = SQLHelper.get_ConnName();
        //            using (SqlConnection conn = new SqlConnection(connectionString))
        //            {
        //                using (SqlCommand cmd = new SqlCommand("SP_Shift", conn))
        //                {
        //                    cmd.CommandType = CommandType.StoredProcedure;
        //                    conn.Open();
        //                    var result = cmd.ExecuteScalar();
        //                    if (result != null)
        //                    {
        //                        labelshift.Text = result.ToString();
        //                    }
        //                    else
        //                    {
        //                        labelshift.Text = "No result";
        //                    }
        //                }
        //            }

        //            if (Globalvariable.Alarm_Pause)
        //            {
        //                StopActive.Visible = true;
        //                StopNonactive.Visible = false;

        //                PauseActive.Visible = false;
        //                PauseNonActive.Visible = true;

        //                RunActive.Visible = true;
        //                RunNonActive.Visible = false;
        //                Globalvariable.Fault_reset = false;
        //            }

        //            if (Globalvariable.Alarm_Stop)
        //            {
        //                StopActive.Visible = false;
        //                StopNonactive.Visible = true;

        //                PauseActive.Visible = false;
        //                PauseNonActive.Visible = true;

        //                RunActive.Visible = true;
        //                RunNonActive.Visible = false;
        //                Globalvariable.Fault_reset = false;
        //            }
        //            if (Globalvariable.MC_Read_DI[Variables.Reset_button])
        //            {
        //                Globalvariable.Fault_reset = true;
        //            }

        //        }
        //        catch (Exception es)
        //        {
        //            timer1_lock = false;
        //            Logger.WriteLog("Form1", "timer1_Tick", "timer1_Tick", "Error", es.ToString());
        //        }
        //    }
        //    timer1_lock = false;
        //}

        private void Login_Click(object sender, EventArgs e)
        {
            Form ModeSelection = new ModeSelection();
            ModeSelection.ShowDialog();
            //Stepper.OpenPort();
        }

        private void button11_Click(object sender, EventArgs e)
        {


        }
        private void simpleButton11_Click(object sender, EventArgs e)
        {

        }
        private void button11_Click_1(object sender, EventArgs e)
        {

        }
        private void btnResetAuto_Click(object sender, EventArgs e)
        {
            //////AutoSequence.Curr_comp_no = 1;
            //////AutoSequence.Process_Curr_comp_no = 1;
            ////////AutoSequence.Auto_Status = 2;
        }


        private void circularButton1_Click(object sender, EventArgs e)
        {

        }

        private void labelControl1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //NoError.Visible = false;
            ErrorActiveButton.Visible = true;
            Form AlarmScreen = new AlarmScreen();
            AlarmScreen.Show();
            // Form AlarmPopUp = new AlarmPopUp();
            // AlarmPopUp.ShowDialog();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            ErrorActiveButton.Visible = false;
            //NoError.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Close the Application?", "Confirmation Box", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dialogResult == DialogResult.Yes)
                {

                    //LeadShineInterface.close_board();
                    // GlobalVar.Reset_Alarm();
                    LeadShineInterface.close_board();
                    PLC.serialPort1.Close();
                    Environment.Exit(0);
                }
                else if (dialogResult == DialogResult.No)
                {

                    //do something else
                   // MessageBox.Show("Form Didn't Close Properly");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Form1--Error in this function:button1_Click()" + ex);
            }
        }

        //Added//
        public void Active_btn_dis_or_en()
        {

            if (Login_valditation)
            {
                if (Globalvariable.Login_user_mode.ToUpper() == "PRODUCTION")
                {
                    Login_valditation = false;
                    enablehomeicons();
                    UserType.Text = "Production";
                    // RunMode.Text = "PRODUCTION";
                    //UserType.Text = Login_user_mode + " User";
                    //RunMode.Text = GlobalVar.User_Mode +" Mode";
                    //curssor_activity.Resetlastactivity();



                }
                else
                {


                    Login_valditation = false;
                    enablehomeicons_engineering();
                    UserType.Text = "Engineering";
                    // RunMode.Text = "Engineering";
                    //UserType.Text = Login_user_mode + " User";
                    //RunMode.Text = GlobalVar.User_Mode + " Mode";
                    isengineeringmode = true;
                    //curssor_activity.Resetlastactivity();
                    lastEngineeringactivity = DateTime.Now;

                }
            }
            //if (Login_user_mode.ToUpper() != "PRODUCTION")
            //{

            //    if (((DateTime.Now - lastEngineeringactivity).TotalMilliseconds >= idle_time_threshold) && Login_user_mode.ToUpper() != "PRODUCTION")
            //    {
            //        if (Login_user_mode.ToUpper() != "PRODUCTION")
            //        {
            //            Login_user_mode = "PRODUCTION";
            //            Login_valditation = true;

            //            if (ActiveMdiChild.Text != "calibration_settings" && ActiveMdiChild.Text != "sop_sequence" && ActiveMdiChild.Text != "io_diagnostics")
            //            {
            //                if (ActiveMdiChild != null)
            //                {
            //                    ActiveMdiChild.Close();
            //                }
            //                Form Home = new Home();
            //                Home.MdiParent = this;
            //                Home.Show();
            //            }

            //        }
            //    }
            //}
            if (Process_Start && !Process_Pause && !Process_Stop)
            {
                ////if (!DIOConfig.DO[DIOConfig.O_WC_TL_Gn])
                ////{
                ////    DIOConfig.WriteOPS(true, DIOConfig.O_WC_TL_Gn);
                ////    DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Rd);
                ////    DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Ye);
                ////}
            }

            if (Process_Pause)
            {
                RunActive.Visible = false;
                RunNonActive.Visible = true;
                PauseActive.Visible = true;
                StopActive.Visible = false;
                StopNonactive.Visible = true;
                //if (!DIOConfig.DO[DIOConfig.O_WC_TL_Ye] && !Process_Stop)
                //{
                //    DIOConfig.WriteOPS(false,DIOConfig.O_WC_TL_Gn);
                //    DIOConfig.WriteOPS(false,DIOConfig.O_WC_TL_Rd);
                //    DIOConfig.WriteOPS(true,DIOConfig.O_WC_TL_Ye);
                //}
                // Interface.Kill_All_Motions_Gantry();
            }
            else if (Process_Stop)
            {
                //RunActive.Visible = false;
                //PauseActive.Visible = false;
                //StopActive.Visible = true;
                //////if (!DIOConfig.DO[DIOConfig.O_WC_TL_Rd])
                //////{
                //////    DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Gn);
                //////    DIOConfig.WriteOPS(true, DIOConfig.O_WC_TL_Rd);
                //////    DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Ye);
                //////}
                //Interface.Kill_All_Motions_Gantry();
            }
            //////else if(AutoSequence.Auto_Status==1)
            //////{
            //////    if (!DIOConfig.DO[DIOConfig.O_WC_TL_Gn])
            //////    {
            //////        DIOConfig.WriteOPS(true, DIOConfig.O_WC_TL_Gn);
            //////        DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Rd);
            //////        DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Ye);
            //////    }
            //////}
            ////// if(((GlobalVar.Error_code >1 || GlobalVar.ExceptionError>1|| Alarmbit)) && ( DIOConfig.DI[DIOConfig.I_WC_Estop_PB_FB] || DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]))
            //////{
            //////   //Alarmbit = false;
            //////   //if (ActiveMdiChild != null)
            //////   //{
            //////   //    ActiveMdiChild.Close();o
            //////   //}
            //////   //Auto_process_stop= true;
            //////   Process_Pause = true;
            //////   Process_Stop = false;
            //////   RunActive.Visible = false;
            //////   RunNonActive.Visible = true;
            //////   StopActive.Visible = false;
            //////   StopNonactive.Visible = true;
            //////   PauseActive.Visible = true;
            //////   PauseNonActive.Visible =false ;
            //////   ErrorActiveButton.Visible = true;
            //////   NoError.Visible = false;
            //////   //Form form_alarmscreen = new AlarmLiveScreen();
            //////   //form_alarmscreen.MdiParent = this;
            //////   //form_alarmscreen.Show();
            //////}
            //////// else if (DIOConfig.DI[DIOConfig.I_WC_Estop_PB_FB] || !DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB])
            //////// {
            ////////    Process_Pause = false;
            ////////    Process_Stop = true;
            ////////    RunActive.Visible = false;
            ////////    RunNonActive.Visible = true;
            ////////    StopActive.Visible = true;
            ////////    StopNonactive.Visible = false;
            ////////    PauseActive.Visible = false;
            ////////    PauseNonActive.Visible = true;
            ////////    ErrorActiveButton.Visible = true;
            ////////    NoError.Visible = false;
            ////////}

            //else
            //{
            //    ErrorActiveButton.Visible = true;
            //    //NoError.Visible = true;
            //}


        }
   
        public void enablehomeicons()
        {
            try
            {
                btnHome.Enabled = true;
                //NoError.Enabled = true;
                ControlConfig.Enabled = false;
                DataReview.Enabled = false;
                //CameraVision.Enabled = false;
                Settings.Enabled = false;
                Manual.Enabled = true;
                RunNonActive.Enabled = false;
                RunActive.Enabled = true;
                PauseNonActive.Enabled = false;
                PauseActive.Enabled = true;
                StopActive.Enabled = true;
                StopNonactive.Enabled = false;
                //NoError.Enabled = true;
                //if (Globalvariable.error_active)
                //{
                //    NoError.Enabled = false;
                //    ErrorActiveButton.Enabled = true;
                //}
                //else
                //{
                //    NoError.Enabled = true;
                //    ErrorActiveButton.Enabled = false;
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show("Form1--Error in this function:enablehomeicons()" + ex);
            }

        }

        public void enablehomeicons_engineering()
        {
            try
            {

                btnHome.Enabled = true;
                // Double time coming NoError.Enabled = false;
                ControlConfig.Enabled = true;
                //NoError.Enabled = true;
                ErrorActiveButton.Enabled = true;
                DataReview.Enabled = true;
                //CameraVision.Enabled = true;
                Settings.Enabled = true;
                Manual.Enabled = true;
                RunActive.Enabled = true;
                RunNonActive.Enabled = false;
                PauseActive.Enabled = true;
                PauseNonActive.Enabled = false;
                StopActive.Enabled = true;
                StopNonactive.Enabled = false;
                // NoError.Enabled = true;
                //if (Globalvariable.error_active)
                //{
                //    NoError.Enabled = false;
                //    ErrorActiveButton.Enabled = true;
                //}
                //else
                //{
                //    NoError.Enabled = true;
                //    ErrorActiveButton.Enabled = false;
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show("Form1--Error in this function:enablehomeicons_engineering()" + ex);
            }

        }
        public void disablehomeicons()
        {
            try
            {


                btnHome.Enabled = false;
                //NoError.Enabled = false;
                ControlConfig.Enabled = false;
                DataReview.Enabled = false;
                //CameraVision.Enabled = false;
                Settings.Enabled = false;
                Manual.Enabled = false;
                RunActive.Enabled = false;
                RunNonActive.Enabled = false;
                PauseActive.Enabled = false;
                PauseNonActive.Enabled = false;
                StopActive.Enabled = false;
                StopNonactive.Enabled = false;
                ErrorActiveButton.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Form1--Error in this function:disablehomeicons()" + ex);
            }
        }

        private void menubuttonshow()
        {
            box = new GroupBox();

            ElipseControl nn = new ElipseControl();
            ElipseControl mm = new ElipseControl();
            ElipseControl oo = new ElipseControl();
            ElipseControl pp = new ElipseControl();

            nn.TargetControl = btnHome;
            nn.CornerRadius = 10;
            box.Controls.Add(btnHome);
            box.AutoSize = true;

            //nn.TargetControl = NoError;
            //nn.CornerRadius = 10;
            //box.Controls.Add(NoError);

            nn.TargetControl = ErrorActiveButton;
            nn.CornerRadius = 10;
            box.Controls.Add(ErrorActiveButton);

            nn.TargetControl = ControlConfig;
            nn.CornerRadius = 10;
            box.Controls.Add(ControlConfig);

            nn.TargetControl = DataReview;
            nn.CornerRadius = 10;
            box.Controls.Add(DataReview);

            //nn.TargetControl = CameraVision;
            nn.CornerRadius = 10;
            //box.Controls.Add(CameraVision);

            nn.TargetControl = Settings;
            nn.CornerRadius = 10;
            box.Controls.Add(Settings);

            nn.TargetControl = Manual;
            nn.CornerRadius = 10;
            box.Controls.Add(Manual);


            nn.TargetControl = RunActive;
            nn.CornerRadius = 10;
            box.Controls.Add(RunActive);

            nn.TargetControl = RunNonActive;
            nn.CornerRadius = 10;
            box.Controls.Add(RunNonActive);

            nn.TargetControl = PauseActive;
            nn.CornerRadius = 10;
            box.Controls.Add(PauseActive);

            nn.TargetControl = PauseNonActive;
            nn.CornerRadius = 10;
            box.Controls.Add(PauseNonActive);

            nn.TargetControl = StopActive;
            nn.CornerRadius = 10;
            box.Controls.Add(StopActive);

            nn.TargetControl = StopNonactive;
            nn.CornerRadius = 10;
            box.Controls.Add(StopNonactive);

            nn.TargetControl = Login;
            nn.CornerRadius = 10;
            box.Controls.Add(Login);

            //nn.TargetControl = usericon;
            //box.Controls.Add(usericon);

            nn.TargetControl = UserType;
            box.Controls.Add(UserType);

            //nn.TargetControl = RunMode;
            //box.Controls.Add(RunMode);

            this.Controls.Add(box);

            box.Enabled = true;
        }

         //Newly declared  //Recipe Calling Functions
        private async void LoadRecipeDataAsync()
        {
            try
            {
                await recipe.LoadDataInGrid();
                await recipe.LoadDataInRoller();
                await recipe.LoadDataInFI();
                //recipe.XY_Gantry_DownloadData();
               // recipe.XYZ_Roller_DownloadData();
                //recipe.XY_FI_DownloadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Form1--Error in this function:LoadRecipeDataAsync()"+ex);
            }
            
        }
        //Newly declared
        private void Form1_OnMouseMove(MouseEventArgs obj)
        {
            throw new NotImplementedException();
        }
        public void Open_Datalog_EXE()
        {
            Process[] processName = Process.GetProcessesByName("Datalog");
            if (processName.Length > 0)
            {
                foreach (var process in processName)
                {
                    process.Kill();
                }
            }

            //Process.Start(@"D:\TEAL\NOVA\EXE\Datalog\bin\Debug\Datalog.Exe");


        }
        public static bool Rotory_Initialization_trig = false;
        public static bool Rotory_Initialization_trig_load = false;
        int Rotary_time_cnt = 0;
        public void Rotory_Initialization()
        {
            Tmr_Status.Enabled = true;
            //Rotory_Initialization_trig = true;
            //Rotory_Initialization_trig_load = true;



        }
        public void Rotory_inital_homing()
        {
            //// DIOConfig.DI = Interface.DI_RefreshValue();
            // Rotary_time_cnt += 1;
            // if (DIOConfig.DI[DIOConfig.I_Rotary_hme1])
            // {
            //     Interface.Stop(GlobalVar.Nozzle_Ang_nodeid[1]);
            //     //Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[1]);
            //     //  Interface.Set_Ref_Pos_Ang_N1(GlobalVar.Nozzle_Ang_nodeid[1]);
            // }
            // else
            // {
            //    // Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[1]);
            //     bool process = Nozzle.Rotate_Nozzle_hme(GlobalVar.Nozzle_Ang_nodeid[1], 300);
            // }
            // if (DIOConfig.DI[DIOConfig.I_Rotary_hme2])
            // {

            //     Interface.Stop(GlobalVar.Nozzle_Ang_nodeid[2]);
            //   //  Interface.Set_Ref_Pos_Ang(GlobalVar.Nozzle_Ang_nodeid[2], GlobalVar.Nozzle_Ang_nodeid,GlobalVar.Nozzle_Ref);
            // }
            // else
            // {
            //   //  Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[2]);
            //    // bool process = Nozzle.Rotate_Nozzle_hme(GlobalVar.Nozzle_Ang_nodeid[2], 300);
            // }
            // if (DIOConfig.DI[DIOConfig.I_Rotary_hme3])
            // {
            //     Interface.Stop(GlobalVar.Nozzle_Ang_nodeid[3]);
            //    // Interface.Set_Ref_Pos_Ang(GlobalVar.Nozzle_Ang_nodeid[3], GlobalVar.Nozzle_Ang_nodeid, GlobalVar.Nozzle_Ref);
            // }
            // else
            // {
            //    // Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[3]);
            //    // bool process = Nozzle.Rotate_Nozzle_hme(GlobalVar.Nozzle_Ang_nodeid[3], 300);
            // }
            // if (DIOConfig.DI[DIOConfig.I_Rotary_hme4])
            // {
            //     Interface.Stop(GlobalVar.Nozzle_Ang_nodeid[4]);
            //   //  Interface.Set_Ref_Pos_Ang(GlobalVar.Nozzle_Ang_nodeid[4], GlobalVar.Nozzle_Ang_nodeid, GlobalVar.Nozzle_Ref);
            // }
            // else
            // {
            //    // Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[4]);
            //    // bool process = Nozzle.Rotate_Nozzle_hme(GlobalVar.Nozzle_Ang_nodeid[4], 300);
            // }

            // if (DIOConfig.DI[DIOConfig.I_Rotary_hme1] && DIOConfig.DI[DIOConfig.I_Rotary_hme2] && DIOConfig.DI[DIOConfig.I_Rotary_hme3] && DIOConfig.DI[DIOConfig.I_Rotary_hme4])
            // {
            //     Rotory_Initialization_trig = false;
            //     application_Start = true;
            //     Rotary_time_cnt = 0;
            //     Onload_rotoryinit = false;
            //    // Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[1]);
            //    // Interface.Set_Ref_Pos_Ang(GlobalVar.Nozzle_Ang_nodeid[2],GlobalVar.Nozzle_Z_Axis,GlobalVar.Nozzle_Ref);
            //     //Interface.Set_Ref_Pos_Ang(GlobalVar.Nozzle_Ang_nodeid[3], GlobalVar.Nozzle_Z_Axis, GlobalVar.Nozzle_Ref);
            //     //Interface.Set_Ref_Pos_Ang(GlobalVar.Nozzle_Ang_nodeid[4], GlobalVar.Nozzle_Z_Axis, GlobalVar.Nozzle_Ref);
            //     //if (!Rotory_Initialization_trig)
            //     //{
            //     //    box.Enabled = true;
            //     //}
            //     //else
            //     //{
            //     //    box.Enabled = false;
            //     //}
            // }
            // else
            // {
            //     if(Rotary_time_cnt>3000)
            //     {
            //         //GlobalVar.Nozzle_Ang__Max_Deg_Error = 1;
            //     }
            // }
        }
        public static void Auto_initialize()
        {

            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Inp_Buff_Motor1_2_Strt_Stop_ON);
            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Cnvy_Motor1_2_Strt_Stop_ON);
            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Outp_Buff_Motor1_2_Strt_Stop_ON);


        }
        public void load_SQL_Datas()
        {
            //    SQLHelper helper = new SQLHelper();
            //  //  GlobalVar glblvar = new GlobalVar();
            //    AutoSequence Autoseq = new AutoSequence();

            //    AlrmDesc_getdatafromSql();
        }

        public void AlrmDesc_getdatafromSql()
        {
            //DataSet ds1 = SQLHelper.GetDataset(CommandType.StoredProcedure, "sp_Get_Alrm_Desc_Details");
            //if (ds1.Tables[0].Rows.Count > 0)
            //{
            //    GlobalVar.AlrmDescdt = ds1.Tables[0];
            //}
        }
        //public void LoadQ()
        //{
        //    bool process = false;
        //    //    process = Stepper.m_SCLLibHelper.WriteQueueLoadAndExecute(1, 1);
        //    //    if (process)
        //    //        process = Stepper.m_SCLLibHelper.WriteQueueLoadAndExecute(2, 1);

        //}
        public void Load_Devices()
        {

            //Device_Initialization Device_Initialize = new Device_Initialization();
            //DIOConfig.WriteOPS(false, 0);
            // Thread.Sleep(500);
            Thread.Sleep(2000);


        }
        public void Load_Retained_Variables()
        {
            // ToRetain.Read_Retain_Variables();


        }
        public void Initialiaze_reciepe_variables()
        {
            try
            {
                #region "Pick"
                string ModelName = File.ReadAllText(Environment.CurrentDirectory + @"\RunningModel.txt");
                string SqlQuery = "Exec Sp_Recipe_Parameter_selection_Pick @Modelid = '" + ModelName.Trim() + "', @Category = 'Pick'";

                // DataSet DS = AHDP.SQLHelper.GetData(SqlQuery);
                //if (DS.Tables[0].Rows.Count > 0)
                //{
                //    ///Pick
                //    AutoSequence.Gantry_X_to_LH_Feeder_pos = Convert.ToDouble(DS.Tables[0].Rows[0]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_to_LH_Feeder_pos = Convert.ToDouble(DS.Tables[0].Rows[1]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_LH_Feeder_Pos_b_CCD1 = Convert.ToDouble(DS.Tables[0].Rows[2]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_LH_Feeder_Pos_b_CCD1 = Convert.ToDouble(DS.Tables[0].Rows[3]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_to_RH_Feeder_pos = Convert.ToDouble(DS.Tables[0].Rows[4]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_to_RH_Feeder_pos = Convert.ToDouble(DS.Tables[0].Rows[5]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_RH_Feeder_Pos_b_CCD1 = Convert.ToDouble(DS.Tables[0].Rows[6]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_RH_Feeder_Pos_b_CCD1 = Convert.ToDouble(DS.Tables[0].Rows[7]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Feeder_vel = Convert.ToDouble(DS.Tables[0].Rows[8]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Foam1_vel = Convert.ToDouble(DS.Tables[0].Rows[9]["VALUE"].ToString());
                //    AutoSequence.Vaccum_Stabilizing_Time = Convert.ToInt32(DS.Tables[0].Rows[10]["VALUE"].ToString());
                //    AutoSequence.Nozzle_UP_After_Foam_Pick[1] = Convert.ToDouble(DS.Tables[0].Rows[11]["VALUE"].ToString());
                //    AutoSequence.Nozzle_UP_After_Foam_Pick[2] = Convert.ToDouble(DS.Tables[0].Rows[12]["VALUE"].ToString());
                //    AutoSequence.Nozzle_UP_After_Foam_Pick[3] = Convert.ToDouble(DS.Tables[0].Rows[13]["VALUE"].ToString());
                //    AutoSequence.Nozzle_UP_After_Foam_Pick[4] = Convert.ToDouble(DS.Tables[0].Rows[14]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_vel = Convert.ToDouble(DS.Tables[0].Rows[15]["VALUE"].ToString());
                //    AutoSequence.Foam_Feeder_Peeling_Vel = Convert.ToDouble(DS.Tables[0].Rows[16]["VALUE"].ToString());
                //    AutoSequence.Gantry_Arc_Cowl_Int_vel = Convert.ToDouble(DS.Tables[0].Rows[17]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_CCD2_N1_Start_pos = Convert.ToDouble(DS.Tables[0].Rows[18]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_CCD2_N4_End_pos = Convert.ToDouble(DS.Tables[0].Rows[19]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_CCD2_pos = Convert.ToDouble(DS.Tables[0].Rows[20]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_vel_Int_Mov = Convert.ToDouble(DS.Tables[0].Rows[21]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_PickVel = Convert.ToDouble(DS.Tables[0].Rows[22]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Foam_LH[1] = Convert.ToDouble(DS.Tables[0].Rows[23]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Foam_LH[2] = Convert.ToDouble(DS.Tables[0].Rows[24]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Foam_LH[3] = Convert.ToDouble(DS.Tables[0].Rows[25]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Foam_LH[4] = Convert.ToDouble(DS.Tables[0].Rows[26]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Foam_RH[1] = Convert.ToDouble(DS.Tables[0].Rows[27]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Foam_RH[2] = Convert.ToDouble(DS.Tables[0].Rows[28]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Foam_RH[3] = Convert.ToDouble(DS.Tables[0].Rows[29]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Foam_RH[4] = Convert.ToDouble(DS.Tables[0].Rows[30]["VALUE"].ToString());
                //    AutoSequence.Gantry_Ejection_X_LH = Convert.ToDouble(DS.Tables[0].Rows[31]["VALUE"].ToString());
                //    AutoSequence.Gantry_Ejection_Y_LH = Convert.ToDouble(DS.Tables[0].Rows[32]["VALUE"].ToString());
                //    AutoSequence.Gantry_Ejection_X_RH = Convert.ToDouble(DS.Tables[0].Rows[33]["VALUE"].ToString());
                //    AutoSequence.Gantry_Ejection_Y_RH = Convert.ToDouble(DS.Tables[0].Rows[34]["VALUE"].ToString());

                //    AutoSequence.Gantry_to_foambed_Acc = Convert.ToDouble(DS.Tables[0].Rows[35]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_foambed_DAcc = Convert.ToDouble(DS.Tables[0].Rows[36]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_Acc = Convert.ToDouble(DS.Tables[0].Rows[37]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_DAcc = Convert.ToDouble(DS.Tables[0].Rows[38]["VALUE"].ToString());


                //    AutoSequence.Gantry_to_Feeder_Vel_X = Convert.ToDouble(DS.Tables[0].Rows[39]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Feeder_Vel_Y = Convert.ToDouble(DS.Tables[0].Rows[40]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Foam1_Vel_X = Convert.ToDouble(DS.Tables[0].Rows[41]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Foam1_Vel_Y = Convert.ToDouble(DS.Tables[0].Rows[42]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_Vel_X = Convert.ToDouble(DS.Tables[0].Rows[43]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_Vel_Y = Convert.ToDouble(DS.Tables[0].Rows[44]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_int_Vel_X = Convert.ToDouble(DS.Tables[0].Rows[45]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_int_Vel_Y = Convert.ToDouble(DS.Tables[0].Rows[46]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Feeder_X_Acc = Convert.ToDouble(DS.Tables[0].Rows[47]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Feeder_X_DAcc = Convert.ToDouble(DS.Tables[0].Rows[48]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Feeder_Y_Acc = Convert.ToDouble(DS.Tables[0].Rows[49]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Feeder_Y_DAcc = Convert.ToDouble(DS.Tables[0].Rows[50]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_X_Acc = Convert.ToDouble(DS.Tables[0].Rows[51]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_X_DAcc = Convert.ToDouble(DS.Tables[0].Rows[52]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_Y_Acc = Convert.ToDouble(DS.Tables[0].Rows[53]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_CCD2_Y_DAcc = Convert.ToDouble(DS.Tables[0].Rows[54]["VALUE"].ToString());
                //    ///////////

                //}
                #endregion
                #region "Place"
                ModelName = File.ReadAllText(Environment.CurrentDirectory + @"\RunningModel.txt");
                SqlQuery = "Exec Sp_Recipe_Parameter_selection_Pick @Modelid = '" + ModelName.Trim() + "', @Category = 'Place'";

                // DS = AHDP.SQLHelper.GetData(SqlQuery);
                //if (DS.Tables[0].Rows.Count > 0)
                //{
                //    ///Place
                //    AutoSequence.Gantry_X_to_Rej_pos = Convert.ToDouble(DS.Tables[0].Rows[0]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_to_Rej_pos = Convert.ToDouble(DS.Tables[0].Rows[1]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Rej_vel = Convert.ToDouble(DS.Tables[0].Rows[2]["VALUE"].ToString());
                //    AutoSequence.Total_No_of_Comp_in_row = Convert.ToInt32(DS.Tables[0].Rows[3]["VALUE"].ToString());
                //    AutoSequence.Total_No_of_Comp_in_col = Convert.ToInt32(DS.Tables[0].Rows[4]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_to_Arccowling_start_pos = Convert.ToDouble(DS.Tables[0].Rows[5]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_to_Arccowling_start_pos = Convert.ToDouble(DS.Tables[0].Rows[6]["VALUE"].ToString());
                //    AutoSequence.Arc_Cowling_Horizontal_Gap = Convert.ToDouble(DS.Tables[0].Rows[7]["VALUE"].ToString());
                //    AutoSequence.Arc_Cowling_Vertical_Gap = Convert.ToDouble(DS.Tables[0].Rows[8]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_ArcCowling_Placing_pos = Convert.ToDouble(DS.Tables[0].Rows[9]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_ArcCowling_Placing_pos = Convert.ToDouble(DS.Tables[0].Rows[10]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Arc_1[1] = Convert.ToDouble(DS.Tables[0].Rows[11]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Arc_1[2] = Convert.ToDouble(DS.Tables[0].Rows[12]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Arc_1[3] = Convert.ToDouble(DS.Tables[0].Rows[13]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Z_to_Arc_1[4] = Convert.ToDouble(DS.Tables[0].Rows[14]["VALUE"].ToString());
                //    AutoSequence.Nozzle_placing_speed = Convert.ToDouble(DS.Tables[0].Rows[15]["VALUE"].ToString());
                //    AutoSequence.CCD1_Frst_Placing_Vel = Convert.ToDouble(DS.Tables[0].Rows[16]["VALUE"].ToString());

                //    AutoSequence.Gantry_to_Rej_Acc = Convert.ToDouble(DS.Tables[0].Rows[17]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Rej_DAcc = Convert.ToDouble(DS.Tables[0].Rows[18]["VALUE"].ToString());
                //    AutoSequence.Gantry_Arc_Cowl_Int_Acc = Convert.ToDouble(DS.Tables[0].Rows[19]["VALUE"].ToString());
                //    AutoSequence.Gantry_Arc_Cowl_Int_DAcc = Convert.ToDouble(DS.Tables[0].Rows[20]["VALUE"].ToString());
                //    AutoSequence.CCD2_CCD1_Gantry_Frst_Placing_Acc = Convert.ToDouble(DS.Tables[0].Rows[21]["VALUE"].ToString());
                //    AutoSequence.CCD2_CCD1_Gantry_Frst_Placing_DAcc = Convert.ToDouble(DS.Tables[0].Rows[22]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_ArcCowling_Placing_pos_End = Convert.ToDouble(DS.Tables[0].Rows[23]["VALUE"].ToString());


                //    AutoSequence.Gantry_to_Rej_Vel_X = Convert.ToDouble(DS.Tables[0].Rows[24]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Rej_Vel_Y = Convert.ToDouble(DS.Tables[0].Rows[25]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Arc_Cowl_int_Vel_X = Convert.ToDouble(DS.Tables[0].Rows[26]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Arc_Cowl_int_Vel_Y = Convert.ToDouble(DS.Tables[0].Rows[27]["VALUE"].ToString());
                //    AutoSequence.CCD2_CCD1_First_Placing_Vel_X = Convert.ToDouble(DS.Tables[0].Rows[28]["VALUE"].ToString());
                //    AutoSequence.CCD2_CCD1_First_Placing_Vel_Y = Convert.ToDouble(DS.Tables[0].Rows[29]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Rej_X_Acc = Convert.ToDouble(DS.Tables[0].Rows[30]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Rej_X_DAcc = Convert.ToDouble(DS.Tables[0].Rows[31]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Rej_Y_Acc = Convert.ToDouble(DS.Tables[0].Rows[32]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Rej_Y_DAcc = Convert.ToDouble(DS.Tables[0].Rows[33]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Arc_Cowl_Int_X_Acc = Convert.ToDouble(DS.Tables[0].Rows[34]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Arc_Cowl_Int_X_DAcc = Convert.ToDouble(DS.Tables[0].Rows[35]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Arc_Cowl_Int_Y_Acc = Convert.ToDouble(DS.Tables[0].Rows[36]["VALUE"].ToString());
                //    AutoSequence.Gantry_to_Arc_Cowl_Int_Y_DAcc = Convert.ToDouble(DS.Tables[0].Rows[37]["VALUE"].ToString());
                //    AutoSequence.Gantry_First_Placing_X_Acc = Convert.ToDouble(DS.Tables[0].Rows[38]["VALUE"].ToString());
                //    AutoSequence.Gantry_First_Placing_X_DAcc = Convert.ToDouble(DS.Tables[0].Rows[39]["VALUE"].ToString());
                //    AutoSequence.Gantry_First_Placing_Y_Acc = Convert.ToDouble(DS.Tables[0].Rows[40]["VALUE"].ToString());
                //    AutoSequence.Gantry_First_Placing_Y_DAcc = Convert.ToDouble(DS.Tables[0].Rows[41]["VALUE"].ToString());

                //    ///////////

                //}
                #endregion
                #region "Inspection"
                ModelName = File.ReadAllText(Environment.CurrentDirectory + @"\RunningModel.txt");
                SqlQuery = "Exec Sp_Recipe_Parameter_selection_Pick @Modelid = '" + ModelName.Trim() + "', @Category = 'Inspection'";

                // DS = AHDP.SQLHelper.GetData(SqlQuery);
                //if (DS.Tables[0].Rows.Count > 0)
                //{
                //    ///Inspection
                //    AutoSequence.Gantry_X_to_Arccowling_start_pos = Convert.ToDouble(DS.Tables[0].Rows[0]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_to_Arccowling_start_pos = Convert.ToDouble(DS.Tables[0].Rows[1]["VALUE"].ToString());
                //    AutoSequence.Tot_no_of_foams = Convert.ToInt32(DS.Tables[0].Rows[2]["VALUE"].ToString());
                //    AutoSequence.Feeder_timer_Wait = Convert.ToInt32(DS.Tables[0].Rows[3]["VALUE"].ToString());
                //    AutoSequence.Gantry_x_offset = Convert.ToDouble(DS.Tables[0].Rows[4]["VALUE"].ToString());
                //    AutoSequence.Gantry_y_offset = Convert.ToDouble(DS.Tables[0].Rows[5]["VALUE"].ToString());
                //    AutoSequence.Nozzle_z_offset = Convert.ToDouble(DS.Tables[0].Rows[6]["VALUE"].ToString());
                //    AutoSequence.Nozzle_Ang_offset = Convert.ToDouble(DS.Tables[0].Rows[7]["VALUE"].ToString());
                //    AutoSequence.Final_Inspection_vel = Convert.ToDouble(DS.Tables[0].Rows[8]["VALUE"].ToString());

                //    AutoSequence.Final_Inspection_Acc = Convert.ToDouble(DS.Tables[0].Rows[9]["VALUE"].ToString());
                //    AutoSequence.Final_Inspection_DAcc = Convert.ToDouble(DS.Tables[0].Rows[10]["VALUE"].ToString());

                //    AutoSequence.Final_Inspection_Vel_X = Convert.ToDouble(DS.Tables[0].Rows[11]["VALUE"].ToString());
                //    AutoSequence.Final_Inspection_Vel_Y = Convert.ToDouble(DS.Tables[0].Rows[12]["VALUE"].ToString());
                //    AutoSequence.Final_Inspection_X_Acc = Convert.ToDouble(DS.Tables[0].Rows[13]["VALUE"].ToString());
                //    AutoSequence.Final_Inspection_X_DAcc = Convert.ToDouble(DS.Tables[0].Rows[14]["VALUE"].ToString());
                //    AutoSequence.Final_Inspection_Y_Acc = Convert.ToDouble(DS.Tables[0].Rows[15]["VALUE"].ToString());
                //    AutoSequence.Final_Inspection_Y_DAcc = Convert.ToDouble(DS.Tables[0].Rows[16]["VALUE"].ToString());

                //    ///////////

                //}
                #endregion
                #region "DryCycle"
                ModelName = File.ReadAllText(Environment.CurrentDirectory + @"\RunningModel.txt");
                SqlQuery = "Exec Sp_Recipe_Parameter_selection_Pick @Modelid = '" + ModelName.Trim() + "', @Category = 'Dry Cycle '";

                //DS = AHDP.SQLHelper.GetData(SqlQuery);
                //if (DS.Tables[0].Rows.Count > 0)
                //{
                //    ///DryCycle
                //    AutoSequence.Gantry_X_LH_Foam_pos[1] = Convert.ToDouble(DS.Tables[0].Rows[0]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_LH_Foam_pos[1] = Convert.ToDouble(DS.Tables[0].Rows[1]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_LH_Foam_pos[2] = Convert.ToDouble(DS.Tables[0].Rows[2]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_LH_Foam_pos[2] = Convert.ToDouble(DS.Tables[0].Rows[3]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_LH_Foam_pos[3] = Convert.ToDouble(DS.Tables[0].Rows[4]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_LH_Foam_pos[3] = Convert.ToDouble(DS.Tables[0].Rows[5]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_LH_Foam_pos[4] = Convert.ToDouble(DS.Tables[0].Rows[6]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_LH_Foam_pos[4] = Convert.ToDouble(DS.Tables[0].Rows[7]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_RH_Foam_pos[1] = Convert.ToDouble(DS.Tables[0].Rows[8]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_RH_Foam_pos[1] = Convert.ToDouble(DS.Tables[0].Rows[9]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_RH_Foam_pos[2] = Convert.ToDouble(DS.Tables[0].Rows[10]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_RH_Foam_pos[2] = Convert.ToDouble(DS.Tables[0].Rows[11]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_RH_Foam_pos[3] = Convert.ToDouble(DS.Tables[0].Rows[12]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_RH_Foam_pos[3] = Convert.ToDouble(DS.Tables[0].Rows[13]["VALUE"].ToString());
                //    AutoSequence.Gantry_X_RH_Foam_pos[4] = Convert.ToDouble(DS.Tables[0].Rows[14]["VALUE"].ToString());
                //    AutoSequence.Gantry_Y_RH_Foam_pos[4] = Convert.ToDouble(DS.Tables[0].Rows[15]["VALUE"].ToString());
                //    AutoSequence.Gandry_drycycle_speed = Convert.ToDouble(DS.Tables[0].Rows[16]["VALUE"].ToString());

                //    ///////////

                //}
                #endregion
            }
            catch (Exception es)
            {

            }

        }
        public static bool Auto_process_stop = false;

        public static bool Process_Start = false;
        public static bool Process_Pause = false;
        public static bool Process_Stop = false;

        private void StopNonactive_Click(object sender, EventArgs e)
        {
            Auto_process_stop = true;
            Process_Pause = false;
            Process_Stop = true;
            //convrun = false;
            //AutoSequence.Conv_thread = false;
            RunActive.Visible = false;
            RunNonActive.Visible = true;
            StopActive.Visible = true;
            StopNonactive.Visible = false;
            PauseActive.Visible = false;
            PauseNonActive.Visible = true;
            Process_Start = false;
            //////if (!AutoSequence.autoProcess)
            //////{
            //////    Interface.Kill_All_Motions_Gantry();
            //////}

        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            if (ActiveMdiChild != null)
            {
                ActiveMdiChild.Close();
            }
            //foreach (Form child in this.MdiChildren)
            //{
            //    child.Close();
            //}

            Form form_alarmscreen = new AlarmScreen();
            form_alarmscreen.MdiParent = this;
            form_alarmscreen.Show();
            //if (previousform != null)
            //    previousform.Close();
            //previousform = form_alarmscreen;
        }

        private void Manual_MouseMove(object sender, MouseEventArgs e)
        {
            if (isengineeringmode)
            {
                lastEngineeringactivity = DateTime.Now;
            }
        }

        private void RunNonActive_Click(object sender, EventArgs e)
        {
            Form1.Alarmbit = false;
            ////if (!AutoSequence.autoProcess)
            ////{


            ////    RunActive.Visible = true;
            ////    RunNonActive.Visible = false;
            ////    StopActive.Visible = false;
            ////    StopNonactive.Visible = true;
            ////    PauseActive.Visible = false;
            ////    PauseNonActive.Visible = true;
            ////    AutoSequence.Current_thread_running = false;
            ////    Process_Stop = false;
            ////    Process_Start = true;

            ////    //DIOConfig.WriteOPS(true, DIOConfig.O_FF_Ejec_Cyl_up);
            ////    if (AutoSequence.Post_Inspection)
            ////    {
            ////        AutoSequence.Post_seq_step = 1;
            ////        AutoSequence.start_Thread_Post_seq_Check();
            ////    }
            ////    if (application_Onload)
            ////    {
            ////        application_Onload = false;
            ////        if(conveyor_esd.Conv_dryrun)
            ////        {
            ////            InputConveyorProcess.start_Thread_inp_Convprcss();
            ////            ProcessConveyorProcess.start_Thread_Prc_Convprcss();
            ////            OutputConveyorProcess.start_Thread_OP_Convprcss();
            ////        }
            ////        else if (AutoSequence.Dry_cycle)
            ////        {
            ////            InputConveyorProcess.start_Thread_inp_Convprcss();
            ////            if (AutoSequence.Process_Curr_comp_no > 1)
            ////            {
            ////                DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Resume the process with Process cavity Num- " + AutoSequence.Process_Curr_comp_no, "Confirmation Box", MessageBoxButtons.YesNo);
            ////                if (dialogResult == DialogResult.Yes)
            ////                {
            ////                    //do something
            ////                    if (!DIOConfig.DO[DIOConfig.O_WC_TL_Gn])
            ////                    {
            ////                        DIOConfig.WriteOPS(true, DIOConfig.O_WC_TL_Gn);
            ////                        DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Rd);
            ////                        DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Ye);
            ////                    }

            ////                }
            ////                else if (dialogResult == DialogResult.No)
            ////                {
            ////                    AutoSequence.Process_Curr_comp_no = 1;
            ////                    AutoSequence.Curr_comp_no = 1;
            ////                    AutoSequence._autoStep = 0;
            ////                    AutoSequence.autoStep = 1;
            ////                    AutoSequence.autoProcess = true;
            ////                    //do something else
            ////                }
            ////            }

            ////        }
            ////        else
            ////        {
            ////            if (AutoSequence.Process_Curr_comp_no > 1)
            ////            {
            ////                DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Resume the process with Process cavity Num- " + AutoSequence.Process_Curr_comp_no, "Confirmation Box", MessageBoxButtons.YesNo);
            ////                if (dialogResult == DialogResult.Yes)
            ////                {
            ////                    //do something
            ////                    if (!DIOConfig.DO[DIOConfig.O_WC_TL_Gn])
            ////                    {
            ////                        DIOConfig.WriteOPS(true, DIOConfig.O_WC_TL_Gn);
            ////                        DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Rd);
            ////                        DIOConfig.WriteOPS(false, DIOConfig.O_WC_TL_Ye);
            ////                    }
            ////                }
            ////                else if (dialogResult == DialogResult.No)
            ////                {
            ////                    AutoSequence.Process_Curr_comp_no = 1;
            ////                    AutoSequence.Curr_comp_no = 1;
            ////                    AutoSequence.autoProcess = true;
            ////                    //do something else
            ////                }
            ////            }
            ////        }

            ////    }
            ////    bool process = false;

            ////    if ((DIOConfig.DI[DIOConfig.I_WC_Vacuum_Press_Switch1_FB] || DIOConfig.DI[DIOConfig.I_WC_Vacuum_Press_Switch2_FB] ||  DIOConfig.DI[DIOConfig.I_WC_Vacuum_Press_Switch3_FB]) || DIOConfig.DI[DIOConfig.I_WC_Vacuum_Press_Switch4_FB])
            ////    {
            ////        process = Nozzle.Move_Nozzle(GlobalVar.Nozzle_Z_Axis[1], GlobalVar.Nozzle_Z_Homeposs[1]);
            ////        Thread.Sleep(100);
            ////        process = Nozzle.Move_Nozzle(GlobalVar.Nozzle_Z_Axis[2], GlobalVar.Nozzle_Z_Homeposs[2]);
            ////        Thread.Sleep(100);
            ////        process = Nozzle.Move_Nozzle(GlobalVar.Nozzle_Z_Axis[3], GlobalVar.Nozzle_Z_Homeposs[3]);
            ////        Thread.Sleep(100);
            ////        process = Nozzle.Move_Nozzle(GlobalVar.Nozzle_Z_Axis[4], GlobalVar.Nozzle_Z_Homeposs[4]);
            ////        Thread.Sleep(100);
            ////        AutoSequence.Rej_Module_CCD2[1] = true;
            ////        AutoSequence.Rej_Module_CCD2[2] = true;
            ////        AutoSequence.Rej_Module_CCD2[3] = true;
            ////        AutoSequence.Rej_Module_CCD2[4] = true;
            ////        if (process)
            ////        {
            ////            AutoSequence.CCD2_Rej_Seq_cnt = 1;
            ////            Form_load_tossing = true;
            ////            AutoSequence.start_Thread_RejSwq_CCD2();
            ////        }


            ////    }
            ////    if(!Form_load_tossing)
            ////    {
            ////        Start_Resume_Autoprocess();

            ////    }


            ////    //InputConveyorProcess.start_Thread_inp_Convprcss();by karthik
            ////    //ProcessConveyorProcess.start_Thread_Prc_Convprcss();by karthik
            ////    //OutputConveyorProcess.start_Thread_OP_Convprcss();by karthik
            ////}
        }

        private void simpleButton13_Click(object sender, EventArgs e)
        {
            //if ( AutoSequence.autoStep != 20  && AutoSequence.autoStep != 24 && AutoSequence.autoStep != 19 && !AutoSequence.CCD2_Validation )
            //{


            //    Interface.Kill_All_Motions_Gantry();

            //    Seq_Pause_click = true;
            //    AutoSequence.autoProcess = false;
            //    RunActive.Visible = false;
            //    RunNonActive.Visible = true;
            //    StopActive.Visible = false;
            //    StopNonactive.Visible = true;
            //    PauseActive.Visible = true;
            //    PauseNonActive.Visible = false;
            //    Process_Pause = true;
            //    Process_Stop = false;
            //    AutoSequence.foam_empty_alaram = 0;
            //}

        }

        private void ErrorActiveButton_MouseMove(object sender, MouseEventArgs e)
        {
            //if (isengineeringmode)
            //{
            //    lastEngineeringactivity = DateTime.Now;
            //}
        }

        private void Tmr_Status_Tick(object sender, EventArgs e)
        {
            LeadShineInterface.Read_DI_from_Motioncard(0);
            LeadShineInterface.servo_status_no(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Pick_X_Axis, ref Globalvariable.Pick_X_Alarm, ref Globalvariable.Pick_X_Positive_lim, ref Globalvariable.Pick_X_Negative_lim, ref Globalvariable.Pick_X_Origin);
            LeadShineInterface.servo_status_no(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Pick_Y_Axis, ref Globalvariable.Pick_Y_Alarm, ref Globalvariable.Pick_Y_Positive_lim, ref Globalvariable.Pick_Y_Negative_lim, ref Globalvariable.Pick_Y_Origin);

            LeadShineInterface.servo_status_no(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Roller_X_Axis, ref Globalvariable.Roller_X_Alarm, ref Globalvariable.Roller_X_Positive_lim, ref Globalvariable.Roller_X_Negative_lim, ref Globalvariable.Roller_X_Origin);
            LeadShineInterface.servo_status_no(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Roller_Y_Axis, ref Globalvariable.Roller_Y_Alarm, ref Globalvariable.Roller_Y_Positive_lim, ref Globalvariable.Roller_Y_Negative_lim, ref Globalvariable.Roller_Y_Origin);
            LeadShineInterface.servo_status_no(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Roller_Z_Axis, ref Globalvariable.Roller_Z_Alarm, ref Globalvariable.Roller_Z_Positive_lim, ref Globalvariable.Roller_Z_Negative_lim, ref Globalvariable.Roller_Z_Origin);

            LeadShineInterface.servo_status_no(Globalvariable.Leadshine_card_No, Globalvariable.Battery_FI_X_Axis, ref Globalvariable.FI_X_Alarm, ref Globalvariable.FI_X_Positive_lim, ref Globalvariable.FI_X_Negative_lim, ref Globalvariable.FI_X_Origin);
            LeadShineInterface.servo_status_no(Globalvariable.Leadshine_card_No, Globalvariable.Battery_FI_Y_Axis, ref Globalvariable.FI_Y_Alarm, ref Globalvariable.FI_Y_Positive_lim, ref Globalvariable.FI_Y_Negative_lim, ref Globalvariable.FI_Y_Origin);
            PLC.DO_VALUES_READ();
            label4.Text = DateTime.Now.ToString();
           if( Globalvariable.Alarm_Pause)
            {
                PauseActive.Visible = false;
                PauseNonActive.Visible = true;

                RunActive.Visible = true;
                RunNonActive.Visible = false;

                StopActive.Visible = true;
                StopNonactive.Visible = false;
            }

            if (Globalvariable.Alarm_Stop)
            {
                PauseActive.Visible = false;
                PauseNonActive.Visible = true;

                RunActive.Visible = true;
                RunNonActive.Visible = false;

                StopActive.Visible = false;
                StopNonactive.Visible = true;
            }
            //if(Globalvariable.MC_Read_DI[Variables.Reset_button])
            //{
            //    Globalvariable.Fault_reset=true;
            //    PLC.WRITE_DO_TO_PLC(Variables.Three_color_yellow_light, 1);
            //}

            //if(PLC.DIO_Read[Variables.Emergency_stop_signal] == 1)
            //{
            //    PLC.WRITE_DO_TO_PLC(Variables.Stop_input0_or_Denso_step_stop, 1);
            //}
            
            if (LeadShineInterface.Get_Home_status(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Roller_X_Axis) == "Homing_Done")
            {

            }

                //UserType.Text = Form1.Login_user_mode;
                //Active_btn_dis_or_en();
                //IO_Status();
                //device_cnctn();
                //OEE.OEE_LOG();
                //InputConveyorProcess.INP_Conv_process("");
                //Vision_cnnctn_sts();

                //Nozzle_status_ILock();

                ///////////////////////////////////////////////////////////////////////////////////////////////////////////
                /// Stepper_sts();
                //if (AHDP.SQLHelper.openconnection())
                //{
                //    string currentTime = DateTime.Now.ToString("HH:mm:ss");
                //    if (currentTime == "00:00")
                //    {
                //        AutoSequence.Tray_cnt = 1;
                //        AutoSequence.Cycle_Number = 1;
                //        ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg);
                //    }
                //    SqlParameter[] cmdmodel = {
                //        new SqlParameter("CURRENT_TIME", currentTime)};
                ////DataSet ds = AHDP.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_SHIFT_ID", cmdmodel);
                ////if (ds.Tables[0].Rows.Count > 0)
                ////{
                ////    AHDP.GlobalVar.Shift = ds.Tables[0].Rows[0]["shift_id"].ToString();
                ////    lblShift.Text = ds.Tables[0].Rows[0]["shift_id"].ToString();
                ////    GlobalVar.Shift= ds.Tables[0].Rows[0]["shift_id"].ToString();

                ////    Invoke(new MethodInvoker(delegate
                ////        {
                ////            lblShift.Text = ds.Tables[0].Rows[0]["shift_id"].ToString();
                ////            lblDatetime.Text = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");
                ////        }));

                ////}
                ////    AHDP.SQLHelper.closeconnection();

                ////}
                ////lblDatetime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                /////////////////////////////////////////////////////////////////////////////////////////////////////////////

                //if (DIOConfig.DI[DIOConfig.I_WC_Rst_PB] && !AutoSequence.autoProcess)
                //    {
                //       // Interface.ResetAxisError(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
                //        AutoSequence.Current_thread_running = false;
                //        //Interface.Rem_Interpol_Axis();
                //        GlobalVar.Reset_Alarm();
                //        IO_Status();

                //        if (DIOConfig.DI[DIOConfig.I_WC_Plt_Lift_Cyl_Up])
                //        {
                //            DIOConfig.WriteOPS(true, DIOConfig.O_WC_Plt_Lift_Cyl_Up);
                //            DIOConfig.WriteOPS(false, DIOConfig.O_WC_Plt_Lift_Cyl_Dn);
                //        }
                //        else
                //        {
                //            DIOConfig.WriteOPS(false, DIOConfig.O_WC_Plt_Lift_Cyl_Up);
                //            DIOConfig.WriteOPS(true, DIOConfig.O_WC_Plt_Lift_Cyl_Dn);

                //        }
                //        if (GlobalVar.Axis_Disconnect_Error > 0 || (safety_pressed))
                //        {
                //        //AutoSequence.Stop_Thread_IO();

                //        safety_pressed = false;
                //          //    Interface.CloseBoard(); 
                //          //    Interface.m_GpHand = IntPtr.Zero;
                //          //    Interface.AxCountInGp = 0;
                //          //    Interface.AxisArray = new uint[64];
                //          //    Interface.m_IsGpOpen = false;
                //          //    Interface.Grp_State = string.Empty;
                //          //    RE_Initialization();
                //          //Thread.Sleep(200);
                //          Interface.ResetAxisError(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
                //          Thread.Sleep(500);
                //          //AutoSequence.start_Thread_IO();
                //               Interface.ServoOn(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
                //          //AxisConfig.Interpolation_Configuration();


                //      }
                //      else
                //      {
                //          Interface.ResetAxisError(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
                //      }

                //      //Interface.OpenBoard();
                //      Thread.Sleep(500);
                //      Interface.ServoOn(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
                //      //Interface.ResetAxisError(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
                //      //Interface.m_bServoOn = false;
                //      // Interface.ServoOn(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);
                //      //Interface.Interpol_Axis();
                //      //Interface.ResetAxisError(DIOConfig.DI[DIOConfig.I_WC_Sfty_Rly_FB]);

                //      //GlobalVar.Reset_Alarm();
                //      AlarmBit =false;
                //      ErrorActiveButton.Visible = false;
                //      NoError.Visible = true;

                //  }
                // else if(DIOConfig.DI[DIOConfig.I_WC_Rst_PB] && AutoSequence.autoProcess)
                // {
                //      if (AutoSequence.autoStep != 7 && AutoSequence.autoStep != 20 && AutoSequence.autoStep != 13 && AutoSequence.autoStep != 19 && !AutoSequence.CCD2_Validation)
                //      {


                //          Interface.Kill_All_Motions_Gantry();

                //          Seq_Pause_click = true;
                //          AutoSequence.autoProcess = false;
                //          RunActive.Visible = false;
                //          RunNonActive.Visible = true;
                //          StopActive.Visible = false;
                //          StopNonactive.Visible = true;
                //          PauseActive.Visible = true;
                //          PauseNonActive.Visible = false;
                //          Process_Pause = true;
                //          Process_Stop = false;
                //          AutoSequence.foam_empty_alaram = 0;
                //      }

                //  }


                //  if (DIOConfig.DI[DIOConfig.I_WC_Cyc_Strt_FB] && Login_user_mode != "" )
                //  {

                //      if(!AutoSequence.autoProcess)
                //      {
                //          RunActive.Visible = true;
                //          RunNonActive.Visible = false;
                //          StopActive.Visible = false;
                //          StopNonactive.Visible = true;
                //          PauseActive.Visible = false;
                //          PauseNonActive.Visible = true;
                //          Form1.convrun = true;
                //          AutoSequence.Process_Curr_comp_no = 1;
                //          AutoSequence.Curr_comp_no = 1;
                //          AutoSequence.autoStep = 1;
                //          AutoSequence.autoProcess = true;

                //          InputConveyorProcess.start_Thread_inp_Convprcss();
                //          ProcessConveyorProcess.start_Thread_Prc_Convprcss();
                //          OutputConveyorProcess.start_Thread_OP_Convprcss();
                //          AutoSequence.FF_Start_operation = true;
                //          Load_Q_for_conv();

                //      }


                //  }
                ////  AutoSequence.Conv_process("");
                //  //AutoSequence.FF_Index("");


            }
        static bool safety_pressed = false;
        static bool LH_Empty = false;
        static bool RH_Empty = false;

        //Alarm declaration
        public static Dictionary<string, string> Alarmlist = new Dictionary<string, string>();
        
        public static void Alarmdetails()
        {
            //string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;  //Location of Debug File
            //string filePath = Path.Combine(projectDirectory, "..", "..", "Datafiles", "AHDP_Alarm_list.txt");//It come out and gives the outside bin file location
            //filePath = Path.GetFullPath(filePath);  //Will be having Alarmlist file loacation
            //try
            //{
            //    string[] lines = File.ReadAllLines(filePath); //it will read exact data from the file
            //    foreach (var line in lines)  //1 line at at a time it will read as it is and stores in the line 
            //    {
            //        if (string.IsNullOrWhiteSpace(line))  //checks for null,empty,whitespace
            //            continue;
            //        string[] parts = line.Split(':'); //it will split as two rows

            //        if (parts.Length == 2)
            //        {
            //            string alarmDescription = parts[0].Trim();  //holding the alarm description data
            //            string alarmcode = parts[1].Trim();   //hold the alarm code data
            //            Alarmlist[alarmDescription] = alarmcode;  //will be there as key value pair, Key=Alarm description ,, Value=errorcode
            //                                                      //all will be holding one data at a time,only the dictionary will store the new values recursively
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Form1:Error in this function:Update_C_Alarm()" + ex);
            //    return;
            //}
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void OpenFolder_Click(object sender, EventArgs e)
        {
            string locatn = "D:\\Nova";
            Process.Start(locatn);
        }
        //Added//
        public void Panel_add(Form CurrentForm)
        {

            CurrentForm.TopLevel = false;
            CurrentForm.Dock = DockStyle.Fill;
            panel3.Controls.Clear();
            panel3.Controls.Add(CurrentForm);
            CurrentForm.TopMost = true;
            CurrentForm.Show();
        }

        private void toolTipManual_Popup(object sender, PopupEventArgs e)
        {

        }
        bool PLC_Timer_lock = false;
        private void PLC_IO_Read_Tick(object sender, EventArgs e)
        {

            if (!PLC_Timer_lock)
            {
                PLC_Timer_lock = true;
                try
                {
                    PLC.Read_IO(sender);
                }
                catch
                {
                    PLC_Timer_lock = false;
                    //    Logger.WriteLog("Form1", "timer1_Tick", "timer1_Tick", "Error", e.ToString());
                }
                PLC_Timer_lock = false;

            }
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {

        }
    }
    class ElipseControl : Component
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        public static extern IntPtr CreateRoundRectRgn
            (
               int nLeftRect,
               int nTopRect,
               int nRightRect,
               int nBottomRect,
               int nWidthEllipse,
               int nHeightEllipse
            );
        private Control _cntrl;
        private int _CornerRadius = 150;

        public Control TargetControl
        {
            get { return _cntrl; }
            set
            {
                _cntrl = value;
                _cntrl.SizeChanged += (sender, eventArgs) => _cntrl.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, _cntrl.Width, _cntrl.Height, _CornerRadius, _CornerRadius));
            }
        }

        public int CornerRadius
        {
            get { return _CornerRadius; }
            set
            {
                _CornerRadius = value;
                if (_cntrl != null)
                    _cntrl.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, _cntrl.Width, _cntrl.Height, _CornerRadius, _CornerRadius));
            }
        }

        
    }
}
