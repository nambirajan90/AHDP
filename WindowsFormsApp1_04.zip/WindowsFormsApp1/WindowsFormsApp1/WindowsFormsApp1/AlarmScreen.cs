﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using System.IO;
using System.Threading;


namespace AHDP

{
    public partial class AlarmScreen : Form
    {
        public string shift;

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
    (
        int nLeftRect,
        int nTopRect,
        int nRightRect,
        int nBottomRect,
        int nWidthEllipse,
        int nHeightEllipse
    );
        public void Panel_Shape()
        {
         //   panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
         //panel4.Height, 30, 30));

        }
        public AlarmScreen() //Loads UI
        {
            InitializeComponent();
        }
        private void AlarmScreen_Load(object sender, EventArgs e)  //Loads Shift Data
        {
            try
            {

                cmbShift.Items.Insert(0, "A");
                cmbShift.Items.Insert(1, "B");
                cmbShift.Items.Insert(2, "C");
                shift = cmbShift.Text;
                Panel_Shape();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alarm Screen--Error in this function:AlarmScreen_Load()" + ex);
                return;
            }
        }
        private async void btnQuery_Click(object sender, EventArgs e) //Validation of all fields and data binding Function call
        {
            try
            {
                if (dateTimePicker1.Value == DateTime.MinValue)
                {
                    gridControl1.DataSource = new DataTable();
                    MessageBox.Show("Enter the Start Date");
                    return;
                }
                if (dateTimePicker2.Value == DateTime.MinValue)
                {
                    gridControl1.DataSource = new DataTable();
                    MessageBox.Show("Enter the End Date");
                    return;
                }
                if (cmbShift.SelectedIndex == -1)
                {
                    gridControl1.DataSource = new DataTable();
                    MessageBox.Show("Enter the Shift");
                    return;
                }
                if (dateTimePicker1.Value > dateTimePicker2.Value)
                {
                    gridControl1.DataSource = new DataTable();
                    MessageBox.Show("Select the correct Dates");
                    return;
                }
                if (dateTimePicker1.Value != DateTime.MinValue && dateTimePicker2.Value != DateTime.MinValue && cmbShift.SelectedIndex != -1)
                {
                    var starttime = dateTimePicker1.Value;
                    var endtime = dateTimePicker2.Value;
                    var shift = cmbShift.Text;

                    gridControl1.DataSource = new DataTable();
                    Alarmtabledata(starttime, endtime, shift);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alarm Screen--Error in this function:btnQuery_Click()" + ex);
                return;
            }
        }
        private async void Alarmtabledata(DateTime starttime, DateTime endtime, string Shift)   //Data binding for Datagridview
        {


            string connectionString = SQLHelper.get_ConnName();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_Alarm_View_Historic", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@StartTime", starttime);
                    cmd.Parameters.AddWithValue("@EndTime", endtime);
                    cmd.Parameters.AddWithValue("@Shift", Shift);

                    try
                    {
                        await conn.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            await Task.Run(() => adapter.Fill(dt));

                            if (dt.Rows.Count > 0)
                            {
                                gridControl1.DataSource = dt;
                                gridControl1.Show();
                            }
                            else
                            {
                                MessageBox.Show("No Alarm for the selected Dates");
                                gridControl1.DataSource = null;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Alarm Screen--Error in this function:Alarmtabledata()" + ex);
                        return;
                    }
                }
            }
        }
        private void btnReset_Click(object sender, EventArgs e)  //Reset Button Functionality
        {
            gridControl1.DataSource = new DataTable();
        }
        private async void btnSave_Click(object sender, EventArgs e) //Save data for Excel 
        {
            if (dateTimePicker1.Value == DateTime.MinValue)
            {
                MessageBox.Show("Enter the Start Date");
                return;
            }
            if (dateTimePicker2.Value == DateTime.MinValue)
            {
                MessageBox.Show("Enter the End Date");
                return;
            }
            if (cmbShift.SelectedIndex == -1)
            {
                MessageBox.Show("Enter the Shift");
                return;
            }
            if (dateTimePicker1.Value > dateTimePicker2.Value)
            {
                MessageBox.Show("Select the correct Dates");
                return;
            }
            if (dateTimePicker1.Value != DateTime.MinValue && dateTimePicker2.Value != DateTime.MinValue && cmbShift.SelectedIndex != -1)
            {
                var starttime = dateTimePicker1.Value;
                var endtime = dateTimePicker2.Value;
                var shift = cmbShift.Text;
                string connectionString = SQLHelper.get_ConnName();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_Alarm_View_Historic", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@StartTime", starttime);
                        cmd.Parameters.AddWithValue("@EndTime", endtime);
                        cmd.Parameters.AddWithValue("@Shift", shift);
                        try
                        {
                            await conn.OpenAsync();
                            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                            {
                                DataSet dt = new DataSet();
                                adapter.Fill(dt);
                                if (dt.Tables[0].Rows.Count > 0)
                                {
                                    Thread t = new Thread((ThreadStart)(() =>
                                    {
                                        var saveFileDialog1 = new SaveFileDialog();
                                        saveFileDialog1.Filter = "csv files (*.csv)|*.csv";
                                        saveFileDialog1.Title = "Alarm History Data";
                                        saveFileDialog1.FilterIndex = 2;
                                        saveFileDialog1.ShowDialog();
                                        saveFileDialog1.RestoreDirectory = true;
                                        if (saveFileDialog1.FileName.Length > 0)
                                        {
                                            writeCSV(dt, saveFileDialog1.FileName.ToString());
                                        }
                                    }));
                                    t.SetApartmentState(ApartmentState.STA);
                                    t.Start();
                                    t.Join();
                                }


                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Alarm Screen--Error in this function:btnSave_Click()" + ex);
                            return;
                        }
                    }
                }

            }
        }
        private void writeCSV(DataSet paramDset, string fileName) //Writing Data for Excel
        {
            StreamWriter sw = new StreamWriter(fileName, false);
            //headers
            try
            {
                for (int i = 0; i < paramDset.Tables[0].Columns.Count; i++)
                {
                    sw.Write(paramDset.Tables[0].Columns[i]);
                    if (i < paramDset.Tables[0].Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
                foreach (DataRow dr in paramDset.Tables[0].Rows)
                {
                    for (int i = 0; i < paramDset.Tables[0].Columns.Count; i++)
                    {
                        if (!Convert.IsDBNull(dr[i]))
                        {
                            string value = dr[i].ToString();
                            if (value.Contains(','))
                            {
                                value = String.Format("\"{0}\"", value);
                                sw.Write(value);
                            }
                            else
                            {
                                sw.Write(dr[i].ToString());
                            }
                        }
                        if (i < paramDset.Tables[0].Columns.Count - 1)
                        {
                            sw.Write(",");
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alarm Screen--Error in this function:writeCSV()" + ex);
                return;
            }
        }

    }
}