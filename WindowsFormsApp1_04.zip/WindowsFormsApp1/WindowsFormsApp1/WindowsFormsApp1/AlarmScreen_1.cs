﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices.ComTypes;

namespace B3I
{
    public partial class AlarmScreen : Form
    {
        public string shift;

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]


        private static extern IntPtr CreateRoundRectRgn
    (
        int nLeftRect,
        int nTopRect,
        int nRightRect,
        int nBottomRect,
        int nWidthEllipse,
        int nHeightEllipse
    );

        public void Panel_Shape()
        {
            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width,
          panel1.Height, 30, 30));
            //   panel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel2.Width,
            //panel2.Height, 30, 30));
            panel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel3.Width,
         panel3.Height, 30, 30));
            panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
         panel4.Height, 30, 30));

        }
        public AlarmScreen()
        {
            InitializeComponent();
        }
        //   public static int Rowcnt = 0;
        private void AlarmScreen_Load(object sender, EventArgs e)  //Input for Field Shift
        {
            try
            {
                //cmbShift.Items.Insert(0, "ALL");
                cmbShift.Items.Insert(0, "A");
                cmbShift.Items.Insert(1, "B");
                cmbShift.Items.Insert(2, "C");
                shift = cmbShift.Text;
                Panel_Shape();
                //loadalarmdowntimestatistics("Load");
                //loadalarmoee("Load");
                //loadalarmminutes("Load");
                //loadalarmgrid("Load");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alarm Screen--Error in this function:AlarmScreen_Load()" + ex);
                return;
            }
        }

        private void loadalarmdowntimestatistics(string mode)
        {
            //try
            //{
            //    //B3I.SQLHelper.get_ConnName();
            //    if (B3I.SQLHelper.openconnection())
            //    {
            //        shift = cmbShift.Text;
            //        DateTime start_time = Convert.ToDateTime(dtStartTime.Text);
            //        DateTime end_time = Convert.ToDateTime(dtEndTime.Text);                   
            //        SqlParameter[] cmdmodel = {
            //            new SqlParameter("MODE", mode),
            //            new SqlParameter("START_TIME", start_time.ToString("yyyy-MM-dd HH:mm:ss")),
            //            new SqlParameter("END_TIME", end_time.ToString("yyyy-MM-dd HH:mm:ss")),
            //            new SqlParameter("SHIFT", shift)};
            //        DataSet ds = B3I.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_ALARM_DOWNTIME_STATISTICS",cmdmodel);
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            lblunitfailures.Text = ds.Tables[0].Rows[0]["UNIT_FAILURE"].ToString();
            //            lbltossing.Text = ds.Tables[0].Rows[0]["TOSSING"].ToString();
            //            lblmaterialissue.Text = ds.Tables[0].Rows[0]["MATERIAL_ISSUE"].ToString();
            //            lblnone.Text = ds.Tables[0].Rows[0]["_NONE"].ToString();
            //            lblother.Text = ds.Tables[0].Rows[0]["OTHER"].ToString();
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{

            //}
        }

        private void loadalarmoee(string mode)
        {
            //try
            //{
            //    //B3I.SQLHelper.get_ConnName();
            //    if (B3I.SQLHelper.openconnection())
            //    {
            //        shift = cmbShift.Text;
            //        DateTime start_time = Convert.ToDateTime(dtStartTime.Text);
            //        DateTime end_time = Convert.ToDateTime(dtEndTime.Text);
            //        SqlParameter[] cmdmodel = {
            //            new SqlParameter("MODE", mode),
            //            new SqlParameter("START_TIME", start_time.ToString("yyyy-MM-dd")),
            //            new SqlParameter("END_TIME", end_time.ToString("yyyy-MM-dd")),
            //            new SqlParameter("SHIFT", shift)};
            //        DataSet ds = B3I.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_ALARM_MACHINE_HEALTH_STATUS", cmdmodel);
            //        if (ds.Tables[0].Rows.Count > 0)
            //        {
            //            lbldowntime.Text = ds.Tables[0].Rows[0]["Downtime"].ToString();
            //            lblruntime.Text = ds.Tables[0].Rows[0]["Runtime"].ToString();
            //            lblidletime.Text = ds.Tables[0].Rows[0]["Idletime"].ToString();
            //            //lblstoppedtime.Text = ds.Tables[0].Rows[0]["Stoptime"].ToString();
            //            lbltotaltime.Text = ds.Tables[0].Rows[0]["Totaltime"].ToString();

            //            loadmachineoeeChart();
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{

            //}
        }

        private void loadmachineoeeChart()
        {
            try
            {
                //this.chartControlAlarmOEE.Series.Clear();
                //Series machineHealthPie = new Series("MachineHealth", ViewType.Pie);
                //machineHealthPie.ArgumentDataMember = "Argument";
                //machineHealthPie.ValueDataMembers.AddRange(new string[] { "Value" });
                //machineHealthPie.ColorDataMember = "Color";
                //machineHealthPie.DataSource = CreateChartData();
                //PieSeriesView view = (PieSeriesView)machineHealthPie.View;
                //view.FillStyle.FillMode = FillMode.Solid;
                //this.chartControlAlarmOEE.Series.Add(machineHealthPie);
                //this.chartControlAlarmOEE.Legend.Visibility = DevExpress.Utils.DefaultBoolean.False;
                //this.chartControlAlarmOEE.Series[0].Label.TextPattern = " {V:N2} ";
                //this.chartControl1.Series[0].Label.LineVisibility = DevExpress.Utils.DefaultBoolean.False;
                //this.chartControl1.Series[0].LabelsVisibility = DevExpress.Utils.DefaultBoolean.False;
            }
            catch (Exception ex)
            {

            }
        }

        private DataTable CreateChartData()
        {
            try
            {
                DataTable dtChart1 = new DataTable("ChartTable1");
                dtChart1.Columns.Add("Argument", typeof(string));
                dtChart1.Columns.Add("Value", typeof(Decimal));
                dtChart1.Columns.Add("Color", typeof(string));

                //DataRow row = null;
                //row = dtChart1.NewRow();
                //row["Argument"] = "RunTime";
                //row["Value"] = Convert.ToDecimal(lblruntime.Text.Replace(":", "."));
                //Color c = Color.FromArgb(255, 46, 204, 113);
                //row["Color"] = "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
                //dtChart1.Rows.Add(row);
                //row = dtChart1.NewRow();
                //row["Argument"] = "DownTime";
                //row["Value"] = Convert.ToDecimal(lbldowntime.Text.Replace(":", "."));
                //c = Color.FromArgb(255, 231, 76, 60);
                //row["Color"] = "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
                //dtChart1.Rows.Add(row);
                //row = dtChart1.NewRow();
                //row["Argument"] = "IdleTime";
                //row["Value"] = Convert.ToDecimal(lblidletime.Text.Replace(":", "."));
                //c = Color.FromArgb(255, 241, 196, 15);
                //row["Color"] = "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
                //dtChart1.Rows.Add(row);
                //row = dtChart1.NewRow();
                //row["Argument"] = "StopTime";
                //row["Value"] = Convert.ToDecimal(lblstoppedtime.Text.Replace(":", "."));
                //c = Color.FromArgb(255, 112, 123, 124);
                //row["Color"] = "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
                //dtChart1.Rows.Add(row);

                return dtChart1;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private void loadalarmminutes(string mode)
        {
            try
            {
                shift = cmbShift.Text;
                //B3I.SQLHelper.get_ConnName();
                //if (B3I.SQLHelper.openconnection())
                //{
                //    DataSet ds = B3I.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_ALARM_DOWNTIME_BAR", cmdmodel);
                //    if (ds.Tables[0].Rows.Count > 0)
                //    {
                //        this.chartControl2.Series.Clear();
                //        Series uphBar = new Series("UPH", ViewType.StackedBar);
                //        uphBar.ArgumentDataMember = "Argument";
                //        uphBar.ValueDataMembers.AddRange(new string[] { "Value" });
                //        uphBar.ColorDataMember = "Color";
                //        uphBar.DataSource = CreateChartDataAlarm(ds);

                //        BarSeriesView view = (BarSeriesView)uphBar.View;
                //        view.FillStyle.FillMode = FillMode.Solid;
                //        this.chartControl2.Series.Add(uphBar);
                //        //this.chartControl3.Legend.Visibility = DevExpress.Utils.DefaultBoolean.False;
                //        this.chartControl2.Series[0].Label.TextPattern = " {V:N2} ";
                //        ((DevExpress.XtraCharts.XYDiagram)chartControl2.Diagram).AxisX.QualitativeScaleOptions.AutoGrid = false;
                //    }
                //}
            }
            catch (Exception ex)
            {

            }
        }

        private DataTable CreateChartDataAlarm(DataSet dataSet)
        {
            try
            {
                DataSet dsAlarm = dataSet;
                DataTable dtChart3 = new DataTable("ChartTable2");
                dtChart3.Columns.Add("Argument", typeof(string));
                dtChart3.Columns.Add("Value", typeof(Decimal));
                dtChart3.Columns.Add("Color", typeof(string));

                DataRow row = null;
                if (dsAlarm.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < dsAlarm.Tables[0].Rows.Count; i++)
                    {
                        row = dtChart3.NewRow();
                        row["Argument"] = dsAlarm.Tables[0].Rows[i]["DateTime"].ToString();
                        row["Value"] = Convert.ToDecimal(dsAlarm.Tables[0].Rows[i]["Minutes"].ToString());
                        Color c1 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                    }
                }

                return dtChart3;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private void loadalarmgrid(string mode)
        {
            try
            {
                shift = cmbShift.Text;
                gridControl1.DataSource = null;

                //B3I.SQLHelper.get_ConnName();
                //if (B3I.SQLHelper.openconnection())
                //{
                //    DataSet ds = B3I.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_ALARM_HISTORY_DETAILS",cmdmodel);
                //    if (ds.Tables[0].Rows.Count > 0)
                //    {
                //        gridControl1.DataSource = ds.Tables[0].DefaultView;
                //    }
                //}
            }
            catch (Exception ex)
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void roundedButton1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void linklblgotoliveAlarm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //sthis.Close();
            //Form alarm_livescreen = new AlarmLiveScreen();
            //alarm_livescreen.MdiParent = Form1.ActiveForm;
            //alarm_livescreen.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //GlobalVar.Gantry_Home_Error = Convert.ToInt32(textBox1.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //GlobalVar.Gantry_X_Error = Convert.ToInt32(textBox1.Text);
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            //GlobalVar.Motion_Timeout = Convert.ToInt32(textBox1.Text);
        }

        private async void btnQuery_Click(object sender, EventArgs e) //VAlidation of all fields and data binding Function call
        {
            try
            {
                //gridControl1.DataSource = null;

                if (dateTimePicker1.Value == DateTime.MinValue)
                {
                    MessageBox.Show("Enter the Start Date");
                    return;
                }
                if (dateTimePicker2.Value == DateTime.MinValue)
                {
                    MessageBox.Show("Enter the End Date");
                    return;
                }
                if (cmbShift.SelectedIndex == -1)
                {
                    MessageBox.Show("Enter the Shift");
                    return;
                }
                if (dateTimePicker1.Value != DateTime.MinValue && dateTimePicker2.Value != DateTime.MinValue && cmbShift.SelectedIndex != -1)
                {
                    var starttime = dateTimePicker1.Value;
                    var endtime = dateTimePicker2.Value;
                    var shift = cmbShift.Text;
                    LoadChartData(starttime, endtime, shift);
                    Alarmtabledata(starttime, endtime, shift);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alarm Screen--Error in this function:btnQuery_Click()" + ex);
                return;
            }
        }

        private async void Alarmtabledata(DateTime starttime, DateTime endtime, string Shift)   //Data binding for Table data
        {


            string connectionString = SQLHelper.get_ConnName();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_Alarm_View_Historic", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@StartTime", starttime);
                    cmd.Parameters.AddWithValue("@EndTime", endtime);
                    cmd.Parameters.AddWithValue("@Shift", Shift);

                    try
                    {
                        await conn.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            await Task.Run(() => adapter.Fill(dt));

                            if (dt.Rows.Count > 0)
                            {
                                gridControl1.DataSource = dt;
                                gridControl1.Show();
                            }
                            else
                            {
                                MessageBox.Show("No Alarm for the selected Dates");
                                gridControl1.DataSource = null;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Alarm Screen--Error in this function:Alarmtabledata()" + ex);
                        return;
                    }
                }
            }
        }

        private void LoadChartData(DateTime starttime, DateTime endtime, string Shift)  //Data binding for Graph 
        {
            string connectionString = SQLHelper.get_ConnName();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                connection.Open();

                SqlCommand command = new SqlCommand("SP_Alarm_historic_Graph", connection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(new SqlParameter("@Starttime", starttime));
                command.Parameters.Add(new SqlParameter("@Endtime", endtime));
                command.Parameters.Add(new SqlParameter("@shift", Shift));
                try
                {
                    SqlDataReader reader = command.ExecuteReader();
                    chart1.Series["Series1"].Points.Clear();
                    while (reader.Read())
                    {
                        DateTime errorDate = reader.GetDateTime(0);
                        int errorCode = reader.GetInt32(1);
                        chart1.Series["Series1"].Points.AddXY(errorDate, errorCode);
                    }
                    reader.Close();
                    connection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Alarm Screen--Error in this function:LoadChartData()" + ex);
                    return;
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)  //Reset Button Functionality
        {
            gridControl1.DataSource = new DataTable();
            chart1.Series["Series1"].Points.Clear();
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {

            if (dateTimePicker1.Value != DateTime.MinValue && dateTimePicker2.Value != DateTime.MinValue && cmbShift.SelectedIndex != -1)
            {
                var starttime = dateTimePicker1.Value;
                var endtime = dateTimePicker2.Value;
                var shift = cmbShift.Text;
                string connectionString = SQLHelper.get_ConnName();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("SP_Alarm_View_Historic", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@StartTime", starttime);
                        cmd.Parameters.AddWithValue("@EndTime", endtime);
                        cmd.Parameters.AddWithValue("@Shift", shift);
                        try
                        {
                            await conn.OpenAsync();
                            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                            {
                                DataSet dt = new DataSet();
                                adapter.Fill(dt);
                                if (dt.Tables[0].Rows.Count > 0)
                                {
                                    Thread t = new Thread((ThreadStart)(() =>
                                    {
                                        var saveFileDialog1 = new SaveFileDialog();
                                        saveFileDialog1.Filter = "csv files (*.csv)|*.csv";
                                        saveFileDialog1.Title = "Alarm History Data";
                                        saveFileDialog1.FilterIndex = 2;
                                        saveFileDialog1.ShowDialog();
                                        saveFileDialog1.RestoreDirectory = true;
                                        if (saveFileDialog1.FileName.Length > 0)
                                        {
                                            writeCSV(dt, saveFileDialog1.FileName.ToString());
                                        }
                                    }));
                                    t.SetApartmentState(ApartmentState.STA);
                                    t.Start();
                                    t.Join();
                                }


                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Alarm Screen--Error in this function:btnSave_Click()" + ex);
                            return;
                        }
                    }
                }

            }
        }
        private void writeCSV(DataSet paramDset, string fileName)
        {
            StreamWriter sw = new StreamWriter(fileName, false);
            //headers
            try
            {
                for (int i = 0; i < paramDset.Tables[0].Columns.Count; i++)
                {
                    sw.Write(paramDset.Tables[0].Columns[i]);
                    if (i < paramDset.Tables[0].Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
                foreach (DataRow dr in paramDset.Tables[0].Rows)
                {
                    for (int i = 0; i < paramDset.Tables[0].Columns.Count; i++)
                    {
                        if (!Convert.IsDBNull(dr[i]))
                        {
                            string value = dr[i].ToString();
                            if (value.Contains(','))
                            {
                                value = String.Format("\"{0}\"", value);
                                sw.Write(value);
                            }
                            else
                            {
                                sw.Write(dr[i].ToString());
                            }
                        }
                        if (i < paramDset.Tables[0].Columns.Count - 1)
                        {
                            sw.Write(",");
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alarm Screen--Error in this function:writeCSV()" + ex);
                return;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void chartControl2_Click(object sender, EventArgs e)
        {

        }

        private void cmbShift_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged_1(object sender, EventArgs e)
        {

        }

        private void gridControl1_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void gridControl1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //public void InsertAlrm(int Alarmcode, bool status)
        //{
        //    if (status)
        //    {
        //        GlobalVar.LiveAlrmdt.Rows.Add();
        //        DataRow match = GlobalVar.AlrmDescdt.Select($"{Alarmcode} = Alarmcode ").SingleOrDefault();
        //        GlobalVar.LiveAlrmdt.Rows[Rowcnt][0] = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss ffff");
        //        GlobalVar.LiveAlrmdt.Rows[Rowcnt][1] = DateTime.Now.ToString("HH:mm:ss ffff");
        //        GlobalVar.LiveAlrmdt.Rows[Rowcnt][2] = Alarmcode;
        //        GlobalVar.LiveAlrmdt.Rows[Rowcnt][3] = match[1].ToString();
        //        GlobalVar.LiveAlrmdt.Rows[Rowcnt][4] = match[2].ToString();
        //        Rowcnt += 1;
        //        gridControl1.DataSource = null;
        //        gridControl1.DataSource = GlobalVar.LiveAlrmdt;
        //        gridControl1.RefreshDataSource();
        //        gridView1.PopulateColumns();
        //        gridView1.BestFitColumns();
        //        gridControl1.Update();
        //        gridControl1.Refresh();
        //    }
        //    else
        //    {
        //        //sql update
        //        DataRow match = GlobalVar.LiveAlrmdt.Select($"{Alarmcode} = Alarmcode ").SingleOrDefault();
        //        Delete(GlobalVar.LiveAlrmdt, match);

        //    }
        //}
        //public DataTable Delete(DataTable table, DataRow Dtrw)
        //{
        //    table.Rows.Remove(Dtrw);
        //    return table;
        //}
        //public void Onload_Alarm()
        //{
        //    gridControl1.DataSource = GlobalVar.LiveAlrmdt;

        //    gridControl1.RefreshDataSource();
        //    gridView1.PopulateColumns();
        //    gridView1.BestFitColumns();
        //    gridControl1.Update();
        //    gridControl1.Refresh();
        //}





    }
}