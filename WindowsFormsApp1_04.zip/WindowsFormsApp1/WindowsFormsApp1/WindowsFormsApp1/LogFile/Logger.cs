﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//using Advantech.Motion;//Common Motion API
namespace AHDP
{
    class Logger
    {
        public static object locker = new object();

        //public static string _dirPath { get; set; } = string.Empty;
        public static string _dirPath = @"D:\TEAL\G1\Log";
        public static int _fileSize { get; set; }
        public static int _fileDayCount = 30;
        public static string fileHeading = "Date,Time,Module,Function,Station,Category,Message";
        public static DateTime Now { get; }

        public static bool CheckDirectory(string DirectoryPath)
        {
            try
            {
                if ((Directory.Exists(DirectoryPath) == false))
                    Directory.CreateDirectory(DirectoryPath);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public static bool CheckFile(string FilePath)
        {
            try
            {
                StreamWriter streamWriter;
                if ((File.Exists(FilePath) == false))
                {
                    FileStream Str;
                    Str = File.Create(FilePath);
                    Str.Close();
                    Str.Dispose();
                    streamWriter = new StreamWriter(FilePath, true);
                    streamWriter.WriteLine(fileHeading);
                    streamWriter.Close();
                    streamWriter.Dispose();
                    File.SetAttributes(FilePath, FileAttributes.ReadOnly);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public static async Task<bool> WriteLog_1(string ModuleName, string FunctionName, string StationName, string Category, string LogMessage)
        {

            lock (locker)
            {
                try
                {


                    string dtFileName = System.DateTime.Now.ToString("dd-MM-yyyy");
                    string Filename = "";
                    StreamWriter SW;

                    string[] sNameSplit;
                    string sLastFilePath;
                    int iLoop = 0;
                    int sTmp;
                  
                    // Set default values
                    if (_fileDayCount == 0)
                    {
                        _fileDayCount = 150;
                    }
                    _fileSize = 20;

                     Filename = _dirPath + @"\" + dtFileName + ".csv";
                    List<string> sList = new List<string>();
                    System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(_dirPath);
                    if (dir.GetFiles("*.csv").Count() > 0)
                    {
                        foreach (System.IO.FileInfo file in dir.GetFiles().OrderByDescending(p => p.LastWriteTime).ToArray())
                        {
                            DateTime dt = DateTime.Parse(file.LastWriteTime.ToString());
                            var dateString = dt.ToString("dd-MM-yyyy");
                            if (dateString == dtFileName)
                            {
                                if (file.FullName.ToString().Contains(dtFileName))
                                    sList.Add(file.FullName.ToString());
                            }
                        }


                        if (sList.Count > 1)
                        {
                            sLastFilePath = sList[0];
                            sNameSplit = Path.GetFileName(sLastFilePath).Split('_');
                            sTmp = Convert.ToInt32(sNameSplit[1].Replace(".csv", ""));
                            iLoop = sTmp + 1;
                        }
                        else
                            sLastFilePath = _dirPath + @"\" + DateTime.Now.ToString("dd-MM-yyyy") + ".csv";
                        Filename = sLastFilePath;

                        FileInfo pthFile = new FileInfo(Filename);
                        if (File.Exists(Filename))
                        {
                            if ((pthFile.Length / (double)1048576) > (_fileSize))
                            {
                                if (sList.Count > 1)
                                    Filename = _dirPath + @"\" + dtFileName + "_" + iLoop + ".csv";
                                else
                                    Filename = _dirPath + @"\" + dtFileName + "_1" + ".csv";
                            }
                        }
                    }

                    if (CheckFile(Filename))
                    {
                        if (File.GetAttributes(Filename) == FileAttributes.ReadOnly)
                            File.SetAttributes(Filename, FileAttributes.Normal);
                        SW = new StreamWriter(Filename, true);
                        SW.WriteLine(DateTime.Now.ToString("yyyy-MM-dd").ToString() + "," + DateTime.Now.ToString("hh:mm:ss ffff") + "," + ModuleName + "," + FunctionName + "," + StationName + "," + Category + "," + LogMessage);
                        SW.Close();
                    }
                    File.SetAttributes(Filename, FileAttributes.ReadOnly);

                    if (_fileDayCount > 1)
                    {
                        foreach (System.IO.FileInfo file in dir.GetFiles())
                        {
                            if ((Now - file.LastWriteTime).Days > _fileDayCount - 1)
                                file.Delete();
                        }
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }

        }
    

        public static bool WriteLog(string ModuleName, string FunctionName, string StationName, string Category, string LogMessage)
        {

            lock (locker)
            {
                try
                {


                    string dtFileName = System.DateTime.Now.ToString("dd-MM-yyyy");
                    string Filename = "";
                    StreamWriter SW;

                    string[] sNameSplit;
                    string sLastFilePath;
                    int iLoop = 0;
                    int sTmp;


                    Filename = _dirPath + @"\" + dtFileName + ".csv";
                    List<string> sList = new List<string>();
                    System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(_dirPath);
                    if (dir.GetFiles("*.csv").Count() > 0)
                    {
                        foreach (System.IO.FileInfo file in dir.GetFiles().OrderByDescending(p => p.LastWriteTime).ToArray())
                        {
                            DateTime dt = DateTime.Parse(file.LastWriteTime.ToString());
                            var dateString = dt.ToString("dd-MM-yyyy");
                            if (dateString == dtFileName)
                            {
                                if (file.FullName.ToString().Contains(dtFileName))
                                    sList.Add(file.FullName.ToString());
                            }
                        }


                        if (sList.Count > 1)
                        {
                            sLastFilePath = sList[0];
                            sNameSplit = Path.GetFileName(sLastFilePath).Split('_');
                            sTmp = Convert.ToInt32(sNameSplit[1].Replace(".csv", ""));
                            iLoop = sTmp + 1;
                        }
                        else
                            sLastFilePath = _dirPath + @"\" + DateTime.Now.ToString("dd-MM-yyyy") + ".csv";
                        Filename = sLastFilePath;
                        _fileSize = 20;
                        FileInfo pthFile = new FileInfo(Filename);
                        if (File.Exists(Filename))
                        {
                            if ((pthFile.Length / (double)1048576) > (_fileSize))
                            {
                                if (sList.Count > 1)
                                    Filename = _dirPath + @"\" + dtFileName + "_" + iLoop + ".csv";
                                else
                                    Filename = _dirPath + @"\" + dtFileName + "_1" + ".csv";
                            }
                        }
                    }

                    if (CheckFile(Filename))
                    {
                        if (File.GetAttributes(Filename) == FileAttributes.ReadOnly)
                            File.SetAttributes(Filename, FileAttributes.Normal);
                        SW = new StreamWriter(Filename, true);
                        SW.WriteLine(DateTime.Now.ToString("yyyy-MM-dd").ToString() + "," + DateTime.Now.ToString("hh:mm:ss ffff") + "," + ModuleName + "," + FunctionName + "," + StationName + "," + Category + "," + LogMessage);
                        SW.Close();
                    }
                    File.SetAttributes(Filename, FileAttributes.ReadOnly);

                    if (_fileDayCount > 1)
                    {
                        foreach (System.IO.FileInfo file in dir.GetFiles())
                        {
                            if ((Now - file.LastWriteTime).Days > _fileDayCount - 1)
                                file.Delete();
                        }
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }

        }
      
    }
}
