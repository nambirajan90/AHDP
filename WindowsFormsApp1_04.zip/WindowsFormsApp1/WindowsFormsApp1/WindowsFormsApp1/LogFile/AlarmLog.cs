﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AHDP.LogFile
{
    public class AlarmLog
    {
        string defltPath;
        string fileName = string.Empty;
        int maxFileCount = 150;
        int maxDays = 30;
        int sizeMax = 8;
        public AlarmLog(String log)
        {
            this.defltPath = log;
        }
        public bool WriteLog(string StartTime, string EndTime, string ErrorCode, string ErrorMessage, string priority, string shift)
        {

            // This macro will write the given log message in the CSV with respect to datetime
            try
            {
                // Holds the runtime path


                if (CheckDirectory(defltPath))
                {
                    string curDate = DateTime.Now.ToString("ddMMyyyy"); // Holds current date
                    string curFileName = string.Concat(curDate, ".txt"); // Holds the current file name
                    double filSize = 8d; // Holds the size of file

                    // Check info of last error file
                    if (string.IsNullOrEmpty(fileName) | fileName.Contains(curDate) == true)
                    {
                        var fileDir = new DirectoryInfo(defltPath);
                        var fileList = fileDir.GetFiles("*.txt"); // Holds the file list
                        if (fileList.Length > 0)
                        {
                            var fileRef = default(DateTime);  // Holds the last file info                        

                            // Set default values
                            if (maxFileCount == 0)
                            {
                                maxFileCount = 150;
                            }
                            else if (maxDays == 0)
                            {
                                maxDays = 30;
                            }

                            foreach (FileInfo file in fileList)
                            {
                                if (file.FullName.Contains(curDate))
                                {

                                    // Sort the last created file
                                    if (file.CreationTime > fileRef)
                                    {
                                        fileRef = file.CreationTime;
                                        curFileName = file.Name;
                                        filSize = file.Length / 1048576d;
                                    }
                                }
                                // Maintain Last 30 days file
                                if ((DateTime.Now - file.LastWriteTime).Days > maxDays)
                                {
                                    file.Delete();
                                }
                            }

                            // check the length of last file and create new file                        

                            // Set default size
                            if (sizeMax == 0)
                            {
                                sizeMax = 8;
                            }

                            if (filSize > sizeMax)
                            {
                                int sufCount = Convert.ToInt32(curFileName.Substring(9, curFileName.Length - 13)) + 1;
                                curFileName = string.Concat(curDate, "_", sufCount, ".txt");
                            }
                            fileName = string.Concat(defltPath, curFileName);
                        }
                        else
                        {
                            fileName = string.Concat(defltPath, curFileName);
                        }
                    }
                    else
                    {
                        fileName = string.Concat(defltPath, curFileName);
                    }

                    var logFile = new FileInfo(fileName);
                    if (CheckFile(fileName))
                    {
                        filSize = logFile.Length / 1048576d; // Holds the size of file
                                                             // Enter log message in the created file
                        StreamWriter SW;
                        SW = new StreamWriter(fileName, true);

                        string logDetails = string.Concat(StartTime, "   ", ErrorCode, "    ", ErrorMessage, "    ", priority, "    ", shift);
                        // Holds the log message
                        SW.WriteLine(logDetails);

                        SW.Close();
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                string ErrorLog_Status = "AlarmLog_Status";
                return false;
            }

            return true;
        }

        public bool CheckDirectory(string DirectoryPath)
        {
            try
            {
                if (Directory.Exists(DirectoryPath) == false)
                {
                    Directory.CreateDirectory(DirectoryPath);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }

        public bool CheckFile(string FilePath)
        {
            try
            {
                if (File.Exists(FilePath) == false)
                {
                    FileStream Str;
                    Str = File.Create(FilePath);
                    Str.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }







    }
}
