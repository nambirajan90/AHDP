﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AHDP;

namespace AHDP
{
    static class Sessions
    {
        public static string userId { get; set; }
        public static string authentication { get; set; }
    }
}
    