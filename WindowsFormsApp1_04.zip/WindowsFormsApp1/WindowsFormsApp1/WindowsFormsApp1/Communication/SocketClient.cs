﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace AHDP
{
    public class SocketClient
    {
        #region "InitialiZation"
        public static TCPIPClient.TCPIPClient Vision1 = new TCPIPClient.TCPIPClient("Vision1");
        public static TCPIPClient.TCPIPClient Vision3 = new TCPIPClient.TCPIPClient("Vision3");
        public static TCPIPClient.TCPIPClient Vision4 = new TCPIPClient.TCPIPClient("Vision4");
        public static TCPIPClient.TCPIPClient Vision5 = new TCPIPClient.TCPIPClient("Vision5");
        public static TCPIPClient.TCPIPClient Scanner = new TCPIPClient.TCPIPClient("Scanner");
        public static TCPIPClient.TCPIPClient Robo = new TCPIPClient.TCPIPClient("Robo");
        public static TCPIPClient.TCPIPClient SFC = new TCPIPClient.TCPIPClient("SFC");
        public static TCPIPClient.TCPIPClient PDCA = new TCPIPClient.TCPIPClient("PDCA");
        public static System.Threading.Timer TCPRecieveVsn1;
        public static System.Threading.Timer TCPRecieveVsn3;
        public static System.Threading.Timer TCPRecieveVsn4;
        public static System.Threading.Timer TCPRecieveVsn5;
        public static System.Threading.Timer TCPRecieveScnr;
        public static System.Threading.Timer TCPRecieveRobo;
        public static System.Threading.Timer TCPRecieveSFC;
        public static System.Threading.Timer TCPRecievePDCA;
        public static string V_ReceiveData = string.Empty;
        public static string Robo_ReceiveData = string.Empty;
        public static string V_ReceiveData_T1 = string.Empty;
        public static string V_ReceiveData_T3 = string.Empty;
        public static string V_ReceiveData_T4 = string.Empty;
        public static string V_ReceiveData_T5 = string.Empty;
        public static string V_ReceiveData_LocatingProduction = string.Empty;
        public static string V_ReceiveData_T1_1 = string.Empty;
        public static string V_ReceiveData_T3_1 = string.Empty;
        public static string V_ReceiveData_T4_1 = string.Empty;
        public static string V_ReceiveData_T5_1 = string.Empty;
        public static string V_ReceiveData_LocatingProduction1 = string.Empty;
        public static string V_ReceiveData4 = string.Empty;
        public static string _V_ReceiveData2 = string.Empty;
        public static string V_ReceiveData2 = string.Empty;
        public static string V_ReceiveData_Q = string.Empty;
        public static string V_ReceiveData4_Q = string.Empty;
        public static string _V_ReceiveData2_Q = string.Empty;
        public static string[] Pre_Inspect = new string[5];
        public static string[] Post_Inspect = new string[5];
        public static string[] Nozzle_Inspect = new string[5];
        public static Queue VisionRecieve_Q_Nozzle_Insp = new Queue();
        public static Queue VisionRecieve_Q_Pre_Insp = new Queue();
        public static Queue VisionRecieve_Q_Post_Insp = new Queue();
        public static calibration_settings cal;
        //Scanner
        public static calibration_settings Scan;
        public static string V_ReceiveData2_Q
        {
            get
            {
                return _V_ReceiveData2_Q;
            }
            set
            {

                if (value != _V_ReceiveData2_Q)
                {
                    _V_ReceiveData2_Q = value;


                    if (value.ToUpper().Contains("T1") && !value.ToUpper().Contains("GROUP") && !value.ToUpper().Contains("CCD1"))
                    {
                        try
                        {
                            string[] Split = value.Split(',');
                            VisionRecieve_Q_Nozzle_Insp.Enqueue(value);
                            //TLN_array[Convert.ToInt32(Split[1])] = Form1.VisionRecieve_Q.Dequeue().ToString();
                            Nozzle_Inspect[Convert.ToInt32(Split[1])] = VisionRecieve_Q_Nozzle_Insp.Dequeue().ToString();
                            //TFC_Onfly_array[Convert.ToInt32(Split[1])] = TFC_array[Convert.ToInt32(Split[1])];
                        }
                        catch (Exception ex)
                         {

                         }
                    }
                    if (value.ToUpper().Contains("T2") && !value.ToUpper().Contains("GROUP") && !value.ToUpper().Contains("CCD1"))
                    {
                        try
                        {
                            string[] Split = value.Split(',');
                            VisionRecieve_Q_Pre_Insp.Enqueue(value);
                            // TLN_array[Convert.ToInt32(Split[1])] = Form1.VisionRecieve_Q.Dequeue().ToString();
                            Pre_Inspect[Convert.ToInt32(Split[2])] = VisionRecieve_Q_Pre_Insp.Dequeue().ToString();
                            //TFC_Onfly_array[Convert.ToInt32(Split[1])] = TFC_array[Convert.ToInt32(Split[1])];
                        }
                        catch (Exception ex)
                        {

                        }

                    }

                    if (value.ToUpper().Contains("T2C") && !value.ToUpper().Contains("GROUP") && !value.ToUpper().Contains("CCD1"))
                    {
                        try
                        {
                            string[] Split = value.Split(',');
                            VisionRecieve_Q_Post_Insp.Enqueue(value);
                            // TLN_array[Convert.ToInt32(Split[1])] = Form1.VisionRecieve_Q.Dequeue().ToString();
                            Post_Inspect[Convert.ToInt32(Split[1])] = VisionRecieve_Q_Pre_Insp.Dequeue().ToString();
                            //TFC_Onfly_array[Convert.ToInt32(Split[1])] = TFC_array[Convert.ToInt32(Split[1])];
                        }
                        catch (Exception ex)
                        {

                        }

                    }
                  


                }


            }
        }
        public static string V_ReceiveSCData_bf = string.Empty;
        public static string V_ReceiveScData = string.Empty;
        public static string V_ReceiveSCData2 = string.Empty;

        public static string V_ReceiveSFCData_bf = string.Empty;
        public static string V_ReceiveSFcData = string.Empty;
        public static string V_ReceiveSFCData2 = string.Empty;

        public static string V_ReceiveRoboData_bf = string.Empty;
        public static string V_ReceiveRoboData = string.Empty;
        public static string V_ReceiveRoboData2 = string.Empty;

        public static string V_ReceivePDCAData_bf = string.Empty;
        public static string V_ReceivePDCAData = string.Empty;
        public static string V_ReceivePDCAData2 = string.Empty;
        static bool Vision_t1_Disconnect = false;
        static bool Vision_t3_Disconnect = false;
        static bool Vision_t4_Disconnect = false;
        static bool Vision_t5_Disconnect = false;
        static bool Scanner_Disconnect = false;
        static bool SFC_Disconnect = false;
        static bool PDCA_Disconnect = false;

        #endregion

         public static bool RoboConnectPrc = false;
        public static bool Connect_Robo()
        {
            
            try
            {
                if (!RoboConnectPrc)
                {
                    Robo.ConnectTCPIP();
                    if (Robo.TCPIP_Sts())
                    {
                        
                        RoboConnectPrc = true;
                        start_Thread_Receive_cmd_from_robo();
                    }
                }
                else
                {
                    RoboConnectPrc = true;
                }
                
            }
            catch(Exception es)
            {
                RoboConnectPrc= false;
                Logger.WriteLog("Socket_Client", "Connect_Robo", "Station", "Exception Error", es.ToString());
            }
            return RoboConnectPrc;
        }
        public static bool CCDConnectPrc = false;
        public static bool Connect_Vision()
        {
           
            try
            {

                if (!CCDConnectPrc)
                {
                    Vision1.ConnectTCPIP();
                    Vision3.ConnectTCPIP();
                    Vision4.ConnectTCPIP();
                    Vision5.ConnectTCPIP();
                    
                    if (Vision1.TCPIP_Sts()&& Vision3.TCPIP_Sts()&& Vision4.TCPIP_Sts()&& Vision5.TCPIP_Sts())
                    {
                        CCDConnectPrc = true;
                        start_Thread_Vision_T1();
                       start_Thread_Vision_T3();
                       start_Thread_Vision_T4();
                       start_Thread_Vision_T5();
                    }
                }
                else
                {
                  //  CCDConnectPrc = true;
                }
                

               
            }
            catch (Exception es)
            {

                CCDConnectPrc = false;
                Logger.WriteLog("Socket_Client", "CONNECT_VISION", "Station", "Exception Error", es.ToString());
            }
            return CCDConnectPrc;

        }
        public static bool ScanConnectPrc = false;
        public static bool Connect_Scnr()
        {    
            try
            {
                if (!ScanConnectPrc)
                {
                    Scanner.ConnectTCPIP();
                    if (Scanner.TCPIP_Sts())
                    {
                        
                        ScanConnectPrc = true;
                        start_Thread_Scanner();
                    }
                    //MessageBox.Show("Scanner Connected Successfully !!", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    ScanConnectPrc = true;
                    //MessageBox.Show("Scanner Already Connected !!", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Connect_Scanner", "Scanner_Station", "Error", es.ToString());
                ScanConnectPrc = false;
            }
            return ScanConnectPrc;

        }
        public static bool Connect_SFC()
        {
            bool Prc = false;
            try
            {
                SFC.ConnectTCPIP();
                Prc = true;
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Connect_SFC", "Station", "Error", es.ToString());
                Prc = false;
            }
            return Prc;

        }
        public static bool Connect_PDCA()
        {
            bool Prc = false;
            try
            {
                PDCA.ConnectTCPIP();
                Prc = true;
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "CONNECT_SFC", "Station", "Error", es.ToString());
                Prc = false;
            }
            return Prc;

        }


        //public static bool Check_Vision_Sts()
        //{
        //    bool prc = false;
        //    try
        //    {
        //        Vision1.ConnectTCPIP();
        //        start_Thread_Vision_T1();
        //        start_Thread_Vision_LocatingProduction();
        //        prc = Vision1.TCPIP_Sts();
        //        if (prc)
        //        {
        //            Vision_Disconnect = false;
        //        }
        //        else if (!Vision_Disconnect && !prc)
        //        {
        //            Vision_Disconnect = true;
        //            Vision1.client.Disconnect();
        //            Thread.Sleep(200);
        //            Vision1.ConnectTCPIP();
        //            prc = Vision1.TCPIP_Sts();
        //            if (!prc)
        //            {
        //                return prc;
        //            }
        //        }
        //    }
        //    catch (Exception es)
        //    {
        //        Logger.WriteLog("Socket_Client", "CHECK_VISION_STATUS", "Station", "Error", es.ToString());
        //    }
        //    return prc;
        //}
        public static bool Check_Vision_T1_Sts()
        {
            bool prc = false;
            try
            {
                Vision1.ConnectTCPIP();
                start_Thread_Vision_T1();
               
                prc = Vision1.TCPIP_Sts();
                if (prc)
                {
                    Vision_t1_Disconnect = false;
                }
                else if (!Vision_t1_Disconnect && !prc)
                {
                    Vision_t1_Disconnect = true;
                    Vision1.client.Disconnect();
                    Thread.Sleep(200);
                    Vision1.ConnectTCPIP();
                    prc = Vision1.TCPIP_Sts();
                    if (!prc)
                    {
                        return prc;
                    }
                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Check_Vision_T1_Sts", "Station", "Error", es.ToString());
            }
            return prc;
        }
        public static bool Check_Vision_T3_Sts()
        {
            bool prc = false;
            try
            {
                Vision3.ConnectTCPIP();
                start_Thread_Vision_T3();

                prc = Vision3.TCPIP_Sts();
                if (prc)
                {
                    Vision_t3_Disconnect = false;
                }
                else if (!Vision_t3_Disconnect && !prc)
                {
                    Vision_t3_Disconnect = true;
                    Vision3.client.Disconnect();
                    Thread.Sleep(200);
                    Vision3.ConnectTCPIP();
                    prc = Vision3.TCPIP_Sts();
                    if (!prc)
                    {
                        return prc;
                    }
                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Check_Vision_T3_Sts", "Station", "Error", es.ToString());
            }
            return prc;
        }
        public static bool Check_Vision_T4_Sts()
        {
            bool prc = false;
            try
            {
                Vision4.ConnectTCPIP();
                start_Thread_Vision_T4();

                prc = Vision4.TCPIP_Sts();
                if (prc)
                {
                    Vision_t4_Disconnect = false;
                }
                else if (!Vision_t4_Disconnect && !prc)
                {
                    Vision_t4_Disconnect = true;
                    Vision4.client.Disconnect();
                    Thread.Sleep(200);
                    Vision4.ConnectTCPIP();
                    prc = Vision4.TCPIP_Sts();
                    if (!prc)
                    {
                        return prc;
                    }
                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Check_Vision_T4_Sts", "Station", "Error", es.ToString());
            }
            return prc;
        }
        public static bool Check_Vision_T5_Sts()
        {
            bool prc = false;
            try
            {
                Vision5.ConnectTCPIP();
                start_Thread_Vision_T5();

                prc = Vision5.TCPIP_Sts();
                if (prc)
                {
                    Vision_t5_Disconnect = false;
                }
                else if (!Vision_t5_Disconnect && !prc)
                {
                    Vision_t5_Disconnect = true;
                    Vision5.client.Disconnect();
                    Thread.Sleep(200);
                    Vision5.ConnectTCPIP();
                    prc = Vision5.TCPIP_Sts();
                    if (!prc)
                    {
                        return prc;
                    }
                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Check_Vision_T5_Sts", "Station", "Error", es.ToString());
            }
            return prc;
        }
        public static bool Check_Scnr_Sts()
        {
            bool prc = false;
            try
            {
                Scanner.ConnectTCPIP();
                prc = Scanner.TCPIP_Sts();
                if (prc)
                {
                    Scanner_Disconnect = false;
                    start_Thread_Scanner();  
                  //X1Y1.Trig_X1Y1Scanner(1);
                }
                else if (!Scanner_Disconnect && !prc)
                {
                    Scanner_Disconnect = true;
                    Scanner.client.Disconnect();
                    Thread.Sleep(200);
                    Scanner.ConnectTCPIP();
                    prc = Scanner.TCPIP_Sts();
                    if (!prc)
                    {
                        return prc;
                    }
                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "CHECK_SCANNER_STATUS", "Scanner_Station", "Error", es.ToString());
            }
            return prc;
        }
        public static bool Check_SFC_Sts()
        {
            bool prc = false;
            try
            {
                prc = SFC.TCPIP_Sts();
                if (prc)
                {
                    SFC_Disconnect = false;
                }
                else if (!SFC_Disconnect && !prc)
                {
                    SFC_Disconnect = true;
                    SFC.client.Disconnect();
                    Thread.Sleep(200);
                    SFC.ConnectTCPIP();
                    prc = SFC.TCPIP_Sts();
                    if (!prc)
                    {
                        return prc;
                    }
                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "CHECK_SFC_STATUS", "Station", "Error", es.ToString());
            }
            return prc;
        }
        public static bool Check_PDCA_Sts()
        {
            bool prc = false;
            try
            {
                prc = PDCA.TCPIP_Sts();
                if (prc)
                {
                    PDCA_Disconnect = false;
                }
                else if (!PDCA_Disconnect && !prc)
                {
                    PDCA_Disconnect = true;
                    PDCA.client.Disconnect();
                    Thread.Sleep(200);
                    PDCA.ConnectTCPIP();
                    prc = PDCA.TCPIP_Sts();
                    if (!prc)
                    {
                        return prc;
                    }
                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "CHECK_PDCA_STATUS", "Station", "Error", es.ToString());
            }
            return prc;
        }
        public static void Recieve_VisionData_T1(object Sender)
        {
            if (!Thread_lock_T1)
            {
                Thread_lock_T1 = true;
                try
                {
                    var buffer = new byte[60001];

                    buffer = Vision1.getReceiveData();
                    if (buffer != null)
                    {
                        V_ReceiveData_T1_1 = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");
                        string tst1 = V_ReceiveData_T1_1.Trim().Replace("\0", "");
                        V_ReceiveData_T1 = tst1.Trim();
                    }
                    if (V_ReceiveData_T1.Contains("T1,1,1"))
                    {
                        //T1,1,1,BatteryX,BatteryY,BatteryAngle,GANTRY_TO_BACKLIGHT_X,GANTRY_TO_BACKLIGHT_Y,GANTRY_TO_BACKLIGHT_A
                        string[] Received_data_T1 = V_ReceiveData_T1.Split(',');
                        Globalvariable.BatteryX = Received_data_T1[3];
                        Globalvariable.BatteryY = Received_data_T1[4];
                        Globalvariable.BatteryAngle = Received_data_T1[5];
                        Globalvariable.GANTRY_TO_BACKLIGHT_X = Received_data_T1[6];
                        Globalvariable.GANTRY_TO_BACKLIGHT_Y = Received_data_T1[7];
                        Globalvariable.GANTRY_TO_BACKLIGHT_A = Received_data_T1[8];

                    }
                    else
                    {
                        Logger.WriteLog("Socket_Client", "Recieve_VisionData_T1", "Station", "Error", V_ReceiveData_T1);
                    }

                }
                catch (Exception es)
                {
                    Thread_lock_T1 = false;
                    Logger.WriteLog("Socket_Client", "Recieve_VisionData_T1", "Station", "Error", es.ToString());
                }
            }
            Thread_lock_T1 = false;


        }
        public static void Recieve_VisionData_T3(object Sender)
        {
            if (!Thread_lock_T3)
            {
                Thread_lock_T3 = true;
                try
                {
                    var buffer = new byte[60001];

                    buffer = Vision3.getReceiveData();
                    if (buffer != null)
                    {
                        V_ReceiveData_T3_1 = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");
                        string tst3 = V_ReceiveData_T3_1.Trim().Replace("\0", "");
                        V_ReceiveData_T3 = tst3.Trim();
                    }

                }
                catch (Exception es)
                {
                    Thread_lock_T3 = false;
                    Logger.WriteLog("Socket_Client", "Recieve_VisionData_T3", "Station", "Error", es.ToString());
                }
            }
            Thread_lock_T3 = false;

            
        }
        public static void Recieve_VisionData_T4(object Sender)
        {
            if (!Thread_lock_T4)
            {
                Thread_lock_T4 = true;
                try
                {
                    var buffer = new byte[60001];

                    buffer = Vision4.getReceiveData();
                    if (buffer != null)
                    {
                        V_ReceiveData_T4_1 = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");
                        string tst4 = V_ReceiveData_T4_1.Trim().Replace("\0", "");
                        V_ReceiveData_T4 = tst4.Trim();
                      //  receive();
                    }
                    if (V_ReceiveData_T4.Contains("T4,1,1"))
                    {
                        
                        //T4,4,1,B1,B2,B3,B4,B5，ROBOTPICK_TO_BACKLIGHT_X，ROBOTPICK_TO_BACKLIGHT_Y,ROBOTPICK_TO_BACKLIGHT_A，DeltaX，DeltaY，DeltaAngle
                          Globalvariable.T4_4_values_received = V_ReceiveData_T4_1.Split(',');
                        
                    }

                }
                catch (Exception es)
                {
                    Thread_lock_T4 = false;
                    Logger.WriteLog("Socket_Client", "Recieve_VisionData_T4", "Station", "Error", es.ToString());
                }
            }
            Thread_lock_T4 = false;

            
        }
        public static void Recieve_VisionData_T5(object Sender)
        {
            if (!Thread_lock_T5)
            {
                Thread_lock_T5 = true;
                try
                {
                    var buffer = new byte[60001];

                    buffer = Vision4.getReceiveData();
                    if (buffer != null)
                    {
                        V_ReceiveData_T5_1 = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");
                        string tst5 = V_ReceiveData_T5_1.Trim().Replace("\0", "");
                        V_ReceiveData_T5 = tst5.Trim();
                    }

                }
                catch (Exception es)
                {
                    Thread_lock_T5 = false;
                    Logger.WriteLog("Socket_Client", "Recieve_VisionData_T5", "Station", "Error", es.ToString());
                }
            }
            Thread_lock_T5 = false;

            
        }

        public static bool Proces = false;
        public static bool Recieve_VisionData_LocatingProduction(object Sender)
        {
            if (!Proces)
            {

                try
                {
                    string[] split_As_pos_all = new string[15];
                    var buffer = new byte[60001];

                    buffer = Vision1.getReceiveData();
                    if (buffer != null)
                    {
                        V_ReceiveData_LocatingProduction1 = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");
                        string tst = V_ReceiveData_LocatingProduction1.Trim().Replace("\0", "");
                        V_ReceiveData_LocatingProduction = tst.Trim();
                        split_As_pos_all = V_ReceiveData_LocatingProduction.Split(',');
                        Proces = true;


                    }
                }
                catch (Exception es)
                {
                    Logger.WriteLog("Socket_Client", "RECEIVE_VISION_DATA", "Station", "Error", es.ToString());
                }
            }
            else
            {
                Proces = false;
            }
            return Proces;

        }
        public static void Recieve_VisionData_Q(object Sender)
        {
            try
            {
                var buffer = new byte[60001];
                buffer = Vision1.getReceiveData();
                if (buffer != null)
                {
                    V_ReceiveData_Q = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");

                    string tst = V_ReceiveData_Q.Trim().Replace("\0", "");
                    V_ReceiveData2_Q = tst.Trim();
                   

                }


            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "RECEIVE_VISION_Q_DATA", "Station", "Error", es.ToString());
            }
        }
        public static void Recieve_Scanner_Data(object Sender)
        {
            try
            {
                    var buffer = new byte[60001];
                
                 buffer = Scanner.getReceiveData();

                    if (buffer != null)
                    {
                        V_ReceiveScData = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");
                        string tst = V_ReceiveScData.Trim().Replace("\0", "");
                        V_ReceiveSCData2 = tst.Trim();
                   

                    }
                




            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Receive_Scanner_data", "Scanner_Station", "Error", es.ToString());
            }

        }
        public static void Recieve_SFC_Data(object Sender)// Receive  SFC data from server
        {
            try
            {


                var buffer = new byte[60001];

                buffer = SFC.getReceiveData();
                if (buffer != null)
                {
                    V_ReceiveSFcData = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");

                    string tst = V_ReceiveSFcData.Trim().Replace("\0", "");
                    V_ReceiveSFCData2 = tst.Trim();

                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Receive_SFC_data", "Station", "Error", es.ToString());
            }

        }
        public static void Recieve_Robo_Data(object Sender)
        {
            try
            {


                var buffer = new byte[60001];

                buffer = Robo.getReceiveData();
                if (buffer != null)
                {
                    V_ReceiveRoboData = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");

                    string tst = V_ReceiveRoboData.Trim().Replace("\0", "");
                    V_ReceiveRoboData2 = tst.Trim();

                    //if (SocketClient.V_ReceiveRoboData2.Contains("Reset,1"))
                    //{
                    //    Home.Add_sequence("Robo Reset Done !!");
                    //}

                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Receive_Robo_data", "Station", "Error", es.ToString());
            }

        }
        public static void Recieve_PDCA_Data(object Sender)
        {
           
                var buffer = new byte[60001];
            try
            {
                buffer = PDCA.getReceiveData();
                if (buffer != null)
                {
                    V_ReceivePDCAData = Encoding.ASCII.GetString(buffer).Trim().Replace(@"\0", "");

                    string tst = V_ReceivePDCAData.Trim().Replace("\0", "");
                    V_ReceivePDCAData2 = tst.Trim();

                }
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "Receive_PDCA_data", "Station", "Error", es.ToString());
            }

        }
        public static string send_data_to_robo = string.Empty;
        public static string send_data_to_T1 = string.Empty;
        public static string send_data_to_T3 = string.Empty;
        public static string send_data_to_T4 = string.Empty;
        public static string send_data_to_T5 = string.Empty;
        public static string send_data_to_scanner = string.Empty;
        public static string send_data_to_SFC = string.Empty;
        public static string send_data_to_PDCA =  string.Empty;
        public static string send_data_to_HIVE = string.Empty;
        public static bool TCP_Senddata_Robo(string val)
        {
            try
            {
                if (Robo.client != null)
                {
                    Robo_ReceiveData = string.Empty;
                    //_V_ReceiveData2 = string.Empty;
                    //V_ReceiveData2 = string.Empty;
                    bool process = false;
                    val = val + "<CR><LF>";
                    process = Robo.SendDatav1(val);
                    Robo.ClearRcvdDta();
                    //  send_data = val;
                    if (!process)
                        Robo.ConnectTCPIP();
                    return process;
                }

            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_VISION", "Station", "Error", es.ToString());
            }
            return false;
        }
        public static bool TCP_Senddata_Vision_T1(string val)
        {
            try
            {
                if (Vision1.client != null)
                {
                    //V_ReceiveData = string.Empty;
                    //_V_ReceiveData2 = string.Empty;
                    //V_ReceiveData2 = string.Empty;
                    bool process = false;
                    val = val + "<CR><LF>";
                    process = Vision1.SendDatav1(val);
                    send_data_to_T1 = val;
                    if (!process)
                        Vision1.ConnectTCPIP();
                    return process;
                }
                
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_VISION_T1", "Station", "Error", es.ToString());
            }
            return false;
        }
        public static bool TCP_Senddata_Vision_T3(string val)
        {
            try
            {
                if (Vision3.client != null)
                {
                    //V_ReceiveData = string.Empty;
                    //_V_ReceiveData2 = string.Empty;
                    //V_ReceiveData2 = string.Empty;
                    bool process = false;
                    val = val + "<CR><LF>";
                    process = Vision3.SendDatav1(val);
                    send_data_to_T3 = val;
                    if (!process)
                        Vision3.ConnectTCPIP();
                    return process;
                }

            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_VISION_T3", "Station", "Error", es.ToString());
            }
            return false;
        }
        public static bool TCP_Senddata_Vision_T4(string val)
        {
            try
            {
                Vision4.ConnectTCPIP();
                if (Vision4.client != null)
                {
                    //V_ReceiveData = string.Empty;
                    //_V_ReceiveData2 = string.Empty;
                    //V_ReceiveData2 = string.Empty;
                    bool process = false;
                    val = val + "<CR><LF>";
                    process = Vision4.SendDatav1(val);
                    send_data_to_T4 = val;
                    if (!process)
                        Vision4.ConnectTCPIP();
                    return process;
                }

            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_VISION_T4", "Station", "Error", es.ToString());
            }
            return false;

        }
        public static bool TCP_Senddata_Vision_T5(string val)
        {
            try
            {
                if (Vision5.client != null)
                {
                    //V_ReceiveData = string.Empty;
                    //_V_ReceiveData2 = string.Empty;
                    //V_ReceiveData2 = string.Empty;
                    bool process = false;
                    val = val + "<CR><LF>";
                    process = Vision5.SendDatav1(val);
                    send_data_to_T5 = val;
                    if (!process)
                        Vision5.ConnectTCPIP();
                    return process;
                }

            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_VISION_T5", "Station", "Error", es.ToString());
            }
            return false;
        }

        public static bool Scanner_Triggered = false;
        public static bool TCP_Senddata_Scanner(string val)
        {
            try
            {
                if (Scanner.client != null)
                {
                    
                    bool process = false;
                    val = val + "<CR><LF>";
                    process = Scanner.SendDatav1(val);
                    send_data_to_scanner = val;
                    if (!process)
                    Scanner.ConnectTCPIP();
                    return process;
                }
              
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_SCANNER", "Scanner_Station", "Error", es.ToString());
            }
            return false;
        }
        public static bool TCP_Senddata_SFC(string val)
        {
            try
            {
                if (SFC.client != null)
                {

                    bool process = false;
                    val = val + "<CR><LF>";
                    process = SFC.SendDatav1(val);
                    send_data_to_SFC = val;
                    if (!process)
                        SFC.ConnectTCPIP();
                    return process;
                }
               
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_SFC", "Scanner_Station", "Error", es.ToString());
            }
            return false;
        }
        public static bool TCP_Senddata_PDCA(string val)
        {
            try
            {

                if (SFC.client != null)
                {

                    bool process = false;
                    val = val + "<CR><LF>";
                    process = PDCA.SendDatav1(val);
                    send_data_to_PDCA = val;
                    if (!process)
                        PDCA.ConnectTCPIP();
                    return process;
                }
               
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_PDCA", "Scanner_Station", "Error", es.ToString());
            }
            return false;
        }
       public static bool Thread_lock_T1 = false;
       public static bool Thread_lock_T3 = false;
        public static bool Thread_lock_T4 = false;
        public static bool Thread_lock_T5 = false;

        public static void start_Thread_Vision_T1()
        {
            Thread_lock_T1 = false;
            TCPRecieveVsn1 = new System.Threading.Timer(new TimerCallback(Recieve_VisionData_T1), null, 200, 100);
        }
        public static void start_Thread_Vision_T3()
        {
            Thread_lock_T3 = false;
            TCPRecieveVsn3 = new System.Threading.Timer(new TimerCallback(Recieve_VisionData_T3), null, 200, 100);
        }
        public static void start_Thread_Vision_T4()
        {
            Thread_lock_T4 = false;
            TCPRecieveVsn4 = new System.Threading.Timer(new TimerCallback(Recieve_VisionData_T4), null, 200, 100);
        }
        public static void start_Thread_Vision_T5()
        {
            Thread_lock_T5 = false;
            TCPRecieveVsn5 = new System.Threading.Timer(new TimerCallback(Recieve_VisionData_T5), null, 200, 100);
        }
        public static void start_Thread_Vision_LocatingProduction()
        {
          //  TCPRecieveVsn = new System.Threading.Timer(new TimerCallback(Recieve_VisionData_LocatingProduction), null, 80, 80);
        }
        public static void start_Thread_Scanner()
        {
            TCPRecieveScnr = new System.Threading.Timer(new TimerCallback(Recieve_Scanner_Data), null, 200, 200);
        }
        public static void start_Thread_Receive_cmd_from_robo()
        {
            TCPRecieveRobo = new System.Threading.Timer(new TimerCallback(Recieve_Robo_Data), null, 200, 200);
        }
        public static void start_Thread_SFC()
        {
            TCPRecieveSFC = new System.Threading.Timer(new TimerCallback(Recieve_SFC_Data), null, 5, 2);
        }
        public static void start_Thread_PDCA()
        {
            TCPRecievePDCA = new System.Threading.Timer(new TimerCallback(Recieve_PDCA_Data), null, 5, 2);
        }
        public static void show(calibration_settings cal1)
        {
           // Thread.Sleep(int.Parse(cal.textBox1.Text));
            cal = cal1;
            start_Thread_Vision_T4();
        }


        public static bool stop_Thread_Vision_T4()
        {
            try
            {

                if (TCPRecieveVsn4 != null && Vision4!=null)
                {
                    TCPRecieveVsn4.Change(Timeout.Infinite, Timeout.Infinite);
                    Vision4.Dispose();

                    TCPRecieveVsn4.Dispose();
                    return true;

                }
                return false;
            }
            catch (Exception es)
            {
                Logger.WriteLog("VisionCalibration", "stop_thread_CCD1", "Station", "Exception Error", es.ToString());
                return false;
            }
           
        }



        public static void receive()
        {
            if (cal.RecivedDataCamera.InvokeRequired)
            {
                cal.RecivedDataCamera.Invoke(new Action(() =>
                { cal.RecivedDataCamera.Text =  V_ReceiveData_T4_1; }));
            }
            else
            {
                cal.RecivedDataCamera.Text = V_ReceiveData_T4_1;
            }
            

        }

        /// For   Scanner
        public static bool Thread_lock_Scanner = false;
        public static bool stop_Thread_Scanner()
        {
            try
            {

                if (TCPRecieveScnr != null && Scanner != null)
                {
                    TCPRecieveScnr.Change(Timeout.Infinite, Timeout.Infinite);
                    TCPRecieveScnr.Dispose();
                    Scanner.Dispose();

                    ////TCPRecieveScnr.Dispose();
                    return true;

                }
                return false;
            }
            catch (Exception es)
            {
                Logger.WriteLog("Scanner", "stop_Thread_Scanner", "Station", "Exception Error", es.ToString());
                return false;
            }

        }

        public static void scannershow(calibration_settings scannercal1)
        {
            Scan = scannercal1;
            start_Thread_Scanner();
        }

        public static void Scanreceive() //To recive the data from the hercules
        {

            if (Scan.RecieveData_Scanner.InvokeRequired)
            {
                Scan.RecieveData_Scanner.Invoke(new Action(() =>
                { Scan.RecieveData_Scanner.Text = V_ReceiveSCData2; }));
            }
            else
            {
                Scan.RecieveData_Scanner.Text = V_ReceiveSCData2;
            }


        }

        public static bool TCP_Connect_Scanner()
        {
            try
            {
                Scanner.ConnectTCPIP();
                return true;
            }
            catch (Exception es)
            {
                Logger.WriteLog("Socket_Client", "TCP_SEND_DATA_SCANNER", "Scanner_Station", "Error", es.ToString());
            }
            return false;

        }

    }
}
