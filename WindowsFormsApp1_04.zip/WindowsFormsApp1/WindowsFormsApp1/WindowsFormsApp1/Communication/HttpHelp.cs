﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Web;
using System.Net.Http;
using System.Windows.Forms;
using System.Net.Cache;
namespace AHDP
{
    public enum HttpMode
    {
       GET,
       POST,
    }
    public class HttpHelp
    {
      
        
        public string HttpGet(string _sUrl, string _sPostDataStr)
        {

            System.GC.Collect();
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(_sUrl + (_sPostDataStr == "" ? "" : "?") + _sPostDataStr);
            request.Method = "GET";
            request.KeepAlive = false;
            request.ContentType = "text/html;charset=UTF-8";
            string retString = null;

            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
                Stream myResponseStream = response.GetResponseStream();
                StreamReader myStreamReader = new StreamReader(myResponseStream, Encoding.GetEncoding("utf-8"));
                retString = myStreamReader.ReadToEnd();
                myStreamReader.Close();
                myResponseStream.Close();
            }
            catch (WebException ex)
            {
                // 30-10-2024 GlobClass.ThreadExWriteAndShow(string.Format("WebService.HttpGet异常,捕获异常：{0}\r\n异常堆栈：{1}", ex.Message, ex.StackTrace));
            }
            return retString;
        }
       
        public string HttpPost(string _sUrlWithParam)
        {
            System.GC.Collect();
            System.Net.ServicePointManager.DefaultConnectionLimit = 200;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(_sUrlWithParam);
            request.Method = "POST";
            request.KeepAlive = false;
            request.ContentType = "application/json;charset=UTF-8";
            byte[] byteReq = Encoding.GetEncoding("UTF-8").GetBytes(_sUrlWithParam);
            request.ContentLength = byteReq.Length;
            string retString = null;
            try
            {
                Stream stream;
                stream = request.GetRequestStream();
                stream.Write(byteReq, 0, byteReq.Length);
                stream.Close();
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                string encoding = response.ContentEncoding;
                if (encoding == null || encoding.Length < 1)
                {
                    encoding = "UTF-8"; //Default encoding
                }
                StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.GetEncoding(encoding));
                retString = reader.ReadToEnd();

                if (response != null)
                    response.Close();
                if (request != null)
                    request.Abort();

            }
            catch (Exception ex)
            {
                //30-10-2024 GlobClass.ThreadExWriteAndShow(string.Format("WebService.HttpPost exception, catch exception：{0}\r\n exception stack：{1}", ex.Message, ex.StackTrace));
            }

            return retString;

        }
       
        public string HttpPost(string _sUrl, string _sPostData)
        {
            string result = string.Empty;
            string param = string.Empty;
            byte[] bytes = null;
            Stream writer = null;
            HttpWebRequest request = null;
            HttpWebResponse response = null;
            param = HttpUtility.UrlEncode("p") + "=" + HttpUtility.UrlEncode(_sPostData);
            bytes = Encoding.UTF8.GetBytes(_sPostData);
            request = (HttpWebRequest)WebRequest.Create(_sUrl);
            request.Method = "POST";
            request.ContentType = "multipart/form-data";   //  application/x-www-form-urlencoded
            request.ContentLength = bytes.Length;
            writer = request.GetRequestStream();        //Get the Stream object used to write the requested data
            writer.Write(bytes, 0, bytes.Length);       //Write parameter data to the request data stream
            writer.Close();
            try
            {
                response = (HttpWebResponse)request.GetResponse();      //get response
                #region What is read in this way is a returned result string
                Stream stream = response.GetResponseStream();        //Get response stream

                using (var httpStreamReader = new StreamReader(stream, Encoding.GetEncoding("utf-8")))
                {
                    string responseContent = httpStreamReader.ReadToEnd();
                    result = responseContent;
                }
                //XmlTextReader Reader = new XmlTextReader(stream);
                //Reader.MoveToContent();
                //result = Reader.ReadInnerXml();
                #endregion
                response.Close();
                // Reader.Close();
                stream.Dispose();
                stream.Close();
            }
            catch (System.Exception ex)
            {
               //30-10-2024 GlobClass.ThreadExWriteAndShow(string.Format("WebService.HttpPost exception, catch exception：{0}\r\n exception stack：{1}", ex.Message, ex.StackTrace));
            }
            return result;
        }

        public string HttpSend(string _sURL,string _postdata,HttpMode _mode,Encoding _encoding)
        {
            string sReturn="";
            Encoding uTF = Encoding.UTF8;
            string contentType = "application/x-www-form-urlencoded";
            try
            {
                HttpWebRequest httpWebRequest = WebRequest.Create(_sURL) as HttpWebRequest;
                httpWebRequest.Method = _mode.ToString();
                httpWebRequest.Accept = "*/*";
                httpWebRequest.KeepAlive = false;
                httpWebRequest.CachePolicy = new HttpRequestCachePolicy(HttpRequestCacheLevel.NoCacheNoStore);
                if (_mode==HttpMode.POST)
                {
                    byte[] bytes = uTF.GetBytes(_postdata);
                    httpWebRequest.ContentType = contentType;
                    httpWebRequest.ContentLength = (long)bytes.Length;
                    Stream requestStream = httpWebRequest.GetRequestStream();
                    requestStream.Write(bytes, 0, bytes.Length);
                    requestStream.Close();
                }
                HttpWebResponse httpWebResponse = httpWebRequest.GetResponse() as HttpWebResponse;
                try
                {
                    using (Stream responseStream = httpWebResponse.GetResponseStream())
                    {
                        using (StreamReader streamReader = new StreamReader(responseStream, _encoding))
                        {
                            sReturn=streamReader.ReadToEnd();
                        }
                    }
                }
                finally
                {
                    httpWebResponse.Close();
                }
            }
            catch (Exception ex)
            {
                sReturn=ex.ToString();
            }
            return sReturn;
        }

        

        
    }
}
