﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AHDP;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Diagnostics;
using AHDP.UIScreens.ParameterSetting_Screens;

namespace AHDP
{
    public class Static_and_Dynamic_test
    {

    }
}
