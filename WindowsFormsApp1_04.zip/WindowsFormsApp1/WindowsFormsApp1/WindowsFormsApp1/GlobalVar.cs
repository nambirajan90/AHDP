﻿using AHDP.LogFile;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP
{
    public class GlobalVar
    {

        public GlobalVar()
        {
            Create_Alarm_buffer_dt();


        }
        public static int Feeder_Delay = 0;
        public static bool Resume_Sequence = false;
        //public static AlarmLiveScreen alrm = new AlarmLiveScreen();
        public static DataTable LiveAlrmdt = new DataTable();
        public static DataTable AlrmDescdt = new DataTable();
        public static int PulseMode = 0;
        public static int PulseLogic = 0;
        public static int PostCheck_Delay = 0;
        public static int PostCheck_Retrycnt = 0;
        public static int[] Nozzle_Ref = new int[5];
        public static string AckTime = string.Empty;
        public static int _Ack_errcode = 0;
        public static string Category = string.Empty;
        public static AlarmLog Alarmlog = new AlarmLog(GetDataFromXML.AlarmlogPath);
        public static RunningLog Runninglog = new RunningLog(GetDataFromXML.Runninglog);
        public static int Ack_errcode
        {
            get
            {
                return _Ack_errcode;
            }
            set
            {

                if (value != _Ack_errcode)
                {
                    _Ack_errcode = value;

                    if (value > 0)
                    {
                        try
                        {
                            //alrm.InsertAck_Alarm(_Ack_errcode);
                        }
                        catch (Exception es)
                        {

                        }



                    }

                }


            }
        }

        #region "User variables"
        public static string UserCode = string.Empty;
        public static string LoginMode = string.Empty;
        public static string Shift = string.Empty;
        public static string Machine_State = string.Empty;
        public static bool _Machine_sts = false;
        public static bool _Machine_sts_auto = false;
        public static bool _Tossing_sts = false;
        public static bool _Unit_failure_sts = false;
        public static bool Machine_sts
        {
            get
            {
                return _Machine_sts;
            }
            set
            {

                if (value != _Machine_sts)
                {
                    _Machine_sts = value;

                    if (value)
                    {
                        try
                        {
                            //int reslt = SQLHelper.Executequery("insert into machine_availability_production(shift,category,start_time)values('"+GlobalVar.Shift+"','Machine Idle Time',getdate())");
                        }
                        catch (Exception es)
                        {
                            Logger.WriteLog("GlobalVar.cs", "Machine Sts", "PropertyChange", "Exception Error", es.ToString());
                           
                        }
                        

                    }
                    else if (!value)
                    {
                        //int reslt = SQLHelper.Executequery("update  machine_availability_production set end_time=getdate() where row_id=(Select MAX(row_id) from machine_availability_production  where Category='Machine Idle Time')");
                    }
                }


            }
        }
        public static bool Machine_sts_auto
        {
            get
            {
                return _Machine_sts_auto;
            }
            set
            {

                if (value != _Machine_sts_auto)
                {
                    _Machine_sts_auto = value;

                    if (value)
                    {

                        try
                        {
                            //int reslt = SQLHelper.Executequery("insert into machine_availability_production(shift,category,start_time)values('"+GlobalVar.Shift+"','Machine Process Time',getdate())");
                        }
                        catch (Exception es)
                        {
                            Logger.WriteLog("GlobalVar.cs", "Machine Sts Auto", "PropertyChange", "Exception Error", es.ToString());

                        }
                    }
                    else if (!value)
                    {
                        //int reslt = SQLHelper.Executequery("update  machine_availability_production set end_time=getdate() where row_id=(Select MAX(row_id) from machine_availability_production where Category='Machine Process Time') ");

                    }
                }


            }
        }
        public static bool Tossing_sts
        {
            get
            {
                return _Tossing_sts;
            }
            set
            {

                if (value != _Tossing_sts)
                {
                    _Tossing_sts = value;

                    if (value)
                    {

                        try
                        {
                            //int reslt = SQLHelper.Executequery("insert into machine_availability_production(shift,category,start_time)values('" + GlobalVar.Shift + "','Tossing Time',getdate())");
                        }
                        catch (Exception es)
                        {
                            Logger.WriteLog("GlobalVar.cs", "Tossing_sts", "PropertyChange", "Exception Error", es.ToString());

                        }
                    }
                    else if (!value)
                    {
                        //int reslt = SQLHelper.Executequery("update  machine_availability_production set end_time=getdate() where row_id=(Select MAX(row_id) from machine_availability_production where Category='Tossing Time') ");

                    }
                }


            }
        }
        public static bool Unit_failure_sts
        {
            get
            {
                return _Unit_failure_sts;
            }
            set
            {

                if (value != _Unit_failure_sts)
                {
                    _Unit_failure_sts = value;

                    if (value)
                    {

                        try
                        {
                            //int reslt = SQLHelper.Executequery("insert into machine_availability_production(shift,category,start_time)values('" + GlobalVar.Shift + "','UnitFailure Time',getdate())");
                        }
                        catch (Exception es)
                        {
                            Logger.WriteLog("GlobalVar.cs", "Tossing_sts", "PropertyChange", "Exception Error", es.ToString());

                        }
                    }
                    else if (!value)
                    {
                       // int reslt = SQLHelper.Executequery("update  machine_availability_production set end_time=getdate() where row_id=(Select MAX(row_id) from machine_availability_production where Category='UnitFailure Time') ");

                    }
                }


            }
        }
        public static DateTime Machine_state_strt_dt;
        public static DateTime Machine_state_strt_dt_auto;
        public static DateTime Tossing_strt_dt;
        public static DateTime Unit_failure_strt_dt_auto;
        public static string User_Mode = string.Empty;
        #endregion
     
      
        #region "AlarmVariable"
        #region "AlarmCode"


        public static int ExceptionError_code = 1;
        public static int Gantry_Move_Error_code = 2;
        public static int Gantry_X_Error_code = 3;
        public static int Gantry_Y_Error_code = 4;
        public static int Nozzle_Z1_Error_code = 5;
        public static int Nozzle_Z2_Error_code = 6;
        public static int Nozzle_Z3_Error_code = 7;
        public static int Nozzle_Z4_Error_code = 8;
        public static int Nozzle_A1_Error_code = 9;
        public static int Nozzle_A2_Error_code = 10;
        public static int Nozzle_A3_Error_code = 11;
        public static int Nozzle_A4_Error_code = 12;
        public static int Axis_Error_code = 13;
        public static int DIO_Error_code = 14;
        public static int Motion_Timeout_code = 15;
        public static int Vision_Connection_Error_code = 16;
        public static int Vision_Send_Error_code = 17;
        public static int Vision_TLM_Error_code = 18;
        public static int Vision_Recieve_Error_code = 19;
        public static int Ejection_Vaccum_Error_code = 20;
        public static int Gantry_Home_Error_code = 21;
        public static int E_Stop_code = 22;
        public static int Safety_Relay_code = 23;
        public static int Main_Pressure_Swtch_code = 24;
        public static int Pallet_Lft_up_Autoseq_code = 25;// In auto while running or before start check PALLET IS LIFT UP
        public static int Axis_Disconnect_Error_code = 26;
        public static int IO_Disconnect_Error_code = 27;

        public static int Gantry_X_Max_MM_Error_code = 28;
        public static int Gantry_Y_Max_MM_Error_code = 29;// In auto while running or before start check PALLET IS LIFT UP
        public static int Nozzle_Z__Max_MM_Error_code = 30;
        public static int Nozzle_Ang__Max_Deg_Error_code = 31;
        public static int Vaccum1_ff_error_code = 32;
        public static int Vaccum2_ff_error_code = 33;
        public static int Vaccum3_ff_error_code = 34;
        public static int Vaccum4_ff_error_code = 35;
        //Have to include in databse and create property for below
        public static int Cowling_Abs_error_code = 36;
        public static int Both_FEEDER_Empty_Error_code = 37;
        public static int Stepper_cmmnctn_error_code = 38;
        public static int Loader_Empty_error_code = 39;
        public static int Rotory_home_sensor_error_code = 40;
        #endregion
        #region "Alrm PropertyVar"
        public static int _ExceptionError = 0;
        public static int _Rotory_home_sensor_error = 0;
        public static int _Gantry_Home_Error = 0;
        public static int _Gantry_Move_Error = 0;
        public static int _Gantry_X_Error = 0;
        public static int _Gantry_Y_Error = 0;
        public static int _Nozzle_Z1_Error = 0;
        public static int _Nozzle_Z2_Error = 0;
        public static int _Nozzle_Z3_Error = 0;
        public static int _Nozzle_Z4_Error = 0;
        public static int _Nozzle_A1_Error = 0;
        public static int _Nozzle_A2_Error = 0;
        public static int _Nozzle_A3_Error = 0;
        public static int _Nozzle_A4_Error = 0;
        public static int _Axis_Error = 0;
        public static int _DIO_Error = 0;
        public static int _Motion_Timeout = 0;
        public static int _Vision_Connection_Error = 0;
        public static int _Vision_Send_Error = 0;
        public static int _Vision_TLM_Error = 0;
        public static int _Vision_Recieve_Error = 0;
        public static int _Ejection_Vaccum_Error = 0;
        public static int _E_Stop = 0;
        public static int _Safety_Relay = 0;
        public static int _Main_Pressure_Swtch = 0;
        public static int _Pallet_Lft_up_Autoseq = 0;
        public static int _Axis_Disconnect_Error = 0;
        public static int _IO_Disconnect_Error = 0;
        public static int _Gantry_X_Max_MM_Error = 0;
        public static int _Gantry_Y_Max_MM_Error = 0;// In auto while running or before start check PALLET IS LIFT UP
        public static int _Nozzle_Z__Max_MM_Error = 0;
        public static int _Nozzle_Ang__Max_Deg_Error = 0;
        public static int _Vaccum1_ff_error = 0;
        public static int _Vaccum2_ff_error = 0;
        public static int _Vaccum3_ff_error = 0;
        public static int _Vaccum4_ff_error = 0;
        public static int _Cowling_Abs_error = 0;
        public static int _Both_FEEDER_Empty_Error = 0;
        public static int _Stepper_cmmnctn_error = 0;
        public static int _Loader_Empty_error = 0;
        #endregion

        public static bool PopubActive = false;
        public static int _Error_code = 0;
        public static int cnt_err = 0;
        public static int Error_code
        {
            get
            {
                return _Error_code;
            }
            set
            {

                if (value != _Error_code)
                {
                    _Error_code = value;

                    if (value > 0)
                    {

                        if (!PopubActive)
                        {
                            if (Ack_errcode == 0)
                            {
                                cnt_err += 1;
                                PopubActive = true;
                              //  Form AlarmPopUp = new AlarmPopUp();
                               // AlarmPopUp.ShowDialog();

                            }


                        }

                    }
                    else if (value == 0)
                    {

                        InvokeRequired = false;
                       // Form1.Alarmbit = false;
                        //PopubActive = false;
                    }
                }


            }
        }

        private static void Invoke(MethodInvoker methodInvoker)
        {
            throw new NotImplementedException();
        }

        public static bool Error_Active = false;

        public static int ExceptionError
        {
            get
            {
                return _ExceptionError;
            }
            set
            {

                if (value != _ExceptionError)
                {
                    _ExceptionError = value;

                    if (value > 0)
                    {

                        //alrm.InsertAlrm(ExceptionError_code, true);
                        Error_code = ExceptionError_code;
                       // Form1.Process_Stop = true;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(ExceptionError_code, false);
                    }
                }


            }
        }
        public static int Rotory_home_sensor_error
        {
            get
            {
                return _Rotory_home_sensor_error;
            }
            set
            {

                if (value != _Rotory_home_sensor_error)
                {
                    _Rotory_home_sensor_error = value;

                    if (value > 0)
                    {

                       // alrm.InsertAlrm(Rotory_home_sensor_error_code, true);
                        Error_code = Rotory_home_sensor_error_code;
                       // Form1.Process_Stop = true;

                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Rotory_home_sensor_error_code, false);
                    }
                }


            }
        }
        public static int Gantry_Home_Error
        {
            get
            {
                return _Gantry_Home_Error;
            }
            set
            {

                if (value != _Gantry_Home_Error)
                {
                    _Gantry_Home_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Gantry_Home_Error_code, true);
                        Error_code = Gantry_Home_Error_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Gantry_Home_Error_code, false);
                    }
                }


            }
        }

        public static int Gantry_Move_Error
        {
            get
            {
                return _Gantry_Move_Error;
            }
            set
            {

                if (value != _Gantry_Move_Error)
                {
                    _Gantry_Move_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Gantry_Move_Error_code, true);
                        Error_code = Gantry_Move_Error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Gantry_Move_Error_code, false);
                    }
                }


            }
        }
        public static int Gantry_X_Error
        {
            get
            {
                return _Gantry_X_Error;
            }
            set
            {

                if (value != _Gantry_X_Error)
                {
                    _Gantry_X_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Gantry_X_Error_code, true);
                        Error_code = Gantry_X_Error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Gantry_X_Error_code, false);
                    }
                }


            }
        }
        public static int Gantry_Y_Error
        {
            get
            {
                return _Gantry_Y_Error;
            }
            set
            {

                if (value != _Gantry_Y_Error)
                {
                    _Gantry_Y_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Gantry_Y_Error_code, true);

                        Error_code = Gantry_Y_Error_code;
                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Gantry_Y_Error_code, false);
                    }
                }


            }
        }
        public static int Nozzle_Z1_Error
        {
            get
            {
                return _Nozzle_Z1_Error;
            }
            set
            {

                if (value != _Nozzle_Z1_Error)
                {
                    _Nozzle_Z1_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Nozzle_Z1_Error_code, true);
                        Error_code = Nozzle_Z1_Error_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Nozzle_Z1_Error_code, false);
                    }
                }


            }
        }
        public static int Nozzle_Z2_Error
        {
            get
            {
                return _Nozzle_Z2_Error;
            }
            set
            {

                if (value != _Nozzle_Z2_Error)
                {
                    _Nozzle_Z2_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Nozzle_Z2_Error_code, true);
                        Error_code = Nozzle_Z2_Error_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Nozzle_Z2_Error_code, false);
                    }
                }


            }
        }
        public static int Nozzle_Z3_Error
        {
            get
            {
                return _Nozzle_Z3_Error;
            }
            set
            {

                if (value != _Nozzle_Z3_Error)
                {
                    _Nozzle_Z3_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Nozzle_Z3_Error_code, true);
                        Error_code = Nozzle_Z3_Error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Nozzle_Z3_Error_code, false);
                    }
                }


            }
        }
        public static int Nozzle_Z4_Error
        {
            get
            {
                return _Nozzle_Z4_Error;
            }
            set
            {

                if (value != _Nozzle_Z4_Error)
                {
                    _Nozzle_Z4_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Nozzle_Z4_Error_code, true);
                        Error_code = Nozzle_Z4_Error_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Nozzle_Z4_Error_code, false);
                    }
                }


            }
        }
        public static int Nozzle_A1_Error
        {
            get
            {
                return _Nozzle_A1_Error;
            }
            set
            {

                if (value != _Nozzle_A1_Error)
                {
                    _Nozzle_A1_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Nozzle_A1_Error_code, true);
                        Error_code = Nozzle_A1_Error_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Nozzle_A1_Error_code, false);
                    }
                }


            }
        }
        public static int Nozzle_A2_Error
        {
            get
            {
                return _Nozzle_A2_Error;
            }
            set
            {

                if (value != _Nozzle_A2_Error)
                {
                    _Nozzle_A2_Error = value;

                    if (value > 0)
                    {
                     //   alrm.InsertAlrm(Nozzle_A2_Error_code, true);
                        Error_code = Nozzle_A2_Error_code;

                    }
                    else if (value == 0)
                    {
                      //  alrm.InsertAlrm(Nozzle_A2_Error_code, false);
                    }
                }


            }
        }
        public static int Nozzle_A3_Error
        {
            get
            {
                return _Nozzle_A3_Error;
            }
            set
            {

                if (value != _Nozzle_A3_Error)
                {
                    _Nozzle_A3_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Nozzle_A3_Error_code, true);
                        Error_code = Nozzle_A3_Error_code;


                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Nozzle_A3_Error_code, false);
                    }
                }


            }
        }

        public static int Nozzle_A4_Error
        {
            get
            {
                return _Nozzle_A4_Error;
            }
            set
            {

                if (value != _Nozzle_A4_Error)
                {
                    _Nozzle_A4_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Nozzle_A4_Error_code, true);
                        Error_code = Nozzle_A4_Error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Nozzle_A4_Error_code, false);
                    }
                }


            }
        }
        public static int Axis_Error
        {
            get
            {
                return _Axis_Error;
            }
            set
            {

                if (value != _Axis_Error)
                {
                    _Axis_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Axis_Error_code, true);
                        Error_code = Axis_Error_code;



                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Axis_Error_code, false);
                    }
                }


            }
        }

        public static int DIO_Error
        {
            get
            {
                return _DIO_Error;
            }
            set
            {

                if (value != _DIO_Error)
                {
                    _DIO_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(DIO_Error_code, true);

                        Error_code = DIO_Error_code;
                    }
                    else if (value == 0)
                    {
                     //   alrm.InsertAlrm(DIO_Error_code, false);
                    }
                }


            }
        }
        public static int Motion_Timeout
        {
            get
            {
                return _Motion_Timeout;
            }
            set
            {

                if (value != _Motion_Timeout)
                {
                    _Motion_Timeout = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Motion_Timeout_code, true);


                        Error_code = Motion_Timeout_code;
                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Motion_Timeout_code, false);
                    }
                }


            }
        }
        public static int Vision_Connection_Error
        {
            get
            {
                return _Vision_Connection_Error;
            }
            set
            {

                if (value != _Vision_Connection_Error)
                {
                    _Vision_Connection_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Vision_Connection_Error_code, true);
                        Error_code = Vision_Connection_Error_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Vision_Connection_Error_code, false);
                    }
                }


            }
        }
        public static int Vision_Send_Error
        {
            get
            {
                return _Vision_Send_Error;
            }
            set
            {

                if (value != _Vision_Send_Error)
                {
                    _Vision_Send_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Vision_Send_Error_code, true);
                        Error_code = Vision_Send_Error_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Vision_Send_Error_code, false);
                    }
                }


            }
        }
        public static int Vision_TLM_Error
        {
            get
            {
                return _Vision_TLM_Error;
            }
            set
            {

                if (value != _Vision_TLM_Error)
                {
                    _Vision_TLM_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Vision_TLM_Error_code, true);
                        Error_code = Vision_TLM_Error_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Vision_TLM_Error_code, false);
                    }
                }


            }
        }
        public static int Vision_Recieve_Error
        {
            get
            {
                return _Vision_Recieve_Error;
            }
            set
            {

                if (value != _Vision_Recieve_Error)
                {
                    _Vision_Recieve_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Vision_Recieve_Error_code, true);
                        Error_code = Vision_Recieve_Error_code;

                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Vision_Recieve_Error_code, false);
                    }
                }


            }
        }
        public static int Ejection_Vaccum_Error
        {
            get
            {
                return _Ejection_Vaccum_Error;
            }
            set
            {

                if (value != _Ejection_Vaccum_Error)
                {
                    _Ejection_Vaccum_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Ejection_Vaccum_Error_code, true);
                        Error_code = Ejection_Vaccum_Error_code;


                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Ejection_Vaccum_Error_code, false);
                    }
                }


            }
        }

        public static int E_Stop
        {
            get
            {
                return _E_Stop;
            }
            set
            {

                if (value != _E_Stop)
                {
                    _E_Stop = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(E_Stop_code, true);
                        Error_code = E_Stop_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(E_Stop_code, false);
                    }
                }


            }
        }

        public static int Safety_Relay
        {
            get
            {
                return _Safety_Relay;
            }
            set
            {

                if (value != _Safety_Relay)
                {
                    _Safety_Relay = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Safety_Relay_code, true);
                        Error_code = Safety_Relay_code;

                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Safety_Relay_code, false);
                    }
                }


            }
        }
        public static int Main_Pressure_Swtch
        {
            get
            {
                return _Main_Pressure_Swtch;
            }
            set
            {

                if (value != _Main_Pressure_Swtch)
                {
                    _Main_Pressure_Swtch = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Main_Pressure_Swtch_code, true);
                        Error_code = Main_Pressure_Swtch_code;

                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Main_Pressure_Swtch_code, false);
                    }
                }


            }
        }
        public static int Pallet_Lft_up_Autoseq
        {
            get
            {
                return _Pallet_Lft_up_Autoseq;
            }
            set
            {

                if (value != _Pallet_Lft_up_Autoseq)
                {
                    _Pallet_Lft_up_Autoseq = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Pallet_Lft_up_Autoseq_code, true);
                        Error_code = Pallet_Lft_up_Autoseq_code;


                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Pallet_Lft_up_Autoseq_code, false);
                    }
                }


            }
        }
        public static int Axis_Disconnect_Error
        {
            get
            {
                return _Axis_Disconnect_Error;
            }
            set
            {

                if (value != _Axis_Disconnect_Error)
                {
                    _Axis_Disconnect_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Axis_Disconnect_Error_code, true);

                        Error_code = Axis_Disconnect_Error_code;
                    }
                    else if (value == 0)
                    {
                     //   alrm.InsertAlrm(Axis_Disconnect_Error_code, false);
                    }
                }


            }
        }
        public static int IO_Disconnect_Error
        {
            get
            {
                return _IO_Disconnect_Error;
            }
            set
            {

                if (value != _IO_Disconnect_Error)
                {
                    _IO_Disconnect_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(IO_Disconnect_Error_code, true);
                        Error_code = IO_Disconnect_Error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(IO_Disconnect_Error_code, false);
                    }
                }


            }
        }
        public static int Gantry_X_Max_MM_Error
        {
            get
            {
                return _Gantry_X_Max_MM_Error;
            }
            set
            {

                if (value != _Gantry_X_Max_MM_Error)
                {
                    _Gantry_X_Max_MM_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Gantry_X_Max_MM_Error_code, true);
                        Error_code = Gantry_X_Max_MM_Error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Gantry_X_Max_MM_Error_code, false);
                    }
                }


            }
        }
        public static int Gantry_Y_Max_MM_Error
        {
            get
            {
                return _Gantry_Y_Max_MM_Error;
            }
            set
            {

                if (value != _Gantry_Y_Max_MM_Error)
                {
                    _Gantry_Y_Max_MM_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Gantry_Y_Max_MM_Error_code, true);
                        Error_code = Gantry_Y_Max_MM_Error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Gantry_Y_Max_MM_Error_code, false);
                    }
                }


            }
        }

        public static int Nozzle_Z__Max_MM_Error
        {
            get
            {
                return _Nozzle_Z__Max_MM_Error;
            }
            set
            {

                if (value != _Nozzle_Z__Max_MM_Error)
                {
                    _Nozzle_Z__Max_MM_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Nozzle_Z__Max_MM_Error_code, true);
                        Error_code = Nozzle_Z__Max_MM_Error_code;


                    }
                    else if (value == 0)
                    {
                     //   alrm.InsertAlrm(Nozzle_Z__Max_MM_Error_code, false);
                    }
                }


            }
        }
        public static int Nozzle_Ang__Max_Deg_Error
        {
            get
            {
                return _Nozzle_Ang__Max_Deg_Error;
            }
            set
            {

                if (value != _Nozzle_Ang__Max_Deg_Error)
                {
                    _Nozzle_Ang__Max_Deg_Error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Nozzle_Ang__Max_Deg_Error_code, true);
                        Error_code = Nozzle_Ang__Max_Deg_Error_code;


                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Nozzle_Ang__Max_Deg_Error_code, false);
                    }
                }


            }
        }
        public static int Vaccum1_ff_error
        {
            get
            {
                return _Vaccum1_ff_error;
            }
            set
            {

                if (value != _Vaccum1_ff_error)
                {
                    _Vaccum1_ff_error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Vaccum1_ff_error_code, true);
                        Error_code = Vaccum1_ff_error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Vaccum1_ff_error_code, false);
                    }
                }


            }
        }
        public static int Vaccum2_ff_error
        {
            get
            {
                return _Vaccum2_ff_error;
            }
            set
            {

                if (value != _Vaccum2_ff_error)
                {
                    _Vaccum2_ff_error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Vaccum2_ff_error_code, true);
                        Error_code = Vaccum2_ff_error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Vaccum2_ff_error_code, false);
                    }
                }


            }
        }

        public static int Vaccum3_ff_error
        {
            get
            {
                return _Vaccum3_ff_error;
            }
            set
            {

                if (value != _Vaccum3_ff_error)
                {
                    _Vaccum3_ff_error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Vaccum3_ff_error_code, true);
                        Error_code = Vaccum3_ff_error_code;


                    }
                    else if (value == 0)
                    {
                     //   alrm.InsertAlrm(Vaccum3_ff_error_code, false);
                    }
                }


            }
        }
        public static int Vaccum4_ff_error
        {
            get
            {
                return _Vaccum4_ff_error;
            }
            set
            {

                if (value != _Vaccum4_ff_error)
                {
                    _Vaccum4_ff_error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Vaccum4_ff_error_code, true);
                        Error_code = Vaccum4_ff_error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Vaccum4_ff_error_code, false);
                    }
                }


            }
        }

        public static int Cowling_Abs_error
        {
            get
            {
                return _Cowling_Abs_error;
            }
            set
            {

                if (value != _Cowling_Abs_error)
                {
                    _Cowling_Abs_error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Cowling_Abs_error_code, true);
                        Error_code = Cowling_Abs_error_code;


                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Cowling_Abs_error_code, false);
                    }
                }


            }
        }

        public static int Stepper_cmmnctn_error
        {
            get
            {
                return _Stepper_cmmnctn_error;
            }
            set
            {

                if (value != _Stepper_cmmnctn_error)
                {
                    _Stepper_cmmnctn_error = value;

                    if (value > 0)
                    {
                       // alrm.InsertAlrm(Stepper_cmmnctn_error_code, true);
                        Error_code = Stepper_cmmnctn_error_code;


                    }
                    else if (value == 0)
                    {
                        //alrm.InsertAlrm(Stepper_cmmnctn_error_code, false);
                    }
                }


            }
        }

        public static int Loader_Empty_error
        {
            get
            {
                return _Loader_Empty_error;
            }
            set
            {

                if (value != _Loader_Empty_error)
                {
                    _Loader_Empty_error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Loader_Empty_error_code, true);
                        Error_code = Loader_Empty_error_code;


                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Loader_Empty_error_code, false);
                    }
                }


            }
        }
        public static int Both_FEEDER_Empty_Error
        {
            get
            {
                return _Both_FEEDER_Empty_Error;
            }
            set
            {

                if (value != _Both_FEEDER_Empty_Error)
                {
                    _Both_FEEDER_Empty_Error = value;

                    if (value > 0)
                    {
                        //alrm.InsertAlrm(Both_FEEDER_Empty_Error_code, true);
                        Error_code = Both_FEEDER_Empty_Error_code;
                       // AutoSequence.autoProcess = false;

                    }
                    else if (value == 0)
                    {
                       // alrm.InsertAlrm(Both_FEEDER_Empty_Error_code, false);
                    }
                }


            }
        }

        public static bool InvokeRequired = false;
        #endregion
        #region "DataBase variables"
        public static double[] Cam_X_CCD2_Check_Pos = new double[5];
        public static double[] Cam_Y_CCD2_Check_Pos = new double[5];
        public static double[] Cam_Ang_CCD2_Check_Pos = new double[5];
        public static double Loadcellvalue = 0.0;
        public static double Before_X_gap = 0.0;
        public static double Before_Y_gap = 0.0;
        public static double Before_Ang_gap = 0.0;
        public static double After_X_gap = 0.0;
        public static double After_Y_gap = 0.0;
        public static double After_Ang_gap = 0.0;
        #endregion

        public static void Reset_Alarm()
        {
            ExceptionError = 0;
            Gantry_Home_Error = 0;
            Gantry_Move_Error = 0;
            Gantry_X_Error = 0;
            Gantry_Y_Error = 0;
            Nozzle_Z1_Error = 0;
            Nozzle_Z2_Error = 0;
            Nozzle_Z3_Error = 0;
            Nozzle_Z4_Error = 0;
            Nozzle_A1_Error = 0;
            Nozzle_A2_Error = 0;
            Nozzle_A3_Error = 0;
            Nozzle_A4_Error = 0;
            Axis_Error = 0;
            DIO_Error = 0;
            Motion_Timeout = 0;
            Vision_Connection_Error = 0;
            Vision_Send_Error = 0;
            Vision_TLM_Error = 0;
            Vision_Recieve_Error = 0;
            Ejection_Vaccum_Error = 0;
            E_Stop = 0;
            Safety_Relay = 0;
            Error_code = 0;
            Main_Pressure_Swtch = 0;
            Pallet_Lft_up_Autoseq = 0;
            Axis_Disconnect_Error = 0;
            IO_Disconnect_Error = 0;
            Gantry_X_Max_MM_Error = 0;
            Gantry_Y_Max_MM_Error = 0;// In auto while running or before start check PALLET IS LIFT UP
            Nozzle_Z__Max_MM_Error = 0;
            Nozzle_Ang__Max_Deg_Error = 0;
            Vaccum1_ff_error = 0;
            Vaccum2_ff_error = 0;
            Vaccum3_ff_error = 0;
            Vaccum4_ff_error = 0;
            Cowling_Abs_error = 0;
            Stepper_cmmnctn_error = 0;
            Both_FEEDER_Empty_Error = 0;
            Loader_Empty_error = 0;
        }
        public static void Create_Alarm_buffer_dt()
        {
            LiveAlrmdt.Columns.Add("DateTime");

            LiveAlrmdt.Columns.Add("AlarmType");
            LiveAlrmdt.Columns.Add("AlarmCode");
            LiveAlrmdt.Columns.Add("AlarmDesc");
            LiveAlrmdt.Columns.Add("Component");
            LiveAlrmdt.Columns.Add("Category");
            LiveAlrmdt.Columns.Add("Acknowledged By");
            LiveAlrmdt.Columns.Add("Acknowledged Date");
            LiveAlrmdt.Columns.Add("Shift");
            //DataColumn[] keys = new DataColumn[1];
            //keys[0] = LiveAlrmdt.Columns[2];
            //LiveAlrmdt.PrimaryKey = keys;
        }
        public static void AlrmDesc_dt()//temporary after that load desc table from db
        {
            AlrmDescdt.Columns.Add("Alarmcode");
            AlrmDescdt.Columns.Add("Type");
            AlrmDescdt.Columns.Add("Component");
            AlrmDescdt.Rows.Add();
            AlrmDescdt.Rows[0][0] = "2";    //2 21 15
            AlrmDescdt.Rows[0][1] = "Gantry_Error";
            AlrmDescdt.Rows[0][2] = "Gantry";
            AlrmDescdt.Rows.Add();
            AlrmDescdt.Rows[1][0] = "15";    //2 21 15
            AlrmDescdt.Rows[1][1] = "Gantry_Error";
            AlrmDescdt.Rows[1][2] = "Gantry";
            AlrmDescdt.Rows.Add();
            AlrmDescdt.Rows[2][0] = "21";    //2 21 15
            AlrmDescdt.Rows[2][1] = "Gantry_Error";
            AlrmDescdt.Rows[2][2] = "Gantry";

        }

        #region "Setting_variables"
        #region "Conveyor"
        #region "Input Conveyor"
        public static byte Input_Conv_mot1_nodeid = 1;
        public static byte Input_Conv_mot2_nodeid = 2;

        public static double input_conv_vel = 0.0;
        public static double input_conv_Acc = 0.0;
        public static double input_conv_DAcc = 0.0;
        public static double input_conv_pitch = 56.55;
        public static int input_conv_PPR = 20000;
        #endregion Region
        #region "Process Conveyor"
        public static byte process_Conv_mot1_nodeid = 3;
        public static byte process_Conv_mot2_nodeid = 4;

        public static double process_conv_vel1 = 0.0;
        public static double process_conv_vel2 = 0.0;
        public static double process_conv_Acc = 0.0;
        public static double process_conv_DAcc = 0.0;
        public static double process_conv_pitch = 56.55;
        public static int process_conv_PPR = 20000;
        #endregion Region
        #region "Output Conveyor"
        public static byte Output_Conv_mot1_nodeid = 5;
        public static byte Output_Conv_mot2_nodeid = 6;

        public static double output_conv_vel = 0.0;
        public static double output_conv_Acc = 0.0;
        public static double output_conv_DAcc = 0.0;
        public static double output_conv_pitch = 56.55;
        public static int output_conv_PPR = 20000;
        #endregion Region

        #endregion
        #region "Gantry"
        public static int Gantry_X_MIO_axis = 1;
        public static int Gantry_Y_MIO_axis = 0;
        public static int Gantry_X_axis = 0;
        public static int Gantry_Y_axis = 1;
        public static int Gantry_X_PPR = 100000;
        public static int Gantry_Y_PPR = 100000;
        public static double Gantry_X_GearRatio = 1.0;
        public static double Gantry_Y_GearRatio = 1.0;// have to  change
        public static double Gantry_X_pitch = 25.00;
        public static double Gantry_Y_pitch = 40.00;
        public static double Gantry_X_Acc = 0.0;
        public static double Gantry_X_DAcc = 0.0;
        public static double Gantry_Y_Acc = 0.0;
        public static double Gantry_Y_DAcc = 0.0;
        public static double Gantry_X_HomeVel = 0.0;
        public static double Gantry_Y_HomeVel = 0.0;
        public static double Gantry_X_ProcessVel = 0.0;
        public static double Gantry_Y_ProcessVel = 0.0;
        public static double Gantry_X_HomePos = 55.00;
        public static double Gantry_X_Max_mm = 615.00;
        public static double Gantry_X_Min_mm = 0.00;//Add in manualsett in notepad
        public static double Gantry_Y_HomePos = 0.00;
        public static double Gantry_Y_Max_mm = 510.00;
        public static double Gantry_Y_Min_mm = 0.00;//Add in manualsett in notepad


        #endregion
        #region "Nozzle"


        public static int Nozzle_Z_PPR = 50000;
        public static int Nozzle_Ang_PPR = 36000;//steps per revolution
        public static double Nozzle_Z_GearRatio = 1.0;
        public static double Nozzle_Ang_GearRatio = 1.0;
        public static double Nozzle_Z_pitch = 6.0;
        public static double Nozzle_Ang_pitch = 360;
        public static double Nozzle_Z_Acc = 0.0;
        public static double Nozzle_Z_DAcc = 0.0;
        public static double Nozzle_Ang_Acc = 10.0;
        public static double Nozzle_Ang_DAcc = 10.0;
        public static double Nozzle_Z_HomeVel = 0.0;
        public static double Nozzle_Ang_HomeVel = 0.0;
        public static double Nozzle_Z_ProcessVel = 0.0;
      
        public static double Nozzle_Ang_ProcessVel = 150.0;

        public static double Nozzle_Z_HomePos = 0.00;
        public static double Nozzle_Z_Max_mm = 50.00;
        public static double Nozzle_Z_Min_mm = 0.00;
        public static double Nozzle_Z2_HomePos = 0.00;
        public static double Nozzle_Z2_Max_mm = 50.00;
        public static double Nozzle_Z2_Mim_mm = 0.00;
        public static double Nozzle_Z3_HomePos = 0.00;
        public static double Nozzle_Z3_Max_mm = 50.00;
        public static double Nozzle_Z3_Mim_mm = 0.00;
        public static double Nozzle_Z4_HomePos = 0.00;
        public static double Nozzle_Z4_Max_mm = 50.00;
        public static double Nozzle_Z4_Mim_mm = 0.00;
        public static double Nozzle_Ang_HomePos = 0.00;
        public static double Nozzle_Ang_Max_deg = 300.00;
        public static double Nozzle_Ang_Min_deg = 0.00;
        public static int[] Nozzle_Ang_nodeid = new int[5];
        public static int[] Nozzle_Z_Axis = new int[5];
        public static double[] Nozzle_Z_Homeposs = new double[5];



        #endregion
        #region "FoamFeeder"
        public static double FoamFeeder_PITCH = 0;
        public static int FoamFeeder_PPR = 0;
        public static double FoamFeeder_Acc = 0.0;
        public static double FoamFeeder_DAcc = 0.0;
        public static double FoamFeeder_JogSpeed = 0.0;
        public static double FoamFeeder_Speed = 0.0;
        public static double FoamFeeder_Pitch = 0.0;
        // public static int FoamFeeder_steps_Per_Rotation = 0;
        public static byte FoamFeeder_LH_ID = 7;
        public static byte FoamFeeder_RH_ID = 8;
        public static double foamfeeder_index = 5.0;
        public static double foamfeeder_index_offset = 2.0;
        #endregion
        public static double[] X_Gap = new double[5];
        public static double[] Y_Gap = new double[5];
        public static double[] Ang_Gap = new double[5];
        public static bool Stepmode_En = false;
        public static bool SingleCycle_En = false;
        public static bool Interpol = false;
        #endregion



    }
}
