﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using System.IO;


namespace AHDP
{
    public class SQLHelper
    {
        public static string _SQLConnString = string.Empty;
        public static SqlConnection _SQLConnection;
        //static SqlConnection con;


        public static string get_ConnName()   //have changed from void to string
        {
            if (GetDataFromXML.LoadValues1() == true)
            {
                if (GetDataFromXML.AUTHENTICATION.ToUpper() == "SQL AUTHENTICATION")
                {
                    _SQLConnString = "Data Source=" + GetDataFromXML.INSTANCE_NAME.ToString() + ";Initial Catalog=" + GetDataFromXML.DATABASE_NAME.ToString() + " ;User id= " + GetDataFromXML.USER_NAME.ToString() + ";Password= " + GetDataFromXML.PASSWORD.ToString();

                    //_SQLConnString = "Data Source=" + GetDataFromXML.INSTANCE_NAME.ToString() + ";Initial Catalog=" + GetDataFromXML.DATABASE_NAME.ToString() + ";Integrated Security = True";

                }
                else
                {
                    _SQLConnString = "Data Source=" + GetDataFromXML.INSTANCE_NAME.ToString() + ";Initial Catalog=" + GetDataFromXML.DATABASE_NAME.ToString() + ";Integrated Security = True";

                    // _SQLConnString = "Data Source=" + GetDataFromXML.INSTANCE_NAME.ToString() + ";Initial Catalog=" + GetDataFromXML.DATABASE_NAME.ToString() + " ;User id= " + GetDataFromXML.USER_NAME.ToString() + ";Password= " + GetDataFromXML.PASSWORD.ToString();
                }
            }
            return _SQLConnString;
        }
        public static SqlConnection con = new SqlConnection(SQLHelper.get_ConnName());
        public SQLHelper()
        {
            get_ConnName();
            openconnection();
        }
        public static bool openconnection()
        {
            try
            {
                _SQLConnection = new SqlConnection(_SQLConnString);
                con = new SqlConnection(_SQLConnString);
                con.Open();
                return true;
            }
            catch
            {
                // MessageBox.Show("Connection to Server Failed!");
                return false;
            }
        }
        public static bool closeconnection()
        {
            try
            {
                _SQLConnection = new SqlConnection(_SQLConnString);
                con = new SqlConnection(_SQLConnString);
                con.Open();
                return true;
            }
            catch
            {
                // MessageBox.Show("Connection to Server Failed!");
                return false;
            }
        }

        public static DataSet GetData(string sPName)
        {
            //if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
            //{
            //    con.Open();
            //}
            SqlDataAdapter dA = new SqlDataAdapter();
            DataSet dS = new DataSet();
            try
            {
                dA.SelectCommand = new SqlCommand(sPName, con);
                dA.Fill(dS);
                return dS;
            }
            catch (Exception ex)
            {
                //throw (ex);
                return dS;
            }
            finally
            {
                GC.Collect();
            }
        }
        //public static bool CheckConnection()
        //{
        //    try
        //    {
        //        //*****----- Checking SQL connection status (OPEN or CLOSE) -----*****\\
        //        _SQLConnection = new SqlConnection(_SQLConnString);
        //        using (SqlConnection sqlConn = new SqlConnection(_SQLConnString))
        //        {
        //            sqlConn.Open();
        //            sqlConn.Close();
        //            return true;
        //        }
        //    }
        //    catch (SqlException Ex)
        //    {
        //        Logger.WriteLog("LASEREXE", "CheckConnection", "NA", "Exception Error", Ex.ToString());
        //        return false;

        //    }
        //}
        public static int Executequery(string sPName)
        {
            try
            {
                openconnection();
                if (con.State == ConnectionState.Broken || con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
                SqlCommand dbCommand = new SqlCommand();
                dbCommand.Connection = con;
                dbCommand.CommandType = CommandType.Text;
                dbCommand.CommandText = sPName;
                int returnVal = dbCommand.ExecuteNonQuery();
                return returnVal;
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.ToString());
                //MessageBox.Show("Execution Failed");
                return -1;
            }
            finally
            {
                GC.Collect();
            }
        }
        public int ExecuteNonQuery(string strSQL)
        {
            using (var db = new SqlConnection(_SQLConnString))
            {
                var command = new SqlCommand(strSQL, db);
                command.CommandType = CommandType.Text;
                db.Open();
                int retval = command.ExecuteNonQuery();
                return retval;
            }
        }


        public static int ExecuteNonQuery(CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            try
            {
                using (var db = new SqlConnection(_SQLConnString))
                {
                    var cmd = new SqlCommand();
                    cmd.CommandTimeout = 120;
                    PrepareCommand(cmd, db, default, cmdType, cmdText, commandParameters);
                    int val = Convert.ToInt32(cmd.ExecuteNonQuery());
                    string output = Convert.ToString(cmd.Parameters["@output"].Value);
                    cmd.Parameters.Clear();
                    return Int32.Parse(output.ToString());

                }
            }
            catch (Exception ex)
            {

                throw;
            }

        }
        //public static int ExecuteNonQuery(CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        //{
        //    try
        //    {

        //        var cmd = new SqlCommand();
        //        cmd.CommandTimeout = 120;
        //        PrepareCommand(cmd, default, cmdType, cmdText, commandParameters);
        //        int val = Convert.ToInt32(cmd.ExecuteNonQuery());
        //        string output = Convert.ToString(cmd.Parameters["@output"].Value);
        //        cmd.Parameters.Clear();
        //        return Int32.Parse(output.ToString());

        //    }
        //    catch (Exception ex)
        //    {

        //        throw;
        //    }

        //}

        public static SqlDataReader ExecuteReader(CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            try
            {
                var db = new SqlConnection(_SQLConnString);
                var cmd = new SqlCommand();
                cmd.CommandTimeout = 120;
                PrepareCommand(cmd, db, default, cmdType, cmdText, commandParameters);
                SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                cmd.Parameters.Clear();
                return rdr;
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        public static DataSet GetDataset(CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            try
            {

                var db = new SqlConnection(_SQLConnString);
                var cmd = new SqlCommand();
                cmd.CommandTimeout = 120;
                SqlDataAdapter objAdap;
                DataSet objDs = default;
                PrepareCommand(cmd, db, default, cmdType, cmdText, commandParameters);
                objAdap = new SqlDataAdapter(cmd);
                objDs = new DataSet();
                objDs.Clear();
                objAdap.Fill(objDs);
                return objDs;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public static DataSet GetDataset(CommandType cmdType, string cmdText)
        {
            try
            {
                var db = new SqlConnection(_SQLConnString);
                var cmd = new SqlCommand();
                cmd.CommandTimeout = 120;
                DataSet objDs = default;
                SqlDataAdapter objAdap;
                PrepareCommand(cmd, db, default, cmdType, cmdText, default);
                objAdap = new SqlDataAdapter(cmd);
                objDs = new DataSet();
                objDs.Clear();
                objAdap.Fill(objDs);
                return objDs;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static void PrepareCommand(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, CommandType cmdType, string cmdText, SqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null)
            {
                cmd.Transaction = trans;
            }

            cmd.CommandType = cmdType;
            if (cmdParms != null)
            {
                foreach (SqlParameter parm in cmdParms)
                {
                    if (parm != null)
                    {
                        cmd.Parameters.Add(parm);
                    }
                }
                cmd.Parameters.Add("@output", SqlDbType.VarChar, 100);
                cmd.Parameters["@output"].Direction = ParameterDirection.Output;
            }
        }


        public static DataSet GetDatasets(CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            try
            {

                var db = new SqlConnection(_SQLConnString);
                var cmd = new SqlCommand();
                cmd.CommandTimeout = 120;
                SqlDataAdapter objAdap;
                DataSet objDs = default;
                PrepareCommands(cmd, db, default, cmdType, cmdText, commandParameters);
                objAdap = new SqlDataAdapter(cmd);
                objDs = new DataSet();
                objDs.Clear();
                objAdap.Fill(objDs);
                return objDs;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private static void PrepareCommands(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, CommandType cmdType, string cmdText, SqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
            {
                conn.Open();
            }

            cmd.Connection = conn;
            cmd.CommandText = cmdText;
            if (trans != null)
            {
                cmd.Transaction = trans;
            }

            cmd.CommandType = cmdType;
            if (cmdParms != null)
            {
                foreach (SqlParameter parm in cmdParms)
                {
                    if (parm != null)
                    {
                        cmd.Parameters.Add(parm);
                    }
                }
            }
        }

        public static int CheckBarcodeExistence(string SP, string BarcodeValue)
        {

            try
            {
                using (var db = new SqlConnection(_SQLConnString))
                {
                    db.Open();
                    int returnValue;
                    var command = new SqlCommand(SP, db);
                    //command.Parameters.Add("@pvalue_SerialNo", SqlDbType.NVarChar, 50, ParameterDirection.Input).Value = BarcodeValue;
                    command.Parameters.Add(new SqlParameter("@pvalue_SerialNo", BarcodeValue));

                    command.CommandType = CommandType.StoredProcedure;
                    SqlParameter returnParameter;
                    returnParameter = command.Parameters.Add("@Avail", SqlDbType.Int);
                    returnParameter.Direction = ParameterDirection.Output;
                    int x = command.ExecuteNonQuery();
                    returnValue = (int)returnParameter.Value;
                    return returnValue;
                    db.Close();
                }
            }

            catch (Exception ex)
            {
            }

            return default;
        }
        public static DataTable GetSerialAndModel(string stationName, string Model)
        {
            try
            {
                DataSet ResultSet;
                var Prm = new SqlParameter[3];
                Prm[0] = new SqlParameter("@Mode", "GETSerialNumber");
                Prm[1] = new SqlParameter("@stationName", stationName);
                Prm[2] = new SqlParameter("@Model", Model);
                ResultSet = GetDataset(CommandType.StoredProcedure, "GetSerialAndModel", Prm);
                if (ResultSet != null && ResultSet.Tables[0] != null)
                {
                    return ResultSet.Tables[0];
                }
            }
            catch (Exception ex)
            {
                return default;
            }

            return default;
        }
        public static DataTable GetSerialModel_Reserve(string stationName, string Model)
        {
            try
            {
                DataSet ResultSet;
                var Prm = new SqlParameter[3];
                Prm[0] = new SqlParameter("@Mode", "SerialNumberReserve");
                Prm[1] = new SqlParameter("@stationName", stationName);
                Prm[2] = new SqlParameter("@Model", Model);
                ResultSet = GetDataset(CommandType.StoredProcedure, "GetSerialAndModel", Prm);
                if (ResultSet != null && ResultSet.Tables[0] != null)
                {
                    return ResultSet.Tables[0];
                }
            }
            catch (Exception ex)
            {
                return default;
            }

            return default;
        }

        public static int CheckPartNumberExistenc(string SP, string BarcodeValue, string Mode)
        {

            try
            {
                using (var db = new SqlConnection(_SQLConnString))
                {
                    db.Open();
                    DataSet d_Result;
                    int returnValue;
                    var command = new SqlCommand(SP, db);
                    var ScannedBarcode = new SqlParameter("@Barcode", SqlDbType.NVarChar, 100);
                    var Modes = new SqlParameter("@Mode", SqlDbType.NVarChar, 50);
                    var Avail = new SqlParameter("@Avail", SqlDbType.Int);
                    ScannedBarcode.Value = BarcodeValue;
                    Modes.Value = Mode;
                    Avail.Value = 0;
                    d_Result = GetDataset(CommandType.StoredProcedure, "Check_CP_SerialNo", ScannedBarcode, Modes, Avail);
                    if (d_Result != null)
                    {
                        if (d_Result.Tables.Count > 0)
                        {
                            if (d_Result.Tables[0].Rows.Count > 0 && d_Result.Tables[0] != null)
                            {
                                return Convert.ToInt32(d_Result.Tables[0].Rows[0][0]);
                            }
                            else
                            {
                                return default;
                            }
                        }
                        else
                        {
                            return default;
                        }
                    }
                    db.Close();
                }
            }

            catch (Exception ex)
            {
                throw;
                // MsgBox("Barcode check Stored procedure execution error" & ex.ToString)
            }

            return default;
        }





        public static DataTable GetModelNumber(string sSerial)
        {
            try
            {
                DataSet ResultSet;
                ResultSet = GetDataset(CommandType.Text, "select MODEL_NUMBER from dbo.MES_PRODUCTION_INFO where PRD_SERIAL_NUMBER='" + sSerial + "'");
                if (ResultSet != null && ResultSet.Tables[0] != null)
                {
                    return ResultSet.Tables[0];
                }
            }
            catch (Exception ex)
            {
                return default;
            }

            return default;
        }
        public static int UpdateSerialStatus(string sSerialNumber, int I)
        {
            try
            {
                int iResult;
                var pSerialNumber = new SqlParameter("@Serial", SqlDbType.VarChar, 50);
                var pMode = new SqlParameter("@IMode", SqlDbType.Int);
                pSerialNumber.Value = sSerialNumber;
                pMode.Value = I;
                iResult = ExecuteNonQuery(CommandType.StoredProcedure, "UpdateSerialStatus", pSerialNumber, pMode);
                return iResult;
            }
            catch (Exception ex)
            {
            }

            return default;
        }



        //public static int UpdateOEE(string sShift, string sStationID, string sStationName, string OEE_1, string OEE_2, string OEE_3, string OEE_4, string OEE_5, string OEE_6, string OEE_7, string OEE_8, string OEE_9, string OEE_10, string OEE_11, string OEE_12, string OEE_13)
        //{
        //    try
        //    {
        //        int iResult;
        //        var @params = new SqlParameter[16];
        //        @params[0] = new SqlParameter("@STATION_ID", sStationID);
        //        @params[1] = new SqlParameter("@STATION_NAME", sStationName);
        //        @params[2] = new SqlParameter("@DESIGNED_CYCLE_TIME", OEE_1);
        //        @params[3] = new SqlParameter("@TOTAL_CYCLE_TIME", OEE_2);
        //        @params[4] = new SqlParameter("@AUTOMATIC_TIME", OEE_3);
        //        @params[5] = new SqlParameter("@MANUAL_TIME", OEE_4);
        //        @params[6] = new SqlParameter("@STOPPAGE_TIME", OEE_5);
        //        @params[7] = new SqlParameter("@TECH_TIME", OEE_6);
        //        @params[8] = new SqlParameter("@PERFORMANCE", OEE_7);
        //        @params[9] = new SqlParameter("@QUALITY", OEE_8);
        //        @params[10] = new SqlParameter("@TECH_UTILIZATION_OEE", OEE_9);
        //        @params[11] = new SqlParameter("@No_OF_STOPPAGES", Conversions.ToInteger(OEE_10));
        //        @params[12] = new SqlParameter("@TOTAL_PARTS", Conversions.ToInteger(OEE_11));
        //        @params[13] = new SqlParameter("@OK_PARTS", Conversions.ToInteger(OEE_12));
        //        @params[14] = new SqlParameter("@NOK_PARTS", Conversions.ToInteger(OEE_13));
        //        @params[15] = new SqlParameter("@SHIFT", sShift);
        //        iResult = ExecuteNonQuery(CommandType.StoredProcedure, "UPDATE_OEE_STATION", @params);
        //        return iResult;
        //    }
        //    catch (Exception ex)
        //    {
        //    }

        //    return default;
        //}

        public DataTable GetPartNo_DOC(string s_SerialNumber)
        {
            try
            {
                DataSet ResultDataset;
                ResultDataset = GetDataset(CommandType.Text, "select MODEL_NUMBER from dbo.MES_PRODUCTION_INFO where PRD_SERIAL_NUMBER='" + s_SerialNumber + "'");
                if (ResultDataset != null && ResultDataset.Tables[0] != null)
                {
                    return ResultDataset.Tables[0];
                }
            }
            catch (Exception ex)
            {
                return default;
            }

            return default;


        }
        public DataSet getdata(DateTime FROM_DATE, string SHIFT)
        {
            SQLHelper conn = new SQLHelper();
            SqlCommand cmd = new SqlCommand("OEE_CALCULATION2", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("FROM_DATE", @FROM_DATE);
            cmd.Parameters.AddWithValue("SHIFT", @SHIFT);
            SqlDataAdapter objAdap;
            DataSet objDs = default;
            objAdap = new SqlDataAdapter(cmd);
            objDs = new DataSet();
            objDs.Clear();
            objAdap.Fill(objDs);
            return objDs;
        }


    }


}
