﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace AHDP
{
    public static class CPDCAMoton
    {
        /// <summary>
        /// PDCA上传项目
        /// </summary>
        public static List<CPDCAUploadItem> m_lstPDCAUploadItem = new List<CPDCAUploadItem>();

        #region 获取PDCA上传信息
        /// <summary>
        /// 获取PDCA上传信息(Start与信息分开，信息结尾已加回车换行符)
        /// </summary>
        /// <returns></returns>
        public static bool GetPDCASendInfoPartType(List<CPDCAuploadData> lstPDCAData, ref string SendStartInfo, ref string SendInfo)
        {
            SendStartInfo = "";
            SendInfo = "";
            string sTempSendStart = "";
            for (int i = 0; i < lstPDCAData.Count; i++)
            {
                string SendSN = GetItemValue(lstPDCAData[i], m_lstPDCAUploadItem[0].sItemValue).ToString();                
                if (SendSN == null)
                {
                    continue;
                }
                if (lstPDCAData[i].sMode == "1"|| lstPDCAData[i].sMode == "2")
                {
                    sTempSendStart += SendSN + "@start@audit\r\n";
                }
                else
                {
                    sTempSendStart += SendSN + "@start\r\n";
                }
            }
            SendStartInfo = "_{\r\n" + sTempSendStart + "}\r\n";

            string sTempSendInfo = "";
            for (int i = 0; i < lstPDCAData.Count; i++)
            {
                string SendSN = GetItemValue(lstPDCAData[i], m_lstPDCAUploadItem[0].sItemValue).ToString();
                if (SendSN == null)
                {
                    continue;
                }
                for (int j = 0; j < m_lstPDCAUploadItem.Count-1; j++)
                {
                    if (j == 0)
                    {
                        continue;
                    }
                    string SendValue = GetItemValue(lstPDCAData[i], m_lstPDCAUploadItem[j].sItemValue).ToString();
                    sTempSendInfo += SendSN + "@" + m_lstPDCAUploadItem[j].sItemFormat + "@" + m_lstPDCAUploadItem[j].sItemName + "@" + SendValue;
                    if (m_lstPDCAUploadItem[j].bItemIsLimit)
                    {
                        sTempSendInfo += "@" + m_lstPDCAUploadItem[j].sItemLowerLimit + "@" + m_lstPDCAUploadItem[j].sItemsUpperLimit;
                    }
                    else
                    {
                        if (m_lstPDCAUploadItem[j].bItemIsUnit)
                        {
                            sTempSendInfo += "@NA@NA";
                        }
                            
                    }
                    if (m_lstPDCAUploadItem[j].bItemIsUnit)
                    {
                        sTempSendInfo += "@" + m_lstPDCAUploadItem[j].sItemUnit;
                    }
                    sTempSendInfo += "\r\n";
                }
                string SendValue2 = GetItemValue(lstPDCAData[i], m_lstPDCAUploadItem[m_lstPDCAUploadItem.Count-1].sItemValue).ToString();
                sTempSendInfo += SendSN + "@submit@"+ SendValue2+"\r\n";
            }
            SendInfo = "_{\r\n" + sTempSendInfo + "}\r\n";
            return true;
        }

        /// <summary>
        /// 获取PDCA上传信息(Start信息合并，信息结尾已加回车换行符)
        /// </summary>
        /// <returns></returns>
        public static bool GetPDCASendInfoGroupType(List<CPDCAuploadData> lstPDCAData, ref string SendInfo)
        {
            SendInfo = "";

            string sTempSendInfo = "";
            for (int i = 0; i < lstPDCAData.Count; i++)
            {
                string SendSN = GetItemValue(lstPDCAData[i], m_lstPDCAUploadItem[0].sItemValue).ToString();
                if (SendSN == null)
                {
                    continue;
                }
                if (lstPDCAData[i].sMode == "1" || lstPDCAData[i].sMode == "2")
                {
                    sTempSendInfo += SendSN + "@start@audit\r\n";
                }
                else
                {
                    sTempSendInfo += SendSN + "@start\r\n";
                }
                for (int j = 0; j < m_lstPDCAUploadItem.Count-1; j++)
                {
                    if (j == 0)
                    {
                        continue;
                    }
                    string SendValue = GetItemValue(lstPDCAData[i], m_lstPDCAUploadItem[j].sItemValue).ToString();
                    sTempSendInfo += SendSN + "@" + m_lstPDCAUploadItem[j].sItemFormat + "@" + m_lstPDCAUploadItem[j].sItemName + "@" + SendValue;
                    if (m_lstPDCAUploadItem[j].bItemIsLimit)
                    {
                        sTempSendInfo += "@" + m_lstPDCAUploadItem[j].sItemLowerLimit + "@" + m_lstPDCAUploadItem[j].sItemsUpperLimit;
                    }
                    else
                    {
                        if (m_lstPDCAUploadItem[j].bItemIsUnit)
                        {
                            sTempSendInfo += "@NA@NA";
                        }
                    }
                    if (m_lstPDCAUploadItem[j].bItemIsUnit)
                    {
                        sTempSendInfo += "@" + m_lstPDCAUploadItem[j].sItemUnit;
                    }
                    sTempSendInfo += "\r\n";
                }
                string SendValue2 = GetItemValue(lstPDCAData[i], m_lstPDCAUploadItem[m_lstPDCAUploadItem.Count - 1].sItemValue).ToString();
                sTempSendInfo += SendSN + "@submit@" + SendValue2 + "\r\n";
            }
            SendInfo = "_{\r\n" + sTempSendInfo + "}\r\n";
            return true;
        }
        /// <summary>
        /// 获取项目值
        /// </summary>
        /// <param name="ItemName"></param>
        /// <returns></returns>
        private static object GetItemValue(CPDCAuploadData TempData, string ItemName)
        {
            object sReceive = new object();
            if(ItemName=="NA")
            {
                sReceive = "NA";
            }
            else
            {
                Type t = TempData.GetType();
                foreach (PropertyInfo pi in t.GetProperties())
                {
                    string name = pi.Name;
                    if (ItemName == name)
                    {
                        sReceive = pi.GetValue(TempData, null);
                        break;
                    }
                }
            }
            
            return sReceive;
        }
        /// <summary>
        /// 设置项目值
        /// </summary>
        /// <param name="ItemName"></param>
        /// <param name="SetValue"></param>
        /// <returns></returns>
        public static bool SetItemValue(string ItemName,object SetValue,ref CPDCAuploadData SetData)
        {
            Type t = SetData.GetType();
            foreach (PropertyInfo pi in t.GetProperties())
            {
                string name = pi.Name;
                if (ItemName == name)
                {
                    pi.SetValue(SetData, SetValue);
                    return true;
                }
            }
            return false;
        }
        #endregion
    }
}
