﻿
namespace AHDP
{
    partial class PDCAControl
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DGV_PDCAItem = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.添加一行信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除该行信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.向上移动一行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.向下移动一行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sItemNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sItemFormatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.bItemIsLimitDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sItemsUpperLimitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sItemLowerLimitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bItemIsUnitDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.sItemUnitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sItemValueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_PDCAItem)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_PDCAItem
            // 
            this.DGV_PDCAItem.AllowUserToAddRows = false;
            this.DGV_PDCAItem.AllowUserToDeleteRows = false;
            this.DGV_PDCAItem.AllowUserToResizeRows = false;
            this.DGV_PDCAItem.AutoGenerateColumns = false;
            this.DGV_PDCAItem.BackgroundColor = System.Drawing.Color.White;
            this.DGV_PDCAItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_PDCAItem.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sItemNameDataGridViewTextBoxColumn,
            this.sItemFormatDataGridViewTextBoxColumn,
            this.bItemIsLimitDataGridViewCheckBoxColumn,
            this.sItemsUpperLimitDataGridViewTextBoxColumn,
            this.sItemLowerLimitDataGridViewTextBoxColumn,
            this.bItemIsUnitDataGridViewCheckBoxColumn,
            this.sItemUnitDataGridViewTextBoxColumn,
            this.sItemValueDataGridViewTextBoxColumn});
            this.DGV_PDCAItem.ContextMenuStrip = this.contextMenuStrip1;
            this.DGV_PDCAItem.DataSource = this.bindingSource1;
            this.DGV_PDCAItem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGV_PDCAItem.Location = new System.Drawing.Point(0, 0);
            this.DGV_PDCAItem.MultiSelect = false;
            this.DGV_PDCAItem.Name = "DGV_PDCAItem";
            this.DGV_PDCAItem.ReadOnly = true;
            this.DGV_PDCAItem.RowHeadersVisible = false;
            this.DGV_PDCAItem.RowTemplate.Height = 23;
            this.DGV_PDCAItem.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_PDCAItem.Size = new System.Drawing.Size(935, 567);
            this.DGV_PDCAItem.TabIndex = 9;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.添加一行信息ToolStripMenuItem,
            this.删除该行信息ToolStripMenuItem,
            this.向上移动一行ToolStripMenuItem,
            this.向下移动一行ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(181, 114);
            // 
            // 添加一行信息ToolStripMenuItem
            // 
            this.添加一行信息ToolStripMenuItem.Enabled = false;
            this.添加一行信息ToolStripMenuItem.Name = "添加一行信息ToolStripMenuItem";
            this.添加一行信息ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.添加一行信息ToolStripMenuItem.Text = "添加一行信息";
            this.添加一行信息ToolStripMenuItem.Click += new System.EventHandler(this.添加一行信息ToolStripMenuItem_Click);
            // 
            // 删除该行信息ToolStripMenuItem
            // 
            this.删除该行信息ToolStripMenuItem.Enabled = false;
            this.删除该行信息ToolStripMenuItem.Name = "删除该行信息ToolStripMenuItem";
            this.删除该行信息ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.删除该行信息ToolStripMenuItem.Text = "删除该行信息";
            this.删除该行信息ToolStripMenuItem.Click += new System.EventHandler(this.删除该行信息ToolStripMenuItem_Click);
            // 
            // 向上移动一行ToolStripMenuItem
            // 
            this.向上移动一行ToolStripMenuItem.Enabled = false;
            this.向上移动一行ToolStripMenuItem.Name = "向上移动一行ToolStripMenuItem";
            this.向上移动一行ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.向上移动一行ToolStripMenuItem.Text = "向上移动一行";
            this.向上移动一行ToolStripMenuItem.Click += new System.EventHandler(this.向上移动一行ToolStripMenuItem_Click);
            // 
            // 向下移动一行ToolStripMenuItem
            // 
            this.向下移动一行ToolStripMenuItem.Enabled = false;
            this.向下移动一行ToolStripMenuItem.Name = "向下移动一行ToolStripMenuItem";
            this.向下移动一行ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.向下移动一行ToolStripMenuItem.Text = "向下移动一行";
            this.向下移动一行ToolStripMenuItem.Click += new System.EventHandler(this.向下移动一行ToolStripMenuItem_Click);
            // 
            // sItemNameDataGridViewTextBoxColumn
            // 
            this.sItemNameDataGridViewTextBoxColumn.DataPropertyName = "sItemName";
            this.sItemNameDataGridViewTextBoxColumn.Frozen = true;
            this.sItemNameDataGridViewTextBoxColumn.HeaderText = "上传项目";
            this.sItemNameDataGridViewTextBoxColumn.Name = "sItemNameDataGridViewTextBoxColumn";
            this.sItemNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sItemFormatDataGridViewTextBoxColumn
            // 
            this.sItemFormatDataGridViewTextBoxColumn.DataPropertyName = "sItemFormat";
            this.sItemFormatDataGridViewTextBoxColumn.HeaderText = "上传格式";
            this.sItemFormatDataGridViewTextBoxColumn.Items.AddRange(new object[] {
            "pdata",
            "attr"});
            this.sItemFormatDataGridViewTextBoxColumn.Name = "sItemFormatDataGridViewTextBoxColumn";
            this.sItemFormatDataGridViewTextBoxColumn.ReadOnly = true;
            this.sItemFormatDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.sItemFormatDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // bItemIsLimitDataGridViewCheckBoxColumn
            // 
            this.bItemIsLimitDataGridViewCheckBoxColumn.DataPropertyName = "bItemIsLimit";
            this.bItemIsLimitDataGridViewCheckBoxColumn.HeaderText = "是否有上下限";
            this.bItemIsLimitDataGridViewCheckBoxColumn.Name = "bItemIsLimitDataGridViewCheckBoxColumn";
            this.bItemIsLimitDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // sItemsUpperLimitDataGridViewTextBoxColumn
            // 
            this.sItemsUpperLimitDataGridViewTextBoxColumn.DataPropertyName = "sItemsUpperLimit";
            this.sItemsUpperLimitDataGridViewTextBoxColumn.HeaderText = "上限";
            this.sItemsUpperLimitDataGridViewTextBoxColumn.Name = "sItemsUpperLimitDataGridViewTextBoxColumn";
            this.sItemsUpperLimitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sItemLowerLimitDataGridViewTextBoxColumn
            // 
            this.sItemLowerLimitDataGridViewTextBoxColumn.DataPropertyName = "sItemLowerLimit";
            this.sItemLowerLimitDataGridViewTextBoxColumn.HeaderText = "下限";
            this.sItemLowerLimitDataGridViewTextBoxColumn.Name = "sItemLowerLimitDataGridViewTextBoxColumn";
            this.sItemLowerLimitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bItemIsUnitDataGridViewCheckBoxColumn
            // 
            this.bItemIsUnitDataGridViewCheckBoxColumn.DataPropertyName = "bItemIsUnit";
            this.bItemIsUnitDataGridViewCheckBoxColumn.HeaderText = "是否有单位";
            this.bItemIsUnitDataGridViewCheckBoxColumn.Name = "bItemIsUnitDataGridViewCheckBoxColumn";
            this.bItemIsUnitDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // sItemUnitDataGridViewTextBoxColumn
            // 
            this.sItemUnitDataGridViewTextBoxColumn.DataPropertyName = "sItemUnit";
            this.sItemUnitDataGridViewTextBoxColumn.HeaderText = "单位";
            this.sItemUnitDataGridViewTextBoxColumn.Name = "sItemUnitDataGridViewTextBoxColumn";
            this.sItemUnitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sItemValueDataGridViewTextBoxColumn
            // 
            this.sItemValueDataGridViewTextBoxColumn.DataPropertyName = "sItemValue";
            this.sItemValueDataGridViewTextBoxColumn.HeaderText = "上传数据名称";
            this.sItemValueDataGridViewTextBoxColumn.Name = "sItemValueDataGridViewTextBoxColumn";
            this.sItemValueDataGridViewTextBoxColumn.ReadOnly = true;
            this.sItemValueDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.sItemValueDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = typeof(AHDP.CPDCAUploadItem);
            // 
            // PDCAControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.DGV_PDCAItem);
            this.Name = "PDCAControl";
            this.Size = new System.Drawing.Size(935, 567);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_PDCAItem)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_PDCAItem;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn sItemNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn sItemFormatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn bItemIsLimitDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sItemsUpperLimitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sItemLowerLimitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn bItemIsUnitDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sItemUnitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn sItemValueDataGridViewTextBoxColumn;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 添加一行信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除该行信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 向上移动一行ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 向下移动一行ToolStripMenuItem;
    }
}
