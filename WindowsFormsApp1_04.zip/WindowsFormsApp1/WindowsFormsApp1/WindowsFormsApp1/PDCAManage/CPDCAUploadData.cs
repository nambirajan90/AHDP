﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AHDP
{
    
    /// <summary>
    /// PDCA上传数据类
    /// </summary>
    public class CPDCAuploadData
    {
        /// <summary>
        /// SN
        /// </summary>
        public string sSN { get; set; }
        /// <summary>
        /// 载具SN
        /// </summary>
        public string sCarrier { get; set; }
        /// <summary>
        /// 软件版本
        /// </summary>
        public string sSwVer { get; set; }
        /// <summary>
        /// X值
        /// </summary>
        public double gap_x { get; set; }
        /// <summary>
        /// Y值
        /// </summary>
        public double gap_y { get; set; }
        /// <summary>
        /// 宽
        /// </summary>
        public double width { get; set; }
        /// <summary>
        /// 长
        /// </summary>
        public double length { get; set; }
        /// <summary>
        /// CT
        /// </summary>
        public string sCT { get; set; }
        /// <summary>
        /// 设备ID
        /// </summary>
        public string sMachineID { get; set; }
        /// <summary>
        /// 操作ID
        /// </summary>
        public string sOperatorID { get; set; }
        /// <summary>
        /// 模式
        /// </summary>
        public string sMode { get; set; }
        /// <summary>
        /// 测试ID
        /// </summary>
        public string sTestSeriesID { get; set; }
        /// <summary>
        /// Priority
        /// </summary>
        public string sPriority { get; set; }
        /// <summary>
        /// 在线
        /// </summary>
        public string sOnline { get; set; }
        /// <summary>
        /// PDCA版本
        /// </summary>
        public string sPDCAVer { get; set; }
        /// <summary>
        /// 治具穴位
        /// </summary>
        public string sDutPos { get; set; }
        /// <summary>
        /// 穴位tossing
        /// </summary>
        public int iTossing { get; set; }
        /// <summary>
        /// 数据初始化
        /// </summary>
        public void ThisInit()
        {
            sSN = "1234523";
            sCarrier = "carriersn";
            sSwVer = "V1.0";
            gap_x = 0.12;
            gap_y = 0.11;
            width = 0.14;
            length = 0.15;
            sCT = "34";
            sMachineID = "NA";
            sOperatorID = "0";
            sMode = "0";
            sTestSeriesID = "0";
            sPriority = "0";
            sOnline = "NA";
            sPDCAVer = "V1.0";
            sDutPos = "NA@1";
            iTossing = 0;
        }
        //public void SetRealValue(DataCollect data,int cav)
        //{
        //    sSN = data.sMLB_SN[cav];
        //    sCarrier = data.sCarrierSn;
        //    sSwVer = VersionParam.Instance.SwVersion;
        //    gap_x = data.dGap_X[cav];
        //    gap_y = data.dGap_Y[cav];
        //    width = data.dB_W[cav];
        //    length = data.dB_L[cav];
        //    sCT = data.sCt;
        //    sMachineID = "NA";
        //    sOperatorID = "0";
        //    sMode = GlobClass.g_iSFCMode.PValue.ToString();
        //    if (sMode == "0")
        //    {
        //        sTestSeriesID = "0";
        //        sPriority = "0";
        //    }
        //    else
        //    {
        //        sTestSeriesID = GlobClass.g_sTestSeriesID.PValue;
        //        sPriority = "-2";
        //    }
        //    sOnline = "0";
        //    sPDCAVer = GlobClass.g_SystemParam.PDCA_Ver;
        //    sDutPos = string.Format("{0}@{1}", sCarrier, cav + 1);
        //}
    }
}
