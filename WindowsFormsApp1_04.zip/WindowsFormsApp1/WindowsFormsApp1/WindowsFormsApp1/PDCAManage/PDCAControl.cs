﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.IO;

namespace AHDP
{
    using MsgBox = Test_EN.MessageBox_Ex_Language;
    public partial class PDCAControl : UserControl
    {
        public PDCAControl()
        {
          //  InitializeComponent();

            LoadPDCAItemFile();
            ControlDataInit();
        }
        /// <summary>
        /// 控件数据初始化
        /// </summary>
        public void ControlDataInit()
        {
            List<string> lstPDCADataName = new List<string>();
            CPDCAuploadData TempData = new CPDCAuploadData();
            Type t = TempData.GetType();
            lstPDCADataName.Add("NA");
            foreach (PropertyInfo pi in t.GetProperties())
            {
                string name = pi.Name;
                lstPDCADataName.Add(name);
            }

            DataGridViewComboBoxColumn TempCom = (DataGridViewComboBoxColumn)DGV_PDCAItem.Columns["sItemValueDataGridViewTextBoxColumn"];
            for(int i=0;i<lstPDCADataName.Count;i++)
            {
                TempCom.Items.Add(lstPDCADataName[i]);
            }
            DGV_PDCAItem.DataSource = CPDCAMoton.m_lstPDCAUploadItem;
        }
        /// <summary>
        /// 设置参数
        /// </summary>
        public void SetParam()
        {
            DGV_PDCAItem.ReadOnly = false;
            if(DGV_PDCAItem.Rows.Count>0)
            {
                DGV_PDCAItem.Rows[0].Cells[0].ReadOnly = true;
            }
            添加一行信息ToolStripMenuItem.Enabled = true;
            删除该行信息ToolStripMenuItem.Enabled = true;
            向上移动一行ToolStripMenuItem.Enabled = true;
            向下移动一行ToolStripMenuItem.Enabled = true;
        }
        /// <summary>
        /// 保存参数
        /// </summary>
        public void SaveParam()
        {
            DGV_PDCAItem.ReadOnly = true;
            添加一行信息ToolStripMenuItem.Enabled = false;
            删除该行信息ToolStripMenuItem.Enabled = false;
            向上移动一行ToolStripMenuItem.Enabled = false;
            向下移动一行ToolStripMenuItem.Enabled = false;
            SavePDCAItemFile();
        }
        
        /// <summary>
        /// 加载PDCA上传项目文件
        /// </summary>
        /// <returns></returns>
        public bool LoadPDCAItemFile()
        {
            try
            {
                string sFilePath = Application.StartupPath + @"\Data\AELimit.csv";
                if (!File.Exists(sFilePath))
                {
                    //MessageBox.Show("未找到AELimit文件");
                    if(CPDCAMoton.m_lstPDCAUploadItem.Count<=0)
                    {
                        CPDCAUploadItem TempItem = new CPDCAUploadItem();
                        TempItem.sItemName = "UploadSN(根据此项上传SN，此项目名不可更改)";
                        TempItem.sItemFormat = "attr";
                        TempItem.bItemIsLimit = false;
                        TempItem.sItemsUpperLimit = "NA";
                        TempItem.sItemLowerLimit = "NA";
                        TempItem.bItemIsUnit = false;
                        TempItem.sItemUnit = "NA";
                        TempItem.sItemValue = "NA";
                        CPDCAMoton.m_lstPDCAUploadItem.Add(TempItem);

                        CPDCAUploadItem TempItem2 = new CPDCAUploadItem();
                        TempItem2.sItemName = "submit(此项为结束符)";
                        TempItem2.sItemFormat = "attr";
                        TempItem2.bItemIsLimit = false;
                        TempItem2.sItemsUpperLimit = "NA";
                        TempItem2.sItemLowerLimit = "NA";
                        TempItem2.bItemIsUnit = false;
                        TempItem2.sItemUnit = "NA";
                        TempItem2.sItemValue = "NA";
                        CPDCAMoton.m_lstPDCAUploadItem.Add(TempItem2);
                    }
                    return false;
                }
                CPDCAMoton.m_lstPDCAUploadItem.Clear();
                using (StreamReader TempReader = new StreamReader(sFilePath, Encoding.Default, false))
                {
                    string sTempStr1 = TempReader.ReadLine();
                    sTempStr1 = TempReader.ReadLine();
                    while (sTempStr1 != null)
                    {
                        string[] TempVer1 = sTempStr1.Split(',');
                        if (TempVer1.Length < 8)
                        {
                            sTempStr1 = TempReader.ReadLine();
                            continue;
                        }

                        CPDCAUploadItem TempParts = new CPDCAUploadItem();
                        TempParts.sItemName = TempVer1[0];
                        TempParts.sItemFormat = TempVer1[1];
                        TempParts.bItemIsLimit = Convert.ToBoolean(TempVer1[2]);
                        TempParts.sItemsUpperLimit = TempVer1[3];
                        TempParts.sItemLowerLimit = TempVer1[4];
                        TempParts.bItemIsUnit = Convert.ToBoolean(TempVer1[5]);
                        TempParts.sItemUnit = TempVer1[6];
                        TempParts.sItemValue = TempVer1[7];

                        CPDCAMoton.m_lstPDCAUploadItem.Add(TempParts);
                        sTempStr1 = TempReader.ReadLine();
                    }
                    TempReader.Close();
                }
                return true;
            }
            catch (Exception m)
            {
                MessageBox.Show("加载AELimit信息报错：" + m.Message);
                return false;
            }
        }
        /// <summary>
        /// 保存PDCA上传项目文件
        /// </summary>
        /// <returns></returns>
        public bool SavePDCAItemFile()
        {
            try
            {
                string sFilePath = Application.StartupPath + @"\Data\AELimit.csv";
                if (File.Exists(sFilePath))
                {
                    File.Delete(sFilePath);
                }
                File.Create(sFilePath).Dispose();
                using (StreamWriter TempWriter = new StreamWriter(sFilePath, false, Encoding.Default))
                {
                    string sTital = "上传项目,上传格式,是否有上下限,上限,下限,是否有单位,单位,项目上传数据名称";
                    TempWriter.WriteLine(sTital);
                    for (int i = 0; i < CPDCAMoton.m_lstPDCAUploadItem.Count; i++)
                    {
                        string sTempStr1 = CPDCAMoton.m_lstPDCAUploadItem[i].sItemName + "," + CPDCAMoton.m_lstPDCAUploadItem[i].sItemFormat + "," + CPDCAMoton.m_lstPDCAUploadItem[i].bItemIsLimit.ToString() + "," +
                            CPDCAMoton.m_lstPDCAUploadItem[i].sItemsUpperLimit + "," + CPDCAMoton.m_lstPDCAUploadItem[i].sItemLowerLimit + "," + CPDCAMoton.m_lstPDCAUploadItem[i].bItemIsUnit.ToString() + "," +
                            CPDCAMoton.m_lstPDCAUploadItem[i].sItemUnit + "," + CPDCAMoton.m_lstPDCAUploadItem[i].sItemValue;
                        TempWriter.WriteLine(sTempStr1);
                    }
                    TempWriter.Close();
                }
                return true;
            }
            catch (Exception m)
            {
                MessageBox.Show("保存AELimit文件报错：" + m.Message);
                return false;
            }
        }

        private void 添加一行信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CPDCAUploadItem AddInfo = new CPDCAUploadItem();
            AddInfo.ThisInit();
            CPDCAMoton.m_lstPDCAUploadItem.Insert(CPDCAMoton.m_lstPDCAUploadItem.Count-1, AddInfo);

            List<CPDCAUploadItem> TempList = new List<CPDCAUploadItem>();
            DGV_PDCAItem.DataSource = TempList;

            DGV_PDCAItem.DataSource = CPDCAMoton.m_lstPDCAUploadItem;
        }

        private void 删除该行信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(DGV_PDCAItem.SelectedRows.Count<=0)
            {
                MsgBox.Show("请选中一行");
                return;
            }
            int iIndex = DGV_PDCAItem.SelectedRows[0].Index;
            if(iIndex==0)
            {
                MsgBox.Show("首行不能删除");
                return;
            }
            if(iIndex== CPDCAMoton.m_lstPDCAUploadItem.Count-1)
            {
                MsgBox.Show("末行不能删除");
                return;
            }
            CPDCAMoton.m_lstPDCAUploadItem.RemoveAt(iIndex);

            List<CPDCAUploadItem> TempList = new List<CPDCAUploadItem>();
            DGV_PDCAItem.DataSource = TempList;

            DGV_PDCAItem.DataSource = CPDCAMoton.m_lstPDCAUploadItem;
        }

        private void 向上移动一行ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DGV_PDCAItem.SelectedRows.Count <= 0)
            {
                MsgBox.Show("请选中一行");
                return;
            }
            int iIndex = DGV_PDCAItem.SelectedRows[0].Index;
            if(iIndex<=1)
            {
                MsgBox.Show("该行已到顶层，无法在向上移动");
                return;
            }
            CPDCAUploadItem TempData = CPDCAMoton.m_lstPDCAUploadItem[iIndex];
            CPDCAUploadItem TempData2 = CPDCAMoton.m_lstPDCAUploadItem[iIndex - 1];
            CPDCAMoton.m_lstPDCAUploadItem.Insert(iIndex+1, TempData2);
            CPDCAMoton.m_lstPDCAUploadItem.Insert(iIndex+1, TempData);
            CPDCAMoton.m_lstPDCAUploadItem.RemoveAt(iIndex);
            CPDCAMoton.m_lstPDCAUploadItem.RemoveAt(iIndex-1);

            List<CPDCAUploadItem> TempList = new List<CPDCAUploadItem>();
            DGV_PDCAItem.DataSource = TempList;

            DGV_PDCAItem.DataSource = CPDCAMoton.m_lstPDCAUploadItem;

        }

        private void 向下移动一行ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (DGV_PDCAItem.SelectedRows.Count <= 0)
            {
                MsgBox.Show("请选中一行");
                return;
            }
            int iIndex = DGV_PDCAItem.SelectedRows[0].Index;
            if (iIndex >= CPDCAMoton.m_lstPDCAUploadItem.Count-2)
            {
                MsgBox.Show("该行已到底层，无法在向下移动");
                return;
            }
            if(iIndex==0)
            {
                return;
            }
            CPDCAUploadItem TempData = CPDCAMoton.m_lstPDCAUploadItem[iIndex];
            CPDCAUploadItem TempData2 = CPDCAMoton.m_lstPDCAUploadItem[iIndex + 1];
            CPDCAMoton.m_lstPDCAUploadItem.Insert(iIndex+2, TempData);
            CPDCAMoton.m_lstPDCAUploadItem.Insert(iIndex+2, TempData2);
            CPDCAMoton.m_lstPDCAUploadItem.RemoveAt(iIndex);
            CPDCAMoton.m_lstPDCAUploadItem.RemoveAt(iIndex);

            List<CPDCAUploadItem> TempList = new List<CPDCAUploadItem>();
            DGV_PDCAItem.DataSource = TempList;

            DGV_PDCAItem.DataSource = CPDCAMoton.m_lstPDCAUploadItem;
        }

        //private void InitializeComponent()
        //{
        //    this.SuspendLayout();
        //    // 
        //    // PDCAControl
        //    // 
        //    this.Name = "PDCAControl";
        //    this.Load += new System.EventHandler(this.PDCAControl_Load);
        //    this.ResumeLayout(false);

        //}

        private void PDCAControl_Load(object sender, EventArgs e)
        {

        }
    }
    /// <summary>
    /// PDCA上传项目类
    /// </summary>
    public class CPDCAUploadItem
    {
        /// <summary>
        /// 项目名称
        /// </summary>
        public string sItemName { get; set; }
        /// <summary>
        /// 项目格式
        /// </summary>
        public string sItemFormat { get; set; }
        /// <summary>
        /// 项目是否有上下限
        /// </summary>
        public bool bItemIsLimit { get; set; }
        /// <summary>
        /// 项目上线
        /// </summary>
        public string sItemsUpperLimit { get; set; }
        /// <summary>
        /// 项目下限
        /// </summary>
        public string sItemLowerLimit { get; set; }
        /// <summary>
        /// 项目是否有单位
        /// </summary>
        public bool bItemIsUnit { get; set; }
        /// <summary>
        /// 项目单位
        /// </summary>
        public string sItemUnit { get; set; }
        /// <summary>
        /// 项目上传数据名称
        /// </summary>
        public string sItemValue { get; set; }
        /// <summary>
        /// 数据初始化
        /// </summary>
        public void ThisInit()
        {
            sItemName = "NA";
            sItemFormat = "attr";
            bItemIsLimit = false;
            sItemsUpperLimit = "NA";
            sItemLowerLimit = "NA";
            bItemIsUnit = false;
            sItemUnit = "NA";
            sItemValue = "NA";
        }
    }

}
