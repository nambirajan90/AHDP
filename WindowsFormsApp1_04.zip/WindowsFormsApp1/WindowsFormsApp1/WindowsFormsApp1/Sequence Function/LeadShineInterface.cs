﻿using csLTDMC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AHDP
{
    public static class LeadShineInterface
    {

        public static short ret=0;
        public static short Connect_PCIeCard()
        {
            try
            {
                short ret;
                ret = LTDMC.dmc_board_init();
                if (ret != 0)
                {
                    return ret;
                }
                else { return 0; }
            }
            catch(Exception es)
            {
                return 0;
                Logger.WriteLog("LeadShineInterface", "Connect_PCIeCard", "Station", "Error", es.ToString());
            }
           
            
        }

        public static int Get_card_number()
        {
            try
            {
                short ret;
                ushort CardNumber = 0;
                uint[] cardTypelist = { };
                ushort[] cardList = { };
                ret = LTDMC.dmc_get_CardInfList(ref CardNumber, cardTypelist, cardList);
                if (ret != 0)
                {
                    return CardNumber;
                }
                else { return 0; }
            }
            catch (Exception es)
            {
                return 0;
                Logger.WriteLog("LeadShineInterface", "Get_card_number", "Station", "Error", es.ToString());
            }
           
        }
         public static string Get_Home_status(ushort cardNo, ushort Axis_no)
        {
            try
            {
                UInt16 result = 0;
                LTDMC.dmc_get_home_result(cardNo, Axis_no, ref result);
                
                if (result == 1)
                {
                    return "Homing_Done";
                }
                else
                {
                    return "Homing_NotDone";
                }
            }
            catch (Exception es)
            {
                return "Homing_NotDone";
                Logger.WriteLog("LeadShineInterface", "Get_Home_status", "Station", "Error", es.ToString());
            }
          
        }
       

        public static void close_board()
        {
            try
            {
                LTDMC.dmc_board_close();
            }
            catch (Exception es)
            {
                Logger.WriteLog("LeadShineInterface", "close_board", "Station", "Error", es.ToString());
            }
          
        }
        public static int mm_to_pulse_conversion(double Target_Position ,int axisno)
        {
            try
            {
                int pulses_per_mm = Convert.ToInt32(Globalvariable.AP_Pulse[axisno] / Globalvariable.AP_Pitch[axisno]);
                int pulses_required_to_move_the_position = (int)(pulses_per_mm * Target_Position);
               
                return pulses_required_to_move_the_position;
            }
            catch (Exception es)
            {
                return -10;
                Logger.WriteLog("LeadShineInterface", "mm_to_pulse_conversion", "Station", "Error", es.ToString());
            }
          

        }

        public static double pulse_to_mm_conversion(double EncoderPulse, int axisno)
        {
            try
            {
                int pulses_per_mm = Convert.ToInt32(Globalvariable.AP_Pulse[axisno] / Globalvariable.AP_Pitch[axisno]);
                // int pulses_required_to_move_the_position = (int)(pulses_per_mm * Target_Position);
                double position = EncoderPulse / pulses_per_mm;
                return position;
            }
            catch (Exception es)
            {
                return -10;
                Logger.WriteLog("LeadShineInterface", "mm_to_pulse_conversion", "Station", "Error", es.ToString());
            }


        }
        public static bool Axis_check_done(ushort cardNo, ushort Axis_no)// to check whether the axis was in running or ideal
        {
            try
            {
                short ret;
                ret = LTDMC.dmc_check_done(cardNo, Axis_no);
                if (ret != 0)     /// ret =1 - ideal // ret = 0 - running
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception es)
            {
                return false;
                Logger.WriteLog("LeadShineInterface", "mm_to_pulse_conversion", "Station", "Error", es.ToString());
            }
           

        }
        public static bool Homing(ushort cardNo, ushort usAxis)
        {
            try
            {

                //double dHomeLowSpeed = 10;
                //double dHomeHighSpeed = 50;
                //double dStopSpeed = 5;
                //double dAccTime = 5;
                //double dDecTime = 5;
                double dHomeLowSpeed = 500;
                double dHomeHighSpeed = 1000;
                double dStopSpeed = 100;
                double dAccTime = 0.10;
                double dDecTime = 0.10;
               
                LTDMC.dmc_set_home_pin_logic(cardNo, usAxis, 0, 0);//设置原点低电平有效
                LTDMC.dmc_set_profile(cardNo, usAxis, dHomeLowSpeed, dHomeHighSpeed, dAccTime, dDecTime, dStopSpeed);//设置起始速度、运行速度、停止速度、加速时间、减速时间
                LTDMC.dmc_set_homemode(cardNo, usAxis, GetHomeDir(), GetHomeSpeed(), GetHomeMode(), 0);//设置回零模式
                //LTDMC.dmc_set_home_position(cardNo, usAxis, 1, 0);
                //LTDMC.dmc_set_home_position_unit(cardNo, usAxis, 0, 0);
                
                ret= LTDMC.dmc_home_move(cardNo, usAxis);//
              


                return true;
            }
            catch(Exception es)
            {
                return false;
                Logger.WriteLog("LeadShineInterface", "Homing", "Station", "Error", es.ToString());
            }
        }
        public static void Encoder_Clear(ushort cardNo, ushort usAxis)
        {
            LTDMC.dmc_set_encoder(cardNo, usAxis, 0);
        }

        public static ushort GetHomeDir() // to set the direction of Homing i.e to perform homing in which direction the servo can move intially that was define by this function
        {

            ushort usDir = 1; // 0- Negative direction, 1 -  positive direction
            
            return usDir;
        }
        public static  ushort GetHomeSpeed() // to set the speed of homing function
        {
            ushort dHomeHighSpeed = 1; // 0 -  Lowspeed, 1 -  high Speed   
           
            return dHomeHighSpeed;
        }
        public static ushort GetHomeMode()// to define which homing method the servo can perform, right now homing method 3 was choosen, in this method servo will stop when the orgin sensor was sensed and z marker pulse.
        {
            try
            {
                ushort usMode = 3;
                return usMode;
            
            }
            catch (Exception es)
            {
                return 10;
                Logger.WriteLog("LeadShineInterface", "GetHomeMode", "Station", "Error", es.ToString());
            }

            //if (radioButton_HomeMode1.Checked)
            //{
            //    usMode = 0;
            //}
            //else if (radioButton_HomeMode2.Checked)
            //{
            //    usMode = 1;
            //}
            //else if (radioButton_HomeMode3.Checked)
            //{
            //    usMode = 2;
            //}
            //else if (radioButton_HomeMode4.Checked)
            //{
            //    usMode = 3;
            //}
            //else if (radioButton_HomeMode5.Checked)
            //{
            //    usMode = 4;
            //}
        }
        public static void Stop_Axis(ushort cardNo, ushort usAxis)
        {
            try
            {
                ushort usStopMode = 0;                                 //stop method ,0：decelerate stop，1:emergerncy stop
                double dTdec = 0;       //deceleration time        
                LTDMC.dmc_set_dec_stop_time(cardNo, usAxis, dTdec);  //set decelerartion stop time
                LTDMC.dmc_stop(cardNo, usAxis, usStopMode); // set the  selected axis is going to stop with deceleration
            }
            catch( Exception es)
            {
                Logger.WriteLog("LeadShineInterface", "Stop_Axis", "Station", "Error", es.ToString());
            }
           
        }
        public static void Clear_pos(ushort usAxis, ushort cardNo) //  clear the current position value and set the position value as 0
        {
            try
            {
                double dPos = 0;
                LTDMC.dmc_set_position_unit(cardNo, usAxis, dPos); // to set the current position of selected servo as zero
            }
            catch(Exception es)
            {
                Logger.WriteLog("LeadShineInterface", "Clear_pos", "Station", "Error", es.ToString());
            }
            
        }
        public static bool Single_Axis_move_abs(ushort cardNo, ushort Axis_No, double Min_velocity, double Max_velocity, double Acceleration_Time, double Deacceleration_Time, double position)
       // the selected axis to perfrom absolute movement in this we set the parameter like axis number, min and max velocity, min and max acceleration and target position
        {
            try
            {
                int Position_in_pulses = mm_to_pulse_conversion(position , Axis_No);
                bool Axis_status = Axis_check_done(Globalvariable.Leadshine_card_No, Axis_No);
                if (Axis_status) // ideal
                {
                    LTDMC.dmc_set_pulse_outmode(0, Axis_No, 0);
                    LTDMC.dmc_set_profile(cardNo, Axis_No, Min_velocity, Max_velocity, Acceleration_Time, Deacceleration_Time, 0);// before run the servo to set the parameter of min max velocity,min max acceleration to perfom the smooth movement
                    /* LTDMC.dmc_pmove(cardNo, Axis_No, Convert.ToInt32(position), 0); */// to perfrom the axis movement based on the position value and speed at absolute movement, here the position mode was set as 1- absolute move, 0- relative move
                    LTDMC.dmc_pmove(cardNo, Axis_No, Convert.ToInt32(Position_in_pulses), 0);
                    return true;
                }
                else // running
                {
                    // MessageBox.Show(Axis_status.ToString());
                    Logger.WriteLog("LeadShineInterface", "Single_Axis_move_abs", "Station", "Error", "the selected axis:"+ Axis_No+"-is not  ideal");
                    return false;
                }


            }
            catch (Exception es)
            {

                return false;
                Logger.WriteLog("LeadShineInterface", "Single_Axis_move_abs", "Station", "Error", es.ToString());

            }

        }
        public static double Get_current_Position_of_Axis(ushort cardNo, ushort Axis_No)// to get the current position of servo of selected axis 
        {
            try
            {
                //int value;
                //value = LTDMC.dmc_get_encoder(cardNo, Axis_No);
                //double current_position = (value / (Globalvariable.AP_Pulse[Axis_No] / Globalvariable.AP_Pitch[Axis_No]));
                //return current_position;
                int value;
                value = LTDMC.dmc_get_encoder(cardNo, Axis_No);
                //int currentpos;
                //currentpos  = LTDMC.dmc_get_position(cardNo, Axis_No);
                double current_position = (value / Globalvariable.AP_Pulse[Axis_No]) * (Globalvariable.AP_Pitch[Axis_No]);
                return current_position;
            }
            catch(Exception es)
            {
                return 0;
                Logger.WriteLog("LeadShineInterface", "Get_current_Position_of_Axis", "Station", "Error", es.ToString());
            }
          
        }

        public static double Get_current_Position_Card(ushort cardNo, ushort Axis_No)// to get the current position of servo of selected axis 
        {
            try
            {
                //int value;
                //value = LTDMC.dmc_get_encoder(cardNo, Axis_No);
                //double current_position = (value / (Globalvariable.AP_Pulse[Axis_No] / Globalvariable.AP_Pitch[Axis_No]));
                //return current_position;
                int value;
               // value = LTDMC.dmc_get_encoder(cardNo, Axis_No);
                //int currentpos;
                value  = LTDMC.dmc_get_position(cardNo, Axis_No);
                // double current_position = (value / (Globalvariable.AP_Pulse[Axis_No] / Globalvariable.AP_Pitch[Axis_No]));
                double current_position = (value / Globalvariable.AP_Pulse[Axis_No]) * ( Globalvariable.AP_Pitch[Axis_No]);
                return current_position;
            }
            catch (Exception es)
            {
                return 0;
                Logger.WriteLog("LeadShineInterface", "Get_current_Position_of_Axis", "Station", "Error", es.ToString());
            }

        }
        public static short Write_DO_Leadshine(ushort cardNo, ushort DO_bit_No, ushort Value)// to turn on and turn off of specific output , if the value is 0 to turn off specific output and the value is 1 to turn on of specific output
        {
            try
            {
                short ret;
                ret = LTDMC.dmc_write_outbit(cardNo, DO_bit_No, Value);
                return ret;
            }
            catch(Exception es)
            {
                return -1;
                Logger.WriteLog("LeadShineInterface", "Write_DO_Leadshine", "Station", "Error", es.ToString());
            }
           
        }
        public static bool Compartor_start(ushort CardNo,ushort Axis, int[]ComparePos, int no_of_compare,int Postion, double velocity)
        {
            try
            {
                short ret;
                ushort MyCardNo, Myaxis, Mycmp_mode, Myhcmp, Mycmp_source, Mycmp_logic;
                int MyTime, MyCmpPos;

                MyCardNo = 0;   //card number
                Myaxis = Axis; //Axis number
                Mycmp_mode = 4; //Comparison mode is mode 4
                Myhcmp = 0; //High-speed comparator, corresponding to hardware CMP port
                Mycmp_source = 0;   //The comparison source is the instruction position
                Mycmp_logic = 0;    //Low level is valid
                MyTime = 50000;    //Pulse width 500000us //50ms
                int Target_Pos = mm_to_pulse_conversion(Postion, Axis);
              
                LTDMC.dmc_hcmp_set_config(CardNo, Myhcmp, Myaxis, Mycmp_source, Mycmp_logic, MyTime); //Configure high speed comparator
                LTDMC.dmc_hcmp_clear_points(CardNo, Myhcmp);// Clear comparison points
                LTDMC.dmc_hcmp_set_mode(CardNo, Myhcmp, Mycmp_mode);//Set the high-speed comparison mode to queue mode

                for (int i = 0; i < no_of_compare; i++)
                {
                    MyCmpPos = mm_to_pulse_conversion(ComparePos[i], Axis);
                   
                    LTDMC.dmc_hcmp_add_point(CardNo, Myhcmp, MyCmpPos);
                }
                //MyCmpPos = ComparePos[0];
                //LTDMC.dmc_hcmp_add_point(MyCardNo, Myhcmp, MyCmpPos);
                //MyCmpPos = ComparePos[1];
                //LTDMC.dmc_hcmp_add_point(MyCardNo, Myhcmp, MyCmpPos);//Add high-speed comparison position to 30000 pulseMyCmpPos = 70000;
                //MyCmpPos = ComparePos[2];
                //LTDMC.dmc_hcmp_add_point(MyCardNo, Myhcmp, MyCmpPos);//Add high-speed comparison position to 70000 pulse
                LTDMC.dmc_set_profile(CardNo, Myaxis, 1000, velocity, 0.01, 0.01, 1000); //Set trapezoidal speed curve
                LTDMC.dmc_pmove(CardNo, Myaxis, Target_Pos, 1);	//Fixed length motion, displacement is 100000, absolute mode
                return true;

            }
            catch (Exception es )
            {
                Logger.WriteLog("LeadShineInterface", "Compartor_start", "Station", "Error", es.ToString());
                return false;
            }
            
        }
        public static bool[]Di_read = new bool[15];
        public static bool[] Do_read = new bool[15];
        public static bool[] Read_DI_from_Motioncard(ushort cardNo)// to read digital input state from motion card
        {

            try
            {
                short ret;
                for(ushort i = 0;i<=15;i++)
                {
                    ret = LTDMC.dmc_read_inbit(cardNo, i); //LTDMC.dmc_read_inport(cardNo, i);
                    if (ret != 0)
                    {
                        Globalvariable.MC_Read_DI[i] = false;
                    }
                    else
                    {
                        Globalvariable.MC_Read_DI[i] = true;
                    }

                }
                return Globalvariable.MC_Read_DI;


            }
            catch (Exception es)
            {
                return Globalvariable.MC_Read_DI;
               // MessageBox.Show(e.ToString());
                Logger.WriteLog("Socket_Client", "Read_DI_from_Motioncard", "Station", "Error", es.ToString());
            }
        }
        public static bool[] Read_DO_from_Motioncard(ushort cardNo)// to read digital output state from motion card
        {
            {

                try
                {
                    short ret;
                    for (ushort i = 0; i <= 15; i++)
                    {
                        ret = LTDMC.dmc_read_inbit(cardNo, i);
                        if (ret != 0)
                        {
                            Globalvariable.MC_Read_DO[i] = true;
                        }
                        else
                        {
                            Globalvariable.MC_Read_DO[i] = false;
                        }

                    }
                    return Globalvariable.MC_Read_DO;



                }
                catch (Exception es)
                {

                    return Globalvariable.MC_Read_DO;
                    Logger.WriteLog("Socket_Client", "Read_DO_from_Motioncard", "Station", "Error", es.ToString());
                }
            }

        }
        public static void servo_Enable_Write(ushort cardNo, ushort Axis_No)
        {
            try
            {
                LTDMC.dmc_write_sevon_pin(cardNo, Axis_No, 0);

            }
            catch (Exception ex)
            {
                Logger.WriteLog("Socket_Client", "servo_Enable_Write", "Station", "Error", ex.ToString());
                return;
            }
        }

        public static void JOG(ushort cardNo, ushort Axis_No, ushort dir)
        {
            
            try
            {
                LTDMC.dmc_vmove(cardNo,Axis_No, dir);

            }
            catch (Exception ex)
            {
                Logger.WriteLog("Socket_Client", "servo_JOG", "Station", "Error", ex.ToString());
                return;
            }
        }

        public static void servo_Disable_Write(ushort cardNo, ushort Axis_No)
        {
            try
            {
                LTDMC.dmc_write_sevon_pin(cardNo, Axis_No, 1);

            }
            catch (Exception ex)
            {
                Logger.WriteLog("Socket_Client", "servo_Disable_Write", "Station", "Error", ex.ToString());
                return;
            }
        }
        
            public static void servo_Error_Clear_Write(ushort cardNo, ushort Axis_No)
            {
            try
            {
                LTDMC.dmc_clear_stop_reason(cardNo, Axis_No);

            }
            catch (Exception ex)
            {
                Logger.WriteLog("Socket_Client", "servo_Error_Clear_Write", "Station", "Error", ex.ToString());
                return;
            }
        }


        public static bool servo_Enable_Read(ushort cardNo, ushort Axis_No)
        {
            try
            {

                if (LTDMC.dmc_read_sevon_pin(cardNo, Axis_No) == 0)
                    return true;
                else
                {
                    return false;
                }
               

            }
            catch (Exception ex)
            {
                Logger.WriteLog("Socket_Client", "servo_Enable_Read", "Station", "Error", ex.ToString());
                return false;
            }
        }

        public static void servo_status_no(ushort cardNo, ushort Axis_No, ref int alarm,ref int positive_lim, ref int negative_lim, ref int origin)
        {
            try
            {
                alarm = 0; 
                positive_lim = 0;
                negative_lim = 0;
                origin = 0;
                uint status = 0;
               status = LTDMC.dmc_axis_io_status(cardNo, Axis_No);
                string binary = Convert.ToString(status, 2);
                string[] servo_status = binary.Select(c => c.ToString()).ToArray();
                //char[] servo_status = binary.ToArray();
                Array.Reverse(servo_status);
                
                alarm = Convert.ToInt32(servo_status[0]);
                positive_lim= Convert.ToInt32(servo_status[1]);
                negative_lim = Convert.ToInt32(servo_status[2]);
                origin = Convert.ToInt32(servo_status[4]);

                //return status;
            }
            catch (Exception ex)
            {
                Logger.WriteLog("Socket_Client", "servo_status_Read", "Station", "Error", ex.ToString());
                //return 1000;
            }
        }
       

        public static bool servo_Ready(ushort cardNo, ushort Axis_No)
        {
            try
            {
                if (LTDMC.dmc_read_rdy_pin(cardNo, Axis_No) != 0)
                {
                    return true;
                }
                else
                    return false;
            }
            catch (Exception ex)
            {

                Logger.WriteLog("Socket_Client", "servo_Enable_Write", "Station", "Error", ex.ToString());
                return false;
            }
        }

        public static double servo_Current_speed(ushort cardNo, ushort Axis_No)
        {
            try
            {
                return LTDMC.dmc_read_current_speed(cardNo, Axis_No);

            }
            catch (Exception ex)
            {

                Logger.WriteLog("Socket_Client", "servo_Enable_Write", "Station", "Error", ex.ToString());
                return 0;
            }
        }

        public static bool servo_Conn_Status(ushort cardNo)
        {
            try
            {
                ushort state = 0;
                LTDMC.dmc_LinkState(cardNo, ref state);
                if (state == 0)
                {
                    return true;
                }
                else
                    return false;

            }
            catch (Exception ex)
            {

                Logger.WriteLog("Socket_Client", "servo_Enable_Write", "Station", "Error", ex.ToString());
                return false;
            }
        }

        public static void ToGetCurrentPos(int Axis, out double Actpos, out string Act_status, out double Act_Vel)
        {

            try
            {
                double CurCmd = new double();
                double CurPos = new double();
                double CurrVel = new double();
                Actpos = 0.0;
                Act_Vel = 0.0;
                Act_status = "";
                UInt16 AxState = new UInt16();
                UInt32 Result;
                UInt32 IOStatus = new UInt32();
                //if (m_bInit)
                //{
                //    //Get current command position of the specified axis
                //    Motion.mAcm_AxGetActualPosition(m_Axishand[Axis], ref CurCmd);
                //    //Get current actual position of the specified axis
                //    Motion.mAcm_AxGetActualPosition(m_Axishand[Axis], ref CurPos);
                //    Actpos = CurPos;
                //    //  Motion.mAcm_AxGetCmdPosition(m_Axishand[Axis], ref CurCmd);
                //    Motion.mAcm_AxGetCmdVelocity(m_Axishand[Axis], ref CurrVel);
                //    Act_Vel = CurrVel;
                //    //Get the Axis's current state
                //    Motion.mAcm_AxGetState(m_Axishand[Axis], ref AxState);
                //    Act_status = ((AxisState)AxState).ToString();

                //}

            }
            catch (Exception es)
            {
                Logger.WriteLog("Device_Interface", "ToGetCurrentPos()", "PCIE-1203_Interface", "Exception Error", es.ToString());
                Actpos = 0.0;
                Act_Vel = 0.0;
                Act_status = "";
            }


        }

    }
}
