﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AHDP.UIScreens.GRR;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AHDP
{
    public static  class PLC
    {
        public static SerialPort serialPort1;
        public static string[] readIO_from_PLC = new string[2];
        public static System.Threading.Timer PLC_IOTimer;
       public static List<int> DI_Concat_value = new List<int>();
        public static List<int> DO_Concat_value = new List<int>();
        public  static void OmronPLC(string portName)
        {
            serialPort1 = new SerialPort
            {
                PortName = "COM2",   // e.g., COM1, COM2, etc.
                BaudRate = 115200,       // Default for CP1H, confirm with settings
                DataBits = 7,          // Omron CP1H typically uses 7 data bits
                Parity = Parity.Even,  // Even parity
                StopBits = StopBits.Two,
                Handshake = Handshake.None
            };

        }
        public static int connect_plc()
        {
            try
            {


                OmronPLC("");
                if (serialPort1.IsOpen == false)
                {
                    serialPort1.Open();
                    return 2;
                }
                else
                {
                    return 1;
                }
            }
            catch (Exception ex)
            {
                //cmd priya
               // MessageBox.Show("PLC COMMUNICATION ERROR !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return 1;
            }


        }

        public static string CalculateFCS(string command)
        {
            string TJ;
            int A = 0;
            int fcs = 0;
            for (int i = 0; i < command.Length; i++)
            {
                TJ = command.Substring(i, 1);
                A = Convert.ToInt32(TJ[0]) ^ A;               
            }
            return A.ToString("X2");
        }

        public static string RXD, TX, FCS_r,FCS_w;
        public static string DO_TX,DO_RXD;

        public static string communicate(string BufferTX_R, string FCS)
        {
            string Buffer;
            //string fcs_rxd;
            
            try
            {
                //RXD = string.Empty;

                if (!Globalvariable.PlC_read_pause)
                {
                    Buffer = BufferTX_R + FCS + "*" + "\r";
                    //serialPort1.Write(BufferTX);
                    serialPort1.Write(Buffer);
                    Thread.Sleep(50);
                //serialPort1.ReadTimeout = 1000;
                //serialPort1.DiscardOutBuffer();
                //  serialPort1.DiscardInBuffer();
                if (Buffer.Contains("@00RH"))
                {
                    RXD = serialPort1.ReadTo("\r");
                }
                   // serialPort1.DiscardInBuffer();
                    // Thread.Sleep(50);
                    // serialPort1.DiscardOutBuffer();
                    // serialPort1.DiscardInBuffer();
                    //}
                    //else
                    //{
                    //    //string TX_STATUS = serialPort1.ReadTo("\r");
                    //    //serialPort1.DiscardOutBuffer();
                    //    // serialPort1.DiscardInBuffer();
                   //}
                }
                 //stp1.Stop();
                // textBox6.Text = ((stp1.ElapsedMilliseconds) / 1000).ToString();
                // Get the FCS of the returned information
                // fcs_rxd = RXD.Substring(RXD.Length - 3,2);
                // if (RXD[0] == '@')
                //{
                //    TX = RXD.Substring(0, RXD.Length - 3);
                //}
                //else if (RXD[2] == '@')
                //{
                //    TX = RXD.Substring(2, RXD.Length - 5);
                //    RXD = RXD.Substring(2, RXD.Length - 1);
                //}

                //// Check the FCS of the returned information
                //CalculateFCS(TX);
                //if (FCS != fcs_rxd)
                //{
                //    RXD = "Communication Error";
                //}
                return RXD;
            }
            catch (Exception)
            {
               RXD = "Communication Error";
            }
            return RXD;
        }
        
        public static void WRITE_DO_TO_PLC( int do_no, int on_off)
        {
            string BufferTX;
            string fcs_rxd;

            try
            {
                Globalvariable.PlC_read_pause = true;
                //Thread.Sleep(10);
                //Array.Copy(DIO_Read, 128, DO_WRITE, 0, 64);
                DO_WRITE[do_no]= on_off;
                string Hexvalue = Binnary_to_Hex(DO_WRITE);
                if ((Hexvalue != "0") && (Hexvalue != "1"))
                {
                    if (Hexvalue.Length > 0)
                    {
                        DO_TX = "@00WH0008" + Hexvalue;
                    }
                }
                FCS_w = CalculateFCS(DO_TX);
                BufferTX = DO_TX + FCS_w + "*" + "\r";
               // Globalvariable.PlC_read_pause = true;
                Thread.Sleep(50);
                serialPort1.Write(BufferTX);
                serialPort1.DiscardInBuffer();
                Globalvariable.PlC_read_pause = false;
                Thread.Sleep(100);

            }

            catch (Exception)
            {
               
            }
        }


        public static bool Read_IO_lock = false;
        public static void Read_IO(object sender)
        {
            if (Read_IO_lock == false)
            {
                Read_IO_lock = true;
                try
                {
                   
                        Read_IO_from_PLC(Globalvariable.PLC_Read_Start_Address, Globalvariable.PLC_Read_End_address,
                            Globalvariable.PLC_Write_Start_Address, Globalvariable.PLC_Write_End_Address);
                       // Thread.Sleep(50);
                   
                        //string Hexvalue = Binnary_to_Hex(DO_WRITE);
                        //if ((Hexvalue != "0") && (Hexvalue != "1"))
                        //{
                        //    if (Hexvalue.Length > 0)
                        //    {
                        //        TX = "@00WH0008" + Hexvalue;
                        //    }
                        //}
                        //FCS = CalculateFCS(TX);
                        //communicate();
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    Read_IO_lock = false;
                }
            }
            Read_IO_lock = false;


        }
        public static int[] PLC_DI = new int[100];
        public static int[] PLC_DO = new int[100];
        public static int[] CH0, CH1, CH2, CH3, CH4, CH5, CH6, CH7,CH8,CH9,CH10, CH11, Array8;

        public static void HexToBinary_PLC_DI(string Readvalue, ref int[] DI_values)
        {
            try
            {
                for (int i = 0; i < 12; i++) //21 to 5
                {
                    string extract = Readvalue.Substring(7 + (i * 4), 4);
                    int decimalvalue = Convert.ToInt32(extract, 16);
                    string binaryValue = Convert.ToString(decimalvalue, 2).PadLeft(16, '0');
                    string reversedBinaryString = new string(binaryValue.Reverse().ToArray());
                    if (i == 0)
                    {
                        CH0 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                    }

                    else if (i == 1)
                    {
                        CH1 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                    }

                    else if (i == 2)
                    {
                        CH2 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                    }

                    else if (i == 3)
                    {
                        CH3 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                    }

                    else if (i == 4)
                    {
                        CH4 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 5)
                    {
                        CH5 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 6)
                    {
                        CH6 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                    }
                    else if (i == 7)
                    {
                        CH7 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 8)
                    {
                        CH8 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                    }

                    else if (i == 9)
                    {
                        CH9 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                    }
                    else if (i == 10)
                    {
                        CH10 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                        
                    }
                    else if (i == 11)
                    {
                        CH11 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                        PLC_DI = CH0
                                      .Concat(CH1)
                                      .Concat(CH2)
                                      .Concat(CH3)
                                      .Concat(CH4)
                                       .Concat(CH5)
                                       .Concat(CH6)
                                       .Concat(CH7)
                                       .Concat(CH8)
                                       .Concat(CH9)
                                       .Concat(CH10)
                                       .Concat(CH11)
                                       .ToArray();
                        DI_values = PLC_DI;



                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
       
        public static bool HexToBinary_PLC_DIO(string Readvalue, ref int[] DI_values, ref int[] DO_values)
        {
            try
            {
                // Initialize a list to accumulate all channel arrays
              

                for (int i = 0; i <= 18; i++)
                {
                    if ((i >= 0) && (i <= 13))//
                    {
                        string extract = Readvalue.Substring(7 + (i * 4), 4);
                        int decimalValue = Convert.ToInt32(extract, 16);
                        string binaryValue = Convert.ToString(decimalValue, 2).PadLeft(16, '0');
                        string reversedBinaryString = new string(binaryValue.Reverse().ToArray());

                        int[] channelArray = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();


                        if (i <= 7) // input address read from register D0 to D7
                        {
                            DI_Concat_value.AddRange(channelArray);
                        }
                        if ((i > 7) && (i <= 13))// output address read from D8 to D13
                        {
                            DO_Concat_value.AddRange(channelArray);
                        }
                    }
                    if ((i > 13) && (i <= 18))// read load cell values form plc from register from register D14 to D18
                    {
                        string extract = Readvalue.Substring(7 + (i * 4), 4);
                        int decimalValue = Convert.ToInt32(extract, 16);
                        // Globalvariable.loadcell_value[i] = decimalValue;
                    }


                }

                // Convert the accumulated list to an array and assign it to DI_values
                DI_values = DI_Concat_value.ToArray();
                DO_values = DO_Concat_value.ToArray();
                return true;
            }
            catch (Exception ex)
            {
                return false;
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }
        public static void HexToBinary_PLC_DO(string Readvalue, ref int[] DO_values)
        {
            try
            {
                string extract_0 = Readvalue.Substring(7, 4);
                string extract_1 = Readvalue.Substring(11, 4);
                string extract_2 = Readvalue.Substring(15, 4);
                string extract_3 = Readvalue.Substring(19, 4);
                string extract_4 = Readvalue.Substring(22, 4);
                string extract_5 = Readvalue.Substring(26, 4);
                string extract_6 = Readvalue.Substring(29, 4);
                string extract_7 = Readvalue.Substring(33, 4);
                for (int i = 0; i < 8; i++)
                {
                    string extract = Readvalue.Substring(7 + (i * 4), 4);
                    int decimalvalue = Convert.ToInt32(extract, 16);
                    string binaryValue = Convert.ToString(decimalvalue, 2).PadLeft(8, '0');
                    string reversedBinaryString = new string(binaryValue.Reverse().ToArray());
                    if (i == 0)
                    {
                        CH0 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                    }
                    else if (i == 1)
                    {
                        CH1 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 2)
                    {
                        CH2 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 3)
                    {
                        CH3 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 4)
                    {
                        CH4 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 5)
                    {
                        CH5 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 6)
                    {
                        CH6 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();

                    }
                    else if (i == 7)
                    {
                        CH7 = reversedBinaryString.Select(bit => int.Parse(bit.ToString())).ToArray();
                        PLC_DO = CH0
                                      .Concat(CH1)
                                      .Concat(CH2)
                                      .Concat(CH3)
                                      .Concat(CH4)
                                       .Concat(CH5)
                                       .Concat(CH6)
                                       .Concat(CH7)
                                       .ToArray();
                        DO_values = PLC_DO;
                    }

                }
            }
            catch (Exception ex)
            {

            }
        }
        public static int[] DI_Read = new int[200];
        public static int[] DO_Read = new int[100];
        public static int[] DIO_Read = new int[200];
        public static int[] DO_WRITE = new int[64];
        public static int[] DO_READ = new int[64];
        public static int[] DI_Read_OP = new int[100];
        public static string Startaddress, endaddress,BufferTX_W = string.Empty;
        public static void Read_IO_from_PLC(string IPstartaddress, string IPendaddress, string OPstartaddress, string OPendaddress)
        {
            try
            {
                
                    if (serialPort1.IsOpen == true)
                    {
                    if (!Globalvariable.PlC_read_pause)
                    {
                        TX = "@00RH" + IPstartaddress + IPendaddress;
                        FCS_r = CalculateFCS(TX);
                        readIO_from_PLC[0] = communicate(TX, FCS_r);
                        //if (readIO_from_PLC[0] != "Communication Error")
                        //{
                        HexToBinary_PLC_DI(readIO_from_PLC[0], ref DI_Read);
                        DIO_Read = DI_Read;
                        //Thread.Sleep(50);
                        //}
                    }
                    //Globalvariable.PlC_read_pause = true;
                    //string Hexvalue = Binnary_to_Hex(DO_WRITE);
                    //if ((Hexvalue != "0") && (Hexvalue != "1"))
                    //{
                    //    if (Hexvalue.Length > 0)
                    //    {
                    //        DO_TX = "@00WH0008" + Hexvalue;
                    //    }
                    //}
                    //FCS_w = CalculateFCS(DO_TX);
                    ////BufferTX_W = DO_TX + FCS + "*" + "\r";
                    //communicate(DO_TX, FCS_w);
                    //Globalvariable.PlC_read_pause = false;



                }
                //}
            }

            catch (Exception ex)
            {
            }
        }
        public static int[] ddoo = new int[64];
        public static string[] splited_binary_data = new string[8];
        public static int[] binary_to_decimal = new int[8];
        public static string[] decimal_to_Hex = new string[8];
        public static string Binnary_to_Hex(int[] DO_read_binary)
        {
            try
            {
                int[] array1 = new int[16];  // First 16 elements
                int[] array2 = new int[16];  // Next 16 elements
                int[] array3 = new int[16];  // Next 16 elements
                int[] array4 = new int[16];  // Last 16 elements

                // Use Array.Copy to split the array
                Array.Copy(DO_read_binary, 0, array1, 0, 16);  // Copy first 16 elements
                Array.Copy(DO_read_binary, 16, array2, 0, 16); // Copy next 16 elements
                Array.Copy(DO_read_binary, 32, array3, 0, 16); // Copy next 16 elements
                Array.Copy(DO_read_binary, 48, array4, 0, 16); // Copy last 16 elements

                Array.Reverse(array1);
                Array.Reverse(array2);
                Array.Reverse(array3);
                Array.Reverse(array4);

                string BinaryValue1 = string.Join("", array1);
                string BinaryValue2 = string.Join("", array2);
                string BinaryValue3 = string.Join("", array3);
                string BinaryValue4 = string.Join("", array4);

                
                int number1 = Convert.ToInt32(BinaryValue1, 2); // Convert binary string to integer
                string hexValue1 = number1.ToString("X4"); // Convert integer to hexadecimal string
                int number2 = Convert.ToInt32(BinaryValue2, 2); // Convert binary string to integer
                string hexValue2 = number2.ToString("X4"); // Convert integer to hexadecimal string
                int number3 = Convert.ToInt32(BinaryValue3, 2); // Convert binary string to integer
                string hexValue3 = number3.ToString("X4"); // Convert integer to hexadecimal string
                int number4 = Convert.ToInt32(BinaryValue4, 2); // Convert binary string to integer
                string hexValue4 = number4.ToString("X4"); // Convert integer to hexadecimal string

                string hexa = hexValue1 + hexValue2 + hexValue3 + hexValue4;
                return hexa;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return "1";
            }
        }
        public static int[] Last_DO_Values = new int[64];

        public static void LAST_DO_VALUES()
        {
          //  Globalvariable.PlC_read_pause = true;
            //Array.Copy(DIO_Read, 128, DO_WRITE, 0, 64);
           // Globalvariable.PlC_read_pause = false;
        }

        public static void DO_VALUES_READ()
        {
            Array.Copy(DIO_Read, 128, DO_READ, 0, 64);
        }
        public static void Write_to_PLC(int[] DI_Read_OP)
        {
            try
            {
                
                if (serialPort1.IsOpen == true)
                {
                   // Globalvariable.PlC_read_pause = true;
                    string Hexvalue = Binnary_to_Hex(DI_Read_OP);
                    if ((Hexvalue != "0") && (Hexvalue != "1"))
                    {
                        if (Hexvalue.Length > 0)
                        {
                            TX = "@00WH0008" + Hexvalue;
                        }
                    }
                    //FCS = CalculateFCS(TX);
                   // communicate();
                    //Globalvariable.PlC_read_pause = false;

                }               

            }

            catch (Exception ex)
            {
            }
        }

        public static void start_Thread_PLC_IO()
        {
            //  autoProcess = false;
            Read_IO_lock = false; 
         PLC_IOTimer = new System.Threading.Timer(new TimerCallback(Read_IO), null, 50, 50);


        }
    }
}
