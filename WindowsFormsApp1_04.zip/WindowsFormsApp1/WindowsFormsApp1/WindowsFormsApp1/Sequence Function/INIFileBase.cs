﻿namespace AHDP.Class
{
    public class INIFileBase
    {
       
    }
}