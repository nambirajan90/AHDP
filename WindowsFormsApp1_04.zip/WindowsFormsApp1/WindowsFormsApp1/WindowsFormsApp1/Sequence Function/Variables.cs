﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using AHDP.UIScreens.User;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace AHDP
{
    public static class Variables
    {
        #region PLC_Input
        public static int Start_PB_Left = 0;
        public static int Start_PB_Right = 1;
        public static int Negative_pressure_at_left_station = 2;
        public static int Negative_pressure_at_right_station = 3;
        public static int axis_home_position_1 = 4;
        public static int axis_home_position_2 = 5;
        public static int axis_home_position_3 = 6;
        public static int axis_home_position_4 = 7;
        public static int Access_Control_1 = 8;
        public static int Access_Control_2 = 9;
        public static int Access_control_3 = 10;
        public static int Fan_Alarm = 11;
        public static int Left_Light_curtain = 12;
        public static int Right_Light_curtain = 13;
        public static int Liquid_Level_Sensor = 14;
        public static int P1_Air_Pressure_Detection = 15;
        public static int Spare = 16;
        public static int Spare1 = 17;
        public static int Spare2 = 18;
        public static int Spare3 = 19;
        public static int Spare4 = 20;
        public static int Spare5 = 21;
        public static int Photoelectric_detection_signal = 22;
        public static int Emergency_Stop_signal = 23;
        


        #endregion
        #region PLC_Output

        public static int Start_PB_Left_light = 0;
        public static int Start_PB_Right_light = 1;
        public static int Stop_PB_light = 2;
        public static int Reset_PB_light = 3;
        public static int Inhale_left = 4;
        public static int Inhale_right = 5;
        public static int Buzzer = 6;
        public static int Race_terminal_board_IN6_Zhongwei_Xing_terminal_board_IN17 = 7;
        public static int Tri_color_lamp_Red_light = 8;
        public static int Tri_color_lamp_Yellow_light = 9;
        public static int Tri_color_lamp_green_light = 10;
        public static int Flurescen_lamp_control_power_suppy_Relay = 11;
        public static int Stepper_motor_start = 12;
        public static int Spare6 = 13;
        public static int Spare7 = 14;
        public static int Race_termina_board_IN13_Zhongwei_Xing_erminal_board_IN29 = 15;
       

        #endregion
        #region Motion_Card_Input
        public static int Battery_feeding_vaccum_indication = 5;
        public static int Door_sensor = 6;
        public static int Battery_platform_light_source_extension_sensor = 7;
        public static int Battery_platform_light_source_retraction_sensor = 8;
        public static int Battery_platform_vaccum_suction_sensor = 9;
        public static int Gantry_battery_suction_cyl_extension_sensor = 10;
        public static int Gantry_battery_suction_cyl_retraction_sensor = 11;
        public static int Start_button = 13;
        public static int Reset_button = 15;
        #endregion
        #region Motion_Card_Output
        public static int XY_Gantry_Battery_pick_Cyl_retract = 11;
        public static int XY_Gantry_Battery_Pick_Cyl_extract = 10;
        public static int XY_Gantry_Battery_Feeding_Vacuum_suction = 7;
        public static int Battery_platform_vacumm_suction = 9;
        public static int Battery_platform_light_source_gasbar = 8;
        public static int Film_tearing_jaw_cylinder = 6;
        public static int Small_field_view_trigger = 5;
        public static int Small_field_view_Top_light = 2;
        #endregion

    }
}
