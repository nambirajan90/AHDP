﻿using AHDP.Class;
using csLTDMC;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace AHDP
{

    public static class Globalvariable
    {

        //  AlarmLiveScreen Alarm_grid = new AlarmLiveScreen();
        public static INIFile devices_iNI = new INIFile(Application.StartupPath + "\\device_Config.ini");
        #region PLC
        public static string PLC_Read_Start_Address = "0000";
        public static string PLC_Read_End_address = "0012";
        public static string PLC_Write_Start_Address = "0008";
        public static string PLC_Write_End_Address = "0011";
        public static bool PlC_read_pause = false;
        #endregion
        #region Tray_loading_variables
        public static bool Tray_loading_seq_lock = false;
        public static int Tray_loading_step_count = 0;
        public static bool loading_ready_to_process = false;
        public static bool Transfer_empty_tray_to_unload = false;
        #endregion
        #region Tray_unload_variables
        public static bool Tray_unload_seq_lock = false;
        public static int Tray_unload_step_count = 0;
        public static bool unload_empty_tray = false;
        public static bool unload_empty_tray_done = false;
        #endregion
        public static bool Battery_Place_Completed = false;
        public static bool Barcode_Scan_Completed = false;

        public static bool Streamline1_Completed = false;
        public static bool Streamline1_2_Completed = true;
        public static bool Streamline2_Completed = false;
        public static bool Streamline2_3_Completed = true;
        public static bool Streamline3_Completed = true;


        #region XY_gantry_variables
        public static ushort Gantry_X_Axis = 0;
        public static ushort Gantry_Y_Axis = 0;
        public static string[] Gantry_X_coordinates = new string[10];
        public static string[] Gantry_Y_coordinates = new string[10];
        public static double Gantry_X_Home, Gantry_X_P1, Gantry_X_P2, Gantry_X_P3, Gantry_X_P4, Gantry_X_P5, Gantry_X_P6, Gantry_X_P7, Gantry_X_P8, Gantry_X_P9, Gantry_X_P10, Gantry_X_current_Pos = 0;
        public static double[] Gantry_X_Pick_Position = new double[9];
        public static double[] Gantry_Y_Pick_Position = new double[9];
        public static double Gantry_X_Place_position = 0;
        public static double Gantry_Y_Place_position = 0;
        public static double Gantry_Y_Home, Gantry_Y_P1, Gantry_Y_P2, Gantry_Y_P3, Gantry_Y_P4, Gantry_Y_P5, Gantry_Y_P6, Gantry_Y_P7, Gantry_Y_P8, Gantry_Y_P9, Gantry_Y_P10, Gantry_Y_current_Pos = 0;
        public static double Gantry_X_validation_offset, Gantry_Y_validation_offset = 0;
        #endregion

        public static double[] AP_Pitch = new double[9];
        public static double[] AP_Pulse = new double[9];
        public static double[] AP_PPR = new double[9];
        public static double[] AP_Manual_Acc = new double[9];
        public static double[] AP_Manual_Deacc = new double[9];
        public static double[] AP_Manual_Speed = new double[9];
        public static double[] AP_Jog_Acc = new double[9];
        public static double[] AP_Jog_Deacc = new double[9];
        public static double[] AP_Jog_Speed = new double[9];
        public static double[] AP_Homing_Acc = new double[9];
        public static double[] AP_Homing_Deacc = new double[9];
        public static double[] AP_Homing_Speed = new double[9];
        public static double[] AP_Homing_method = new double[9];
        public static double[] AP_Homing_mode = new double[9];

        public static int Pick_X_Alarm = 0;
        public static int Pick_X_Positive_lim = 0;
        public static int Pick_X_Negative_lim = 0;
        public static int Pick_X_Origin = 0;

        public static int Pick_Y_Alarm = 0;
        public static int Pick_Y_Positive_lim = 0;
        public static int Pick_Y_Negative_lim = 0;
        public static int Pick_Y_Origin = 0;

        public static int Roller_X_Alarm = 0;
        public static int Roller_X_Positive_lim = 0;
        public static int Roller_X_Negative_lim = 0;
        public static int Roller_X_Origin = 0;

        public static int Roller_Y_Alarm = 0;
        public static int Roller_Y_Positive_lim = 0;
        public static int Roller_Y_Negative_lim = 0;
        public static int Roller_Y_Origin = 0;

        public static int Roller_Z_Alarm = 0;
        public static int Roller_Z_Positive_lim = 0;
        public static int Roller_Z_Negative_lim = 0;
        public static int Roller_Z_Origin = 0;

        public static int FI_X_Alarm = 0;
        public static int FI_X_Positive_lim = 0;
        public static int FI_X_Negative_lim = 0;
        public static int FI_X_Origin = 0;

        public static int FI_Y_Alarm = 0;
        public static int FI_Y_Positive_lim = 0;
        public static int FI_Y_Negative_lim = 0;
        public static int FI_Y_Origin = 0;

        #region FI
        //public static ushort FI_X_Axis = 0;
        //public static ushort FI_Y_Axis = 0;
        public static double[] FI_X_coordinates = new double[10];
        public static double[] FI_Y_coordinates = new double[10];
        public static bool Final_Inspection_lock = false;
        public static int FI_step_count = 0;
        public static ushort FI_X_axis, FI_Y_axis = 0;
        public static double FI_X_Current_pos, FI_Y_Current_pos = 0;
        public static double FI_X_Home_Pos, FI_Y_Home_Pos, FI_X_Home_acc, FI_Y_Home_Acc, FI_Y_Home_Deacc, FI_X_Home_Deacc, FI_X_R1_Deacc,
            FI_X_R2_Deacc, FI_X_R3_Deacc, FI_X_R4_Deacc, FI_X_R5_Deacc, FI_Y_R1_Deacc, FI_Y_R2_Deacc, FI_Y_R3_Deacc, FI_Y_R4_Deacc, FI_Y_R5_Deacc = 0;
        public static bool Final_Inspection_start = false;
        public static bool Final_Inspection_done = false;
        public static double[] FI_X_calib_coordinates = new double[20];
        public static double[] FI_Y_calib_coordinates = new double[20];

        #endregion
        #region Roller
        public static ushort Roller_X_Axis = 0;
        public static ushort Roller_Y_Axis = 0;
        public static ushort Roller_Z_Axis = 0;
        public static double[] Roller_x_coordinates = new double[10];
        public static double[] Roller_y_coordinates = new double[10];
        public static double[] Roller_z_coordinates = new double[10];
        public static bool Roller_AutoSeq_lock = false;
        public static int Roller_step_count = 0;
        public static double Roller_X_current_pos, Roller_Y_current_pos, Roller_Z_current_Pos;
        public static double Roller_X_HomePos, Roller_Y_HomePos, Roller_Z_HomePos = 0;

        public static int Roller_Position = 0;
        public static bool Roller_seq_thread_lock = false;
        public static int Roller_seq_count = 0;
        public static bool Roller_process_start = false;
        #endregion
        #region Streamline1
        public static int Streamline1_step_count = 1;
        public static bool Streamline1_Seq_thread_lock = false;
        #endregion
        #region Streamline2
        public static bool Streamline2_Lifter_up_down = false;
        public static bool Streamline2_Seq_thread_lock = false;
        public static int Streamline2_step_count = 1;
        #endregion
        #region Streamline3
        public static bool Streamline3_Seq_thread_lock = false;
        public static int Streamline3_step_count = 1;
        #endregion
        #region Battery_barcode_scan
        public static bool Battery_barcode_scan_seq_thread_lock = false;
        public static int Battery_scan_step_count = 0;
        #endregion
        public static int Pitch_of_the_shaft = 0;
        public static int Pulses_per_revolution = 0;
        public static bool T4_backlight_move = false;
        public static bool PeelOff_seq_lock = false;
        public static int PeelOff_Seq_step_count = 0;
        public static bool T4_Housing_validation_done = false;
        public static bool PDCA_Online = false;
        public static bool Battery_placing_done = false;

        public static bool Peeling_Completed = false;
        public static bool Robo_Homing_seqlock = false;

        //sam
        public static ushort Leadshine_card_No = 0;
        public static bool Robo_Ready_to_Place = false;
        public static bool Robo_Place_Completed = false;

        public static ushort Battery_Pick_X_Axis = 5;
        public static ushort Battery_Pick_Y_Axis = 6;

        public static ushort Battery_Roller_X_Axis = 2;
        public static ushort Battery_Roller_Y_Axis = 3;
        public static ushort Battery_Roller_Z_Axis = 4;

        public static ushort Battery_FI_X_Axis = 0;
        public static ushort Battery_FI_Y_Axis = 1;

        public static double Battery_Pick_X_Acc_Manual = 0.0;
        public static double Battery_Pick_Y_Acc_Manual = 0.0;
        public static double Battery_Pick_X_Decc_Manual = 0.0;
        public static double Battery_Pick_Y_Decc_Manual = 0.0;
        public static double Battery_Pick_X_Speed_Manual = 0.0;
        public static double Battery_Pick_Y_Speed_Manual = 0.0;

        public static double Battery_Roller_X_Acc_Manual = 0.0;
        public static double Battery_Roller_Y_Acc_Manual = 0.0;
        public static double Battery_Roller_Z_Acc_Manual = 0.0;
        public static double Battery_Roller_X_Decc_Manual = 0.0;
        public static double Battery_Roller_Y_Decc_Manual = 0.0;
        public static double Battery_Roller_Z_Decc_Manual = 0.0;
        public static double Battery_Roller_X_Speed_Manual = 0.0;
        public static double Battery_Roller_Y_Speed_Manual = 0.0;
        public static double Battery_Roller_Z_Speed_Manual = 0.0;

        public static double Battery_FI_X_Acc_Manual = 0.0;
        public static double Battery_FI_Y_Acc_Manual = 0.0;
        public static double Battery_FI_X_Decc_Manual = 0.0;
        public static double Battery_FI_Y_Decc_Manual = 0.0;
        public static double Battery_FI_X_Speed_Manual = 0.0;
        public static double Battery_FI_Y_Speed_Manual = 0.0;



        public static bool[] MC_Read_DI = new bool[16];
        public static bool[] MC_Read_DO = new bool[16];
        public static int[] MC_Write_DO = new int[16];
        //
        //pulses per mm = pulses per revolution  / pitch of the shaft (mm)
        //Pulses required = Pulses per mm * target position in (mm)

        /// <summary>
        /// --- Decalred ----
        /// </summary>
        public static double[] Gantry_X_Pick_velocity = new double[15];
        public static double[] Gantry_Y_Pick_velocity = new double[15];
        public static double[] Gantry_Y_Pick_Acceleration = new double[15];
        public static double[] Gantry_X_Pick_Acceleration = new double[15];
        public static double[] Gantry_Y_pick_acceleration = new double[15];
        public static double[] Gantry_X_Pick_Deacceleration = new double[15];
        public static double[] Gantry_Y_pick_Deacceleration = new double[15];
        public static double[] Gantry_X_Offset = new double[15];
        public static double[] Gantry_Y_Offset = new double[15];
        public static double Gantry_X_Place_Offset = 0.0;
        // public static double Gantry_X_Place_Offset = 0.0;
        public static double Gantry_Y_place_Offset = 0.0;
        //public static double[] Gantry_Y_place_Offset=new double[15];
        //public static double[] Gantry_Y_Home_Offset=new double[15];

        public static bool Alarm_Pause = false;
        public static bool Alarm_Stop = false;
        public static bool Manual_Pause = false;
        public static bool Manual_Stop = false;
        public static bool Fault_reset = false;

        public static double Gantry_X_Place_velocity = 0.0;
        public static double Gantry_Y_place_velocity = 0.0;
        public static double Gantry_X_Place_Acceleration = 0.0;
        public static double Gantry_Y_Place_acceleration = 0.0;
        public static double Gantry_X_Place_Deacceleration = 0.0;
        public static double Gantry_Y_Place_Deacceleration = 0.0;
        public static double Gantry_X_Home_Acceleration = 0.0;
        public static double Gantry_Y_Home_acceleration = 0.0;
        public static double Gantry_X_Home_Deacceleration = 0.0;
        public static double Gantry_Y_Home_Deacceleration = 0.0;
        public static double Gantry_X_Home_velocity = 0.0;
        public static double Gantry_Y_Home_velocity = 0.0;
        public static double Gantry_X_Home_Offset = 0.0;
        public static double Gantry_Y_Home_Offset = 0.0;

        public static double Roller_X_Home_Acceleration = 0.0;
        public static double Roller_Y_Home_Acceleration = 0.0;
        public static double Roller_Z_Home_Acceleration = 0.0;
        public static double Roller_X_Home_Deacceleration = 0.0;
        public static double Roller_Y_Home_Deacceleration = 0.0;
        public static double Roller_Z_Home_Deacceleration = 0.0;
        public static double[] Roller_X_Pick_Acceleration = new double[15];
        public static double[] Roller_Y_pick_acceleration = new double[15];
        public static double[] Roller_Z_pick_acceleration = new double[15];
        public static double[] Roller_X_Pick_Deacceleration = new double[15];
        public static double[] Roller_Y_pick_Deacceleration = new double[15];
        public static double[] Roller_Z_pick_Deacceleration = new double[15];
        public static double Roller_X_Home_velocity = 0.0;
        public static double Roller_Y_Home_velocity = 0.0;
        public static double Roller_Z_Home_velocity = 0.0;
        public static double[] Roller_X_Pick_velocity = new double[15];
        public static double[] Roller_Y_pick_velocity = new double[15];
        public static double[] Roller_Z_pick_velocity = new double[15];

        // public static double Gantry_X_Home_Acc, Gantry_X_P1_Acc, Gantry_X_P2_Acc, 
        // Gantry_X_P3_Acc, Gantry_X_P4_Acc, Gantry_X_P5_Acc, Gantry_X_P6_Acc, 
        // Gantry_X_P7_Acc, Gantry_X_P8_Acc, Gantry_X_P9_Acc, Gantry_X_P10_Acc, Gantry_X_current_Pos_Acc = 0;

        // public static double Gantry_X_Home_Deacc, Gantry_X_P1_Deacc, Gantry_X_P2_Deacc,
        // Gantry_X_P3_Deacc, Gantry_X_P4_Deacc, Gantry_X_P5_Deacc, Gantry_X_P6_Deacc,
        // Gantry_X_P7_Deacc, Gantry_X_P8_Deacc, Gantry_X_P9_Deacc, Gantry_X_P10_Deacc, 
        // Gantry_X_current_Pos_Deacc = 0;

        // public static double Gantry_Y_Home_Acc, Gantry_Y_P1_Acc, Gantry_Y_P2_Acc, 
        // Gantry_Y_P3_Acc, Gantry_Y_P4_Acc, Gantry_Y_P5_Acc, 
        // Gantry_Y_P6_Acc, Gantry_Y_P7_Acc, Gantry_Y_P8_Acc, Gantry_Y_P9_Acc, Gantry_Y_P10_Acc,
        // Gantry_Y_current_Pos_Acc = 0;

        // public static double Gantry_Y_Home_Deacc, Gantry_Y_P1_Deacc, Gantry_Y_P2_Deacc,
        // Gantry_Y_P3_Deacc, Gantry_Y_P4_Deacc, Gantry_Y_P5_Deacc,
        // Gantry_Y_P6_Deacc, Gantry_Y_P7_Deacc, Gantry_Y_P8_Deacc, Gantry_Y_P9_Deacc, Gantry_Y_P10_Deacc,
        // Gantry_Y_current_Pos_Deacc = 0;

        // public static double Gantry_X_Home_Speed, Gantry_X_P1_Speed, Gantry_X_P2_Speed,
        //Gantry_X_P3_Speed, Gantry_X_P4_Speed, Gantry_X_P5_Speed,
        //Gantry_X_P6_Speed, Gantry_X_P7_Speed, Gantry_X_P8_Speed, Gantry_X_P9_Speed, Gantry_X_P10_Speed,
        //Gantry_X_current_Pos_Speed = 0;

        // public static double Gantry_Y_Home_Speed, Gantry_Y_P1_Speed, Gantry_Y_P2_Speed,
        //Gantry_Y_P3_Speed, Gantry_Y_P4_Speed, Gantry_Y_P5_Speed,
        //Gantry_Y_P6_Speed, Gantry_Y_P7_Speed, Gantry_Y_P8_Speed, Gantry_Y_P9_Speed, Gantry_Y_P10_Speed,
        //Gantry_Y_current_Pos_Speed = 0;


        // //Roller Assigning

        // public static double Roller_X_Home, Roller_X_R1, Roller_X_R2, Roller_X_R3, Roller_X_R4, 
        // Roller_X_R5, Roller_X_current_Pos = 0;

        // public static double Roller_Y_Home, Roller_Y_R1, Roller_Y_R2, Roller_Y_R3, Roller_Y_R4, 
        // Roller_Y_R5, Roller_Y_current_Pos = 0;

        // public static double Roller_Z_Home, Roller_Z_R1, Roller_Z_R2, Roller_Z_R3, Roller_Z_R4,
        // Roller_Z_R5;

        // public static double Roller_X_Home_Acc, Roller_X_R1_Acc, Roller_X_R2_Acc,
        // Roller_X_R3_Acc, Roller_X_R4_Acc, Roller_X_R5_Acc, Roller_X_current_Pos_Acc = 0;

        // public static double Roller_X_Home_Deacc, Roller_X_R1_Deacc, Roller_X_R2_Deacc,
        // Roller_X_R3_Deacc, Roller_X_R4_Deacc, Roller_X_R5_Deacc,Roller_X_current_Pos_Deacc = 0;

        // public static double Roller_Y_Home_Acc, Roller_Y_R1_Acc, Roller_Y_R2_Acc,
        // Roller_Y_R3_Acc, Roller_Y_R4_Acc, Roller_Y_R5_Acc,
        // Roller_Y_current_Pos_Acc = 0;

        // public static double Roller_Y_Home_Deacc, Roller_Y_R1_Deacc, Roller_Y_R2_Deacc,
        // Roller_Y_R3_Deacc, Roller_Y_R4_Deacc, Roller_Y_R5_Deacc,
        // Roller_Y_current_Pos_Deacc = 0;

        // public static double Roller_Z_Home_Acc, Roller_Z_R1_Acc, Roller_Z_R2_Acc,
        // Roller_Z_R3_Acc, Roller_Z_R4_Acc, Roller_Z_R5_Acc,
        // Roller_Z_current_Pos_Acc = 0;

        // public static double Roller_Z_Home_Deacc, Roller_Z_R1_Deacc, Roller_Z_R2_Deacc,
        // Roller_Z_R3_Deacc, Roller_Z_R4_Deacc, Roller_Z_R5_Deacc,
        // Roller_Z_current_Pos_Deacc = 0;

        // public static double Roller_X_Home_Speed, Roller_X_R1_Speed, Roller_X_R2_Speed,
        //Roller_X_R3_Speed, Roller_X_R4_Speed, Roller_X_R5_Speed,
        //Roller_X_current_Pos_Speed = 0;

        //public static double Roller_Y_Home_Speed, Roller_Y_R1_Speed, Roller_Y_R2_Speed,
        //Roller_Y_R3_Speed, Roller_Y_R4_Speed, Roller_Y_R5_Speed,
        //Roller_Y_current_Pos_Speed = 0;


        // public static double Roller_Z_Home_Speed, Roller_Z_R1_Speed, Roller_Z_R2_Speed,
        // Roller_Z_R3_Speed, Roller_Z_R4_Speed, Roller_Z_R5_Speed,
        // Roller_Z_current_Pos_Speed = 0;

        // //FI Assigning

        // public static double FI_X_Home, FI_X_R1, FI_X_R2, FI_X_R3, FI_X_R4,
        // FI_X_R5, FI_X_current_Pos = 0;

        // public static double FI_Y_Home, FI_Y_R1, FI_Y_R2, FI_Y_R3, FI_Y_R4,
        // FI_Y_R5, FI_Y_current_Pos = 0;

        // public static double FI_X_Home_Acc, FI_X_R1_Acc, FI_X_R2_Acc,
        // FI_X_R3_Acc, FI_X_R4_Acc, FI_X_R5_Acc, FI_X_current_Pos_Acc = 0;

        // public static double FI_X_Home_Deacc, FI_X_R1_Deacc, FI_X_R2_Deacc,
        // FI_X_R3_Deacc, FI_X_R4_Deacc, FI_X_R5_Deacc, FI_X_current_Pos_Deacc = 0;

        // public static double FI_Y_Home_Acc, FI_Y_R1_Acc, FI_Y_R2_Acc,
        // FI_Y_R3_Acc, FI_Y_R4_Acc, FI_Y_R5_Acc,
        // FI_Y_current_Pos_Acc = 0;

        // public static double FI_Y_Home_Deacc, FI_Y_R1_Deacc, FI_Y_R2_Deacc,
        // FI_Y_R3_Deacc, FI_Y_R4_Deacc, FI_Y_R5_Deacc,
        // FI_Y_current_Pos_Deacc = 0;

        //public static double FI_X_Home_Speed, FI_X_R1_Speed, FI_X_R2_Speed,
        //FI_X_R3_Speed, FI_X_R4_Speed, FI_X_R5_Speed,
        //FI_X_current_Pos_Speed = 0;

        // public static double FI_Y_Home_Speed, FI_Y_R1_Speed, FI_Y_R2_Speed,
        //FI_Y_R3_Speed, FI_Y_R4_Speed, FI_Y_R5_Speed,
        //FI_Y_current_Pos_Speed = 0;


        public static int[] leadshine_Input = new int[15];
        public static int[] leadshine_Output = new int[9];

        public static bool error_active = false;

        public static string Login_user_mode = string.Empty;



        //Importing from the document

        public static int Gantry_X_axis_PPR = 0;
        public static int Gantry_Y_AXIS_PPR = 0;
        public static int Gantry_X_Axis_Pitch = 0;
        public static int Gantry_Y_Axis_Pitch = 0;
        //-------------------------------------------------------T1,1,1,BatteryX,BatteryY,BatteryAngle,GANTRY_TO_BACKLIGHT_X,GANTRY_TO_BACKLIGHT_Y,GANTRY_TO_BACKLIGHT_A
        public static string BatteryX = string.Empty;
        public static string BatteryY = string.Empty;
        public static string BatteryAngle = string.Empty;
        public static string GANTRY_TO_BACKLIGHT_X = string.Empty;
        public static string GANTRY_TO_BACKLIGHT_Y = string.Empty;
        public static string GANTRY_TO_BACKLIGHT_A = string.Empty;
        //----------------------------------------------------T4,4,1,B1,B2,B3,B4,B5，ROBOTPICK_TO_BACKLIGHT_X，ROBOTPICK_TO_BACKLIGHT_Y,ROBOTPICK_TO_BACKLIGHT_A，DeltaX，DeltaY，DeltaAngle
        public static string[] T4_4_values_received = new string[15];
        //------------------------------------------------------RObot T32 X,Y,A coordinates
        public static string[] Robot_T32_coordinates = new string[8];
        //-------------------------------------------------------Vision T32 responses
        public static string[] T3_2_values_received = new string[20];
        //-------------------------------------------------------vision T41 responses
        public static string[] T4_1_values_received = new string[20];
        //-------------------------------------------------------Robot T45 x,y,a coordinates
        public static string[] T45_XY_Coordinates_from_Robo = new string[8];
        //-------------------------------------------------------vision T45 responses
        public static string[] T4_5_values_received = new string[25];
        //--------------------------------------------------------Robot Closed loop coordinates
        public static string[] Closedloop_XY_coordinates_received_from_Robo = new string[8];
        //---------------------------------------------------------vision T43 response
        public static string[] T4_3_received_value = new string[20];

        public static bool start, stop, resume_or_pause = false;
        public static bool Homing_done = false;

        #region Axis_Homing
        public static int XY_Gantry_Homing_stepcount = 0;
        public static int Roller_Homing_stepcount = 0;
        public static int FI_Homing_stepcount = 0;
        public static int Homing_stepcount = 0;
        public static bool X_process, Y_process = false;
        public static bool Roller_X_process, Roller_Y_process, Roller_Z_process = false;
        public static bool FI_X_process, FI_Y_process = false;
        public static bool XY_Homing_done, Roller_Homing_done, FI_Homing_done,Robo_Homing_done = false;
        public static bool Streamline_Homing_done = false;
        #endregion

        public static bool dry_cycle_enable = false;
        public static string Housing_Barcode = string.Empty;
        public static double[] Roller_X_Rollposition = new double[5], Roller_Y_Rollposition = new double[5], Roller_Z_Rollposition = new double[5];

        #region FI
        public static double[] FI_X_Move_pos = new double[10];
        public static double[] FI_X_velocity = new double[10];
        public static double[] FI_X_acceleration = new double[10];
        public static double[] FI_Y_Move_pos = new double[10];
        public static double[] FI_Y_velocity = new double[10];
        public static double FI_X_Home_velocity = 0.0;
        public static double FI_Y_Home_velocity = 0.0;
        public static double[] FI_Y_acceleration = new double[10];
        public static double[] FI_X_Deacceleration = new double[10];
        public static double[] FI_Y_Deacceleration = new double[10];
        public static int FI_X_axis_PPR = 0;
        public static int FI_Y_axis_PPR = 0;
        public static int FI_X_axis_pitch = 0;
        public static int FI_Y_axis_pitch = 0;
        public static double FI_start_Pos = 0;
        public static double FI_end_Pos = 0;
        public static int[] FI_X1_Compare_pos = new int[6];
        public static int[] FI_Y1_Compare_pos = new int[4];
        public static int[] FI_X2_Compare_pos = new int[6];
        public static int[] FI_Y2_Compare_pos = new int[4];

        #endregion
        public static int Roller_X_axis_PPR = 0;
        public static int Roller_Y_axis_PPR = 0;
        public static int Roller_Z_axis_PPR = 0;
        public static int Roller_X_axis_pitch = 0;
        public static int Roller_Y_axis_pitch = 0;
        public static int Roller_Z_axis_pitch = 0;

        #region Device
        public static bool Scanner_Bypass = false;
        public static bool Safety_Door_Bypass = false;
        public static bool SFC_Bypass = false;
        public static bool PDCA_Bypass = false;
        public static bool Dry_run = false;
        public static bool Production_mode = false;
        public static bool Online_mode = false;
        public static bool Offline_mode = false;
        public static bool Conveyor_Run_with_Tray = false;
        public static bool Conveyor_Run_without_Tray = false;
        public static bool Hive = false;


        public static string D_CCD1 = string.Empty;
        public static string D_CCD3 = string.Empty;
        public static string D_CCD4 = string.Empty;
        public static string D_CCD5 = string.Empty;
        public static string D_Scanner = string.Empty;
        public static string D_SFC = string.Empty;
        public static string D_PDCA = string.Empty;
        public static string D_RObot = string.Empty;
        public static Form1 previousform;
        public static LoginScreen LoginScreen;
        public static bool Login_Successful = false;
        #endregion


        #region Recipe
        public static ushort Gantry_Pick_X_Axis = 1;
        public static ushort Gantry_Pick_Y_Axis = 2;
        public static ushort Roller_roll_X_Axis = 3;
        public static ushort Roller_roll_Y_Axis = 4;
        public static ushort Roller_roll_Z_Axis = 5;
        public static ushort FI_X_Axis = 6;
        public static ushort FI_Y_Axis = 7;


        public static double Gantry_X_Pick_manual_velocity = 0.0;
        public static double Gantry_X_Pick_manual_acceleration = 0.0;
        public static double Gantry_Y_Pick_manual_velocity = 0.0;
        public static double Gantry_Y_Pick_manual_acceleration = 0.0;

        public static double Roller_X_Pick_manual_velocity = 0.0;
        public static double Roller_X_Pick_manual_acceleration = 0.0;
        public static double Roller_Y_Pick_manual_velocity = 0.0;
        public static double Roller_Y_Pick_manual_acceleration = 0.0;
        public static double Roller_Z_Pick_manual_velocity = 0.0;
        public static double Roller_Z_Pick_manual_acceleration = 0.0;

        public static double FI_X_Pick_manual_velocity = 0.0;
        public static double FI_X_Pick_manual_acceleration = 0.0;
        public static double FI_Y_Pick_manual_velocity = 0.0;
        public static double FI_Y_Pick_manual_acceleration = 0.0;


        #endregion




        public static void ReadRetentiveFromIni()
        {
            try
            {
                Globalvariable.Gantry_X_Axis = Convert.ToUInt16(devices_iNI.Read("Gantry", "Gantry_X_axis_Number"));
                Globalvariable.Gantry_Y_Axis = Convert.ToUInt16(devices_iNI.Read("Gantry", "Gantry_Y_axis_Number"));
                Globalvariable.Gantry_X_axis_PPR = int.Parse(devices_iNI.Read("Gantry", "Gantry_X_axis_PPR"));
                Globalvariable.Gantry_Y_AXIS_PPR = int.Parse(devices_iNI.Read("Gantry", "Gantry_Y_axis_PPR"));
                Globalvariable.Gantry_X_Axis_Pitch = int.Parse(devices_iNI.Read("Gantry", "Gantry_X_axis_Pitch"));
                Globalvariable.Gantry_Y_Axis_Pitch = int.Parse(devices_iNI.Read("Gantry", "Gantry_Y_axis_Pitch"));

                Globalvariable.FI_X_axis = Convert.ToUInt16(devices_iNI.Read("FI", "FI_X_axis_Number"));
                Globalvariable.FI_Y_axis = Convert.ToUInt16(devices_iNI.Read("FI", "FI_Y_axis_Number"));
                Globalvariable.FI_X_axis_PPR = int.Parse(devices_iNI.Read("FI", "FI_X_axis_PPR"));
                Globalvariable.FI_Y_axis_PPR = int.Parse(devices_iNI.Read("FI", "FI_Y_axis_PPR"));
                Globalvariable.FI_X_axis_pitch = int.Parse(devices_iNI.Read("FI", "FI_X_axis_Pitch"));
                Globalvariable.FI_Y_axis_pitch = int.Parse(devices_iNI.Read("FI", "FI_Y_axis_Pitch"));

                Globalvariable.Roller_X_Axis = Convert.ToUInt16(devices_iNI.Read("Roller", "Roller_X_axis_Number"));
                Globalvariable.Roller_Y_Axis = Convert.ToUInt16(devices_iNI.Read("Roller", "Roller_Y_axis_Number"));
                Globalvariable.Roller_Z_Axis = Convert.ToUInt16(devices_iNI.Read("Roller", "Roller_Z_axis_Number"));
                Globalvariable.Roller_X_axis_PPR = int.Parse(devices_iNI.Read("Roller", "Roller_X_axis_PPR"));
                Globalvariable.Roller_Y_axis_PPR = int.Parse(devices_iNI.Read("Roller", "Roller_Y_axis_PPR"));
                Globalvariable.Roller_Z_axis_PPR = int.Parse(devices_iNI.Read("Roller", "Roller_Z_axis_PPR"));
                Globalvariable.Roller_X_axis_pitch = int.Parse(devices_iNI.Read("Roller", "Roller_X_axis_Pitch"));
                Globalvariable.Roller_Y_axis_pitch = int.Parse(devices_iNI.Read("Roller", "Roller_Y_axis_Pitch"));
                Globalvariable.Roller_Y_axis_pitch = int.Parse(devices_iNI.Read("Roller", "Roller_Y_axis_Pitch"));

                Globalvariable.D_CCD1 = devices_iNI.Read("DeviceIP", "CCD1");
                Globalvariable.D_CCD3 = devices_iNI.Read("DeviceIP", "CCD3");
                Globalvariable.D_CCD4 = devices_iNI.Read("DeviceIP", "CCD4");
                Globalvariable.D_CCD5 = devices_iNI.Read("DeviceIP", "CCD5");
                Globalvariable.D_Scanner = devices_iNI.Read("DeviceIP", "Scanner");
                Globalvariable.D_SFC = devices_iNI.Read("DeviceIP", "SFC");
                Globalvariable.D_PDCA = devices_iNI.Read("DeviceIP", "PDCA");
                Globalvariable.D_RObot = devices_iNI.Read("DeviceIP", "Robot");



            }
            catch (Exception ex)
            {

                // Logger.WriteLog1("General", "LoadTags", "Error", ex.ToString());
            }
        }
        public static void XY_gantry_Homing()
        {
            while (XY_Homing_done)// aborting option include and include delay time
            {
                switch (XY_Gantry_Homing_stepcount)
                {
                    case 1:
                        if (Globalvariable.MC_Read_DI[Variables.Gantry_battery_suction_cyl_retraction_sensor])
                        {
                            if (LeadShineInterface.Axis_check_done(Globalvariable.Leadshine_card_No, Gantry_X_Axis) && LeadShineInterface.Axis_check_done(Globalvariable.Leadshine_card_No, Gantry_Y_Axis))
                            {
                                X_process = LeadShineInterface.Homing(Gantry_X_Axis, Globalvariable.Leadshine_card_No);
                                Y_process = LeadShineInterface.Homing(Gantry_Y_Axis, Globalvariable.Leadshine_card_No);
                                XY_Gantry_Homing_stepcount = 2;
                            }
                        }

                        else
                        {
                            LeadShineInterface.Write_DO_Leadshine(Globalvariable.Leadshine_card_No, (ushort)Globalvariable.MC_Write_DO[Variables.XY_Gantry_Battery_Pick_Cyl_extract], 0);
                            LeadShineInterface.Write_DO_Leadshine(Globalvariable.Leadshine_card_No, (ushort)Globalvariable.MC_Write_DO[Variables.XY_Gantry_Battery_pick_Cyl_retract], 1);

                        }
                        break;
                    case 2:
                        if (X_process && Y_process)
                        {
                            Globalvariable.Gantry_X_current_Pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Gantry_X_Axis);
                            Globalvariable.Gantry_Y_current_Pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Gantry_Y_Axis);
                            if ((Math.Abs(Globalvariable.Gantry_X_Home - Globalvariable.Gantry_X_current_Pos) <= Globalvariable.Gantry_X_validation_offset) && (Math.Abs(Globalvariable.Gantry_Y_Home - Globalvariable.Gantry_Y_current_Pos) <= Globalvariable.Gantry_Y_validation_offset))
                            {
                                XY_Homing_done = true;

                                XY_Gantry_Homing_stepcount = 0;

                            }
                        }
                        break;


                }
            }
        }
        public static void Roller_Homing()
        {
            while (Roller_Homing_done)
            {
                switch (Roller_Homing_stepcount)
                {
                    case 1:
                        Globalvariable.Roller_X_current_pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Roller_X_Axis);
                        Globalvariable.Roller_Y_current_pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Roller_Y_Axis);
                        Globalvariable.Roller_Z_current_Pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Roller_Z_Axis);
                        if ((Math.Abs(Globalvariable.Roller_Z_HomePos - Globalvariable.Roller_Z_current_Pos) <= Globalvariable.Gantry_Y_validation_offset))//) && (Math.Abs(Globalvariable.Gantry_Y_Home - Globalvariable.Gantry_Y_current_Pos) <= Globalvariable.Gantry_Y_validation_offset))
                        {
                            Roller_Homing_stepcount = 2;
                        }
                        else
                        {
                            if (LeadShineInterface.Axis_check_done(Globalvariable.Leadshine_card_No, Globalvariable.Roller_Z_Axis))
                            {
                                Roller_Z_process = LeadShineInterface.Homing(Globalvariable.Leadshine_card_No, Roller_Z_Axis);
                            }
                        }


                        break;
                    case 2:
                        if (LeadShineInterface.Axis_check_done(Globalvariable.Leadshine_card_No, Roller_X_Axis) &&
                            LeadShineInterface.Axis_check_done(Globalvariable.Leadshine_card_No, Globalvariable.Roller_Y_Axis) &&
                              LeadShineInterface.Axis_check_done(Globalvariable.Leadshine_card_No, Globalvariable.Roller_Z_Axis))
                        {
                            Roller_X_process = LeadShineInterface.Homing(Globalvariable.Leadshine_card_No, Roller_X_Axis);
                            Roller_Y_process = LeadShineInterface.Homing(Globalvariable.Leadshine_card_No, Roller_Y_Axis);
                            Roller_Homing_stepcount = 3;
                        }
                        break;


                    case 3:
                        if (Roller_X_process && Roller_Y_process)
                        {
                            Globalvariable.Roller_X_current_pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Roller_X_Axis);
                            Globalvariable.Roller_Y_current_pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Roller_Y_Axis);
                            if ((Math.Abs(Globalvariable.Roller_X_HomePos - Globalvariable.Roller_X_current_pos) <= Globalvariable.Gantry_X_validation_offset) &&
                                (Math.Abs(Globalvariable.Roller_Y_HomePos - Globalvariable.Roller_Y_current_pos) <= Globalvariable.Gantry_Y_validation_offset))
                            {
                                Roller_Homing_done = true;
                                Roller_Homing_stepcount = 0;
                            }
                        }
                        break;



                }
            }
        }


        public static void Streamline_Homing()
        {
            Homing_stepcount = 1;
            while (!Streamline_Homing_done)
            {
                switch (Homing_stepcount)
                {

                    case 1:
                       // PLC.WRITE_DO_TO_PLC(Variables.Streamline2_lifitng_cyl_extends, 0);
                        Homing_stepcount = 2;
                        break;
                    case 2:
                        //if (PLC.DIO_Read[Variables.Streamline2_Jacking_cylinde_retract] == 1)
                        //{
                        //    PLC.WRITE_DO_TO_PLC(Variables.T4_backlight_panel_retract, 1);
                        //   // Thread.Sleep(200);
                        //    PLC.WRITE_DO_TO_PLC(Variables.T4_backlight_panel_extend, 0);
                        //   // Thread.Sleep(200);
                        //    Homing_stepcount = 3;
                        //}
                        //else
                        //{
                        //    Homing_stepcount = 2;
                        //}

                        break;

                    case 3:
                        //if(PLC.DIO_Read[Variables.T4_backlight_retraction_sensor] == 1)
                        //{
                        //    PLC.WRITE_DO_TO_PLC(Variables.vertical_Positioning1_rear, 0);
                        //   // Thread.Sleep(200);
                        //    PLC.WRITE_DO_TO_PLC(Variables.Streamline2_push_cyclinder, 0);
                        //   // Thread.Sleep(200);
                        //    PLC.WRITE_DO_TO_PLC(Variables.Horizontal_Fold, 0);
                        //   // Thread.Sleep(200);
                        //    PLC.WRITE_DO_TO_PLC(Variables.Intermediate_flowline_HSG_jacket_cyl_retracted, 1);
                        //    //Thread.Sleep(200);
                        //    PLC.WRITE_DO_TO_PLC(Variables.Intermediate_flowline_HSG_jacket_cyl_extend, 0);
                        //   // Thread.Sleep(200);
                        //    Homing_stepcount = 4;
                        //}
                        //else
                        //{
                        //    Homing_stepcount = 3;

                        //}
                        break;

                    case 4:
                        //if(PLC.DIO_Read[Variables.Streamline2_clamps_vertically1_front_out] == 1 && PLC.DIO_Read[Variables.Streamline2_Verical1_positioning_retracted] == 1 && PLC.DIO_Read[Variables.Streamline2_flips_horizontal_fold_retract] == 1 && PLC.DIO_Read[Variables.Streamline2_HSG_Jacking_cylinder_retract] == 1)
                        //{
                        //    Homing_stepcount = 1;
                        //    Streamline_Homing_done = true;
                        //    DialogResult result = MessageBox.Show("Streamline Homing Completed !", "Done", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                        //    return;
                        //}
                        //else
                        //{
                        //    Homing_stepcount = 4;
                        //}
                        break;



                }
            }
        }
        public static void FI_Homing()
        {
            while (FI_Homing_done)
            {
                switch (FI_Homing_stepcount)
                {
                    case 1:

                        if (LeadShineInterface.Axis_check_done(Globalvariable.Leadshine_card_No, FI_X_axis) &&
                        LeadShineInterface.Axis_check_done(Globalvariable.Leadshine_card_No, FI_Y_axis))
                        {
                            FI_X_process = LeadShineInterface.Homing(Globalvariable.Leadshine_card_No, FI_X_axis);
                            FI_Y_process = LeadShineInterface.Homing(Globalvariable.Leadshine_card_No, FI_Y_axis);
                            FI_Homing_stepcount = 2;
                        }

                        break;
                    case 2:
                        if (FI_X_process && FI_Y_process)
                        {
                            Globalvariable.FI_X_Current_pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, FI_X_axis);
                            Globalvariable.FI_Y_Current_pos = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, FI_Y_axis);
                            if ((Math.Abs(Globalvariable.FI_X_Home_Pos - Globalvariable.FI_X_Current_pos) <= Globalvariable.Gantry_X_validation_offset) &&
                                (Math.Abs(Globalvariable.FI_Y_Home_Pos - Globalvariable.FI_Y_Current_pos) <= Globalvariable.Gantry_Y_validation_offset))
                            {
                                FI_Homing_done = true;
                                FI_Homing_stepcount = 0;

                            }
                        }
                        break;


                }
            }
        }

        public static void Homing_check()
        {
            while (Homing_done)
            {
                if (XY_Homing_done && Roller_Homing_done && FI_Homing_done)
                {
                    MessageBox.Show("Homing Done", "Information!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Homing_done = true;
                }
            }
        }

        public static void Start_function()
        {
            if (!resume_or_pause && start)
            {
                if (Globalvariable.XY_Homing_done && Globalvariable.Roller_Homing_done && Globalvariable.FI_Homing_done)
                {
                    //XY_Gantry.start_Thread_XY_Gantry_prcss();
                   
                    //Streamline1.start_Thread_Streamline1_prcss();
                
                }
                else
                {
                    DialogResult result = MessageBox.Show("Do homing before start the process", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                    if (result == DialogResult.OK)
                    {
                        Globalvariable.XY_Gantry_Homing_stepcount = 1;
                        Globalvariable.Roller_Homing_stepcount = 1;
                        Globalvariable.FI_Homing_stepcount = 1;
                        Globalvariable.XY_gantry_Homing();
                        Globalvariable.Roller_Homing();
                        Globalvariable.FI_Homing();
                        Homing_done = false;
                        Homing_check();
                    }
                    else if (result == DialogResult.Cancel)
                    {

                        MessageBox.Show("Homing Process Cancelled !");
                    }
                }


            }
        }



        //Alarm calling

        public static bool CAlarm_intrlock = false;
        public static List<string> C_alarm = new List<string>();
        public static void findAlarmdetails(string errordescription)
        {
            try
            {
                if (Form1.Alarmlist.ContainsKey(errordescription)) //it checks whether the particlar alarm there or not
                {

                    string msgAlarmcode = Form1.Alarmlist[errordescription]; //error code will be stored
                    string msgAlarmdescription = errordescription; //error description will be stored
                    Add_C_Alarm(msgAlarmdescription, msgAlarmcode);//calling the insert function

                }
                else
                {
                    MessageBox.Show("Alarm Live Screen Error:The Alarm Details not there in the File");
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alarm Live screen:Error in this function:findAlarmdetails()" + ex);
                return;
            }
        }

        public static void Add_C_Alarm(string msgAlarmdescription, string msgAlarmcode)
        {
            string category = string.Empty; // to store the category data initially assigned as empty
            string shift = string.Empty;
            if (!CAlarm_intrlock)
            {
                CAlarm_intrlock = true;
                try
                {
                    // Set category based on Alarm Code
                    if (msgAlarmcode == "1000")
                    {
                        category = "Safety";
                    }
                    else
                    {
                        category = "Error";
                    }

                    bool alarmExists = false;
                    using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
                    {
                        connection.Open();

                        // Check if the alarm already exists in the database
                        string checkAlarmQuery = "SELECT COUNT(*) FROM Alarm_Log_Data " +
                                                 "WHERE Error_Description = @ErrorDescription AND End_Time IS NULL";
                        using (SqlCommand checkCommand = new SqlCommand(checkAlarmQuery, connection))
                        {
                            checkCommand.Parameters.AddWithValue("@ErrorDescription", msgAlarmdescription);
                            int count = (int)checkCommand.ExecuteScalar();
                            if (count > 0)
                            {
                                alarmExists = true;
                            }
                        }
                    }
                    if (alarmExists)   //need to change it to the home screen tab
                    {
                        //AlarmLiveScreen alarmpage = new AlarmLiveScreen();
                        //alarmpage.AlarmDataingrid();
                        //return;
                    }

                    // If the alarm does not exist, proceed with insertion
                    string[] dataalarmdescription = new string[] { msgAlarmdescription };
                    string[] datalarmcode = new string[] { msgAlarmcode };
                    string endTime = DBNull.Value.ToString(); // Ensure this is set as DBNull if needed
                    C_alarm.Add(DateTime.Now.ToString("HH:mm:ss") + ": " + datalarmcode[0]);
                    //For shift
                    string connectionString = SQLHelper.get_ConnName();
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand("SP_Shift", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            conn.Open();
                            var result = cmd.ExecuteScalar();
                            if (result != null)
                            {
                                shift = result.ToString();
                            }
                            else
                            {
                                MessageBox.Show("No result while retriving Shift");
                            }
                        }
                    }

                    // Insert the new alarm into the database
                    using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
                    {
                        connection.Open();

                        string SqlQuery = "INSERT INTO Alarm_Log_Data (Start_Time, End_Time, Error_Code, Error_Description, Error_Category,Shift) " +
                                          "VALUES (@StartTime, @EndTime, @ErrorCode, @ErrorDescription, @ErrorCategory , @Shift)";

                        using (SqlCommand command = new SqlCommand(SqlQuery, connection))
                        {
                            command.Parameters.AddWithValue("@StartTime", DateTime.Now);
                            command.Parameters.AddWithValue("@EndTime", DBNull.Value);
                            command.Parameters.AddWithValue("@ErrorCode", datalarmcode[0]);
                            command.Parameters.AddWithValue("@ErrorDescription", dataalarmdescription[0]);
                            command.Parameters.AddWithValue("@ErrorCategory", category);
                            command.Parameters.AddWithValue("@Shift", shift);
                            command.ExecuteNonQuery();
                        }
                    }

                    // After inserting, update the alarm grid
                    Globalvariable.error_active = true;
                    if (Globalvariable.error_active)
                    {
                        //AlarmLiveScreen alarmpage = new AlarmLiveScreen();
                        //alarmpage.AlarmDataingrid(); // Show the alarm grid after inserting a new alarm

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("AlarmLive Screen--Error in this function:Add_C_Alarm()" + ex);
                    return;
                }
                finally
                {
                    CAlarm_intrlock = false;
                }
            }
            else
            {
                MessageBox.Show("Alarm function is currently locked.");
                return;
            }
        }

        public static void Update_C_Alarm()
        {
            // AlarmLiveScreen alarmpage = new AlarmLiveScreen();
            //alarmpage.ALarm_dataGridView1.DataSource = null;
            try
            {
                using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
                {
                    connection.Open();
                    string almQry = "UPDATE Alarm_Log_Data SET End_Time = GETDATE() WHERE End_Time IS NULL";

                    using (SqlCommand command = new SqlCommand(almQry, connection))
                    {
                        int result = command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Alarm Live screen:Error in this function:Update_C_Alarm()" + ex);
                return;
            }
        }
    }
}
