﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP
{
   public  class RoundLabel : Label
    {
        public RoundLabel()
        {
            this.AutoSize = false;
            this.FlatStyle = FlatStyle.Flat;
            this.Font = new Font("Arial", 12, FontStyle.Bold); // Set your desired font size and style

            this.Size = new Size(100, 100); // Set your desired size
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddEllipse(this.ClientRectangle);
                this.Region = new Region(path);

                using (SolidBrush brush = new SolidBrush(this.BackColor))
                {
                    e.Graphics.FillEllipse(brush, this.ClientRectangle);
                }
            }
        }
    }
  
}
