﻿
using System.Windows.Forms;

namespace AHDP
    {
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Button();
            this.UserType = new System.Windows.Forms.Label();
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.StopActive = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnHome = new System.Windows.Forms.Button();
            this.RunNonActive = new System.Windows.Forms.Button();
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.RunActive = new System.Windows.Forms.Button();
            this.toolTipPauseNonActive = new System.Windows.Forms.ToolTip(this.components);
            this.PauseNonActive = new System.Windows.Forms.Button();
            this.toolTipErrorActive = new System.Windows.Forms.ToolTip(this.components);
            this.ErrorActiveButton = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Tmr_Status = new System.Windows.Forms.Timer(this.components);
            this.toolTipManual = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipSettings = new System.Windows.Forms.ToolTip(this.components);
            this.Settings = new System.Windows.Forms.Button();
            this.toolTipCameraVision = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipDataReview = new System.Windows.Forms.ToolTip(this.components);
            this.OpenFolder = new System.Windows.Forms.Button();
            this.Login = new System.Windows.Forms.Button();
            this.PauseActive = new System.Windows.Forms.Button();
            this.Manual = new System.Windows.Forms.Button();
            this.DataReview = new System.Windows.Forms.Button();
            this.toolTipControlConfig = new System.Windows.Forms.ToolTip(this.components);
            this.ControlConfig = new System.Windows.Forms.Button();
            this.toolTipNoError = new System.Windows.Forms.ToolTip(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelshift = new System.Windows.Forms.Label();
            this.labelDatetime = new System.Windows.Forms.Label();
            this.lblNozzlests = new System.Windows.Forms.Label();
            this.btnResetAuto = new System.Windows.Forms.Button();
            this.lblDatetime = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblShift = new System.Windows.Forms.Label();
            this.lblErrorMessage = new System.Windows.Forms.Label();
            this.PLC_IO_Read = new System.Windows.Forms.Timer(this.components);
            this.CCD = new System.Windows.Forms.Button();
            this.StopNonactive = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.close);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1280, 40);
            this.panel1.TabIndex = 20;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1231, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(41, 34);
            this.button2.TabIndex = 49;
            this.button2.Text = "X";
            this.toolTipDataReview.SetToolTip(this.button2, "Close");
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1320, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(43, 34);
            this.button1.TabIndex = 47;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-3, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(151, 49);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 45;
            this.pictureBox1.TabStop = false;
            this.toolTipDataReview.SetToolTip(this.pictureBox1, "Titan Engineering & Automation Limited");
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(624, -3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 42);
            this.label3.TabIndex = 1;
            this.label3.Text = "AHDP";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.toolTipErrorActive.SetToolTip(this.label3, "Battery 3 Inspection");
            // 
            // close
            // 
            this.close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(82)))), ((int)(((byte)(128)))));
            this.close.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(82)))), ((int)(((byte)(128)))));
            this.close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.close.ImageIndex = 0;
            this.close.Location = new System.Drawing.Point(1542, 5);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(46, 32);
            this.close.TabIndex = 0;
            this.close.Text = "X";
            this.close.UseVisualStyleBackColor = false;
            this.close.Click += new System.EventHandler(this.button1_Click);
            // 
            // UserType
            // 
            this.UserType.AutoSize = true;
            this.UserType.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.UserType.Location = new System.Drawing.Point(1469, 47);
            this.UserType.Name = "UserType";
            this.UserType.Size = new System.Drawing.Size(118, 25);
            this.UserType.TabIndex = 22;
            this.UserType.Text = "No  User      ";
            this.UserType.Click += new System.EventHandler(this.labelControl1_Click);
            // 
            // StopActive
            // 
            this.StopActive.BackColor = System.Drawing.Color.Transparent;
            this.StopActive.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.EnergizedStopIcon;
            this.StopActive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StopActive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StopActive.ForeColor = System.Drawing.Color.DarkGray;
            this.StopActive.Location = new System.Drawing.Point(919, 46);
            this.StopActive.Name = "StopActive";
            this.StopActive.Size = new System.Drawing.Size(90, 84);
            this.StopActive.TabIndex = 30;
            this.toolTip2.SetToolTip(this.StopActive, "Stop");
            this.StopActive.UseVisualStyleBackColor = false;
            this.StopActive.Click += new System.EventHandler(this.StopActive_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.Transparent;
            this.btnHome.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.HomeIcon;
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.ForeColor = System.Drawing.Color.Transparent;
            this.btnHome.Location = new System.Drawing.Point(5, 46);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(90, 84);
            this.btnHome.TabIndex = 21;
            this.toolTip1.SetToolTip(this.btnHome, "Home");
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            this.btnHome.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnHome_MouseClick);
            // 
            // RunNonActive
            // 
            this.RunNonActive.BackColor = System.Drawing.Color.Transparent;
            this.RunNonActive.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.DenergizedStartIcon;
            this.RunNonActive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RunNonActive.FlatAppearance.BorderSize = 0;
            this.RunNonActive.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(209)))), ((int)(((byte)(56)))));
            this.RunNonActive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RunNonActive.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(237)))));
            this.RunNonActive.Location = new System.Drawing.Point(730, 46);
            this.RunNonActive.Name = "RunNonActive";
            this.RunNonActive.Size = new System.Drawing.Size(90, 84);
            this.RunNonActive.TabIndex = 28;
            this.toolTip1.SetToolTip(this.RunNonActive, "Start");
            this.RunNonActive.UseVisualStyleBackColor = false;
            this.RunNonActive.Click += new System.EventHandler(this.RunNonActive_Click);
            // 
            // RunActive
            // 
            this.RunActive.BackColor = System.Drawing.Color.Transparent;
            this.RunActive.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.EnergizedStartIcon2;
            this.RunActive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RunActive.FlatAppearance.BorderSize = 0;
            this.RunActive.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(209)))), ((int)(((byte)(56)))));
            this.RunActive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RunActive.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(254)))), ((int)(((byte)(254)))));
            this.RunActive.Location = new System.Drawing.Point(730, 46);
            this.RunActive.Name = "RunActive";
            this.RunActive.Size = new System.Drawing.Size(90, 84);
            this.RunActive.TabIndex = 13;
            this.toolTip3.SetToolTip(this.RunActive, "Start");
            this.RunActive.UseVisualStyleBackColor = false;
            this.RunActive.Click += new System.EventHandler(this.RunActive_Click);
            // 
            // PauseNonActive
            // 
            this.PauseNonActive.BackColor = System.Drawing.Color.Transparent;
            this.PauseNonActive.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.DenergizedHoldIcon;
            this.PauseNonActive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PauseNonActive.FlatAppearance.BorderSize = 0;
            this.PauseNonActive.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(209)))), ((int)(((byte)(56)))));
            this.PauseNonActive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PauseNonActive.Location = new System.Drawing.Point(826, 46);
            this.PauseNonActive.Name = "PauseNonActive";
            this.PauseNonActive.Size = new System.Drawing.Size(90, 84);
            this.PauseNonActive.TabIndex = 29;
            this.toolTipPauseNonActive.SetToolTip(this.PauseNonActive, "Hold");
            this.PauseNonActive.UseVisualStyleBackColor = false;
            this.PauseNonActive.Click += new System.EventHandler(this.simpleButton13_Click);
            // 
            // ErrorActiveButton
            // 
            this.ErrorActiveButton.BackColor = System.Drawing.Color.Transparent;
            this.ErrorActiveButton.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.ActiveAlarmIcon1;
            this.ErrorActiveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ErrorActiveButton.FlatAppearance.BorderSize = 0;
            this.ErrorActiveButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(209)))), ((int)(((byte)(56)))));
            this.ErrorActiveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ErrorActiveButton.ForeColor = System.Drawing.Color.Transparent;
            this.ErrorActiveButton.Location = new System.Drawing.Point(102, 46);
            this.ErrorActiveButton.Name = "ErrorActiveButton";
            this.ErrorActiveButton.Size = new System.Drawing.Size(90, 84);
            this.ErrorActiveButton.TabIndex = 24;
            this.toolTipErrorActive.SetToolTip(this.ErrorActiveButton, "Alarm Data");
            this.ErrorActiveButton.UseVisualStyleBackColor = false;
            this.ErrorActiveButton.Click += new System.EventHandler(this.NoAlarm_Click);
            this.ErrorActiveButton.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ErrorActiveButton_MouseMove);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // Tmr_Status
            // 
            this.Tmr_Status.Enabled = true;
            this.Tmr_Status.Interval = 50;
            this.Tmr_Status.Tick += new System.EventHandler(this.Tmr_Status_Tick);
            // 
            // toolTipManual
            // 
            this.toolTipManual.Popup += new System.Windows.Forms.PopupEventHandler(this.toolTipManual_Popup);
            // 
            // Settings
            // 
            this.Settings.BackColor = System.Drawing.Color.Transparent;
            this.Settings.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.SettingsIcon;
            this.Settings.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Settings.ForeColor = System.Drawing.Color.Transparent;
            this.Settings.Location = new System.Drawing.Point(393, 44);
            this.Settings.Name = "Settings";
            this.Settings.Size = new System.Drawing.Size(96, 89);
            this.Settings.TabIndex = 26;
            this.toolTipSettings.SetToolTip(this.Settings, "Settings");
            this.Settings.UseVisualStyleBackColor = false;
            this.Settings.Click += new System.EventHandler(this.Settings_Click);
            this.Settings.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Settings_MouseMove);
            // 
            // OpenFolder
            // 
            this.OpenFolder.BackColor = System.Drawing.Color.White;
            this.OpenFolder.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenFolder.BackgroundImage")));
            this.OpenFolder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.OpenFolder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OpenFolder.ForeColor = System.Drawing.Color.Transparent;
            this.OpenFolder.Location = new System.Drawing.Point(1081, 46);
            this.OpenFolder.Name = "OpenFolder";
            this.OpenFolder.Size = new System.Drawing.Size(90, 84);
            this.OpenFolder.TabIndex = 27;
            this.toolTipDataReview.SetToolTip(this.OpenFolder, "Open Log Folder");
            this.OpenFolder.UseVisualStyleBackColor = false;
            this.OpenFolder.Click += new System.EventHandler(this.OpenFolder_Click);
            // 
            // Login
            // 
            this.Login.BackColor = System.Drawing.Color.Transparent;
            this.Login.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.LoginIcon;
            this.Login.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login.ForeColor = System.Drawing.Color.Transparent;
            this.Login.Location = new System.Drawing.Point(1178, 46);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(90, 84);
            this.Login.TabIndex = 31;
            this.toolTipDataReview.SetToolTip(this.Login, "User Login");
            this.Login.UseVisualStyleBackColor = false;
            this.Login.Click += new System.EventHandler(this.Login_Click);
            // 
            // PauseActive
            // 
            this.PauseActive.BackColor = System.Drawing.Color.Transparent;
            this.PauseActive.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.EnergizedHoldIcon;
            this.PauseActive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PauseActive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PauseActive.ForeColor = System.Drawing.Color.DarkGray;
            this.PauseActive.Location = new System.Drawing.Point(826, 45);
            this.PauseActive.Name = "PauseActive";
            this.PauseActive.Size = new System.Drawing.Size(90, 86);
            this.PauseActive.TabIndex = 29;
            this.toolTipDataReview.SetToolTip(this.PauseActive, "Pause");
            this.PauseActive.UseVisualStyleBackColor = false;
            this.PauseActive.Click += new System.EventHandler(this.PauseActive_Click);
            // 
            // Manual
            // 
            this.Manual.AutoSize = true;
            this.Manual.BackColor = System.Drawing.Color.Transparent;
            this.Manual.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Manual.BackgroundImage")));
            this.Manual.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Manual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Manual.ForeColor = System.Drawing.Color.Transparent;
            this.Manual.Location = new System.Drawing.Point(497, 43);
            this.Manual.Name = "Manual";
            this.Manual.Size = new System.Drawing.Size(96, 87);
            this.Manual.TabIndex = 27;
            this.toolTipDataReview.SetToolTip(this.Manual, "Recipe");
            this.Manual.UseVisualStyleBackColor = false;
            this.Manual.Click += new System.EventHandler(this.Manual_Click);
            this.Manual.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Manual_MouseMove);
            // 
            // DataReview
            // 
            this.DataReview.BackColor = System.Drawing.Color.Transparent;
            this.DataReview.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.DataIcon;
            this.DataReview.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DataReview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DataReview.ForeColor = System.Drawing.Color.Transparent;
            this.DataReview.Location = new System.Drawing.Point(296, 46);
            this.DataReview.Name = "DataReview";
            this.DataReview.Size = new System.Drawing.Size(90, 84);
            this.DataReview.TabIndex = 24;
            this.toolTipDataReview.SetToolTip(this.DataReview, "Production Data");
            this.DataReview.UseVisualStyleBackColor = false;
            this.DataReview.Click += new System.EventHandler(this.DataReview_Click);
            // 
            // ControlConfig
            // 
            this.ControlConfig.BackColor = System.Drawing.Color.Transparent;
            this.ControlConfig.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.ControlIcom;
            this.ControlConfig.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ControlConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ControlConfig.ForeColor = System.Drawing.Color.Transparent;
            this.ControlConfig.Location = new System.Drawing.Point(199, 46);
            this.ControlConfig.Name = "ControlConfig";
            this.ControlConfig.Size = new System.Drawing.Size(90, 84);
            this.ControlConfig.TabIndex = 23;
            this.toolTipControlConfig.SetToolTip(this.ControlConfig, "Manual Mode Screen");
            this.ControlConfig.UseVisualStyleBackColor = false;
            this.ControlConfig.Click += new System.EventHandler(this.ControlConfig_Click);
            this.ControlConfig.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ControlConfig_MouseMove);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(1, 135);
            this.panel3.MinimumSize = new System.Drawing.Size(1278, 839);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1278, 839);
            this.panel3.TabIndex = 44;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.labelshift);
            this.panel2.Controls.Add(this.labelDatetime);
            this.panel2.Controls.Add(this.lblNozzlests);
            this.panel2.Controls.Add(this.btnResetAuto);
            this.panel2.Controls.Add(this.lblDatetime);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.lblShift);
            this.panel2.Controls.Add(this.lblErrorMessage);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 699);
            this.panel2.MaximumSize = new System.Drawing.Size(1280, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1280, 50);
            this.panel2.TabIndex = 46;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(573, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 14);
            this.label4.TabIndex = 0;
            this.label4.Text = "label4";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Black;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(555, 17);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(217, 16);
            this.textBox1.TabIndex = 9;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelshift
            // 
            this.labelshift.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelshift.Location = new System.Drawing.Point(1332, 14);
            this.labelshift.Name = "labelshift";
            this.labelshift.Size = new System.Drawing.Size(36, 17);
            this.labelshift.TabIndex = 8;
            // 
            // labelDatetime
            // 
            this.labelDatetime.Font = new System.Drawing.Font("Calibri", 10F);
            this.labelDatetime.Location = new System.Drawing.Point(1449, 14);
            this.labelDatetime.Name = "labelDatetime";
            this.labelDatetime.Size = new System.Drawing.Size(139, 18);
            this.labelDatetime.TabIndex = 7;
            // 
            // lblNozzlests
            // 
            this.lblNozzlests.AutoSize = true;
            this.lblNozzlests.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNozzlests.Location = new System.Drawing.Point(139, 8);
            this.lblNozzlests.Name = "lblNozzlests";
            this.lblNozzlests.Size = new System.Drawing.Size(0, 25);
            this.lblNozzlests.TabIndex = 6;
            // 
            // btnResetAuto
            // 
            this.btnResetAuto.Location = new System.Drawing.Point(3, 8);
            this.btnResetAuto.Name = "btnResetAuto";
            this.btnResetAuto.Size = new System.Drawing.Size(118, 23);
            this.btnResetAuto.TabIndex = 5;
            this.btnResetAuto.Text = "Reset Auto Process";
            this.btnResetAuto.UseVisualStyleBackColor = true;
            this.btnResetAuto.Visible = false;
            // 
            // lblDatetime
            // 
            this.lblDatetime.AutoSize = true;
            this.lblDatetime.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatetime.Location = new System.Drawing.Point(1449, 11);
            this.lblDatetime.Name = "lblDatetime";
            this.lblDatetime.Size = new System.Drawing.Size(0, 19);
            this.lblDatetime.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1374, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Datetime";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1288, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Shift";
            // 
            // lblShift
            // 
            this.lblShift.AutoSize = true;
            this.lblShift.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShift.Location = new System.Drawing.Point(1332, 12);
            this.lblShift.Name = "lblShift";
            this.lblShift.Size = new System.Drawing.Size(0, 16);
            this.lblShift.TabIndex = 1;
            // 
            // lblErrorMessage
            // 
            this.lblErrorMessage.AutoSize = true;
            this.lblErrorMessage.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblErrorMessage.Location = new System.Drawing.Point(12, 14);
            this.lblErrorMessage.Name = "lblErrorMessage";
            this.lblErrorMessage.Size = new System.Drawing.Size(0, 16);
            this.lblErrorMessage.TabIndex = 0;
            // 
            // PLC_IO_Read
            // 
            this.PLC_IO_Read.Tick += new System.EventHandler(this.PLC_IO_Read_Tick);
            // 
            // CCD
            // 
            this.CCD.BackColor = System.Drawing.Color.Transparent;
            this.CCD.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CCD.BackgroundImage")));
            this.CCD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CCD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CCD.ForeColor = System.Drawing.Color.Transparent;
            this.CCD.Location = new System.Drawing.Point(496, 44);
            this.CCD.Name = "CCD";
            this.CCD.Size = new System.Drawing.Size(92, 86);
            this.CCD.TabIndex = 26;
            this.CCD.UseVisualStyleBackColor = false;
            this.CCD.Visible = false;
            this.CCD.Click += new System.EventHandler(this.Settings_Click);
            this.CCD.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Settings_MouseMove);
            // 
            // StopNonactive
            // 
            this.StopNonactive.BackColor = System.Drawing.Color.Transparent;
            this.StopNonactive.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.DenergizedStopIcon;
            this.StopNonactive.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StopNonactive.FlatAppearance.BorderSize = 0;
            this.StopNonactive.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(209)))), ((int)(((byte)(56)))));
            this.StopNonactive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StopNonactive.Location = new System.Drawing.Point(919, 46);
            this.StopNonactive.Name = "StopNonactive";
            this.StopNonactive.Size = new System.Drawing.Size(90, 84);
            this.StopNonactive.TabIndex = 30;
            this.StopNonactive.UseVisualStyleBackColor = false;
            this.StopNonactive.Click += new System.EventHandler(this.StopNonactive_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1280, 749);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.ErrorActiveButton);
            this.Controls.Add(this.OpenFolder);
            this.Controls.Add(this.UserType);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.StopActive);
            this.Controls.Add(this.PauseActive);
            this.Controls.Add(this.RunActive);
            this.Controls.Add(this.Manual);
            this.Controls.Add(this.CCD);
            this.Controls.Add(this.Settings);
            this.Controls.Add(this.DataReview);
            this.Controls.Add(this.ControlConfig);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.RunNonActive);
            this.Controls.Add(this.PauseNonActive);
            this.Controls.Add(this.StopNonactive);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Transparent;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1280, 1024);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "   ";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button ErrorActiveButton;
        private System.Windows.Forms.Button ControlConfig;
        private System.Windows.Forms.Button DataReview;
        private System.Windows.Forms.Button Settings;
        private System.Windows.Forms.Button Manual;
        private System.Windows.Forms.Button RunActive;
        private System.Windows.Forms.Button PauseActive;
        private System.Windows.Forms.Button StopActive;
        private System.Windows.Forms.Button Login;
        private System.Windows.Forms.Label UserType;
        private System.Windows.Forms.Timer timer1;
        //private System.Windows.Forms.Button Manual;
        private System.Windows.Forms.Button RunNonActive;
        private System.Windows.Forms.Button PauseNonActive;
        private System.Windows.Forms.Button StopNonactive;
        private ToolTip toolTip2;
        private ToolTip toolTip1;
        private ToolTip toolTip3;
        private ToolTip toolTipPauseNonActive;
        private ToolTip toolTipErrorActive;
        private System.Windows.Forms.Timer Tmr_Status;
        private ToolTip toolTipManual;
        private ToolTip toolTipSettings;
        private ToolTip toolTipCameraVision;
        private ToolTip toolTipDataReview;
        private ToolTip toolTipControlConfig;
        private ToolTip toolTipNoError;
        public Form previousform;
        private System.Windows.Forms.TabControl tabControl2;
        private Button button1;
        private Button OpenFolder;
        private Button CCD;
        private Button button2;
        internal Panel panel3;
        private Panel panel2;
        private Label labelshift;
        private Label labelDatetime;
        private Label lblNozzlests;
        private Button btnResetAuto;
        private Label lblDatetime;
        private Label label2;
        private Label label1;
        private Label lblShift;
        private Label lblErrorMessage;
        private TextBox textBox1;
        public Timer PLC_IO_Read;
        private Label label4;
    }
}