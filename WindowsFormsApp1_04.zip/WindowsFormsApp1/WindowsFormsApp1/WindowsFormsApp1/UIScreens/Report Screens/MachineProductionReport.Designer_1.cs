﻿
namespace B3I.UIScreens.Report_Screens
{
    partial class MachineProductionReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gridControl1 = new System.Windows.Forms.DataGridView();
            this.Upload = new System.Windows.Forms.Button();
            this.label74 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.dateEdit2 = new System.Windows.Forms.DateTimePicker();
            this.dateEdit1 = new System.Windows.Forms.DateTimePicker();
            this.Load = new System.Windows.Forms.Button();
            this.barcodebox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridControl1
            // 
            this.gridControl1.AllowUserToAddRows = false;
            this.gridControl1.AllowUserToDeleteRows = false;
            this.gridControl1.Location = new System.Drawing.Point(35, 124);
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.ReadOnly = true;
            this.gridControl1.Size = new System.Drawing.Size(1524, 569);
            this.gridControl1.TabIndex = 1;
            this.gridControl1.Click += new System.EventHandler(this.gridControl1_Click);
            // 
            // Upload
            // 
            this.Upload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Upload.ForeColor = System.Drawing.Color.Transparent;
            this.Upload.Location = new System.Drawing.Point(1380, 9);
            this.Upload.Name = "Upload";
            this.Upload.Size = new System.Drawing.Size(96, 30);
            this.Upload.TabIndex = 8;
            this.Upload.Text = "Upload";
            this.Upload.UseVisualStyleBackColor = false;
            this.Upload.Click += new System.EventHandler(this.Upload_Click);
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.Color.Transparent;
            this.label74.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold);
            this.label74.Location = new System.Drawing.Point(647, 28);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(313, 29);
            this.label74.TabIndex = 45;
            this.label74.Text = "PRODUCTION REPORT";
            this.label74.Click += new System.EventHandler(this.label74_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.Upload);
            this.panel1.Controls.Add(this.dateEdit2);
            this.panel1.Controls.Add(this.dateEdit1);
            this.panel1.Controls.Add(this.Load);
            this.panel1.Controls.Add(this.barcodebox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(35, 71);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1524, 47);
            this.panel1.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(1252, 9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 30);
            this.button2.TabIndex = 46;
            this.button2.Text = "Save to excel";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // dateEdit2
            // 
            this.dateEdit2.Location = new System.Drawing.Point(458, 19);
            this.dateEdit2.Name = "dateEdit2";
            this.dateEdit2.Size = new System.Drawing.Size(148, 20);
            this.dateEdit2.TabIndex = 43;
            // 
            // dateEdit1
            // 
            this.dateEdit1.CustomFormat = "yyyy-MM-dd hh:mm:ss";
            this.dateEdit1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateEdit1.Location = new System.Drawing.Point(105, 19);
            this.dateEdit1.Name = "dateEdit1";
            this.dateEdit1.Size = new System.Drawing.Size(137, 20);
            this.dateEdit1.TabIndex = 3;
            this.dateEdit1.ValueChanged += new System.EventHandler(this.dateEdit1_EditValueChanged);
            // 
            // Load
            // 
            this.Load.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Load.ForeColor = System.Drawing.Color.Transparent;
            this.Load.Location = new System.Drawing.Point(1132, 9);
            this.Load.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Load.Name = "Load";
            this.Load.Size = new System.Drawing.Size(96, 30);
            this.Load.TabIndex = 6;
            this.Load.Text = "Load";
            this.Load.UseVisualStyleBackColor = false;
            this.Load.Click += new System.EventHandler(this.button1_Click);
            // 
            // barcodebox
            // 
            this.barcodebox.FormattingEnabled = true;
            this.barcodebox.Items.AddRange(new object[] {
            "11xy11",
            "22xy22"});
            this.barcodebox.Location = new System.Drawing.Point(831, 19);
            this.barcodebox.Name = "barcodebox";
            this.barcodebox.Size = new System.Drawing.Size(121, 20);
            this.barcodebox.TabIndex = 5;
            this.barcodebox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(694, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Housing Bar Code";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(384, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "To Date";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "From Date";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // MachineProductionReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 145);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimizeBox = false;
            this.Name = "MachineProductionReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "MachineProductionReport";
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridControl1;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dateEdit2;
        private System.Windows.Forms.DateTimePicker dateEdit1;
       // private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Load;
        private System.Windows.Forms.ComboBox barcodebox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Upload;
        private System.Windows.Forms.Button button2;
    }
}