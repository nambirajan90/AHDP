﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B3I.UIScreens.Report_Screens
{
    public partial class MachineProductionReport : Form
    {
        public MachineProductionReport()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateEdit1_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void MachineProductionReport_Load(object sender, EventArgs e)
        {
            // MessageBox.Show("MachineProductionReport is loaded!");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void gridControl1_Click(object sender, EventArgs e)
        {

        }

        //private void button2_Click(object sender, EventArgs e)
        //{
            

        //}

        private void label74_Click(object sender, EventArgs e)
        {

        }

        //private void dateEdit1_ValueChanged(object sender, EventArgs e)
        //{

        //}

        private async void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (dateEdit1.Value != null && dateEdit2.Value != null && dateEdit1.Value.Date < dateEdit2.Value.Date)
                {
                    // Load data into the grid
                    await LoadDataInGridMachine();
                    //await LoadDataInRoller();
                    //await LoadDataInFI();
                }

                else
                {
                    MessageBox.Show("Fromdate Should less than Todate");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Report Screen--Error in this function:button1_Click()" + ex);
                return;
            }
        }

        public async Task<object> LoadDataInGridMachine()
        {
            //string connectionString = "Server=TCLHSRPEDLT0737;Database=B3I;User Id=sa;Password=Titan@123;";
            string connectionString = SQLHelper.get_ConnName();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("Production_details", conn))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@fromdate", dateEdit1.Value.Date.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@todate", dateEdit2.Value.Date.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@barcode", barcodebox.SelectedItem.ToString());
                    try
                    {
                        await conn.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            // Check if there are any rows to display
                            if (dt.Rows.Count > 1) // Ensure there's at least 2 rows
                            {
                                gridControl1.DataSource = dt;

                                // gridControl1.AutoGenerateColumns = true;

                                // Return the value from the first column of the second row
                                return dt;
                            }
                            else
                            {
                                MessageBox.Show("No data available for the selected Model.");
                                gridControl1.DataSource = null;
                                return null; // or handle accordingly
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Report Screen--Error in this function:LoadDataInGridMachine()" + ex);
                        return null;
                    }
                }
            }
        }

        private void writeCSV(DataSet paramDset, string fileName)
        {
            StreamWriter sw = new StreamWriter(fileName, false);
            //headers
            try
            {
                for (int i = 0; i < paramDset.Tables[0].Columns.Count; i++)
                {
                    sw.Write(paramDset.Tables[0].Columns[i]);
                    if (i < paramDset.Tables[0].Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
                foreach (DataRow dr in paramDset.Tables[0].Rows)
                {
                    for (int i = 0; i < paramDset.Tables[0].Columns.Count; i++)
                    {
                        if (!Convert.IsDBNull(dr[i]))
                        {
                            string value = dr[i].ToString();
                            if (value.Contains(','))
                            {
                                value = String.Format("\"{0}\"", value);
                                sw.Write(value);
                            }
                            else
                            {
                                sw.Write(dr[i].ToString());
                            }
                        }
                        if (i < paramDset.Tables[0].Columns.Count - 1)
                        {
                            sw.Write(",");
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Production Data--Error in this function:writeCSV()" + ex);
                return;
            }
        }

        private void Upload_Click(object sender, EventArgs e)
        {
            // Cast the grid control to a DataGridView
            DataGridView dataGridView = gridControl1 as DataGridView;

            if (dataGridView != null && dataGridView.SelectedRows.Count > 0)
            {
                // Get the first selected row
                DataGridViewRow selectedRow = dataGridView.SelectedRows[0];

                // Extract values from the selected row
                string column1Value = selectedRow.Cells[0].Value?.ToString() ?? string.Empty;
                string column2Value = selectedRow.Cells[1].Value?.ToString() ?? string.Empty;
                string column3Value = selectedRow.Cells[2].Value?.ToString() ?? string.Empty;
                string column4Value = selectedRow.Cells[3].Value?.ToString() ?? string.Empty;
                string column5Value = selectedRow.Cells[4].Value?.ToString() ?? string.Empty;
                string column6Value = selectedRow.Cells[5].Value?.ToString() ?? string.Empty;

                // Parse date values if they are in the columns
                string column7Value = DateTime.Parse(selectedRow.Cells[6].Value?.ToString() ?? string.Empty).ToString("yyyy-MM-dd");
                string column8Value = DateTime.Parse(selectedRow.Cells[7].Value?.ToString() ?? string.Empty).ToString("yyyy-MM-dd");

                // Extract other column values
                string column9Value = selectedRow.Cells[8].Value?.ToString() ?? string.Empty;
                string column10Value = selectedRow.Cells[9].Value?.ToString() ?? string.Empty;
                string column11Value = selectedRow.Cells[10].Value?.ToString() ?? string.Empty;

                // Get the connection string
                string connectionString = SQLHelper.get_ConnName();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // SQL query to insert data
                    string query = "INSERT INTO tbl_ProductionCount_live " +
                                   "(Machine_code, ShiftID, Variantcode, TotalOkParts, TotalNokParts, Quality, Date, time_stamp, CompanyCode, PlantCode, Barcode) " +
                                   "VALUES (@Column1, @Column2, @Column3, @Column4, @Column5, @Column6, @Column7, @Column8, @Column9, @Column10, @Column11)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters
                        command.Parameters.AddWithValue("@Column1", column1Value);
                        command.Parameters.AddWithValue("@Column2", column2Value);
                        command.Parameters.AddWithValue("@Column3", column3Value);
                        command.Parameters.AddWithValue("@Column4", column4Value);
                        command.Parameters.AddWithValue("@Column5", column5Value);
                        command.Parameters.AddWithValue("@Column6", column6Value);
                        command.Parameters.AddWithValue("@Column7", column7Value);
                        command.Parameters.AddWithValue("@Column8", column8Value);
                        command.Parameters.AddWithValue("@Column9", column9Value);
                        command.Parameters.AddWithValue("@Column10", column10Value);
                        command.Parameters.AddWithValue("@Column11", column11Value);

                        // Execute the query and check rows affected
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data saved successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Error saving data.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to save.");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (dateEdit1.Value.Date != DateTime.MinValue && dateEdit1.Value.Date != DateTime.MinValue)
            {
                string connectionString = SQLHelper.get_ConnName();

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Production_details", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        // Get dates from DateTimePicker
                        cmd.Parameters.AddWithValue("@fromdate", dateEdit1.Value.Date.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@todate", dateEdit1.Value.Date.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@barcode", barcodebox.SelectedItem?.ToString() ?? string.Empty);

                        try
                        {
                            conn.Open();
                            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                            {
                                DataSet dt = new DataSet();
                                adapter.Fill(dt);

                                if (dt.Tables[0].Rows.Count > 0)
                                {
                                    Thread t = new Thread((ThreadStart)(() =>
                                    {
                                        SaveFileDialog saveFileDialog1 = new SaveFileDialog
                                        {
                                            Filter = "csv files (*.csv)|*.csv",
                                            Title = "Production Data",
                                            FilterIndex = 2,
                                            RestoreDirectory = true
                                        };

                                        if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                                        {
                                            if (!string.IsNullOrEmpty(saveFileDialog1.FileName))
                                            {
                                                writeCSV(dt, saveFileDialog1.FileName);
                                            }
                                        }
                                    }));
                                    t.SetApartmentState(ApartmentState.STA);
                                    t.Start();
                                    t.Join();
                                }
                                else
                                {
                                    MessageBox.Show("No data found for the selected range.");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Report Screen - Error in function: {ex.Message}");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select valid From and To dates.");
            }
        }

        //private void gridControl1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //{

        //}

        //private void panel1_Paint(object sender, PaintEventArgs e)
        //{

        //}

        //private void MachineProductionReport_Load_1(object sender, EventArgs e)
        //{

        //}

        //private void MachineProductionReport_Load_2(object sender, EventArgs e)
        //{

        //}
    }
}
