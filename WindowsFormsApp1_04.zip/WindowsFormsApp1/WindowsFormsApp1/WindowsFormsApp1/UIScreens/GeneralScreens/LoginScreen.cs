﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TCPIPClient;

namespace AHDP
{
    public partial class LoginScreen : Form
    {
        Boolean AAT_TAG;
        public LoginScreen()
        {
            InitializeComponent();
        }

        private void LoginScreen_Load(object sender, EventArgs e)
        {
            //AAT_Condition();

            //GetDataFromXML getdtafronxml = new GetDataFromXML();
            //SQLHelper Sql = new SQLHelper();
            //txtusername.Text = "admin";
            //txtpassword.Text = "teal@123";
        }

        private void roundedButton1_Click(object sender, EventArgs e)
        {

        }
        private void roundedButton4_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void roundedButton2_Click(object sender, EventArgs e)
        {

        }

        private void LOCKICON_Click(object sender, EventArgs e)
        {

        }

        private void txtusername_TextChanged(object sender, EventArgs e)
        {

        }
        private void txtpassword_TextChanged(object sender, EventArgs e)
        {

        }

        //Added//

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                // Check for empty username or password fields
                if (string.IsNullOrWhiteSpace(txtusername.Text))
                {
                    MessageBox.Show("Please enter a username.");
                    return;
                }
                if (string.IsNullOrWhiteSpace(txtpassword.Text))
                {
                    MessageBox.Show("Please enter a password.");
                    return;
                }

                string connectionString = SQLHelper.get_ConnName();
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Step 1: Check if the username exists in the database
                    string query = "SELECT Level FROM User_Data WHERE Username = @Username";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", txtusername.Text);

                        object levelResult = cmd.ExecuteScalar();

                        if (levelResult == null)
                        {
                            // If username does not exist in any level
                            MessageBox.Show("Username is incorrect. Please try again.");
                            return;
                        }

                        string actualLevel = levelResult.ToString();

                        // Step 2: Check if the username exists in the selected level
                        if (!string.Equals(actualLevel, GlobalVar.User_Mode, StringComparison.OrdinalIgnoreCase))
                        {
                            // If username exists but in a different level
                            MessageBox.Show("Credential is incorrect. Please try again.");
                            return;
                        }
                    }

                    // Step 3: Check if the username and password match for the selected level
                    query = "SELECT COUNT(*) FROM User_Data WHERE Username = @Username AND Password = @Password AND Level = @Level";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", txtusername.Text);
                        cmd.Parameters.AddWithValue("@Password", txtpassword.Text);
                        cmd.Parameters.AddWithValue("@Level", GlobalVar.User_Mode);

                        int userMatchCount = Convert.ToInt32(cmd.ExecuteScalar());

                        if (userMatchCount == 0)
                        {
                            // If the password is incorrect for the selected level
                            MessageBox.Show("Password is incorrect. Please try again.");
                            return;
                        }
                    }

                    // Step 4: Successful login
                    MessageBox.Show("Login Successful!");
                    Globalvariable.previousform.Active_btn_dis_or_en();
                    Globalvariable.LoginScreen.Close();
                    Globalvariable.Login_Successful = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }


        private void AATScreenAuth_Click(object sender, EventArgs e)
        {
            Form AATLogin = new AATLogin();
            AATLogin.ShowDialog();
            this.Close();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form ModeSelection = new ModeSelection();
            ModeSelection.Show();
        }

        public void AAT_Condition()
        {
            if (AAT_TAG = true)
            {
                txtpassword.Visible = true;
                Passwordtext.Visible = true;
                LOCKICON.Visible = true;
                // AATScreenAuth.Visible = false;

            }
            else
            {
                txtpassword.Visible = true;
                Passwordtext.Visible = true;
                LOCKICON.Visible = true;
                //AATScreenAuth.Visible = false;
            }

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            AAT_Condition();
            Form AATLogin = new AATLogin();
            AATLogin.ShowDialog();
            this.Close();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            txtpassword.Visible = true;
            Passwordtext.Visible = true;
            LOCKICON.Visible = true;
            //AATScreenAuth.Visible = false;
        }
    }
}
