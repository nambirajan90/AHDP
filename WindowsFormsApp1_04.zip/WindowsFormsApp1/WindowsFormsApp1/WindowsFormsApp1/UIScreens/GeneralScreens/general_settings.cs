﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP.UIScreens.GeneralScreens
{
    public partial class general_settings : Form
    {
        public general_settings()
        {
            InitializeComponent();
        }
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
  (
      int nLeftRect,
      int nTopRect,
      int nRightRect,
      int nBottomRect,
      int nWidthEllipse,
      int nHeightEllipse
  );

        public void Panel_Shape()
        {
            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width,
            panel1.Height, 30, 30));
            panel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel2.Width,
         panel2.Height, 30, 30));
            panel8.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel8.Width,
         panel8.Height, 30, 30));
            panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
         panel4.Height, 30, 30));
            panel5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel5.Width,
         panel5.Height, 30, 30));
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
        public void Decimal_Validation(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }
        private void general_settings_Load(object sender, EventArgs e)
        {
            cmbAuto_Logout_Time.SelectedIndex = 0;
            cmbdata_display_default.SelectedIndex = 0;
            cmbhome_screen_timeout.SelectedIndex = 0;
            cmb_def_alarm_log_time.SelectedIndex = 0;
            cmbPulseLogic.SelectedIndex = GlobalVar.PulseLogic;
            cmbPulseMode.SelectedIndex = GlobalVar.PulseMode;
            // txtPostcheckdly.Text = AutoSequence.post_check_Delay.ToString();
            // txtImageretry.Text = GlobalVar.PostCheck_Retrycnt.ToString();
            // Panel_Shape();
            // if(AutoSequence.Four_plus_two_foam)
            // {
            //     cmbFomseq.SelectedIndex = 0;
            // }
            // else if(AutoSequence.Four_Foams_only)
            // {
            //     cmbFomseq.SelectedIndex = 2;
            // }
            // else
            // {
            //     cmbFomseq.SelectedIndex = 1;
            // }
            // lblTrayCount.Text = AutoSequence.Tray_cnt.ToString();
            //if(!AutoSequence.autoProcess)
            //{
            //     chkInterpolation.Enabled = true;
            //}
            //else
            //{
            //     chkInterpolation.Enabled = false;
            //}
            if (GlobalVar.Interpol)
            {
                chkInterpolation.Checked = true;
            }
            else
            {
                chkInterpolation.Checked = false;
            }
        }

        private void cmbFomseq_SelectedIndexChanged(object sender, EventArgs e)
        {
            //            4 + 2 Foam Pick Seq
            //3 + 3 Foam Pick Seq


        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ChkStepmode.Checked)
            {
                GlobalVar.Stepmode_En = true;
            }
            else
            {
                GlobalVar.Stepmode_En = false; ;
            }
            //if (cmbFomseq.Text == "4+2 Foam Pick Seq")
            //{
            //    AutoSequence.Four_plus_two_foam = true;
            //    AutoSequence.Four_Foams_only = false;
            //    AutoSequence.Two_foams_trig = false;
            //    AutoSequence.Four_foams_trig = false;
            //    AutoSequence.Three_foams_trig = false;
            //}
            //else if (cmbFomseq.Text == "3+3 Foam Pick Seq")
            //{
            //    AutoSequence.Four_plus_two_foam = false;
            //    AutoSequence.Four_Foams_only = false;
            //    AutoSequence.Three_foams_trig = false;
            //}
            //else if(cmbFomseq.Text == "4 Foam Pick Seq")
            //{
            //    AutoSequence.Four_plus_two_foam = false;
            //    AutoSequence.Four_Foams_only = true;

            //}
            //Add to retain notepad
            if (cmbPulseMode.Text == "Pulse")
            {
                GlobalVar.PulseMode = 0;
            }
            else
            {
                GlobalVar.PulseMode = 1;
            }
            if (cmbPulseLogic.Text == "Falling Edge")
            {
                GlobalVar.PulseLogic = 0;
            }
            else
            {
                GlobalVar.PulseLogic = 1;
            }
            //if(!string.IsNullOrEmpty(txtPostcheckdly.Text))
            //{
            //    AutoSequence.post_check_Delay = Convert.ToInt32(txtPostcheckdly.Text);
            //}
            if (!string.IsNullOrEmpty(txtImageretry.Text))
            {
                if (Convert.ToInt32(txtImageretry.Text) > 3)
                {
                    GlobalVar.PostCheck_Retrycnt = 3;
                    txtImageretry.Text = GlobalVar.PostCheck_Retrycnt.ToString();
                }
                else
                {
                    GlobalVar.PostCheck_Retrycnt = Convert.ToInt32(txtImageretry.Text);
                }

            }
            //
            //21102024ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg);
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            //if(! string.IsNullOrEmpty(txtFedderDelay.Text))
            // {
            //     GlobalVar.Feeder_Delay = Convert.ToInt32(txtFedderDelay.Text);
            //     ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg);
            // }

        }

        private void txtPostcheckdly_KeyPress(object sender, KeyPressEventArgs e)
        {
            Decimal_Validation(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void txtImageretry_KeyPress(object sender, KeyPressEventArgs e)
        {
            Decimal_Validation(sender, e);
        }

        private void btn_TrayRst_Click(object sender, EventArgs e)
        {
            //if(!AutoSequence.autoProcess && !AutoSequence.Post_Inspection)
            //{
            //    AutoSequence.Tray_cnt = 1;
            //    AutoSequence.Cycle_Number = 1;
            //   //21102024 ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg); lblTrayCount.Text = AutoSequence.Tray_cnt.ToString();
            //}
        }

        private void chkInterpolation_CheckedChanged(object sender, EventArgs e)
        {
            //if(!AutoSequence.autoProcess)
            //{
            //    if (chkInterpolation.Checked)
            //    {
            //        GlobalVar.Interpol = true;
            //    }
            //    else
            //    {
            //        GlobalVar.Interpol = false;
            //    }
            //}

        }

        private void chksaftydoor_CheckedChanged(object sender, EventArgs e)
        {
            //if (chksaftydoor.Checked)
            //{
            //    AutoSequence.safty_door_bypass = true;
            //}
            //else
            //{
            //    AutoSequence.safty_door_bypass = false;
            //}
        }

        private void fontDialog1_Apply(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
