﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP
{
    public partial class CPK :Form
    {
        public CPK()
        {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form ModeSelection = new ModeSelection();
            ModeSelection.Show();
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            // FIRST PUSH RECORD TO DB AND THEN OPEN USER SCREEN
            this.Close();
            Form LoginScreen = new LoginScreen();
            LoginScreen.Show();
        }
    }
}