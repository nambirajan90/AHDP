﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP.UIScreens.GeneralScreens
{
    public partial class modeofoperations : Form
    {
        public modeofoperations()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public static bool Dry_Seq = false;
        private void btnOk_Click(object sender, EventArgs e)
        {
            if (cmbmodeOperation.SelectedItem.ToString() != "--Select--")
            {
                DialogResult result = MessageBox.Show("Are you sure want to change current mode to selected mode", "Alert", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    /*
                     * Continuous Cycle
                            Continuous Step Cycle
                            Conv Dry Cycle
                            Dry Cycle
                            Single Cycle
                            Single Dry Cycle
                            Step Dry Cycle
                     */
                    if (cmbmodeOperation.Text == "Continuous Cycle")
                    {
                        //AutoSequence.Dry_cycle = false;
                        //Dry_Seq = false;
                        //GlobalVar.Stepmode_En = false;
                        //GlobalVar.SingleCycle_En = false;
                        //conveyor_esd.Conv_dryrun = false;
                    }
                    else if (cmbmodeOperation.Text == "Dry Cycle")
                    {
                        //AutoSequence.Dry_cycle = true;
                        //Dry_Seq = true;
                        //GlobalVar.Stepmode_En = false;
                        //GlobalVar.SingleCycle_En = false;
                        //conveyor_esd.Conv_dryrun = false;
                    }
                    else if (cmbmodeOperation.Text == "Continuous Step Cycle")
                    {
                        //AutoSequence.Dry_cycle = false;
                        //Dry_Seq = false;
                        //GlobalVar.Stepmode_En = true;
                        //GlobalVar.SingleCycle_En = false;
                        //conveyor_esd.Conv_dryrun = false;
                    }
                    else if (cmbmodeOperation.Text == "Single Cycle")
                    {
                        //AutoSequence.Dry_cycle = false;
                        //Dry_Seq = false;
                        //GlobalVar.Stepmode_En = false;
                        //GlobalVar.SingleCycle_En = true;
                        //conveyor_esd.Conv_dryrun = false;
                    }
                    else if (cmbmodeOperation.Text == "Conv Dry Cycle")
                    {
                        //AutoSequence.Dry_cycle = false;
                        //Dry_Seq = false;
                        //GlobalVar.Stepmode_En = false;
                        //GlobalVar.SingleCycle_En = false;
                        //conveyor_esd.Conv_dryrun = true;
                    }
                    else if (cmbmodeOperation.Text == "Single Dry Cycle")
                    {
                        //AutoSequence.Dry_cycle = true;
                        //Dry_Seq = true;
                        //GlobalVar.Stepmode_En = false;
                        //GlobalVar.SingleCycle_En = true;
                        //conveyor_esd.Conv_dryrun = false;
                    }
                    else if (cmbmodeOperation.Text == "Step Dry Cycle")
                    {
                        //AutoSequence.Dry_cycle = true;
                        //Dry_Seq = true;
                        //GlobalVar.Stepmode_En = true;
                        //GlobalVar.SingleCycle_En = false;
                        //conveyor_esd.Conv_dryrun = false;
                    }

                    //  ToRetain.WriteValues12(AutoSequence.Auto_Status, AutoSequence.POC, AutoSequence.autoStep, AutoSequence.autoProcess, AutoSequence.loader_to_inputBuffer, AutoSequence.inputBuffer_tDIOConfig.O_process, AutoSequence.process_to_outputBuffer, AutoSequence.outputBuffer_to_unloader, AutoSequence.inputBuffer_to_process_Wc, AutoSequence.process_to_outputBuffer_Wc, AutoSequence.Continous_cycle, AutoSequence.Step_cycle, AutoSequence.step_trig, AutoSequence.Nozzle_Z_home_trig, AutoSequence.Gantry_home_trig, AutoSequence.Enable_Step_btn, AutoSequence.Single_cycle, AutoSequence.Dry_cycle, AutoSequence.Foam_feeder_trig, AutoSequence.curr_foam_pick_in_feeder, AutoSequence.Gantry_X_to_Feedeer_Pos, AutoSequence.Gantry_Y_to_Feeder_Pos, AutoSequence.Gantry_X_to_Foam_last_Pos, AutoSequence.Gantry_Y_to_Foam_last_Pos, AutoSequence.ServDIOConfig.O_movement, AutoSequence.Foam_picked, 0, AutoSequence.Gantry_X_to_CCD2_last_pos, AutoSequence.Gantry_Y_to_CCD2_last_pos, AutoSequence.CCD2_Curr_Foam_num, AutoSequence.LH_Foam_Feeder_Trig, AutoSequence.RH_Foam_Feeder_Trig, FoamFeederProcess.LH_Feeder_Health_State, FoamFeederProcess.RH_Feeder_Health_State, FoamFeederProcess.LH_Feeder_Active_State, FoamFeederProcess.RH_Feeder_Active_State, AutoSequence.Gantry_X_to_Foam_Pos_Foam_pick, AutoSequence.Gantry_Y_to_Foam_Pos_Foam_pick, AutoSequence.Gantry_X_to_Feedeer_center_Pos, AutoSequence.Gantry_Y_to_Feeder_center_Pos, AutoSequence.Curr_Col, AutoSequence.Curr_Row, AutoSequence.Comp_odd_pos, AutoSequence.Comp_even_pos, AutoSequence.Curr_comp_no, AutoSequence.Process_Curr_comp_no, AutoSequence.Gantry_X_Last_Comp_Inception_pos, AutoSequence.Gantry_Y_Last_Comp_Inception_pos, AutoSequence.Gantry_X_ArcCowling_Inception_pos, AutoSequence.Gantry_Y_ArcCowling_Inception_pos, AutoSequence.Gantry_Y_Arc_Cowling_Cor_pos, AutoSequence.Nozzle_Ang_Arc_Cowling_Cor_pos, AutoSequence.curr_Nozzle_Foam_CCD1, AutoSequence.Tot_nDIOConfig.O_of_foams_presence, AutoSequence.Gantry_X_Foam_Pick_pos, AutoSequence.Gantry_Y_Foam_Pick_pos, AutoSequence.Gantry_X_Last_Cam_Check_pos, AutoSequence.Gantry_Y_Last_Cam_Check_pos, AutoSequence.CCD2_Correcting_pos, AutoSequence.Gantry_X_CCD2_Cor_pos, AutoSequence.Gantry_Y_CCD2_Cor_pos, AutoSequence.Nozzle_Ang_CCD2_Cor_pos, AutoSequence.CCD1_Foam_X_Cor_pos, AutoSequence.CCD1_Foam_Y_Cor_pos, AutoSequence.CCD1_Foam_Ang_Cor_pos, GlobalVar.Cam_X_CCD2_Check_Pos, GlobalVar.Cam_Y_CCD2_Check_Pos, GlobalVar.Cam_Ang_CCD2_Check_Pos, AutoSequence.CCD1_Arc_X1_Cor_pos, AutoSequence.CCD1_Arc_Y1_Cor_pos, AutoSequence.CCD1_Arc_Ang1_Cor_pos, AutoSequence.Seq_no, AutoSequence.TwDIOConfig.O_foams_trig, AutoSequence.Four_foams_trig, AutoSequence.Three_foams_trig,AutoSequence.Cavity_number);
                    this.Close();
                }
                else
                {
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Please choose mode of Operation");
            }
        }

        private void modeofoperations_Load(object sender, EventArgs e)
        {
            cmbmodeOperation.SelectedIndex = 0;
        }

        private void cmbmodeOperation_SelectedIndexChanged(object sender, EventArgs e)
        {
            //            --Select--
            //Continuous Cycle
            //Dry Cycle
            //Single Cycle
            //Step Cycle


        }

        private void lblchoosemodeofoperation_Click(object sender, EventArgs e)
        {

        }
    }
}
