﻿
namespace AHDP.UIScreens.GeneralScreens
{
    partial class modeofoperations
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.cmbmodeOperation = new System.Windows.Forms.ComboBox();
            this.lblchoosemodeofoperation = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCancel.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(338, 104);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(96, 37);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOk
            // 
            this.btnOk.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnOk.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.btnOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOk.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOk.Location = new System.Drawing.Point(187, 104);
            this.btnOk.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(96, 37);
            this.btnOk.TabIndex = 6;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = false;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // cmbmodeOperation
            // 
            this.cmbmodeOperation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbmodeOperation.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbmodeOperation.FormattingEnabled = true;
            this.cmbmodeOperation.Items.AddRange(new object[] {
            "--Select--",
            "Offline",
            "Online"});
            this.cmbmodeOperation.Location = new System.Drawing.Point(187, 44);
            this.cmbmodeOperation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbmodeOperation.Name = "cmbmodeOperation";
            this.cmbmodeOperation.Size = new System.Drawing.Size(247, 26);
            this.cmbmodeOperation.Sorted = true;
            this.cmbmodeOperation.TabIndex = 5;
            this.cmbmodeOperation.SelectedIndexChanged += new System.EventHandler(this.cmbmodeOperation_SelectedIndexChanged);
            // 
            // lblchoosemodeofoperation
            // 
            this.lblchoosemodeofoperation.AutoSize = true;
            this.lblchoosemodeofoperation.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchoosemodeofoperation.Location = new System.Drawing.Point(43, 48);
            this.lblchoosemodeofoperation.Name = "lblchoosemodeofoperation";
            this.lblchoosemodeofoperation.Size = new System.Drawing.Size(124, 20);
            this.lblchoosemodeofoperation.TabIndex = 4;
            this.lblchoosemodeofoperation.Text = "Select Mode";
            this.lblchoosemodeofoperation.Click += new System.EventHandler(this.lblchoosemodeofoperation_Click);
            // 
            // modeofoperations
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(477, 185);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.cmbmodeOperation);
            this.Controls.Add(this.lblchoosemodeofoperation);
            this.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "modeofoperations";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "modeofoperations";
            this.Load += new System.EventHandler(this.modeofoperations_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.ComboBox cmbmodeOperation;
        private System.Windows.Forms.Label lblchoosemodeofoperation;
    }
}