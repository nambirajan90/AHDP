﻿
namespace AHDP.UIScreens.GeneralScreens
{
    partial class general_settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_TrayRst = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.chksaftydoor = new System.Windows.Forms.CheckBox();
            this.chkInterpolation = new System.Windows.Forms.CheckBox();
            this.ChkStepmode = new System.Windows.Forms.CheckBox();
            this.txtImageretry = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtPostcheckdly = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbPulseLogic = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.cmbPulseMode = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbFomseq = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTotnumfoams = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtFeedingCnt = new System.Windows.Forms.TextBox();
            this.txtUnitFailureCnt = new System.Windows.Forms.TextBox();
            this.txtTossingFailCnt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbhome_screen_timeout = new System.Windows.Forms.ComboBox();
            this.cmbdata_display_default = new System.Windows.Forms.ComboBox();
            this.cmb_def_alarm_log_time = new System.Windows.Forms.ComboBox();
            this.cmbAuto_Logout_Time = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(2, 131);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 18);
            this.label8.TabIndex = 29;
            this.label8.Text = "SW Rev :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(2, 97);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 18);
            this.label6.TabIndex = 28;
            this.label6.Text = "Build Date :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(2, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 29);
            this.label1.TabIndex = 32;
            this.label1.Text = "Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(2, 163);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 18);
            this.label2.TabIndex = 33;
            this.label2.Text = "SW Updated :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(2, 196);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 18);
            this.label3.TabIndex = 35;
            this.label3.Text = "Total Life Cycles :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(2, 230);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 18);
            this.label4.TabIndex = 37;
            this.label4.Text = "Total Life Rejects :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(2, 15);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 18);
            this.label5.TabIndex = 39;
            this.label5.Text = "For Support";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(2, 71);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(319, 18);
            this.label7.TabIndex = 40;
            this.label7.Text = "Titan Engineering and Automation Limited";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.btn_TrayRst);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(30, 30);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(443, 308);
            this.panel1.TabIndex = 55;
            // 
            // btn_TrayRst
            // 
            this.btn_TrayRst.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_TrayRst.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_TrayRst.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_TrayRst.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TrayRst.Location = new System.Drawing.Point(227, 263);
            this.btn_TrayRst.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_TrayRst.Name = "btn_TrayRst";
            this.btn_TrayRst.Size = new System.Drawing.Size(137, 25);
            this.btn_TrayRst.TabIndex = 63;
            this.btn_TrayRst.Text = "Reset Tray Count";
            this.btn_TrayRst.UseVisualStyleBackColor = false;
            this.btn_TrayRst.Click += new System.EventHandler(this.btn_TrayRst_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(5, 265);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 18);
            this.label17.TabIndex = 39;
            this.label17.Text = "Tray Count :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(30, 386);
            this.panel2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(443, 170);
            this.panel2.TabIndex = 56;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Location = new System.Drawing.Point(-8, 36);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(2, 144);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 14);
            this.label11.TabIndex = 43;
            this.label11.Text = "Hosur - 635126";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(2, 121);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(175, 14);
            this.label10.TabIndex = 42;
            this.label10.Text = "SIPCOT Industrial Complex,";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(2, 98);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 14);
            this.label9.TabIndex = 41;
            this.label9.Text = "Unit - I, NO.27 & 28";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.panel2);
            this.panel4.Controls.Add(this.panel1);
            this.panel4.Location = new System.Drawing.Point(12, 12);
            this.panel4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(746, 586);
            this.panel4.TabIndex = 59;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gainsboro;
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Location = new System.Drawing.Point(781, 12);
            this.panel5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(780, 679);
            this.panel5.TabIndex = 60;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(521, 581);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(55, 25);
            this.button2.TabIndex = 62;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.Controls.Add(this.chksaftydoor);
            this.panel8.Controls.Add(this.chkInterpolation);
            this.panel8.Controls.Add(this.ChkStepmode);
            this.panel8.Controls.Add(this.txtImageretry);
            this.panel8.Controls.Add(this.label27);
            this.panel8.Controls.Add(this.txtPostcheckdly);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Controls.Add(this.cmbPulseLogic);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.cmbPulseMode);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.cmbFomseq);
            this.panel8.Controls.Add(this.label16);
            this.panel8.Controls.Add(this.txtTotnumfoams);
            this.panel8.Controls.Add(this.label15);
            this.panel8.Controls.Add(this.txtFeedingCnt);
            this.panel8.Controls.Add(this.txtUnitFailureCnt);
            this.panel8.Controls.Add(this.txtTossingFailCnt);
            this.panel8.Controls.Add(this.label12);
            this.panel8.Controls.Add(this.label13);
            this.panel8.Controls.Add(this.label14);
            this.panel8.Controls.Add(this.cmbhome_screen_timeout);
            this.panel8.Controls.Add(this.cmbdata_display_default);
            this.panel8.Controls.Add(this.cmb_def_alarm_log_time);
            this.panel8.Controls.Add(this.cmbAuto_Logout_Time);
            this.panel8.Controls.Add(this.label18);
            this.panel8.Controls.Add(this.label19);
            this.panel8.Controls.Add(this.label20);
            this.panel8.Controls.Add(this.label21);
            this.panel8.Controls.Add(this.label22);
            this.panel8.Location = new System.Drawing.Point(38, 19);
            this.panel8.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(424, 645);
            this.panel8.TabIndex = 60;
            // 
            // chksaftydoor
            // 
            this.chksaftydoor.AutoSize = true;
            this.chksaftydoor.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chksaftydoor.Location = new System.Drawing.Point(187, 394);
            this.chksaftydoor.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chksaftydoor.Name = "chksaftydoor";
            this.chksaftydoor.Size = new System.Drawing.Size(188, 22);
            this.chksaftydoor.TabIndex = 77;
            this.chksaftydoor.Text = "Safty Door Bypass";
            this.chksaftydoor.UseVisualStyleBackColor = true;
            this.chksaftydoor.CheckedChanged += new System.EventHandler(this.chksaftydoor_CheckedChanged);
            // 
            // chkInterpolation
            // 
            this.chkInterpolation.AutoSize = true;
            this.chkInterpolation.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkInterpolation.Location = new System.Drawing.Point(25, 394);
            this.chkInterpolation.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkInterpolation.Name = "chkInterpolation";
            this.chkInterpolation.Size = new System.Drawing.Size(142, 22);
            this.chkInterpolation.TabIndex = 76;
            this.chkInterpolation.Text = "Interpolation";
            this.chkInterpolation.UseVisualStyleBackColor = true;
            this.chkInterpolation.CheckedChanged += new System.EventHandler(this.chkInterpolation_CheckedChanged);
            // 
            // ChkStepmode
            // 
            this.ChkStepmode.AutoSize = true;
            this.ChkStepmode.Location = new System.Drawing.Point(17, 602);
            this.ChkStepmode.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ChkStepmode.Name = "ChkStepmode";
            this.ChkStepmode.Size = new System.Drawing.Size(78, 17);
            this.ChkStepmode.TabIndex = 75;
            this.ChkStepmode.Text = "Step Mode";
            this.ChkStepmode.UseVisualStyleBackColor = true;
            // 
            // txtImageretry
            // 
            this.txtImageretry.Location = new System.Drawing.Point(230, 570);
            this.txtImageretry.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtImageretry.Name = "txtImageretry";
            this.txtImageretry.Size = new System.Drawing.Size(100, 20);
            this.txtImageretry.TabIndex = 74;
            this.txtImageretry.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtImageretry_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label27.Location = new System.Drawing.Point(22, 569);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(205, 18);
            this.label27.TabIndex = 73;
            this.label27.Text = "Image Failure Retry Count";
            // 
            // txtPostcheckdly
            // 
            this.txtPostcheckdly.Location = new System.Drawing.Point(230, 529);
            this.txtPostcheckdly.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtPostcheckdly.Name = "txtPostcheckdly";
            this.txtPostcheckdly.Size = new System.Drawing.Size(100, 20);
            this.txtPostcheckdly.TabIndex = 72;
            this.txtPostcheckdly.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPostcheckdly_KeyPress);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label26.Location = new System.Drawing.Point(22, 528);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(133, 18);
            this.label26.TabIndex = 71;
            this.label26.Text = "PostCheck Delay";
            // 
            // cmbPulseLogic
            // 
            this.cmbPulseLogic.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPulseLogic.FormattingEnabled = true;
            this.cmbPulseLogic.Items.AddRange(new object[] {
            "Falling Edge",
            "Rising Edge"});
            this.cmbPulseLogic.Location = new System.Drawing.Point(230, 488);
            this.cmbPulseLogic.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cmbPulseLogic.Name = "cmbPulseLogic";
            this.cmbPulseLogic.Size = new System.Drawing.Size(177, 21);
            this.cmbPulseLogic.TabIndex = 70;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(22, 487);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(163, 18);
            this.label25.TabIndex = 69;
            this.label25.Text = "Compare Pulse Logic";
            // 
            // cmbPulseMode
            // 
            this.cmbPulseMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPulseMode.FormattingEnabled = true;
            this.cmbPulseMode.Items.AddRange(new object[] {
            "Pulse",
            "Toggle"});
            this.cmbPulseMode.Location = new System.Drawing.Point(230, 442);
            this.cmbPulseMode.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cmbPulseMode.Name = "cmbPulseMode";
            this.cmbPulseMode.Size = new System.Drawing.Size(177, 21);
            this.cmbPulseMode.TabIndex = 68;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(22, 441);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(163, 18);
            this.label24.TabIndex = 67;
            this.label24.Text = "Compare Pulse Mode";
            // 
            // cmbFomseq
            // 
            this.cmbFomseq.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFomseq.FormattingEnabled = true;
            this.cmbFomseq.Items.AddRange(new object[] {
            "4+2 Foam Pick Seq",
            "3+3 Foam Pick Seq",
            "4 Foam Pick Seq"});
            this.cmbFomseq.Location = new System.Drawing.Point(229, 360);
            this.cmbFomseq.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cmbFomseq.Name = "cmbFomseq";
            this.cmbFomseq.Size = new System.Drawing.Size(177, 21);
            this.cmbFomseq.TabIndex = 64;
            this.cmbFomseq.SelectedIndexChanged += new System.EventHandler(this.cmbFomseq_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label16.Location = new System.Drawing.Point(20, 359);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(116, 18);
            this.label16.TabIndex = 63;
            this.label16.Text = "Foam Pick Seq";
            // 
            // txtTotnumfoams
            // 
            this.txtTotnumfoams.Location = new System.Drawing.Point(229, 318);
            this.txtTotnumfoams.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtTotnumfoams.Name = "txtTotnumfoams";
            this.txtTotnumfoams.Size = new System.Drawing.Size(100, 20);
            this.txtTotnumfoams.TabIndex = 62;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(20, 317);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(180, 18);
            this.label15.TabIndex = 61;
            this.label15.Text = "Total Number of Foams";
            // 
            // txtFeedingCnt
            // 
            this.txtFeedingCnt.Location = new System.Drawing.Point(229, 280);
            this.txtFeedingCnt.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtFeedingCnt.Name = "txtFeedingCnt";
            this.txtFeedingCnt.Size = new System.Drawing.Size(100, 20);
            this.txtFeedingCnt.TabIndex = 60;
            // 
            // txtUnitFailureCnt
            // 
            this.txtUnitFailureCnt.Location = new System.Drawing.Point(229, 241);
            this.txtUnitFailureCnt.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtUnitFailureCnt.Name = "txtUnitFailureCnt";
            this.txtUnitFailureCnt.Size = new System.Drawing.Size(100, 20);
            this.txtUnitFailureCnt.TabIndex = 59;
            // 
            // txtTossingFailCnt
            // 
            this.txtTossingFailCnt.Location = new System.Drawing.Point(229, 201);
            this.txtTossingFailCnt.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtTossingFailCnt.Name = "txtTossingFailCnt";
            this.txtTossingFailCnt.Size = new System.Drawing.Size(100, 20);
            this.txtTossingFailCnt.TabIndex = 58;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(20, 279);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(162, 18);
            this.label12.TabIndex = 57;
            this.label12.Text = "Feeder Failing Count";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(20, 240);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(143, 18);
            this.label13.TabIndex = 56;
            this.label13.Text = "Unit Failure Count";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(20, 201);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(154, 18);
            this.label14.TabIndex = 55;
            this.label14.Text = "Tossing Limit Count";
            // 
            // cmbhome_screen_timeout
            // 
            this.cmbhome_screen_timeout.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbhome_screen_timeout.FormattingEnabled = true;
            this.cmbhome_screen_timeout.Items.AddRange(new object[] {
            "10 mins"});
            this.cmbhome_screen_timeout.Location = new System.Drawing.Point(229, 168);
            this.cmbhome_screen_timeout.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cmbhome_screen_timeout.Name = "cmbhome_screen_timeout";
            this.cmbhome_screen_timeout.Size = new System.Drawing.Size(177, 21);
            this.cmbhome_screen_timeout.TabIndex = 54;
            // 
            // cmbdata_display_default
            // 
            this.cmbdata_display_default.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbdata_display_default.FormattingEnabled = true;
            this.cmbdata_display_default.Items.AddRange(new object[] {
            "1 week"});
            this.cmbdata_display_default.Location = new System.Drawing.Point(229, 129);
            this.cmbdata_display_default.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cmbdata_display_default.Name = "cmbdata_display_default";
            this.cmbdata_display_default.Size = new System.Drawing.Size(177, 21);
            this.cmbdata_display_default.TabIndex = 53;
            // 
            // cmb_def_alarm_log_time
            // 
            this.cmb_def_alarm_log_time.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_def_alarm_log_time.FormattingEnabled = true;
            this.cmb_def_alarm_log_time.Items.AddRange(new object[] {
            "15 mins"});
            this.cmb_def_alarm_log_time.Location = new System.Drawing.Point(229, 90);
            this.cmb_def_alarm_log_time.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cmb_def_alarm_log_time.Name = "cmb_def_alarm_log_time";
            this.cmb_def_alarm_log_time.Size = new System.Drawing.Size(177, 21);
            this.cmb_def_alarm_log_time.TabIndex = 52;
            // 
            // cmbAuto_Logout_Time
            // 
            this.cmbAuto_Logout_Time.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAuto_Logout_Time.FormattingEnabled = true;
            this.cmbAuto_Logout_Time.Items.AddRange(new object[] {
            "5 mins"});
            this.cmbAuto_Logout_Time.Location = new System.Drawing.Point(229, 49);
            this.cmbAuto_Logout_Time.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cmbAuto_Logout_Time.Name = "cmbAuto_Logout_Time";
            this.cmbAuto_Logout_Time.Size = new System.Drawing.Size(177, 21);
            this.cmbAuto_Logout_Time.TabIndex = 51;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(20, 167);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(170, 18);
            this.label18.TabIndex = 48;
            this.label18.Text = "Home Screen Timeout";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(20, 128);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(162, 18);
            this.label19.TabIndex = 46;
            this.label19.Text = "Data Display Default";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(20, 89);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(182, 18);
            this.label20.TabIndex = 44;
            this.label20.Text = "Default Alarm Log Time";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label21.Location = new System.Drawing.Point(20, 50);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(178, 18);
            this.label21.TabIndex = 42;
            this.label21.Text = "Automatic Logout Time";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold);
            this.label22.Location = new System.Drawing.Point(12, 11);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(124, 29);
            this.label22.TabIndex = 41;
            this.label22.Text = "Settings";
            // 
            // general_settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 220);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimizeBox = false;
            this.Name = "general_settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "general_settings";
            this.Load += new System.EventHandler(this.general_settings_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbhome_screen_timeout;
        private System.Windows.Forms.ComboBox cmbdata_display_default;
        private System.Windows.Forms.ComboBox cmb_def_alarm_log_time;
        private System.Windows.Forms.ComboBox cmbAuto_Logout_Time;
        private System.Windows.Forms.TextBox txtFeedingCnt;
        private System.Windows.Forms.TextBox txtUnitFailureCnt;
        private System.Windows.Forms.TextBox txtTossingFailCnt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbFomseq;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtTotnumfoams;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbPulseLogic;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbPulseMode;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtPostcheckdly;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtImageretry;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btn_TrayRst;
        private System.Windows.Forms.CheckBox ChkStepmode;
        private System.Windows.Forms.CheckBox chkInterpolation;
        private System.Windows.Forms.CheckBox chksaftydoor;
    }
}