﻿
using System;
using System.Windows.Forms;

namespace AHDP
{
    partial class CPK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.close = new System.Windows.Forms.Button();
            this.cmbtest = new System.Windows.Forms.ComboBox();
            this.cmboperator = new System.Windows.Forms.ComboBox();
            this.roundedButton2 = new AHDP.RoundedButton();
            this.roundedButton1 = new AHDP.RoundedButton();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.close);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(416, 30);
            this.panel1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBox1.Location = new System.Drawing.Point(3, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 14);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "Dialog";
            // 
            // close
            // 
            this.close.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.Location = new System.Drawing.Point(379, 4);
            this.close.Name = "close";
            //this.close.PaintStyle = DevExpress.XtraEditors.Controls.PaintStyles.Light;
            this.close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.FlatAppearance.BorderSize = 0; // Removes the border
            this.close.Size = new System.Drawing.Size(27, 22);
            this.close.TabIndex = 3;
            this.close.Text = "X";
            // 
            // cmbtest
            // 
            this.cmbtest.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtest.FormattingEnabled = true;
            this.cmbtest.Items.AddRange(new object[] {
            "ABC",
            "DFR",
            "AEFDWE",
            "FWEF",
            "WF",
            "W"});
            this.cmbtest.Location = new System.Drawing.Point(188, 55);
            this.cmbtest.Name = "cmbtest";
            this.cmbtest.Size = new System.Drawing.Size(202, 26);
            this.cmbtest.TabIndex = 3;
            // 
            // cmboperator
            // 
            this.cmboperator.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmboperator.FormattingEnabled = true;
            this.cmboperator.Items.AddRange(new object[] {
            "ABC",
            "DFR",
            "AEFDWE",
            "FWEF",
            "WF",
            "W"});
            this.cmboperator.Location = new System.Drawing.Point(188, 116);
            this.cmboperator.Name = "cmboperator";
            this.cmboperator.Size = new System.Drawing.Size(202, 26);
            this.cmboperator.TabIndex = 4;
            // 
            // roundedButton2
            // 
            this.roundedButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(198)))), ((int)(((byte)(198)))));
            this.roundedButton2.Font = new System.Drawing.Font("Verdana", 12F);
            this.roundedButton2.Location = new System.Drawing.Point(28, 104);
            this.roundedButton2.Name = "roundedButton2";
            this.roundedButton2.Size = new System.Drawing.Size(122, 48);
            this.roundedButton2.TabIndex = 2;
            this.roundedButton2.Text = "Operator";
            this.roundedButton2.UseVisualStyleBackColor = false;
            // 
            // roundedButton1
            // 
            this.roundedButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(198)))), ((int)(((byte)(198)))));
            this.roundedButton1.Font = new System.Drawing.Font("Verdana", 12F);
            this.roundedButton1.Location = new System.Drawing.Point(28, 42);
            this.roundedButton1.Name = "roundedButton1";
            this.roundedButton1.Size = new System.Drawing.Size(122, 50);
            this.roundedButton1.TabIndex = 1;
            this.roundedButton1.Text = "Test";
            this.roundedButton1.UseVisualStyleBackColor = false;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(198, 198, 198);
            this.btnCancel.Font = new System.Drawing.Font("Verdana", 12F);
            this.btnCancel.Location = new System.Drawing.Point(316, 166);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(74, 33);
            this.btnCancel.TabIndex = 41;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.FlatStyle = FlatStyle.Flat; // Optional, to make the button look flat.
            this.btnSubmit.FlatAppearance.BorderSize = 0; // Removes the border (optional).
            this.btnSubmit.Location = new System.Drawing.Point(227, 166);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(83, 33);
            this.btnSubmit.TabIndex = 40;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // CPK
            // 
            //this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);  // Automatically scales the form when it is resized.
            //this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;  // Specifies that scaling is based on the font size.
            //this.ClientSize = new System.Drawing.Size(416, 207);  // Sets the client (working area) size of the form.
            //this.Controls.Add(this.btnCancel);  // Adds btnCancel control to the form.
            //this.Controls.Add(this.btnSubmit);  // Adds btnSubmit control to the form.
            //this.Controls.Add(this.cmboperator);  // Adds cmboperator control (ComboBox) to the form.
            //this.Controls.Add(this.cmbtest);  // Adds cmbtest control (ComboBox) to the form.
            //this.Controls.Add(this.roundedButton2);  // Adds roundedButton2 control to the form.
            //this.Controls.Add(this.roundedButton1);  // Adds roundedButton1 control to the form.
            //this.Controls.Add(this.panel1);  // Adds panel1 control to the form.
            //this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;  // Sets the form's border style to 'None', so it appears borderless.
            //this.MaximizeBox = false;  // Disables the maximize button.
            //this.MinimizeBox = false;  // Disables the minimize button.
            //this.Name = "CPK";  // Sets the form's name to 'CPK'.
            //this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;  // Centers the form on the screen when it is displayed.
            //this.Text = "CPK";  // Sets the title text of the form.
            //this.panel1.ResumeLayout(false);  // Resumes layout of panel1, ensuring its controls are properly laid out.
            //this.panel1.PerformLayout();  // Makes sure any pending layout changes for panel1 are applied.
            //this.ResumeLayout(false);  // Resumes the form layout, ensuring the controls are properly arranged.

        }

        private void SuspendLayout()
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button close;
        private RoundedButton roundedButton1;
        private RoundedButton roundedButton2;
        private System.Windows.Forms.ComboBox cmbtest;
        private System.Windows.Forms.ComboBox cmboperator;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSubmit;

    }
}