﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP
{
    public partial class ModeSelection : Form
    {
        public ModeSelection()
        {
            InitializeComponent();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            this.Close();
            GlobalVar.User_Mode = "Production";
            Globalvariable. LoginScreen = new LoginScreen();
            Globalvariable.LoginScreen.ShowDialog();
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            this.Close();
            GlobalVar.User_Mode = "Engineer";
            Globalvariable.LoginScreen = new LoginScreen();
            Globalvariable.LoginScreen.ShowDialog();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
            //Form CPK = new CPK();
            //CPK.ShowDialog();
            GlobalVar.User_Mode = "Engineer";
            Globalvariable.LoginScreen = new LoginScreen();
            Globalvariable.LoginScreen.ShowDialog();
        }

        private void ModeSelection_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void simpleButton5_Click(object sender, EventArgs e)
        {
            this.Close();
            GlobalVar.User_Mode = "Test";
            //Form LoginScreen = new LoginScreen();
            //LoginScreen.ShowDialog();

        }
        private void simpleButton4_Click(object sender, EventArgs e)
        {

        }
    }
}
