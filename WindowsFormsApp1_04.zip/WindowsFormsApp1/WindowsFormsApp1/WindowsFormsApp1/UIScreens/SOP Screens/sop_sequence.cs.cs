﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using AHDP.UIScreens.ParameterSetting_Screens;

namespace AHDP
{
    public partial class sop_sequence : Form
    {
        public sop_sequence()
        {
            InitializeComponent();
        }
        public static bool check3 = false;
        public static bool check4 = false;

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
    (
        int nLeftRect,
        int nTopRect,
        int nRightRect,
        int nBottomRect,
        int nWidthEllipse,
        int nHeightEllipse
    );

        public void Panel_Shape()
        {
            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width,
            panel1.Height, 30, 30));
            //   panel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel2.Width,
            //panel2.Height, 30, 30));
            //panel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel3.Width,
            //panel3.Height, 30, 30));
            //   panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
            //panel4.Height, 30, 30));
            //   panel5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel5.Width,
            //panel5.Height, 30, 30));
        }

        private void sop_sequence_Load(object sender, EventArgs e)
        {
            //grpBoxCCD1.Enabled = false;
            //grpBoxCCD2.Enabled = false;
            onload();
        }

        private void chkCCD1_CheckedChanged(object sender, EventArgs e)
        {
            //if (chkCCD1.Checked)
            //{
            //    Static_and_Dynamic_test.Cam1_Active_Dy = true;
            //    Static_and_Dynamic_test.Cam5_Active_Dy = false;
               
            //}


        }
        public void onload()
        {



        }
      

     

        private void Static_timer_Tick(object sender, EventArgs e)
        {
           // Static_and_Dynamic_test.Static_gantry_test();
            // lblRunningCount.Text = Static_and_Dynamic_test.Trig_cam.ToString();
            //lblccd2runningcount.Text = Static_and_Dynamic_test.Trig_cam.ToString();
            //double[] process = Gantry.TogetCurrentPos();
            // lblactualpos_ccd1_x.Text = process[0].ToString() + " mm";
            // lblactualposition_ccd2x.Text = process[0].ToString() + " mm";
            string currstate = string.Empty;
            double Act_Vel = 0.0;
            double Act_pos = 0.0;
            // Interface.ToGetCurrentPos(1, out Act_pos, out currstate, out Act_Vel);
            //lblactualpos_ccd1_y.Text = process[1].ToString() + " mm";
            // lblactualpostion_ccd2y.Text = process[1].ToString() + " mm";
        }

        private void Dyanamic_timer_Tick(object sender, EventArgs e)
        {
            



        }

        private void txtstaticposccd1_x_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Decimal_Validation(sender, e);
        }
        public void Decimal_Validation(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void txtposition_x1_Leave(object sender, EventArgs e)
        {
            //    if (!string.IsNullOrEmpty(txtposition_x1.Text))
            //    {

            //        Static_and_Dynamic_test.Gantry_X_Dynamic_Pos1 = Convert.ToDouble(txtposition_x1.Text);

            //    }
        }

        private void txtposition_y1_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtposition_y1.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_Y_Dynamic_Pos1 = Convert.ToDouble(txtposition_y1.Text);

            //}
        }

        private void txtposition_x2_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtposition_x2.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_X_Dynamic_Pos2 = Convert.ToDouble(txtposition_x2.Text);

            //}
        }

        private void txtposition_y2_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtposition_y2.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_Y_Dynamic_Pos2 = Convert.ToDouble(txtposition_y2.Text);

            //}
        }

        private void txtstaticposccd1_x_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtstaticposccd1_x.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_X_Static_Pos = Convert.ToDouble(txtstaticposccd1_x.Text);

            //}
        }

        private void txtstaticposccd1_y_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtstaticposccd1_y.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_Y_Static_Pos = Convert.ToDouble(txtstaticposccd1_y.Text);

            //}
        }

        private void txtspeed_Leave(object sender, EventArgs e)
        {
            if (chkCCD1.Checked)
            {
                //if (!string.IsNullOrEmpty(txtspeed.Text))
                //{

                //    Static_and_Dynamic_test.Gantry_vel = Convert.ToDouble(txtspeed.Text);

                //}
            }
            else if (chkCCD3.Checked)
            {
                //if (!string.IsNullOrEmpty(txtspeedccd2.Text))
                //{

                //    Static_and_Dynamic_test.Gantry_vel = Convert.ToDouble(txtspeedccd2.Text);

                //}
            }


        }

        private void txtnoofcountccd1_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtnoofcountccd1.Text))
            //{
            //    if (Convert.ToInt32(txtnoofcountccd1.Text) != 0)
            //    {
            //        machine_settings.Repeatcnt = Convert.ToInt32(txtnoofcountccd1.Text);
            //    }

            //}
            //if (!string.IsNullOrEmpty(txtnoofcountccd2.Text) )
            //{
            //    if(Convert.ToInt32(txtnoofcountccd2.Text) != 0)
            //    {
            //        machine_settings.Repeatcnt = Convert.ToInt32(txtnoofcountccd2.Text);
            //    }


            //}
        }

        private void cmbTestmodeccd2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (cmbTestmodeccd2.Text == "Dynamic")
            //{
            //    txtccd2path.Text = @"D:\TEAL\Cam2\Dynamic\";
            //    Static_and_Dynamic_test.Cam2_dynamic_path = txtccd2path.Text;

            //}
            //else if (cmbTestmodeccd2.Text == "Static")
            //{
            //    txtccd2path.Text = @"D:\TEAL\Cam2\Static\";
            //    Static_and_Dynamic_test.Cam2_static_path = txtccd2path.Text;

            //}
        }

        private void txtpositionccd2_x1_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtpositionccd2_x1.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_X_Dynamic_Pos1 = Convert.ToDouble(txtpositionccd2_x1.Text);

            //}
        }

        private void txtpositionccd2_y1_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtpositionccd2_y1.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_Y_Dynamic_Pos1 = Convert.ToDouble(txtpositionccd2_y1.Text);

            //}
        }

        private void txtpositionccd2_x2_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtpositionccd2_x2.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_X_Dynamic_Pos2 = Convert.ToDouble(txtpositionccd2_x2.Text);

            //}
        }

        private void txtpositionccd2_y2_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtpositionccd2_y2.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_Y_Dynamic_Pos2 = Convert.ToDouble(txtpositionccd2_y2.Text);

            //}
        }

        private void txtstaticposccd2_x_Leave(object sender, EventArgs e)
        {
            //    if (!string.IsNullOrEmpty(txtstaticposccd2_x.Text))
            //    {

            //        Static_and_Dynamic_test.Gantry_X_Static_Pos = Convert.ToDouble(txtstaticposccd2_x.Text);

            //    }
        }

        private void txtstaticposccd2_y_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtstaticposccd2_y.Text))
            //{

            //    Static_and_Dynamic_test.Gantry_Y_Static_Pos = Convert.ToDouble(txtstaticposccd2_y.Text);

            //}
        }

        private void btnccd1_stop_Click(object sender, EventArgs e)
        {
            //Interface.Kill_All_Motions();
            Static_timer.Enabled = false;
            Dyanamic_timer.Enabled = false;


        }

        private void btnccd2_stop_Click(object sender, EventArgs e)
        {
            //Interface.Kill_All_Motions();
            Static_timer.Enabled = false;
            Dyanamic_timer.Enabled = false;
        }

        private void btnccd2_start_Click(object sender, EventArgs e)
        {
           

            //if (cmbTestmodeccd2.Text == "Dynamic")
            //{

            //    Dyanamic_timer.Enabled = true;
            //    Static_timer.Enabled = false;
            //    Array.Clear(Static_and_Dynamic_test.Csv_Values_Dy, 0, Static_and_Dynamic_test.Csv_Values_Dy.Length - 1);
            //    Static_and_Dynamic_test.DynamicStep = 1;
            //    Static_and_Dynamic_test.Staticstep = 0;
            //}
            //else if (cmbTestmodeccd2.Text == "Static")
            //{
            //    Static_and_Dynamic_test.Staticstep = 1;
            //    Static_and_Dynamic_test.DynamicStep = 0;
            //    Dyanamic_timer.Enabled = false;
            //    Static_timer.Enabled = true;
            //}
            //else if(cmbTestmodeccd2.Text== "On-fly Dynamic")
            //{
            //   // DIOConfig.WriteOPS(false, DIOConfig.O_Camera_Trig_CCD2);
            //    //Interface.comp_disable(GlobalVar.Gantry_X_MIO_axis);
            //    Dyanamic_timer.Enabled = true;
            //    Static_timer.Enabled = false;
            //    Array.Clear(Static_and_Dynamic_test.Csv_Values_Dy, 0, Static_and_Dynamic_test.Csv_Values_Dy.Length - 1);
            //    Static_and_Dynamic_test.DynamicStep_on_fly = 1;
            //    Static_and_Dynamic_test.DynamicStep = 0;
            //    Static_and_Dynamic_test.Staticstep = 0;
            //}
        }

        private void rdpN1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdpN2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdpN3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rdpN4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtonflyintervel_Leave(object sender, EventArgs e)
        {
            //    if (!string.IsNullOrEmpty(txtonflyintervel.Text))
            //    {
            //        Static_and_Dynamic_test.Gantry_on_fly_interval = Convert.ToDouble(txtonflyintervel.Text);
            //    }
        }

        private void label34_Click(object sender, EventArgs e)
        {

        }

        private void txttriggerpos_Leave(object sender, EventArgs e)
        {

        }

        private void sop_sequence_MouseMove(object sender, MouseEventArgs e)
        {
            if (Form1.isengineeringmode)
            {
                Form1.lastEngineeringactivity = DateTime.Now;
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void grpboxCamera_Enter(object sender, EventArgs e)
        {

        }

       
        private void button11_Click(object sender, EventArgs e)
        {
            //Static_and_Dynamic_test.Trig_cam = 0;
            //Static_and_Dynamic_test.Trig_cam_Dy = 0;
            //Static_and_Dynamic_test.Gantry_vel = double.Parse(CCD1Speed.Text);
            machine_settings.Repeatcnt = int.Parse(CCD1count.Text);
            //  DIOConfig.WriteOPS(false, DIOConfig.O_Camera_Trig);



            if (cmbTestMode.Text == "Dynamic")
            {

                Dyanamic_timer.Enabled = true;
                Static_timer.Enabled = false;
                //Array.Clear(Static_and_Dynamic_test.Csv_Values_Dy, 0, Static_and_Dynamic_test.Csv_Values_Dy.Length - 1);
                //Static_and_Dynamic_test.DynamicStep = 1;
                //Static_and_Dynamic_test.Staticstep = 0;
            }
            else if (cmbTestMode.Text == "Static")
            {
                //Static_and_Dynamic_test.Staticstep = 1;
                //Static_and_Dynamic_test.DynamicStep = 0;
                Dyanamic_timer.Enabled = false;
                Static_timer.Enabled = true;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //Static_and_Dynamic_test.Trig_cam = 0;
            //Static_and_Dynamic_test.Trig_cam_Dy = 0;
            //Static_and_Dynamic_test.Gantry_vel = double.Parse(CCD5Speed.Text);
            machine_settings.Repeatcnt = int.Parse(CCD5count.Text);

            if (CCD5TestMode.Text == "Dynamic")
            {

                Dyanamic_timer.Enabled = true;
                Static_timer.Enabled = false;
                //Array.Clear(Static_and_Dynamic_test.Csv_Values_Dy, 0, Static_and_Dynamic_test.Csv_Values_Dy.Length - 1);
                //Static_and_Dynamic_test.DynamicStep = 1;
                //Static_and_Dynamic_test.Staticstep = 0;
            }
            else if (CCD5TestMode.Text == "Static")
            {
                //Static_and_Dynamic_test.Staticstep = 1;
                //Static_and_Dynamic_test.DynamicStep = 0;
                Dyanamic_timer.Enabled = false;
                Static_timer.Enabled = true;
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < int.Parse(CCD3count.ToString()); i++)
            {
                if (!check4)
                {
                    if (SocketClient.TCP_Senddata_Vision_T3("T1,1," + DateTime.Now.ToString()))
                    {
                        Thread.Sleep(200);
                        //Static_and_Dynamic_test.createExcelCCD3Data();
                    }
                }
                else
                    break;
            }
            check4 = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < int.Parse(CCD3count.ToString()); i++)
            {
                if (!check3)
                {
                    if (SocketClient.TCP_Senddata_Vision_T4("T1,1," + DateTime.Now.ToString()))
                    {
                        Thread.Sleep(200);
                       // Static_and_Dynamic_test.createExcelCCD4Data();
                    }
                    else
                        break;
                }

            }
            check3 = false;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            check3 = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            check4 = false;
        }

        private void CCD5TestMode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                Cam1_path.Text = folderBrowserDialog.SelectedPath;
               // Static_and_Dynamic_test.Cam1_path = folderBrowserDialog.SelectedPath;


            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                //Cam5__path.Text = folderBrowserDialog.SelectedPath;
                //Static_and_Dynamic_test.Cam5_path = folderBrowserDialog.SelectedPath;


            }

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Dyanamic_timer.Enabled = false;
            Static_timer.Enabled = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Dyanamic_timer.Enabled = false;
            Static_timer.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                //Cam5__path.Text = folderBrowserDialog.SelectedPath;
                //Static_and_Dynamic_test.Cam3_path = folderBrowserDialog.SelectedPath;


            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                //Cam5__path.Text = folderBrowserDialog.SelectedPath;
                //Static_and_Dynamic_test.Cam4_path = folderBrowserDialog.SelectedPath;


            }
        }
    }
}