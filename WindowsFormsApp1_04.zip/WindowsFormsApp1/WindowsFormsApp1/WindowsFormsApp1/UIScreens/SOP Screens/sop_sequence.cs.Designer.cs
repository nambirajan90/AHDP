﻿
namespace AHDP
{
    partial class sop_sequence
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.Cam1_path = new System.Windows.Forms.TextBox();
            this.lblactualpos_ccd1_y = new System.Windows.Forms.Label();
            this.lblactualpos_ccd1_x = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.CCD1count = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.CCD1Speed = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.lblRunningCount = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.cmbTestMode = new System.Windows.Forms.ComboBox();
            this.label82 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Cam3_path = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.CCD3count = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txttriggerpos = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.txtonflyintervel = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.Cam5__path = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.CCD5count = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.CCD5Speed = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.CCD5TestMode = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.Cam4_path = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.CCD4count = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.grpboxCamera = new System.Windows.Forms.GroupBox();
            this.chkCCD5 = new System.Windows.Forms.CheckBox();
            this.chkCCD4 = new System.Windows.Forms.CheckBox();
            this.chkCCD3 = new System.Windows.Forms.CheckBox();
            this.chkCCD1 = new System.Windows.Forms.CheckBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.Static_timer = new System.Windows.Forms.Timer(this.components);
            this.Dyanamic_timer = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpboxCamera.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.grpboxCamera);
            this.panel1.Location = new System.Drawing.Point(-44, 74);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1540, 596);
            this.panel1.TabIndex = 4;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.textBox28);
            this.groupBox4.Controls.Add(this.textBox29);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Controls.Add(this.Cam1_path);
            this.groupBox4.Controls.Add(this.lblactualpos_ccd1_y);
            this.groupBox4.Controls.Add(this.lblactualpos_ccd1_x);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.button11);
            this.groupBox4.Controls.Add(this.button12);
            this.groupBox4.Controls.Add(this.CCD1count);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.CCD1Speed);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.textBox33);
            this.groupBox4.Controls.Add(this.textBox34);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.textBox35);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.textBox36);
            this.groupBox4.Controls.Add(this.label79);
            this.groupBox4.Controls.Add(this.lblRunningCount);
            this.groupBox4.Controls.Add(this.label81);
            this.groupBox4.Controls.Add(this.cmbTestMode);
            this.groupBox4.Controls.Add(this.label82);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(13, 101);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(340, 465);
            this.groupBox4.TabIndex = 124;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "CCD 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(201, 270);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 16);
            this.label1.TabIndex = 110;
            this.label1.Text = "(mm/s)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(277, 231);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 109;
            this.label2.Text = "(mm)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(277, 192);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 16);
            this.label3.TabIndex = 108;
            this.label3.Text = "(mm)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(277, 153);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 16);
            this.label4.TabIndex = 107;
            this.label4.Text = "(mm)";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(204, 228);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(63, 23);
            this.textBox28.TabIndex = 84;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(127, 225);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(63, 23);
            this.textBox29.TabIndex = 83;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 82;
            this.label5.Text = "Static Pos";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button10.Enabled = false;
            this.button10.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(216, 377);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(83, 29);
            this.button10.TabIndex = 81;
            this.button10.Text = "Browse";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // Cam1_path
            // 
            this.Cam1_path.Enabled = false;
            this.Cam1_path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam1_path.Location = new System.Drawing.Point(9, 380);
            this.Cam1_path.Name = "Cam1_path";
            this.Cam1_path.Size = new System.Drawing.Size(201, 23);
            this.Cam1_path.TabIndex = 80;
            // 
            // lblactualpos_ccd1_y
            // 
            this.lblactualpos_ccd1_y.AutoSize = true;
            this.lblactualpos_ccd1_y.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblactualpos_ccd1_y.Location = new System.Drawing.Point(309, 89);
            this.lblactualpos_ccd1_y.Name = "lblactualpos_ccd1_y";
            this.lblactualpos_ccd1_y.Size = new System.Drawing.Size(15, 16);
            this.lblactualpos_ccd1_y.TabIndex = 79;
            this.lblactualpos_ccd1_y.Text = "0";
            // 
            // lblactualpos_ccd1_x
            // 
            this.lblactualpos_ccd1_x.AutoSize = true;
            this.lblactualpos_ccd1_x.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblactualpos_ccd1_x.Location = new System.Drawing.Point(277, 88);
            this.lblactualpos_ccd1_x.Name = "lblactualpos_ccd1_x";
            this.lblactualpos_ccd1_x.Size = new System.Drawing.Size(15, 16);
            this.lblactualpos_ccd1_x.TabIndex = 78;
            this.lblactualpos_ccd1_x.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(309, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(16, 16);
            this.label8.TabIndex = 77;
            this.label8.Text = "Y";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(277, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(16, 16);
            this.label9.TabIndex = 76;
            this.label9.Text = "X";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(162, 89);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 16);
            this.label10.TabIndex = 75;
            this.label10.Text = "Actual Position";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 346);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(134, 16);
            this.label11.TabIndex = 74;
            this.label11.Text = "CSV File Save Path";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button11.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(16, 416);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(83, 37);
            this.button11.TabIndex = 73;
            this.button11.Text = "Start";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button12.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(127, 416);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(83, 37);
            this.button12.TabIndex = 72;
            this.button12.Text = "Stop";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // CCD1count
            // 
            this.CCD1count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD1count.Location = new System.Drawing.Point(127, 308);
            this.CCD1count.Name = "CCD1count";
            this.CCD1count.Size = new System.Drawing.Size(63, 23);
            this.CCD1count.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 312);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 16);
            this.label12.TabIndex = 14;
            this.label12.Text = "No of Counts";
            // 
            // CCD1Speed
            // 
            this.CCD1Speed.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD1Speed.Location = new System.Drawing.Point(127, 267);
            this.CCD1Speed.Name = "CCD1Speed";
            this.CCD1Speed.Size = new System.Drawing.Size(63, 23);
            this.CCD1Speed.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 270);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 16);
            this.label13.TabIndex = 12;
            this.label13.Text = "Speed";
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(204, 185);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(63, 23);
            this.textBox33.TabIndex = 11;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(204, 146);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(63, 23);
            this.textBox34.TabIndex = 10;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(227, 117);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(16, 16);
            this.label25.TabIndex = 9;
            this.label25.Text = "Y";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(149, 117);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(16, 16);
            this.label28.TabIndex = 8;
            this.label28.Text = "X";
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(127, 185);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(63, 23);
            this.textBox35.TabIndex = 7;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(6, 185);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(103, 16);
            this.label29.TabIndex = 6;
            this.label29.Text = "Dynamic Pos 2";
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(127, 146);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(63, 23);
            this.textBox36.TabIndex = 5;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(6, 146);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(103, 16);
            this.label79.TabIndex = 4;
            this.label79.Text = "Dynamic Pos 1";
            // 
            // lblRunningCount
            // 
            this.lblRunningCount.AutoSize = true;
            this.lblRunningCount.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRunningCount.Location = new System.Drawing.Point(115, 89);
            this.lblRunningCount.Name = "lblRunningCount";
            this.lblRunningCount.Size = new System.Drawing.Size(15, 16);
            this.lblRunningCount.TabIndex = 3;
            this.lblRunningCount.Text = "0";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(6, 89);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(102, 16);
            this.label81.TabIndex = 2;
            this.label81.Text = "Running Count";
            // 
            // cmbTestMode
            // 
            this.cmbTestMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTestMode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTestMode.FormattingEnabled = true;
            this.cmbTestMode.Items.AddRange(new object[] {
            "Dynamic",
            "Static"});
            this.cmbTestMode.Location = new System.Drawing.Point(88, 33);
            this.cmbTestMode.Name = "cmbTestMode";
            this.cmbTestMode.Size = new System.Drawing.Size(154, 24);
            this.cmbTestMode.TabIndex = 1;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(6, 37);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(76, 16);
            this.label82.TabIndex = 0;
            this.label82.Text = "Test Mode";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.Cam3_path);
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.CCD3count);
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(359, 101);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(340, 465);
            this.groupBox1.TabIndex = 123;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CCD 3";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button1.Enabled = false;
            this.button1.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(230, 287);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 29);
            this.button1.TabIndex = 81;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Cam3_path
            // 
            this.Cam3_path.Enabled = false;
            this.Cam3_path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam3_path.Location = new System.Drawing.Point(23, 287);
            this.Cam3_path.Name = "Cam3_path";
            this.Cam3_path.Size = new System.Drawing.Size(201, 23);
            this.Cam3_path.TabIndex = 80;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(28, 232);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(134, 16);
            this.label46.TabIndex = 74;
            this.label46.Text = "CSV File Save Path";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(16, 416);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(83, 37);
            this.button2.TabIndex = 73;
            this.button2.Text = "Start";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(127, 416);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(83, 37);
            this.button3.TabIndex = 72;
            this.button3.Text = "Stop";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // CCD3count
            // 
            this.CCD3count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD3count.Location = new System.Drawing.Point(161, 164);
            this.CCD3count.Name = "CCD3count";
            this.CCD3count.Size = new System.Drawing.Size(63, 23);
            this.CCD3count.TabIndex = 15;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(28, 164);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(93, 16);
            this.label47.TabIndex = 14;
            this.label47.Text = "No of Counts";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox3.Controls.Add(this.txttriggerpos);
            this.groupBox3.Controls.Add(this.label77);
            this.groupBox3.Controls.Add(this.txtonflyintervel);
            this.groupBox3.Controls.Add(this.label78);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.textBox19);
            this.groupBox3.Controls.Add(this.textBox20);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.Cam5__path);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.button8);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Controls.Add(this.CCD5count);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.CCD5Speed);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.textBox24);
            this.groupBox3.Controls.Add(this.textBox25);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.textBox26);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.textBox27);
            this.groupBox3.Controls.Add(this.label33);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.CCD5TestMode);
            this.groupBox3.Controls.Add(this.label76);
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(1052, 101);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(474, 465);
            this.groupBox3.TabIndex = 111;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "CCD 5";
            // 
            // txttriggerpos
            // 
            this.txttriggerpos.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttriggerpos.Location = new System.Drawing.Point(389, 336);
            this.txttriggerpos.Name = "txttriggerpos";
            this.txttriggerpos.Size = new System.Drawing.Size(63, 23);
            this.txttriggerpos.TabIndex = 122;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(277, 339);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(80, 16);
            this.label77.TabIndex = 121;
            this.label77.Text = "Trigger pos";
            // 
            // txtonflyintervel
            // 
            this.txtonflyintervel.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtonflyintervel.Location = new System.Drawing.Point(389, 305);
            this.txtonflyintervel.Name = "txtonflyintervel";
            this.txtonflyintervel.Size = new System.Drawing.Size(63, 23);
            this.txtonflyintervel.TabIndex = 120;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(277, 308);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(102, 16);
            this.label78.TabIndex = 119;
            this.label78.Text = "On-fly interval";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(201, 270);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 16);
            this.label14.TabIndex = 110;
            this.label14.Text = "(mm/s)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(277, 231);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(39, 16);
            this.label15.TabIndex = 109;
            this.label15.Text = "(mm)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(277, 192);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(39, 16);
            this.label16.TabIndex = 108;
            this.label16.Text = "(mm)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(277, 153);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 16);
            this.label17.TabIndex = 107;
            this.label17.Text = "(mm)";
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(204, 228);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(63, 23);
            this.textBox19.TabIndex = 84;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(127, 225);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(63, 23);
            this.textBox20.TabIndex = 83;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 228);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(75, 16);
            this.label18.TabIndex = 82;
            this.label18.Text = "Static Pos";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button7.Enabled = false;
            this.button7.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(216, 377);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(83, 29);
            this.button7.TabIndex = 81;
            this.button7.Text = "Browse";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // Cam5__path
            // 
            this.Cam5__path.Enabled = false;
            this.Cam5__path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam5__path.Location = new System.Drawing.Point(9, 380);
            this.Cam5__path.Name = "Cam5__path";
            this.Cam5__path.Size = new System.Drawing.Size(201, 23);
            this.Cam5__path.TabIndex = 80;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(386, 88);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 16);
            this.label19.TabIndex = 79;
            this.label19.Text = "0";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(332, 88);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 16);
            this.label20.TabIndex = 78;
            this.label20.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(386, 57);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(16, 16);
            this.label21.TabIndex = 77;
            this.label21.Text = "Y";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(331, 57);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(16, 16);
            this.label22.TabIndex = 76;
            this.label22.Text = "X";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(211, 88);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 16);
            this.label23.TabIndex = 75;
            this.label23.Text = "Actual Position";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(6, 346);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(134, 16);
            this.label24.TabIndex = 74;
            this.label24.Text = "CSV File Save Path";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(16, 416);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(83, 37);
            this.button8.TabIndex = 73;
            this.button8.Text = "Start";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button9.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(127, 416);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(83, 37);
            this.button9.TabIndex = 72;
            this.button9.Text = "Stop";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // CCD5count
            // 
            this.CCD5count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD5count.Location = new System.Drawing.Point(127, 308);
            this.CCD5count.Name = "CCD5count";
            this.CCD5count.Size = new System.Drawing.Size(63, 23);
            this.CCD5count.TabIndex = 15;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(6, 312);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(93, 16);
            this.label26.TabIndex = 14;
            this.label26.Text = "No of Counts";
            // 
            // CCD5Speed
            // 
            this.CCD5Speed.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD5Speed.Location = new System.Drawing.Point(127, 267);
            this.CCD5Speed.Name = "CCD5Speed";
            this.CCD5Speed.Size = new System.Drawing.Size(63, 23);
            this.CCD5Speed.TabIndex = 13;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(6, 270);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 16);
            this.label27.TabIndex = 12;
            this.label27.Text = "Speed";
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(204, 185);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(63, 23);
            this.textBox24.TabIndex = 11;
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(204, 146);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(63, 23);
            this.textBox25.TabIndex = 10;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(227, 117);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(16, 16);
            this.label30.TabIndex = 9;
            this.label30.Text = "Y";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(149, 117);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(16, 16);
            this.label31.TabIndex = 8;
            this.label31.Text = "X";
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(127, 185);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(63, 23);
            this.textBox26.TabIndex = 7;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(6, 185);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(103, 16);
            this.label32.TabIndex = 6;
            this.label32.Text = "Dynamic Pos 2";
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(127, 146);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(63, 23);
            this.textBox27.TabIndex = 5;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(6, 146);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(103, 16);
            this.label33.TabIndex = 4;
            this.label33.Text = "Dynamic Pos 1";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(115, 89);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(15, 16);
            this.label34.TabIndex = 3;
            this.label34.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(6, 89);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(102, 16);
            this.label35.TabIndex = 2;
            this.label35.Text = "Running Count";
            // 
            // CCD5TestMode
            // 
            this.CCD5TestMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CCD5TestMode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD5TestMode.FormattingEnabled = true;
            this.CCD5TestMode.Items.AddRange(new object[] {
            "Dynamic",
            "Static"});
            this.CCD5TestMode.Location = new System.Drawing.Point(88, 33);
            this.CCD5TestMode.Name = "CCD5TestMode";
            this.CCD5TestMode.Size = new System.Drawing.Size(154, 24);
            this.CCD5TestMode.TabIndex = 1;
            this.CCD5TestMode.SelectedIndexChanged += new System.EventHandler(this.CCD5TestMode_SelectedIndexChanged);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(6, 37);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(76, 16);
            this.label76.TabIndex = 0;
            this.label76.Text = "Test Mode";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.Cam4_path);
            this.groupBox2.Controls.Add(this.label66);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.CCD4count);
            this.groupBox2.Controls.Add(this.label67);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(705, 101);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(340, 465);
            this.groupBox2.TabIndex = 88;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "CCD 4";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button4.Enabled = false;
            this.button4.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(216, 290);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(83, 29);
            this.button4.TabIndex = 81;
            this.button4.Text = "Browse";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Cam4_path
            // 
            this.Cam4_path.Enabled = false;
            this.Cam4_path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam4_path.Location = new System.Drawing.Point(9, 290);
            this.Cam4_path.Name = "Cam4_path";
            this.Cam4_path.Size = new System.Drawing.Size(201, 23);
            this.Cam4_path.TabIndex = 80;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(13, 228);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(134, 16);
            this.label66.TabIndex = 74;
            this.label66.Text = "CSV File Save Path";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(16, 416);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(83, 37);
            this.button5.TabIndex = 73;
            this.button5.Text = "Start";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(127, 416);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(83, 37);
            this.button6.TabIndex = 72;
            this.button6.Text = "Stop";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // CCD4count
            // 
            this.CCD4count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD4count.Location = new System.Drawing.Point(156, 161);
            this.CCD4count.Name = "CCD4count";
            this.CCD4count.Size = new System.Drawing.Size(63, 23);
            this.CCD4count.TabIndex = 15;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(25, 164);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(93, 16);
            this.label67.TabIndex = 14;
            this.label67.Text = "No of Counts";
            // 
            // grpboxCamera
            // 
            this.grpboxCamera.BackColor = System.Drawing.Color.WhiteSmoke;
            this.grpboxCamera.Controls.Add(this.chkCCD5);
            this.grpboxCamera.Controls.Add(this.chkCCD4);
            this.grpboxCamera.Controls.Add(this.chkCCD3);
            this.grpboxCamera.Controls.Add(this.chkCCD1);
            this.grpboxCamera.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxCamera.Location = new System.Drawing.Point(13, 17);
            this.grpboxCamera.Name = "grpboxCamera";
            this.grpboxCamera.Size = new System.Drawing.Size(365, 78);
            this.grpboxCamera.TabIndex = 86;
            this.grpboxCamera.TabStop = false;
            this.grpboxCamera.Text = "Choose Camera";
            this.grpboxCamera.Enter += new System.EventHandler(this.grpboxCamera_Enter);
         
            // 
            // chkCCD1
            // 
            this.chkCCD1.AutoSize = true;
            this.chkCCD1.Location = new System.Drawing.Point(31, 36);
            this.chkCCD1.Name = "chkCCD1";
            this.chkCCD1.Size = new System.Drawing.Size(66, 20);
            this.chkCCD1.TabIndex = 87;
            this.chkCCD1.Text = "CCD 1";
            this.chkCCD1.UseVisualStyleBackColor = true;
            this.chkCCD1.CheckedChanged += new System.EventHandler(this.chkCCD1_CheckedChanged);
            // 
            // Static_timer
            // 
            this.Static_timer.Tick += new System.EventHandler(this.Static_timer_Tick);
            // 
            // Dyanamic_timer
            // 
            this.Dyanamic_timer.Tick += new System.EventHandler(this.Dyanamic_timer_Tick);
            // 
            // sop_sequence
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1386, 788);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 215);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimizeBox = false;
            this.Name = "sop_sequence";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "sop_sequence";
            this.Load += new System.EventHandler(this.sop_sequence_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.sop_sequence_MouseMove);
            this.panel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpboxCamera.ResumeLayout(false);
            this.grpboxCamera.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.GroupBox grpboxCamera;
        private System.Windows.Forms.CheckBox chkCCD3;
        private System.Windows.Forms.CheckBox chkCCD1;
        private System.Windows.Forms.Timer Static_timer;
        private System.Windows.Forms.Timer Dyanamic_timer;
        private System.Windows.Forms.CheckBox chkCCD5;
        private System.Windows.Forms.CheckBox chkCCD4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox Cam5__path;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox CCD5count;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox CCD5Speed;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox Cam4_path;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox CCD4count;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txttriggerpos;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox txtonflyintervel;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Cam3_path;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox CCD3count;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox Cam1_path;
        private System.Windows.Forms.Label lblactualpos_ccd1_y;
        private System.Windows.Forms.Label lblactualpos_ccd1_x;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox CCD1count;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox CCD1Speed;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label lblRunningCount;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.ComboBox cmbTestMode;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox CCD5TestMode;
        private System.Windows.Forms.Label label76;
    }
}