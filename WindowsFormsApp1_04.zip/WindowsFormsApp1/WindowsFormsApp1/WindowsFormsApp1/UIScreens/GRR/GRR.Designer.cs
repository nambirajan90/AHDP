﻿
namespace AHDP.UIScreens.GRR
{
    partial class GRR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbllivealarm = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gridControl2 = new System.Windows.Forms.DataGridView();
            this.GRR1 = new System.Windows.Forms.DataGridView();
            this.gridControl3 = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_X_Gap_N1 = new System.Windows.Forms.TextBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.gridControl1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSaveAs = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GRR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl3)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbllivealarm
            // 
            this.lbllivealarm.AutoSize = true;
            this.lbllivealarm.BackColor = System.Drawing.Color.Transparent;
            this.lbllivealarm.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.lbllivealarm.Location = new System.Drawing.Point(737, 9);
            this.lbllivealarm.Name = "lbllivealarm";
            this.lbllivealarm.Size = new System.Drawing.Size(64, 26);
            this.lbllivealarm.TabIndex = 45;
            this.lbllivealarm.Text = "GRR";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.gridControl2);
            this.panel1.Controls.Add(this.GRR1);
            this.panel1.Controls.Add(this.gridControl3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.txt_X_Gap_N1);
            this.panel1.Controls.Add(this.comboBox6);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Location = new System.Drawing.Point(28, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(839, 645);
            this.panel1.TabIndex = 46;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // gridControl2
            // 
            this.gridControl2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridControl2.Location = new System.Drawing.Point(15, 347);
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.Size = new System.Drawing.Size(811, 288);
            this.gridControl2.TabIndex = 98;
            // 
            // GRR1
            // 
            this.GRR1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GRR1.Location = new System.Drawing.Point(275, 52);
            this.GRR1.Name = "GRR1";
            this.GRR1.Size = new System.Drawing.Size(551, 289);
            this.GRR1.TabIndex = 97;
            // 
            // gridControl3
            // 
            this.gridControl3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridControl3.Location = new System.Drawing.Point(15, 52);
            this.gridControl3.Name = "gridControl3";
            this.gridControl3.Size = new System.Drawing.Size(254, 289);
            this.gridControl3.TabIndex = 96;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button2.Location = new System.Drawing.Point(663, 18);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 28);
            this.button2.TabIndex = 95;
            this.button2.Text = "Chart";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.Location = new System.Drawing.Point(529, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 28);
            this.button1.TabIndex = 94;
            this.button1.Text = "Load File";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_X_Gap_N1
            // 
            this.txt_X_Gap_N1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_X_Gap_N1.Location = new System.Drawing.Point(272, 18);
            this.txt_X_Gap_N1.Name = "txt_X_Gap_N1";
            this.txt_X_Gap_N1.Size = new System.Drawing.Size(227, 26);
            this.txt_X_Gap_N1.TabIndex = 86;
            this.txt_X_Gap_N1.TextChanged += new System.EventHandler(this.txt_X_Gap_N1_TextChanged);
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "5",
            "10",
            "20",
            "30",
            "40",
            "50"});
            this.comboBox6.Location = new System.Drawing.Point(104, 18);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(132, 21);
            this.comboBox6.TabIndex = 85;
            this.comboBox6.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(44, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 14);
            this.label17.TabIndex = 84;
            this.label17.Text = "Type";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel2.Controls.Add(this.gridControl1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnSaveAs);
            this.panel2.Controls.Add(this.btnEdit);
            this.panel2.Location = new System.Drawing.Point(891, 48);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(674, 645);
            this.panel2.TabIndex = 47;
            // 
            // gridControl1
            // 
            this.gridControl1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridControl1.Location = new System.Drawing.Point(12, 70);
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(648, 490);
            this.gridControl1.TabIndex = 65;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Verdana", 16F);
            this.label1.Location = new System.Drawing.Point(194, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 26);
            this.label1.TabIndex = 64;
            this.label1.Text = "Specification Limits";
            // 
            // btnSaveAs
            // 
            this.btnSaveAs.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnSaveAs.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Save;
            this.btnSaveAs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSaveAs.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveAs.Location = new System.Drawing.Point(562, 576);
            this.btnSaveAs.Name = "btnSaveAs";
            this.btnSaveAs.Size = new System.Drawing.Size(61, 56);
            this.btnSaveAs.TabIndex = 63;
            this.btnSaveAs.Text = "Save As";
            this.btnSaveAs.UseVisualStyleBackColor = false;
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnEdit.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Edit3;
            this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEdit.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(484, 576);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(61, 56);
            this.btnEdit.TabIndex = 57;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = false;
            // 
            // GRR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbllivealarm);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 248);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimizeBox = false;
            this.Name = "GRR";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "GRR";
            this.Load += new System.EventHandler(this.GRR_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GRR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbllivealarm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.TextBox txt_X_Gap_N1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnEdit; // Converted from DevExpress SimpleButton
        private System.Windows.Forms.Button btnSaveAs; // Converted from DevExpress SimpleButton
        //private System.Windows.Forms.DataGridView gridControl1; // Converted from DevExpress GridControl
        //private System.Windows.Forms.DataGridView gridControl2; // Converted from DevExpress GridControl
        //private System.Windows.Forms.DataGridView gridControl3; // Converted from DevExpress GridControl
        //private System.Windows.Forms.DataGridView GRR1; // Converted from DevExpress GridControl
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView gridControl3;
        private System.Windows.Forms.DataGridView GRR1;
        private System.Windows.Forms.DataGridView gridControl2;
        private System.Windows.Forms.DataGridView gridControl1;
    }
}