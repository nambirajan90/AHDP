﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace AHDP.UIScreens.User
{
    public partial class User : Form
    {
        private System.Windows.Forms.DialogResult dialogResult;

        public User()
        {
            InitializeComponent();
            cmbModelName.DropDown += cmbModelName_DropDown;
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void User_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private async void cmbModelName_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Added//
            //await Task.Delay(1000); // Example asynchronous operation
            //MessageBox.Show("Index changed after 1 second delay.");

        }

        private async void cmbModelName_DropDown(object sender, EventArgs e)
        {
            cmbModelName.Items.Clear();
            // Make sure an item is selected in Modeselection
            if (Modeselection.SelectedItem == null)
            {
                MessageBox.Show("Please select a mode first.");
                return;
            }

            string connectionString = SQLHelper.get_ConnName();
            string modeselection = Modeselection.SelectedItem.ToString();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_User_details", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Mode", modeselection);

                    try
                    {
                        // Open the connection
                        await conn.OpenAsync();

                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            // Clear existing items
                            //cmbModelName.Items.Clear();

                            // Check if there are any rows
                            if (!reader.HasRows)
                            {
                                MessageBox.Show("No users found in the database.");
                                return;
                            }

                            // Populate ComboBox
                            while (await reader.ReadAsync())
                            {
                                cmbModelName.Items.Add(reader["Username"].ToString());
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading data: " + ex.Message);
                    }
                }
            }
        }


        private void sbNew_Click(object sender, EventArgs e)
        {
            Form formBackground = new Form();
            try
            {
                formBackground.StartPosition = FormStartPosition.Manual;
                formBackground.Opacity = 0.70d;
                //formBackground.BackColor = Color.White;
                formBackground.WindowState = FormWindowState.Maximized;
                //formBackground.TopMost = true;
                formBackground.Location = this.Location;
                formBackground.ShowInTaskbar = false;
                formBackground.Show();

                using (Adduser add = new Adduser())
                {
                    add.Owner = formBackground;
                    add.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                formBackground.Dispose();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string selectedItem = cmbModelName.SelectedItem?.ToString();
            string Mode = Modeselection.SelectedItem?.ToString();

            // Ensure that an item is selected
            if (!string.IsNullOrEmpty(selectedItem))
            {
                // Display confirmation dialog for deletion
                System.Windows.Forms.DialogResult dialogResult = MessageBox.Show(
                    "Are you sure you want to delete this user?",
                    "Confirmation Box",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                // If user clicks "Yes", proceed with the deletion
                if (dialogResult == System.Windows.Forms.DialogResult.Yes)
                {
                    try
                    {
                        string connectionString = SQLHelper.get_ConnName();

                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Call stored procedure to delete the user
                            using (SqlCommand command = new SqlCommand("SP_User_Delete", connection))
                            {
                                command.CommandType = System.Data.CommandType.StoredProcedure;
                                command.Parameters.AddWithValue("@Mode", Mode);
                                command.Parameters.AddWithValue("@user", selectedItem);

                                connection.Open();
                                command.ExecuteNonQuery();

                                MessageBox.Show("User deleted successfully!");

                                // Clear the combo box items after deletion
                                cmbModelName.Items.Clear();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
            else
            {
                // Inform the user if no item is selected
                MessageBox.Show("Please select an item to delete.");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string selectedItem = cmbModelName.SelectedItem?.ToString();

            if (!string.IsNullOrEmpty(selectedItem))
            {
                Form formEdit = new Form();
                try
                {
                    formEdit.StartPosition = FormStartPosition.Manual;
                    formEdit.Opacity = 0.70d;
                    formEdit.WindowState = FormWindowState.Maximized;
                    formEdit.Location = this.Location;
                    formEdit.ShowInTaskbar = false;
                    formEdit.Show();

                    using (Updateuser Update = new Updateuser())
                    {
                        Update.SetUsername(selectedItem);
                        Update.Owner = formEdit;
                        Update.ShowDialog();


                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    formEdit.Dispose();
                }
            }
            else
            {
                MessageBox.Show("Please select an item to Update.");
            }


        }

        private void Modeselection_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
