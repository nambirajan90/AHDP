﻿
namespace AHDP.UIScreens.User
{
    partial class Updateuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.edit = new System.Windows.Forms.Button();
            this.Password = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.User = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.updatemode = new System.Windows.Forms.ComboBox();
            this.Mode = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // edit
            // 
            this.edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.edit.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edit.ForeColor = System.Drawing.Color.White;
            this.edit.Location = new System.Drawing.Point(96, 162);
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(100, 31);
            this.edit.TabIndex = 5;
            this.edit.Text = "UPDATE";
            this.edit.UseVisualStyleBackColor = false;
            this.edit.Click += new System.EventHandler(this.button1_Click);
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(102, 122);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(147, 21);
            this.Password.TabIndex = 9;
            this.Password.UseSystemPasswordChar = true;
            this.Password.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 23);
            this.label2.TabIndex = 8;
            this.label2.Text = "Password";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // User
            // 
            this.User.Location = new System.Drawing.Point(102, 78);
            this.User.Name = "User";
            this.User.Size = new System.Drawing.Size(147, 21);
            this.User.TabIndex = 7;
            this.User.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 23);
            this.label1.TabIndex = 6;
            this.label1.Text = "Username";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(220, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Max 10 char";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // updatemode
            // 
            this.updatemode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.updatemode.FormattingEnabled = true;
            this.updatemode.Items.AddRange(new object[] {
            "Production",
            "Engineer",
            "CPK/GRR"});
            this.updatemode.Location = new System.Drawing.Point(104, 37);
            this.updatemode.Name = "updatemode";
            this.updatemode.Size = new System.Drawing.Size(147, 21);
            this.updatemode.TabIndex = 12;
            this.updatemode.SelectedIndexChanged += new System.EventHandler(this.updatemode_SelectedIndexChanged);
            // 
            // Mode
            // 
            this.Mode.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mode.Location = new System.Drawing.Point(1, 37);
            this.Mode.Name = "Mode";
            this.Mode.Size = new System.Drawing.Size(84, 23);
            this.Mode.TabIndex = 11;
            this.Mode.Text = "Mode";
            this.Mode.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Mode.Click += new System.EventHandler(this.Mode_Click);
            // 
            // Updateuser
            // 
            //this.Appearance.BackColor = System.Drawing.Color.Gainsboro;
            //this.Appearance.Options.UseBackColor = true;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(298, 205);
            this.Controls.Add(this.updatemode);
            this.Controls.Add(this.Mode);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.User);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.edit);
            //this.FormBorderEffect = DevExpress.XtraEditors.FormBorderEffect.None;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Updateuser";
            this.Text = "Updateuser";
            this.Load += new System.EventHandler(this.Updateuser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button edit;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox User;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox updatemode;
        private System.Windows.Forms.Label Mode;
    }
}