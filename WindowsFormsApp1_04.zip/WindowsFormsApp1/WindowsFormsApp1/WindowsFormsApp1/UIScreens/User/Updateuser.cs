﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP.UIScreens.User
{
    public partial class Updateuser : Form
    {
        public Updateuser()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mode = updatemode.Text;
            string Username = User.Text;
            string password = Password.Text;
            if (string.IsNullOrEmpty(mode))
            {
                MessageBox.Show("Please enter Mode.");
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter Password.");
                return;
            }
            //string connectionString = "Server=TCLHSRPEDLT0737;Database=AHDP;User Id=sa;Password=Titan@123;";
            string connectionString = SQLHelper.get_ConnName();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("SP_User_Update", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Mode", mode);
                    command.Parameters.AddWithValue("@username", Username);
                    command.Parameters.AddWithValue("@Password", password);
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("User Details Updated successfully!");
                        User.Text = string.Empty;
                        Password.Text = string.Empty;
                        updatemode.Items.Clear();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void Updateuser_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            User.ReadOnly = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string password = Password.Text;
            if (password.Length > 10)
            {
                MessageBox.Show("Maximum 10 Charcter Allowed");
                return;
            }
        }

        public void SetUsername(string username)
        {
            User.Text = username; // Assuming txtUsername is your textbox for the username
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Mode_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void updatemode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
