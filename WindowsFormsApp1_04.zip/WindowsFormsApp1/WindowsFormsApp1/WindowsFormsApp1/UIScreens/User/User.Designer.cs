﻿
namespace AHDP.UIScreens.User
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.Modeselection = new System.Windows.Forms.ComboBox();
            this.cmbModelName = new System.Windows.Forms.ComboBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.sbNew = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.Controls.Add(this.Modeselection);
            this.panel2.Controls.Add(this.cmbModelName);
            this.panel2.Controls.Add(this.btnDelete);
            this.panel2.Controls.Add(this.btnEdit);
            this.panel2.Controls.Add(this.sbNew);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Location = new System.Drawing.Point(634, 209);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(330, 247);
            this.panel2.TabIndex = 63;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // Modeselection
            // 
            this.Modeselection.DropDownHeight = 130;
            this.Modeselection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Modeselection.DropDownWidth = 190;
            this.Modeselection.FormattingEnabled = true;
            this.Modeselection.IntegralHeight = false;
            this.Modeselection.Items.AddRange(new object[] {
            "Production",
            "Engineer",
            "CPK/GRR"});
            this.Modeselection.Location = new System.Drawing.Point(79, 74);
            this.Modeselection.Name = "Modeselection";
            this.Modeselection.Size = new System.Drawing.Size(176, 21);
            this.Modeselection.TabIndex = 62;
            this.Modeselection.SelectedIndexChanged += new System.EventHandler(this.Modeselection_SelectedIndexChanged);
            // 
            // cmbModelName
            // 
            this.cmbModelName.DropDownHeight = 130;
            this.cmbModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbModelName.DropDownWidth = 190;
            this.cmbModelName.FormattingEnabled = true;
            this.cmbModelName.IntegralHeight = false;
            this.cmbModelName.Location = new System.Drawing.Point(79, 101);
            this.cmbModelName.Name = "cmbModelName";
            this.cmbModelName.Size = new System.Drawing.Size(176, 21);
            this.cmbModelName.TabIndex = 61;
            this.cmbModelName.SelectedIndexChanged += new System.EventHandler(this.cmbModelName_SelectedIndexChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnDelete.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Delete2;
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(238, 140);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(64, 63);
            this.btnDelete.TabIndex = 58;
            this.btnDelete.Text = "Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnEdit.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Edit2;
            this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(141, 140);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(64, 63);
            this.btnEdit.TabIndex = 56;
            this.btnEdit.Text = "Edit";
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEdit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // sbNew
            // 
            this.sbNew.BackColor = System.Drawing.SystemColors.ControlLight;
            this.sbNew.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.New3;
            this.sbNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.sbNew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sbNew.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sbNew.Location = new System.Drawing.Point(38, 140);
            this.sbNew.Name = "sbNew";
            this.sbNew.Size = new System.Drawing.Size(64, 63);
            this.sbNew.TabIndex = 55;
            this.sbNew.Text = "New";
            this.sbNew.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.sbNew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.sbNew.UseVisualStyleBackColor = false;
            this.sbNew.Click += new System.EventHandler(this.sbNew_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.LightGray;
            this.label18.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(122, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(82, 26);
            this.label18.TabIndex = 53;
            this.label18.Text = "Users";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 248);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimizeBox = false;
            this.Name = "User";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "User";
            this.Load += new System.EventHandler(this.User_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.ComboBox cmbModelName;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button sbNew;
        public System.Windows.Forms.ComboBox Modeselection;
    }
}