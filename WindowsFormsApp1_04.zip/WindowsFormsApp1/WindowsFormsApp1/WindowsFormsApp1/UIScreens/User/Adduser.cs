﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP.UIScreens.User
{
    public partial class Adduser : Form
    {
        public Adduser()
        {
            InitializeComponent();
        }

        private void Adduser_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            if (username.Length > 10)
            {
                //MessageBox.Show("Maximum Letter Exceeds");
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Mode = comboBox1.Text;
            string username = textBox1.Text;
            string password = textBox2.Text; // Assume textBox2 is for the password

            // Validate inputs
            if (string.IsNullOrEmpty(Mode))
            {
                MessageBox.Show("Please enter Mode.");
                return;
            }
            if (string.IsNullOrEmpty(username))
            {
                MessageBox.Show("Please enter Username.");
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter Password.");
                return;
            }
            // string connectionString = "Server=TCLHSRPEDLT0737;Database=AHDP;User Id=sa;Password=Titan@123;";
            string connectionString = SQLHelper.get_ConnName();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand("SP_User_Add", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Level", Mode);
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("User added successfully!");
                        comboBox1.Items.Clear();
                        textBox1.Clear();
                        textBox2.Clear();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("User Already Exists");
                    }
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string password = textBox2.Text;
            if (password.Length > 10)
            {
                MessageBox.Show("Maximum 10 Charcter Allowed");
                return;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Mode_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
