﻿using System;
namespace AHDP
{
    partial class calibration_settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLoadCell_Stop = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLoadCell_Start = new System.Windows.Forms.Button();
            this.cmbloadcell_Mode = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.CameraConnectionSts = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.RecivedDataCamera = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxDelay = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.FirstCam = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Robo_Disconnect = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.RecieveDataRobo = new System.Windows.Forms.RichTextBox();
            this.Robo_Trigger = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.Robo_textBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.Robo_comboBox = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Scanner_Delay_textBox = new System.Windows.Forms.TextBox();
            this.Scanner_textBox = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.Scanner_Consts = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.RecieveData_Scanner = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.grpboxCamera = new System.Windows.Forms.GroupBox();
            this.chkCCD5 = new System.Windows.Forms.CheckBox();
            this.chkCCD4 = new System.Windows.Forms.CheckBox();
            this.chkCCD3 = new System.Windows.Forms.CheckBox();
            this.chkCCD1 = new System.Windows.Forms.CheckBox();
            this.richTextBox_Calib = new System.Windows.Forms.RichTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.lblServo_Conn_Status_X = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCamera_Stop = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btnCamera_Start = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpboxCamera.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.btnLoadCell_Stop);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnLoadCell_Start);
            this.groupBox1.Controls.Add(this.cmbloadcell_Mode);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(24, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(401, 176);
            this.groupBox1.TabIndex = 85;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Loadcell";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnLoadCell_Stop
            // 
            this.btnLoadCell_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnLoadCell_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadCell_Stop.ForeColor = System.Drawing.Color.White;
            this.btnLoadCell_Stop.Location = new System.Drawing.Point(200, 110);
            this.btnLoadCell_Stop.Name = "btnLoadCell_Stop";
            this.btnLoadCell_Stop.Size = new System.Drawing.Size(99, 35);
            this.btnLoadCell_Stop.TabIndex = 93;
            this.btnLoadCell_Stop.Text = "Stop";
            this.btnLoadCell_Stop.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(48, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 14);
            this.label1.TabIndex = 93;
            this.label1.Text = "Calibration Mode";
            // 
            // btnLoadCell_Start
            // 
            this.btnLoadCell_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnLoadCell_Start.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadCell_Start.ForeColor = System.Drawing.Color.White;
            this.btnLoadCell_Start.Location = new System.Drawing.Point(51, 110);
            this.btnLoadCell_Start.Name = "btnLoadCell_Start";
            this.btnLoadCell_Start.Size = new System.Drawing.Size(99, 35);
            this.btnLoadCell_Start.TabIndex = 92;
            this.btnLoadCell_Start.Text = "Start";
            this.btnLoadCell_Start.UseVisualStyleBackColor = false;
            // 
            // cmbloadcell_Mode
            // 
            this.cmbloadcell_Mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbloadcell_Mode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbloadcell_Mode.FormattingEnabled = true;
            this.cmbloadcell_Mode.Items.AddRange(new object[] {
            "--Select--"});
            this.cmbloadcell_Mode.Location = new System.Drawing.Point(200, 54);
            this.cmbloadcell_Mode.Name = "cmbloadcell_Mode";
            this.cmbloadcell_Mode.Size = new System.Drawing.Size(118, 24);
            this.cmbloadcell_Mode.TabIndex = 92;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.CameraConnectionSts);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.RecivedDataCamera);
            this.groupBox4.Controls.Add(this.button2);
            this.groupBox4.Controls.Add(this.button1);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.textBoxDelay);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.comboBox1);
            this.groupBox4.Controls.Add(this.FirstCam);
            this.groupBox4.Controls.Add(this.button6);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(450, 25);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(365, 305);
            this.groupBox4.TabIndex = 150;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "For Manual Trigger command";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(23, 264);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 35);
            this.button3.TabIndex = 152;
            this.button3.Text = "Disconnect";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // CameraConnectionSts
            // 
            this.CameraConnectionSts.BackColor = System.Drawing.Color.Maroon;
            this.CameraConnectionSts.Location = new System.Drawing.Point(282, 87);
            this.CameraConnectionSts.Name = "CameraConnectionSts";
            this.CameraConnectionSts.Size = new System.Drawing.Size(16, 20);
            this.CameraConnectionSts.TabIndex = 152;
            this.CameraConnectionSts.Click += new System.EventHandler(this.CameraConnectionSts_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(143, 87);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 14);
            this.label5.TabIndex = 152;
            this.label5.Text = "Camera Conn Status";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(143, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 14);
            this.label4.TabIndex = 155;
            this.label4.Text = "Received Data";
            // 
            // RecivedDataCamera
            // 
            this.RecivedDataCamera.AccessibleName = "RecivedDataCamera";
            this.RecivedDataCamera.Location = new System.Drawing.Point(169, 135);
            this.RecivedDataCamera.Name = "RecivedDataCamera";
            this.RecivedDataCamera.Size = new System.Drawing.Size(165, 67);
            this.RecivedDataCamera.TabIndex = 154;
            this.RecivedDataCamera.Text = "";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(23, 87);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 35);
            this.button2.TabIndex = 153;
            this.button2.Text = "5th cam";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(23, 135);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 35);
            this.button1.TabIndex = 152;
            this.button1.Text = "4th cam";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(143, 222);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 14);
            this.label8.TabIndex = 151;
            this.label8.Text = "Trigger Delay Time";
            // 
            // textBoxDelay
            // 
            this.textBoxDelay.Enabled = false;
            this.textBoxDelay.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDelay.Location = new System.Drawing.Point(268, 217);
            this.textBoxDelay.Name = "textBoxDelay";
            this.textBoxDelay.Size = new System.Drawing.Size(66, 26);
            this.textBoxDelay.TabIndex = 150;
            this.textBoxDelay.TextChanged += new System.EventHandler(this.textBoxDelay_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(150, 14);
            this.label7.TabIndex = 147;
            this.label7.Text = "Select Triggercommand";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Verdana", 11.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(9, 52);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(337, 26);
            this.comboBox1.TabIndex = 86;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // FirstCam
            // 
            this.FirstCam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.FirstCam.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstCam.ForeColor = System.Drawing.Color.White;
            this.FirstCam.Location = new System.Drawing.Point(23, 217);
            this.FirstCam.Name = "FirstCam";
            this.FirstCam.Size = new System.Drawing.Size(99, 35);
            this.FirstCam.TabIndex = 144;
            this.FirstCam.Text = "1st Cam";
            this.FirstCam.UseVisualStyleBackColor = false;
            this.FirstCam.Click += new System.EventHandler(this.FirstCam_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(23, 174);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(99, 35);
            this.button6.TabIndex = 145;
            this.button6.Text = "3rd cam";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.groupBox5);
            this.panel3.Controls.Add(this.groupBox3);
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Controls.Add(this.groupBox4);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Location = new System.Drawing.Point(12, 34);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1588, 659);
            this.panel3.TabIndex = 5;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox5.Controls.Add(this.Robo_Disconnect);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.RecieveDataRobo);
            this.groupBox5.Controls.Add(this.Robo_Trigger);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.Robo_textBox);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.Robo_comboBox);
            this.groupBox5.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold);
            this.groupBox5.Location = new System.Drawing.Point(1192, 25);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(365, 305);
            this.groupBox5.TabIndex = 156;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Robot";
            // 
            // Robo_Disconnect
            // 
            this.Robo_Disconnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Robo_Disconnect.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Robo_Disconnect.ForeColor = System.Drawing.Color.White;
            this.Robo_Disconnect.Location = new System.Drawing.Point(23, 141);
            this.Robo_Disconnect.Name = "Robo_Disconnect";
            this.Robo_Disconnect.Size = new System.Drawing.Size(99, 35);
            this.Robo_Disconnect.TabIndex = 152;
            this.Robo_Disconnect.Text = "Disconnect";
            this.Robo_Disconnect.UseVisualStyleBackColor = false;
            this.Robo_Disconnect.Click += new System.EventHandler(this.Robo_Disconnect_Click);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Maroon;
            this.label13.Location = new System.Drawing.Point(282, 87);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 20);
            this.label13.TabIndex = 152;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(143, 87);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(127, 14);
            this.label14.TabIndex = 152;
            this.label14.Text = "Robot Conn Status";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(143, 110);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(94, 14);
            this.label15.TabIndex = 155;
            this.label15.Text = "Received Data";
            // 
            // RecieveDataRobo
            // 
            this.RecieveDataRobo.AccessibleName = "";
            this.RecieveDataRobo.Location = new System.Drawing.Point(146, 135);
            this.RecieveDataRobo.Name = "RecieveDataRobo";
            this.RecieveDataRobo.ReadOnly = true;
            this.RecieveDataRobo.Size = new System.Drawing.Size(188, 67);
            this.RecieveDataRobo.TabIndex = 154;
            this.RecieveDataRobo.Text = "";
            // 
            // Robo_Trigger
            // 
            this.Robo_Trigger.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Robo_Trigger.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Robo_Trigger.ForeColor = System.Drawing.Color.White;
            this.Robo_Trigger.Location = new System.Drawing.Point(23, 87);
            this.Robo_Trigger.Name = "Robo_Trigger";
            this.Robo_Trigger.Size = new System.Drawing.Size(99, 35);
            this.Robo_Trigger.TabIndex = 153;
            this.Robo_Trigger.Text = "Trigger";
            this.Robo_Trigger.UseVisualStyleBackColor = false;
            this.Robo_Trigger.Click += new System.EventHandler(this.Robo_Trigger_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(143, 222);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(119, 14);
            this.label16.TabIndex = 151;
            this.label16.Text = "Trigger Delay Time";
            // 
            // Robo_textBox
            // 
            this.Robo_textBox.Enabled = false;
            this.Robo_textBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Robo_textBox.Location = new System.Drawing.Point(268, 217);
            this.Robo_textBox.Name = "Robo_textBox";
            this.Robo_textBox.Size = new System.Drawing.Size(66, 26);
            this.Robo_textBox.TabIndex = 150;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 32);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(150, 14);
            this.label17.TabIndex = 147;
            this.label17.Text = "Select Triggercommand";
            // 
            // Robo_comboBox
            // 
            this.Robo_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Robo_comboBox.Font = new System.Drawing.Font("Verdana", 11.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Robo_comboBox.FormattingEnabled = true;
            this.Robo_comboBox.Location = new System.Drawing.Point(9, 52);
            this.Robo_comboBox.Name = "Robo_comboBox";
            this.Robo_comboBox.Size = new System.Drawing.Size(337, 26);
            this.Robo_comboBox.TabIndex = 86;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox3.Controls.Add(this.Scanner_Delay_textBox);
            this.groupBox3.Controls.Add(this.Scanner_textBox);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.Scanner_Consts);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.RecieveData_Scanner);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.button8);
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(821, 25);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(365, 305);
            this.groupBox3.TabIndex = 152;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Scanner";
            // 
            // Scanner_Delay_textBox
            // 
            this.Scanner_Delay_textBox.Location = new System.Drawing.Point(146, 218);
            this.Scanner_Delay_textBox.Name = "Scanner_Delay_textBox";
            this.Scanner_Delay_textBox.Size = new System.Drawing.Size(188, 31);
            this.Scanner_Delay_textBox.TabIndex = 157;
            // 
            // Scanner_textBox
            // 
            this.Scanner_textBox.Location = new System.Drawing.Point(20, 41);
            this.Scanner_textBox.Name = "Scanner_textBox";
            this.Scanner_textBox.Size = new System.Drawing.Size(326, 31);
            this.Scanner_textBox.TabIndex = 156;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(20, 110);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(99, 35);
            this.button4.TabIndex = 152;
            this.button4.Text = "Connect";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // Scanner_Consts
            // 
            this.Scanner_Consts.BackColor = System.Drawing.Color.Maroon;
            this.Scanner_Consts.Location = new System.Drawing.Point(282, 87);
            this.Scanner_Consts.Name = "Scanner_Consts";
            this.Scanner_Consts.Size = new System.Drawing.Size(16, 20);
            this.Scanner_Consts.TabIndex = 152;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(143, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 14);
            this.label9.TabIndex = 152;
            this.label9.Text = "Scanner Conn Status";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(143, 110);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 14);
            this.label10.TabIndex = 155;
            this.label10.Text = "Received Data";
            // 
            // RecieveData_Scanner
            // 
            this.RecieveData_Scanner.AccessibleName = "";
            this.RecieveData_Scanner.Location = new System.Drawing.Point(146, 135);
            this.RecieveData_Scanner.Name = "RecieveData_Scanner";
            this.RecieveData_Scanner.ReadOnly = true;
            this.RecieveData_Scanner.Size = new System.Drawing.Size(188, 67);
            this.RecieveData_Scanner.TabIndex = 154;
            this.RecieveData_Scanner.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(17, 222);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 14);
            this.label11.TabIndex = 151;
            this.label11.Text = "Trigger Delay Time";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(20, 151);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(99, 35);
            this.button8.TabIndex = 144;
            this.button8.Text = "Trigger";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.grpboxCamera);
            this.groupBox2.Controls.Add(this.richTextBox_Calib);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.lblServo_Conn_Status_X);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnCamera_Stop);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.btnCamera_Start);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(24, 362);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1533, 278);
            this.groupBox2.TabIndex = 151;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Camera";
            // 
            // grpboxCamera
            // 
            this.grpboxCamera.BackColor = System.Drawing.Color.WhiteSmoke;
            this.grpboxCamera.Controls.Add(this.chkCCD5);
            this.grpboxCamera.Controls.Add(this.chkCCD4);
            this.grpboxCamera.Controls.Add(this.chkCCD3);
            this.grpboxCamera.Controls.Add(this.chkCCD1);
            this.grpboxCamera.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxCamera.Location = new System.Drawing.Point(31, 157);
            this.grpboxCamera.Name = "grpboxCamera";
            this.grpboxCamera.Size = new System.Drawing.Size(365, 51);
            this.grpboxCamera.TabIndex = 152;
            this.grpboxCamera.TabStop = false;
            this.grpboxCamera.Text = "Choose Camera";
            // 
            // chkCCD5
            // 
            this.chkCCD5.AutoSize = true;
            this.chkCCD5.Location = new System.Drawing.Point(280, 22);
            this.chkCCD5.Name = "chkCCD5";
            this.chkCCD5.Size = new System.Drawing.Size(67, 20);
            this.chkCCD5.TabIndex = 90;
            this.chkCCD5.Text = "CCD 5";
            this.chkCCD5.UseVisualStyleBackColor = true;
           // this.chkCCD5.CheckedChanged += new System.EventHandler(this.chkCCD5_CheckedChanged);
            // 
            // chkCCD4
            // 
            this.chkCCD4.AutoSize = true;
            this.chkCCD4.Location = new System.Drawing.Point(207, 22);
            this.chkCCD4.Name = "chkCCD4";
            this.chkCCD4.Size = new System.Drawing.Size(67, 20);
            this.chkCCD4.TabIndex = 89;
            this.chkCCD4.Text = "CCD 4";
            this.chkCCD4.UseVisualStyleBackColor = true;
           // this.chkCCD4.CheckedChanged += new System.EventHandler(this.chkCCD4_CheckedChanged);
            // 
            // chkCCD3
            // 
            this.chkCCD3.AutoSize = true;
            this.chkCCD3.Location = new System.Drawing.Point(115, 22);
            this.chkCCD3.Name = "chkCCD3";
            this.chkCCD3.Size = new System.Drawing.Size(67, 20);
            this.chkCCD3.TabIndex = 88;
            this.chkCCD3.Text = "CCD 3";
            this.chkCCD3.UseVisualStyleBackColor = true;
           // this.chkCCD3.CheckedChanged += new System.EventHandler(this.chkCCD3_CheckedChanged);
            // 
            // chkCCD1
            // 
            this.chkCCD1.AutoSize = true;
            this.chkCCD1.Location = new System.Drawing.Point(28, 22);
            this.chkCCD1.Name = "chkCCD1";
            this.chkCCD1.Size = new System.Drawing.Size(67, 20);
            this.chkCCD1.TabIndex = 87;
            this.chkCCD1.Text = "CCD 1";
            this.chkCCD1.UseVisualStyleBackColor = true;
            this.chkCCD1.CheckedChanged += new System.EventHandler(this.chkCCD1_CheckedChanged_1);
            // 
            // richTextBox_Calib
            // 
            this.richTextBox_Calib.Location = new System.Drawing.Point(529, 45);
            this.richTextBox_Calib.Name = "richTextBox_Calib";
            this.richTextBox_Calib.Size = new System.Drawing.Size(985, 216);
            this.richTextBox_Calib.TabIndex = 144;
            this.richTextBox_Calib.Text = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(28, 45);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(133, 14);
            this.label21.TabIndex = 60;
            this.label21.Text = "Camera Conn Status";
            // 
            // lblServo_Conn_Status_X
            // 
            this.lblServo_Conn_Status_X.BackColor = System.Drawing.Color.Maroon;
            this.lblServo_Conn_Status_X.Location = new System.Drawing.Point(198, 38);
            this.lblServo_Conn_Status_X.Name = "lblServo_Conn_Status_X";
            this.lblServo_Conn_Status_X.Size = new System.Drawing.Size(26, 26);
            this.lblServo_Conn_Status_X.TabIndex = 61;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 14);
            this.label3.TabIndex = 85;
            this.label3.Text = "Running Steps";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 14);
            this.label2.TabIndex = 143;
            this.label2.Text = "Vision Calibration :";
            // 
            // btnCamera_Stop
            // 
            this.btnCamera_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnCamera_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamera_Stop.ForeColor = System.Drawing.Color.White;
            this.btnCamera_Stop.Location = new System.Drawing.Point(202, 226);
            this.btnCamera_Stop.Name = "btnCamera_Stop";
            this.btnCamera_Stop.Size = new System.Drawing.Size(99, 35);
            this.btnCamera_Stop.TabIndex = 90;
            this.btnCamera_Stop.Text = "Stop";
            this.btnCamera_Stop.UseVisualStyleBackColor = false;
            this.btnCamera_Stop.Click += new System.EventHandler(this.btnCamera_Stop_Click);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(189, 79);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(119, 26);
            this.textBox4.TabIndex = 142;
            // 
            // btnCamera_Start
            // 
            this.btnCamera_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnCamera_Start.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamera_Start.ForeColor = System.Drawing.Color.White;
            this.btnCamera_Start.Location = new System.Drawing.Point(27, 226);
            this.btnCamera_Start.Name = "btnCamera_Start";
            this.btnCamera_Start.Size = new System.Drawing.Size(99, 35);
            this.btnCamera_Start.TabIndex = 89;
            this.btnCamera_Start.Text = "Start";
            this.btnCamera_Start.UseVisualStyleBackColor = false;
            this.btnCamera_Start.Click += new System.EventHandler(this.btnCamera_Start_Click);
            // 
            // calibration_settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1386, 788);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 248);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimizeBox = false;
            this.Name = "calibration_settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "calibration_settings";
            this.Load += new System.EventHandler(this.calibration_settings_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.calibration_settings_MouseMove);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpboxCamera.ResumeLayout(false);
            this.grpboxCamera.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLoadCell_Stop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLoadCell_Start;
        private System.Windows.Forms.ComboBox cmbloadcell_Mode;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox textBoxDelay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button FirstCam;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button btnCamera_Stop;
        private System.Windows.Forms.Button btnCamera_Start;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblServo_Conn_Status_X;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox richTextBox_Calib;
        private System.Windows.Forms.GroupBox grpboxCamera;
        private System.Windows.Forms.CheckBox chkCCD5;
        private System.Windows.Forms.CheckBox chkCCD4;
        private System.Windows.Forms.CheckBox chkCCD3;
        private System.Windows.Forms.CheckBox chkCCD1;
        public System.Windows.Forms.RichTextBox RecivedDataCamera;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label CameraConnectionSts;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button Robo_Disconnect;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.RichTextBox RecieveDataRobo;
        private System.Windows.Forms.Label label16;
        public System.Windows.Forms.TextBox Robo_textBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox Robo_comboBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label Scanner_Consts;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.RichTextBox RecieveData_Scanner;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button Robo_Trigger;
        private System.Windows.Forms.TextBox Scanner_textBox;
        private System.Windows.Forms.TextBox Scanner_Delay_textBox;
    }
}