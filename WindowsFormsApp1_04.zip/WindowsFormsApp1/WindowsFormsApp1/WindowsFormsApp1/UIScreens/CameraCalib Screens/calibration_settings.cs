﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Net;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml;

namespace AHDP
{
    public partial class calibration_settings : Form
    {
        public calibration_settings()
        {
            InitializeComponent();

        }
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
   (
       int nLeftRect,
       int nTopRect,
       int nRightRect,
       int nBottomRect,
       int nWidthEllipse,
       int nHeightEllipse
   );

        public void Panel_Shape()
        {
            //panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width,
            //panel1.Height, 30, 30));
            //   panel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel2.Width,
            //panel2.Height, 30, 30));
            panel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel3.Width,
         panel3.Height, 30, 30));
            //panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
            //panel4.Height, 30, 30));
            //   panel5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel5.Width,
            //panel5.Height, 30, 30));
        }
        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void calibration_settings_Load(object sender, EventArgs e)
        {
            textBoxDelay.Text = "300";
            cmbloadcell_Mode.SelectedIndex = 0;

            Panel_Shape();
            //txtLblHomePos.Text = GlobalVar.Gantry_X_HomePos.ToString();
            //txtYhomePos.Text = GlobalVar.Gantry_Y_HomePos.ToString();

            btnCamera_Start.Enabled = true;
            btnCamera_Stop.Enabled = false;
            timer1.Enabled = true;
            loadCalibrationtext_togrid();
            if (Globalvariable.Login_user_mode.ToUpper() == "PRODUCTION")
            {
                panel3.Enabled = false;
            }
            else
            {
                panel3.Enabled = true;
            }
            createDt_and_load_cmb();
            textBoxDelay.Enabled = true;
            read();
            comboBox1.SelectedIndex = 0;
        }

        private void loadCalibrationtext_togrid()
        {
            string calibration_settings_path = Environment.CurrentDirectory + @"\vision_calibration.txt";
            //var textfile = File.ReadAllLines(calibration_settings_path);
            if (File.Exists(calibration_settings_path))
            {
                DataTable dt_calibrationsettings = new DataTable();
                dt_calibrationsettings.Columns.Add("Sno");
                dt_calibrationsettings.Columns.Add("Description");
                dt_calibrationsettings.Columns.Add("Value");
                dt_calibrationsettings.Columns.Add("UOM");
                using (StreamReader file = new StreamReader(calibration_settings_path))
                {
                    int sno_counter = 1;
                    string calibrationValues;

                    while ((calibrationValues = file.ReadLine()) != null)
                    {
                        if (calibrationValues != string.Empty)
                        {
                            dt_calibrationsettings.Rows.Add(sno_counter, calibrationValues.Split(':')[0].ToString(), calibrationValues.Split(':')[1].ToString(), calibrationValues.Split(':')[2].ToString());
                            sno_counter++;
                        }
                    }
                    file.Close();
                }


            }
        }
        public void createDt_and_load_cmb()
        {
            try
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                string selQuery = "select * from Calibration_command";
                ds = SQLHelper.GetData(selQuery);
                dt = ds.Tables[0];
                comboBox1.DataSource = dt;
                comboBox1.DisplayMember = "Cam_UI";
                comboBox1.ValueMember = "Cam_TCPIP";
            }
            catch (Exception es)
            {
                Logger.WriteLog("Vision Calibration", "createDt_and_load_cmb()", "", "Exception Error", es.ToString());
            }


        }
        private void btn_Set_As_Hme_Pos_X_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of X axis and Make sure that X axis in Pin condition ", "Confirmation Box", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {

                //Interface.Set_Zero_Pos(GlobalVar.Gantry_X_axis);
                //Interface.Set_Zero_Pos(1);
            }
        }

        private void btn_Set_Zero_Pos_Y_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of Y axis and Make sure that Y axis in Pin condition", "Confirmation Box", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {

                //Interface.Set_Zero_Pos(GlobalVar.Gantry_Y_axis);
                //Interface.Set_Zero_Pos(0);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //double[] pos = Gantry.TogetCurrentPos();
            //GlobalVar.Gantry_X_HomePos = pos[0];
            //txtLblHomePos.Text = GlobalVar.Gantry_X_HomePos.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // double[] pos = Gantry.TogetCurrentPos();
            //GlobalVar.Gantry_Y_HomePos = pos[1];
            //  txtYhomePos.Text = GlobalVar.Gantry_Y_HomePos.ToString();


        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txtGantry_Y_to_Tray_CCD1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCamera_Start_Click(object sender, EventArgs e)
        {
            ////listboxCamera.Items.Clear();
            ////VisionCalibration.CalibrationStep = 1;


            var Vision1 = new TCPIPClient.TCPIPClient("Vision1");
            //IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
            //string text = hostEntry.AddressList[hostEntry.AddressList.Length - 1].ToString();
            //string[] array = text.Split('.');
            //var Text = array[0] + "." + array[1] + "." + array[2] + "." + array[3];

            //if (File.Exists("D:\\TEAL\\NOVA\\DLL\\ConnectionDetails.xml"))
            //{
            //    var c = "strig";
            //}
            // SocketClient.Connect_Vision();





            bool CCD1 = chkCCD1.Checked;
            bool CCD3 = chkCCD3.Checked;
            bool CCD4 = chkCCD4.Checked;
            bool CCD5 = chkCCD5.Checked;

            if (CCD1)
            {
               // VisionCalibration.start_thread_CCD1();
            }
            else

            {
                MessageBox.Show("Please Choose camera");
                return;
            }
            btnCamera_Start.Enabled = false;
            btnCamera_Stop.Enabled = true;
            timer1.Enabled = true;
        }
        string CamData = string.Empty;
        string CamData_PC = string.Empty;
        private void timer1_Tick(object sender, EventArgs e)
        {
            // VisionCalibration.Start_Calibration_sequence();
            //Vision.Recieve_VisionData();
            // VisionCalibration.TTN_Nozzle_calibration();
            //if (CamData !=Vision.V_ReceiveData2)
            //  {
            //      CamData = Vision.V_ReceiveData2;
            //      //listboxCamera.Items.Add("CAM-"+CamData);
            //  }
            //  if (CamData_PC != Vision.send_data)
            //  {
            //      CamData_PC = Vision.send_data;
            //      //listboxCamera.Items.Add("PC-" + CamData_PC);
            //  }
        }

        private void btnCamera_Stop_Click(object sender, EventArgs e)
        {
            bool CCD1 = chkCCD1.Checked;
            bool CCD3 = chkCCD3.Checked;
            bool CCD4 = chkCCD4.Checked;
            bool CCD5 = chkCCD5.Checked;

            if (CCD1)
            {
               // VisionCalibration.stop_thread_CCD1();
            }
           
            else
            {
                MessageBox.Show("Please Choose camera");
                return;
            }
            timer1.Enabled = false;
            //Interface.Kill_All_Motions();
            // VisionCalibration.Load_all_values();

            btnCamera_Start.Enabled = true;
            btnCamera_Stop.Enabled = false;
        }

        private void btnCamera_Next_Step_Click(object sender, EventArgs e)
        {

        }

        private void btnCamera_Reset_Step_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //listboxCamera.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Vision.TCP_Senddata(textBox4.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem != null && comboBox1.SelectedIndex != 0)
            {
                var CCDNo = comboBox1.SelectedItem.ToString().Split(',').First();
                if (CCDNo == "T3")
                {
                    SocketClient.TCP_Senddata_Vision_T3("T3,2," + DateTime.Now.ToString() + "," + Globalvariable.Robot_T32_coordinates[2] + "," + Globalvariable.Robot_T32_coordinates[3] + "," + Globalvariable.Robot_T32_coordinates[4]);
                }
                else
                {
                    MessageBox.Show("Please Check Selected Option");
                }

            }
            else
            {
                MessageBox.Show("Please Select Dropdown");
            }
            //double[] process = Gantry.TogetCurrentPos();
            //double[] Ang_process = Nozzle.TogetCurrentPos_Rotary_1(12);
            //DIOConfig.WriteOPS(false, DIOConfig.O_Camera_Trig_CCD2);
            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Amax_On_Fly_Lighting_controller_1_Relay);
            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Amax_On_Fly_Lighting_controller_2_Relay);


            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Lighting_Controller1_Voltage_Reverse_Relay);
            //DIOConfig.WriteOPS(true, DIOConfig.O_WC_Lighting_Controller2_Voltage_Reverse_Relay);
            //string cmd = comboBox1.SelectedValue.ToString() + "," + process[0].ToString() + "," + process[1].ToString() + "," + Ang_process[0];

            //Vision.TCP_Senddata(cmd);
            ////listboxCamera.Items.Add("PC-" + cmd);
            //Thread.Sleep(Convert.ToInt32(textBox1.Text));
            //DIOConfig.WriteOPS(true, DIOConfig.O_Camera_Trig_CCD2);
        }

        private void FirstCam_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem != null && comboBox1.SelectedIndex != 0 && textBoxDelay.Text != "")
            {
                var CCDNo = comboBox1.SelectedItem.ToString().Split(',').First();
                if (CCDNo == "T1")
                {
                    if (SocketClient.TCP_Senddata_Vision_T4(comboBox1.SelectedItem.ToString()))
                    {
                        CameraConnectionSts.BackColor = Color.Green;
                        //  Thread.Sleep(int.Parse(textBoxDelay.Text));
                        SocketClient.show(this);
                    }
                }
                else
                {
                    MessageBox.Show("Please Check Selected Option");
                }

            }
            else
            {
                MessageBox.Show("Please Select Dropdown and Give delay");
            }

            //double[] process = Gantry.TogetCurrentPos();
            //DIOConfig.WriteOPS(false, DIOConfig.O_Camera_Trig);
            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Amax_On_Fly_Lighting_controller_1_Relay);
            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Amax_On_Fly_Lighting_controller_2_Relay);
            //if(chk_LC1SW1.Checked)
            //{
            //    DIOConfig.WriteOPS(true, DIOConfig.O_WC_Lighting_Controller1_Light_Switch_1);
            //}
            //else
            //{
            //    DIOConfig.WriteOPS(false, DIOConfig.O_WC_Lighting_Controller1_Light_Switch_1);
            //}
            //if (chk_LC1SW2.Checked)
            //{
            //    DIOConfig.WriteOPS(true, DIOConfig.O_WC_Lighting_Controller1_Light_Switch_2);
            //}
            //else
            //{
            //    DIOConfig.WriteOPS(false, DIOConfig.O_WC_Lighting_Controller1_Light_Switch_2);
            //}

            //DIOConfig.WriteOPS(true, DIOConfig.O_WC_Lighting_Controller1_Voltage_Reverse_Relay);
            //DIOConfig.WriteOPS(false, DIOConfig.O_WC_Lighting_Controller2_Voltage_Reverse_Relay);
            //// double[] Ang_process = Nozzle.TogetCurrentPos_Rotary_1(Convert.ToInt32(textBox3.Text));

            //string cmd = comboBox1.SelectedValue.ToString() + "," + process[0].ToString() + "," + process[1].ToString() + "," + "0";

            //Vision.TCP_Senddata(cmd);
            ////listboxCamera.Items.Add("PC-" + cmd);
            //Thread.Sleep(Convert.ToInt32(textBox1.Text));
            //DIOConfig.WriteOPS(true, DIOConfig.O_Camera_Trig);
        }
        private void calibration_settings_MouseMove(object sender, MouseEventArgs e)
        {
            if (Form1.isengineeringmode)
            {
                Form1.lastEngineeringactivity = DateTime.Now;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null && comboBox1.SelectedIndex != 0)
            {
                var CCDNo = comboBox1.SelectedItem.ToString().Split(',').First();
                if (CCDNo == "T5")
                {
                    SocketClient.TCP_Senddata_Vision_T5("T5,1,20,pos_1,pos_2,pos_3,pos_4,pos_4,pos_5,pos_6" +
                                                "pos_7,pos_8,pos_9,pos_10,pos_11,pos_12,pos_13,pos_14,pos_15,pos_16,pos_17,pos_18,pos_19,pos_20"
                                                + Globalvariable.Housing_Barcode);
                }
                else
                {
                    MessageBox.Show("Please Check Selected Option");
                }

            }
            else
            {
                MessageBox.Show("Please Select Dropdown");
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        public void UpdateRichTextBox(string step)
        {
            if (richTextBox_Calib.InvokeRequired)
            {
                richTextBox_Calib.Invoke(new Action(() => UpdateRichTextBox1(step)));
            }
            else
            {
                UpdateRichTextBox1("thread");
            }

        }
        public void UpdateRichTextBox1(string step)
        {

            // Check if there are more than 5 lines, then remove the first line
            if (richTextBox_Calib.Lines.Length >= 20)
            {
                // Remove the first line
                var lines = richTextBox_Calib.Lines.Skip(1).ToArray();
                richTextBox_Calib.Lines = lines;
            }

            // Add the current step to the RichTextBox
            // richTextBox1.Text = step.ToString();
            richTextBox_Calib.Text += step.ToString() + "\n";
            // richTextBox1.AppendText(step.ToString()+"\n");
            var v = richTextBox_Calib.Lines.Length;

            //// Select the current step line to highlight it
            int start = richTextBox_Calib.GetFirstCharIndexFromLine(richTextBox_Calib.Lines.Length - 1);
            int length = richTextBox_Calib.Lines.Last().Length;
            richTextBox_Calib.Select(start, length);

            //// Apply highlight color to current step
            richTextBox_Calib.SelectionBackColor = Color.Red;

            // Scroll to the current step
            richTextBox_Calib.ScrollToCaret();
        }

        private void chkCCD1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (chkCCD1.Checked)
            {
                //grpBoxCCD1.Enabled = true;
                //grpBoxCCD2.Enabled = false;
              //  Static_and_Dynamic_test.Cam1_Active_Dy = true;
                //Static_and_Dynamic_test.Cam2_Active_Dy = false;
               // Static_and_Dynamic_test.Cam1_Active_Dyf = true;
                //Static_and_Dynamic_test.Cam2_Active_Dyf = false;
               // Static_and_Dynamic_test.Cam1_Active = true;
                //Static_and_Dynamic_test.Cam2_Active = false;
               
            }

        }


        private void button1_Click_1(object sender, EventArgs e)
        {


            if (comboBox1.SelectedItem != null && comboBox1.SelectedIndex != 0)
            {
                var CCDNo = comboBox1.SelectedItem.ToString().Split(',');
                if (CCDNo[0] + "," + CCDNo[1] == "T4,1")
                {
                    SocketClient.TCP_Senddata_Vision_T4("T4,1," + Globalvariable.Housing_Barcode);
                }
                else
                if (CCDNo[0] + "," + CCDNo[1] == "T4,3")
                {
                    SocketClient.TCP_Senddata_Vision_T4("T4,3," + Globalvariable.Housing_Barcode);
                }
                else
                if (CCDNo[0] + "," + CCDNo[1] == "T4,4")
                {
                    SocketClient.TCP_Senddata_Vision_T4("T4,4," + Globalvariable.Housing_Barcode);
                }
                else
                if (CCDNo[0] + "," + CCDNo[1] == "T4,5")
                {
                    SocketClient.TCP_Senddata_Vision_T4("T4,5," + Globalvariable.Housing_Barcode + "," + Globalvariable.T45_XY_Coordinates_from_Robo[3] + "," + Globalvariable.T45_XY_Coordinates_from_Robo[4] + "," + Globalvariable.T45_XY_Coordinates_from_Robo[5]);
                }

                else
                {

                    MessageBox.Show("Please Check Selected Option");
                }

            }
            else
            {
                MessageBox.Show("Please Select Dropdown");
            }
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (SocketClient.stop_Thread_Vision_T4())
                CameraConnectionSts.BackColor = Color.Maroon;

        }
        public void read()
        {
            comboBox1.Items.Add("<----------Select---------->");
            if (File.Exists(GetDataFromXML.AllCmdPath))
            {
                int x = 0;
                var lines = File.ReadAllLines(GetDataFromXML.AllCmdPath).ToList();
                for (int i = 0; i < lines.Count(); i++)
                {
                    if (lines[i].ToString().StartsWith("camera"))
                    {
                        while (++i < lines.Count() && lines[i].ToString().StartsWith(" "))
                        {
                            comboBox1.Items.Add(lines[i].ToString().Trim());
                        }
                        break;

                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private async void button8_Click(object sender, EventArgs e) //After entring the IP address and Clicking on the Trigger Button this code will be executed
        {
            if (Scanner_Delay_textBox.Text != "")  //Checks if IP and Delay time Entered or Not
            {
                var Delaydata = Scanner_Delay_textBox.Text;
                if (SocketClient.TCP_Senddata_Scanner("+"))//TCP_Senddata_Scanner(192.168.1.100)  The IP will be recieved in the Hercules
                {
                    await Task.Delay(int.Parse(Delaydata));
                    SocketClient.Scanreceive();

                }
            }
            else
            {
                MessageBox.Show("Enter the Delay Time");
            }
        }

        private void CameraConnectionSts_Click(object sender, EventArgs e)
        {

        }

        private void textBoxDelay_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Scanner_textBox.Text))
            {
                if (SocketClient.TCP_Connect_Scanner())//TCP_Senddata_Scanner(192.168.1.100)  The IP will be recieved in the Hercules
                {
                    Scanner_Consts.BackColor = Color.Green;//COnnection status will trun green
                    SocketClient.scannershow(this);  //Start thread will be called
                }
            }
            else
            {
                MessageBox.Show("Enter the IP Address");
            }

        }

        private void Robo_Trigger_Click(object sender, EventArgs e)
        {

        }

        private void Robo_Disconnect_Click(object sender, EventArgs e)
        {

        }
    }
}
