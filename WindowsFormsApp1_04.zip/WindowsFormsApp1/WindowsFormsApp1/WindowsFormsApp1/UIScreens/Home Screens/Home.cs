﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Net.Http;
using System.Threading;

namespace AHDP
{

    public partial class Home : Form
    {
        Boolean InputStatusUnit;
        public static ListBox listbox1;
        public static ListBox listbox2;
        public static List<string> updateSquence = new List<string>();
        public static List<string> C_alarm = new List<string>();
        public static bool listboxobjectCreated = false;
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
     (
         int nLeftRect,
         int nTopRect,
         int nRightRect,
         int nBottomRect,
         int nWidthEllipse,
         int nHeightEllipse
     );

        public void Panel_Shape()
        {
            //   panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width,
            // panel1.Height, 30, 30));
            //   panel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel2.Width,
            //panel2.Height, 30, 30));
            //   panel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel3.Width,
            //panel3.Height, 30, 30));
            //   panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
            //panel4.Height, 30, 30));

        }

        public static string Home_Shift;
        public string Get_Home_Shift()
        {
            string connectionString = SQLHelper.get_ConnName();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_Shift", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    var result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        Home_Shift = result.ToString();
                        return Home_Shift;
                    }
                    else
                    {
                        Home_Shift = "No result";
                        return Home_Shift;
                    }
                }
            }
        }
        public Home()
        {
            InitializeComponent();
            // Home_Panel.Hide();
            btnUnitSearch.Hide();
            string connectionString = SQLHelper.get_ConnName();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_Shift", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    var result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        Home_Shift = result.ToString();
                    }
                    else
                    {
                        Home_Shift = "No result";
                    }
                }
            }
            lblshift.Text = Home_Shift;

        }

        public void DisplayInputStatus()
        {
            if (InputStatusUnit = true)
            {
                //  label2.Visible = false;
                //label4.Visible = true;
            }
            else
            {
                //  label2.Visible = true;
                //  label4.Visible = false;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //   label2.Visible = true;
            //label4.Visible = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //   label2.Visible = false;
            //  label4.Visible = true;
        }

        private void Home_Load(object sender, EventArgs e)
        {
            try
            {
                labeladd();
                //lblshift.Text = GlobalVar.Shift;
                //dtMachineHealth.DateTimeOffset = Convert.ToDateTime(DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss"));
                //dtUnitSearch.DateTimeOffset = Convert.ToDateTime(DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss"));
                //DisplayInputStatus();
                //Panel_Shape();
                //cmbMachineHealthShift.Text = lblshift.Text;
                //cmbUnitStatus.Text = lblshift.Text;
                loadmachinehealth();
                loadunitstatus();
                loadfailurecause();
                loadunitperhour();
                //loadexcel();
                //System.Timers.Timer tmrRefresh = new System.Timers.Timer();
                //tmrRefresh.Elapsed += new ElapsedEventHandler(OnTimedEvent);
                //tmrRefresh.Interval = 1000;
                //tmrRefresh.Enabled = true;

                listbox1 = (ListBox)tabControl1.TabPages[0].Controls["lst_Log"];
                listbox2 = (ListBox)tabControl1.TabPages[1].Controls["listBox3"];
                UpdateRowSource();
                Updatesequence();
                listboxobjectCreated = true;
                //EnableDoubleBuffering(listbox1);
                //StartBackgroundThread();
            }
            catch (Exception ex)
            {

            }
        }
        //Added

        public async static void UpdateRowSource()
        {
            

            if (listbox1.InvokeRequired)
            {
                listbox1.Invoke(new Action(() =>
                {
                    listbox1.BeginUpdate();
                    //listbox1.SuspendLayout();
                    listbox1.DataSource = null;

                    listbox1.DataSource = updateSquence;
                    //if (GlobClass.DI[(int)GlobClass.Inputs.OP10_Reset_FB])
                    //{
                    if (C_alarm.Count > 0)
                    {
                        ////Log_Write.WriteToFileAlarmAsync(C_alarm);
                        //int A_range = C_alarm.Count;
                        //C_alarm.RemoveRange(0, A_range);
                        ////TIMER_THREAD_LOCK = false;
                    }
                    // }
                    listbox1.EndUpdate();
                    //listbox1.ResumeLayout();
                }

                ));
            }
            else
            {
                listbox1.BeginUpdate();
                listbox1.DataSource = null;

                listbox1.DataSource = updateSquence;
                //if (GlobClass.DI[(int)GlobClass.Inputs.OP10_Reset_FB])
                //{
                if (C_alarm.Count > 0)
                {
                    ////Log_Write.WriteToFileAlarmAsync(C_alarm);
                    //int A_range = C_alarm.Count;
                    //C_alarm.RemoveRange(0, A_range);
                    ////TIMER_THREAD_LOCK = false;
                }
                // }
                listbox1.EndUpdate();
              
            }
        }
        public async static void Updatesequence()
        {

           

            if (listbox2.InvokeRequired)
            {
                listbox2.Invoke(new Action(() =>
                {
                    listbox2.BeginUpdate();
                    listbox2.DataSource = null;
                    listbox2.DataSource = C_alarm;

                    //if (GlobClass.DI[(int)GlobClass.Inputs.OP10_Reset_FB])
                    //{
                    if (C_alarm.Count > 0)
                    {
                        ////Log_Write.WriteToFileAlarmAsync(C_alarm);
                        //int A_range = C_alarm.Count;
                        //C_alarm.RemoveRange(0, A_range);
                        ////TIMER_THREAD_LOCK = false;
                    }
                    // }

                     listbox2.EndUpdate();


                }

                ));
            }
            else
            {
                listbox2.BeginUpdate();
                listbox2.DataSource = null;
                listbox2.DataSource = C_alarm;

                //if (GlobClass.DI[(int)GlobClass.Inputs.OP10_Reset_FB])
                //{
                if (C_alarm.Count > 0)
                {
                    ////Log_Write.WriteToFileAlarmAsync(C_alarm);
                    //int A_range = C_alarm.Count;
                    //C_alarm.RemoveRange(0, A_range);
                    ////TIMER_THREAD_LOCK = false;
                }
                // }

                 listbox2.EndUpdate();



            }

        }

        //Running log function calling
        public static void Add_sequence(string sequence)
        {
            if (updateSquence.Count > 30)
                updateSquence.RemoveAt(updateSquence.Count-1);
            //validate in list or grid
            //if (!CAlarm_intrlock)
            //{
            //    CAlarm_intrlock = true;
            try
            {
                string[] data = sequence.Split(':');
                updateSquence.Insert(0,DateTime.Now.ToString("HH:mm:ss") + ": " + data[0]);
                GlobalVar.Runninglog.WriteLog(DateTime.Now.ToString(), data[0]);

                if (listboxobjectCreated)
                    UpdateRowSource();
            }
            catch (Exception es)
            {

            }
            //CAlarm_intrlock = false;
            //}
        }

        //Alarm log function calling
        //public static void Add_C_Alarm(string msgAlarm, string AlarmId, string priority)
        //{
        //    if (C_alarm.Count > 30)
        //        C_alarm.RemoveAt(C_alarm.Count-1);
        //    //validate in list or grid
        //    //if (!CAlarm_intrlock)
        //    //{
        //    //    CAlarm_intrlock = true;
        //    try
        //    {
        //        string[] data = msgAlarm.Split(':');
        //        C_alarm.Insert(0,DateTime.Now.ToString("HH:mm:ss") + ": " + data[0] + " " + AlarmId + " " + priority);
        //        GlobalVar.Alarmlog.WriteLog(DateTime.Now.ToString(), DateTime.Now.ToString(), AlarmId, msgAlarm, priority, "A");
        //        string SqlQuery = "INSERT INTO Alarm_Log_Data (Start_Time,End_Time,Error_Code,Error_Description,Error_Category,Shift) VALUES " + "(" + "'" + DateTime.Now.ToString() + "'" + "," + "'" + DateTime.Now.ToString() + "'" + "," + "'" + AlarmId + "'" + "" + "," + "'" + msgAlarm + "'" + "," + "'" + priority + "'" + "," + "'" + "A" + "'" + ")";
        //        int RES = SQLHelper.Executequery(SqlQuery);
        //        if (listboxobjectCreated)
        //            Updatesequence();
        //    }
        //    catch (Exception es)
        //    {

        //    }
        //    //CAlarm_intrlock = false;
        //    //}

        //    if (listboxobjectCreated)
        //        UpdateRowSource();
        //}
        //Newly created 21-01-2025

        public static void Add_C_Alarm(string msgAlarm, string AlarmId, string priority)  //Function which logs data for Alarm Table in the Database
        {
            //if (C_alarm.Count > 30)
            //    C_alarm.RemoveAt(C_alarm.Count-1);
            try
            {
                string[] data = msgAlarm.Split(':');
                //C_alarm.Insert(0,DateTime.Now.ToString("HH:mm:ss") + ": " + data[0] + " " + AlarmId + " " + priority);
                // GlobalVar.Alarmlog.WriteLog(DateTime.Now.ToString(), DateTime.Now.ToString(), AlarmId, msgAlarm, priority, Home_Shift);
                string SqlQuery = "INSERT INTO Alarm_Log_Data ([Start_Time], [End_Time], [Alarm Code], [Alarm Description], [Alarm Category], [Shift]) " +
                  "VALUES (" +
                  "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "', " +
                  "'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "', " +
                  "'" + AlarmId + "', " +
                  "'" + msgAlarm + "', " +
                  "'" + priority + "', " +
                  "'" + Home_Shift + "')";


                int RES = SQLHelper.Executequery(SqlQuery);
                //if (listboxobjectCreated)
                //    Updatesequence();
            }
            catch (Exception es)
            {
                MessageBox.Show("Error in Add_C_Alarm function" + es);
            }
            //if (listboxobjectCreated)
            //    UpdateRowSource();
        }


        public void Refresh_Tray_Status()
        {
            try
            {
                //if (!Form1.Cavity_Refresh)
                //{
                //    txtRetestCount.Text = AutoSequence.Retest_count.ToString();

                //    //string get_query = "select tray_id, status, x_gap, y_gap, angle_gap, nozzle_num, place_datetime from running_tray_cavity_live_status";
                //    //DS = Pick_And_Place_Application.SQLHelper.GetData(get_query);


                //    if (Form1.Tray_Cavity.Rows.Count > 0)
                //    {
                //        ToolTip toolTip = new ToolTip();
                //        for (int i = 0; i < Form1.Tray_Cavity.Rows.Count-1; i++)
                //        {
                //            if (Form1.Tray_Cavity.Rows[i]["status"].ToString() == "1")
                //            {
                //                var label = (Label)this.panel7.Controls[(i + 1)];
                //                label.BackColor = System.Drawing.Color.Yellow;
                //                toolTip.SetToolTip(label, string.Concat("X_Gap :", Form1.Tray_Cavity.Rows[i]["x_gap"].ToString(), "\n", " Y_Gap :", Form1.Tray_Cavity.Rows[i]["y_gap"].ToString(), "\n", " Angle_Gap :", Form1.Tray_Cavity.Rows[i]["angle_gap"].ToString(), "\n", " Nozzle No :", Form1.Tray_Cavity.Rows[i]["nozzle_num"].ToString(), "\n", " Place Time :", Form1.Tray_Cavity.Rows[i]["place_datetime"].ToString(), "\n", "CAVT ID:", (i + 1).ToString()));
                //            }
                //            else if (Form1.Tray_Cavity.Rows[i]["status"].ToString() == "2")
                //            {
                //                var label = (Label)this.panel7.Controls[(i + 1)];
                //                label.BackColor = System.Drawing.Color.Red;
                //                toolTip.SetToolTip(label, string.Concat("X_Gap :", Form1.Tray_Cavity.Rows[i]["x_gap"].ToString(), "\n", " Y_Gap :", Form1.Tray_Cavity.Rows[i]["y_gap"].ToString(), "\n", " Angle_Gap :", Form1.Tray_Cavity.Rows[i]["angle_gap"].ToString(), "\n", " Nozzle No :", Form1.Tray_Cavity.Rows[i]["nozzle_num"].ToString(), "\n", " Place Time :", Form1.Tray_Cavity.Rows[i]["place_datetime"].ToString(), "\n", "CAVT ID:", (i + 1).ToString()));
                //            }
                //            else if (Form1.Tray_Cavity.Rows[i]["status"].ToString() == "3")
                //            {
                //                var label = (Label)this.panel7.Controls[(i + 1)];
                //                label.BackColor = System.Drawing.Color.Green;
                //                toolTip.SetToolTip(label, string.Concat("X_Gap :", Form1.Tray_Cavity.Rows[i]["x_gap"].ToString(), "\n", " Y_Gap :", Form1.Tray_Cavity.Rows[i]["y_gap"].ToString(), "\n", " Angle_Gap :", Form1.Tray_Cavity.Rows[i]["angle_gap"].ToString(), "\n", " Nozzle No :", Form1.Tray_Cavity.Rows[i]["nozzle_num"].ToString(), "\n", " Place Time :", Form1.Tray_Cavity.Rows[i]["place_datetime"].ToString(), "\n", "CAVT ID:", (i + 1).ToString()));
                //            }
                //            else
                //            {
                //                var label = (Label)this.panel7.Controls[(i + 1)];
                //                label.BackColor = System.Drawing.Color.Gray;
                //                toolTip.SetToolTip(label, string.Concat("X_Gap :", Form1.Tray_Cavity.Rows[i]["x_gap"].ToString(), "\n", " Y_Gap :", Form1.Tray_Cavity.Rows[i]["y_gap"].ToString(), "\n", " Angle_Gap :", Form1.Tray_Cavity.Rows[i]["angle_gap"].ToString(), "\n", " Nozzle No :", Form1.Tray_Cavity.Rows[i]["nozzle_num"].ToString(), "\n", " Place Time :", Form1.Tray_Cavity.Rows[i]["place_datetime"].ToString(), "\n", "CAVT ID:", (i + 1).ToString()));
                //            }
                //        }
                //    }
                //}
            }
            catch (Exception es)
            {

            }





        }
        public void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            try
            {

                // load the control with the appropriate data


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void loadexcel()
        {
            try
            {
                // Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                //if (xlApp == null)
                //{
                //    MessageBox.Show("Excel is not properly installed!!");
                //    return;
                //}

                // Excel.Workbook xlWorkBook;
                //Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                //xlWorkBook = xlApp.Workbooks.Add(misValue);
                // xlWorkBook = xlApp.Workbooks.Open(@"E:\03.TEAL\Nova\Vision_Dynamic_Data.xlsx", 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
                //xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                //xlWorkSheet.Cells[7, 2] = "10";

                //string saveas_filename = @"D:\"+ DateTime.Now.ToString("yyyyMMddHHmmss") + "_vision_dynamic.xlsx";
                //xlWorkBook.CheckCompatibility = false;
                //xlWorkBook.DoNotPromptForConvert = true;
                //xlWorkBook.SaveAs(saveas_filename, Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);                
                //xlWorkBook.Close(true, misValue, misValue);
                ////xlApp.Quit();

                //Marshal.ReleaseComObject(xlWorkSheet);
                //Marshal.ReleaseComObject(xlWorkBook);
                //Marshal.ReleaseComObject(xlApp);

                MessageBox.Show("Excel file created , you can find the file d:\\csharp-Excel.xlsx");
            }
            catch (Exception ex)
            {

            }
        }

        private void loadmachinehealth()
        {
            try
            {
                //Pick_And_Place_Application.SQLHelper.get_ConnName();
                //if (Pick_And_Place_Application.SQLHelper.openconnection())
                {
                    //DateTime dtmachine_health = Convert.ToDateTime(dtMachineHealth.Text);
                    //SqlParameter[] cmdmodel = {
                    //    new SqlParameter("FILTER_DATE", dtmachine_health.ToString("yyyy-MM-dd")),
                    //    new SqlParameter("SHIFT", cmbMachineHealthShift.Text)};
                    //DataSet ds = Pick_And_Place_Application.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_HOME_MACHINE_HEALTH_STATUS", cmdmodel);
                    //if (ds.Tables[0].Rows.Count > 0)
                    //{
                    //    lbldowntime.Text = ds.Tables[0].Rows[0]["Downtime"].ToString();
                    //    lblruntime.Text = ds.Tables[0].Rows[0]["Runtime"].ToString();
                    //    lblidletime.Text = ds.Tables[0].Rows[0]["Idletime"].ToString();
                    //    //lblstoptime.Text = ds.Tables[0].Rows[0]["Stoptime"].ToString();
                    //    lbltotaltime.Text = ds.Tables[0].Rows[0]["Totaltime"].ToString();                        

                    //    loadmachinehealthChart();                        
                    //}
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnMachineHealth_Click(object sender, EventArgs e)
        {
            try
            {
                // if (dtMachineHealth.Text != "")
                {
                    //DateTime dtmchealth = Convert.ToDateTime(dtMachineHealth.Text);
                    ////Pick_And_Place_Application.SQLHelper.get_ConnName();
                    //if (Pick_And_Place_Application.SQLHelper.openconnection())
                    //{
                    //    //SqlParameter[] cmdmodel = {
                    //    //new SqlParameter("FILTER_DATE", dtmchealth)};
                    //    SqlParameter[] cmdmodel = {
                    //    new SqlParameter("FILTER_DATE", dtmchealth.ToString("yyyy-MM-dd")),
                    //    new SqlParameter("SHIFT", cmbMachineHealthShift.Text)};
                    //    DataSet ds1 = Pick_And_Place_Application.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_HOME_MACHINE_HEALTH_STATUS", cmdmodel);
                    //    if (ds1.Tables[0].Rows.Count > 0)
                    //    {
                    //        lbldowntime.Text = ds1.Tables[0].Rows[0]["Downtime"].ToString();
                    //        lblruntime.Text = ds1.Tables[0].Rows[0]["Runtime"].ToString();
                    //        lblidletime.Text = ds1.Tables[0].Rows[0]["Idletime"].ToString();
                    //        //lblstoptime.Text = ds1.Tables[0].Rows[0]["Stoptime"].ToString();
                    //        lbltotaltime.Text = ds1.Tables[0].Rows[0]["Totaltime"].ToString();
                    //    }
                    //}

                    loadmachinehealthChart();

                    loadfailurecause();

                    loadunitperhour();
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void loadmachinehealthChart()
        {
            try
            {
                //this.chartControl1.Series.Clear();
                //Series machineHealthPie = new Series("MachineHealth", ViewType.Pie);
                //machineHealthPie.ArgumentDataMember = "Argument";
                //machineHealthPie.ValueDataMembers.AddRange(new string[] { "Value" });
                //machineHealthPie.ColorDataMember = "Color";
                //machineHealthPie.DataSource = CreateChartData();
                //PieSeriesView view = (PieSeriesView)machineHealthPie.View;
                //view.FillStyle.FillMode = FillMode.Solid;
                //this.chartControl1.Series.Add(machineHealthPie);
                //this.chartControl1.Legend.Visibility = DevExpress.Utils.DefaultBoolean.False;
                //this.chartControl1.Series[0].Label.TextPattern = " {V:N2} ";
                //this.chartControl1.Series[0].Label.LineVisibility = DevExpress.Utils.DefaultBoolean.False;
                //this.chartControl1.Series[0].LabelsVisibility = DevExpress.Utils.DefaultBoolean.False;
            }
            catch (Exception ex)
            {

            }
        }

        private DataTable CreateChartData()
        {
            try
            {
                DataTable dtChart1 = new DataTable("ChartTable1");
                dtChart1.Columns.Add("Argument", typeof(string));
                dtChart1.Columns.Add("Value", typeof(Decimal));
                dtChart1.Columns.Add("Color", typeof(string));

                //DataRow row = null;
                //row = dtChart1.NewRow();
                //row["Argument"] = "RunTime";
                //row["Value"] = Convert.ToDecimal(lblruntime.Text.Replace(":", "."));
                //Color c = Color.FromArgb(255, 46, 204, 113);
                //row["Color"] = "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
                //dtChart1.Rows.Add(row);
                //row = dtChart1.NewRow();
                //row["Argument"] = "DownTime";
                //row["Value"] = Convert.ToDecimal(lbldowntime.Text.Replace(":", "."));
                //c = Color.FromArgb(255, 231, 76, 60);
                //row["Color"] = "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
                //dtChart1.Rows.Add(row);
                //row = dtChart1.NewRow();
                //row["Argument"] = "IdleTime";
                //row["Value"] = Convert.ToDecimal(lblidletime.Text.Replace(":", "."));
                //c = Color.FromArgb(255, 241, 196, 15);
                //row["Color"] = "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
                //dtChart1.Rows.Add(row);
                //row = dtChart1.NewRow();
                //row["Argument"] = "StopTime";
                //row["Value"] = Convert.ToDecimal(lblstoptime.Text.Replace(":", "."));
                //c = Color.FromArgb(255, 112, 123, 124);
                //row["Color"] = "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
                //dtChart1.Rows.Add(row);

                return dtChart1;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private void loadunitstatus()
        {
            //try
            //{
            //    DateTime dtunitsearch_status = Convert.ToDateTime(dtUnitSearch.Text);
            //    //Pick_And_Place_Application.SQLHelper.get_ConnName();
            //    if (Pick_And_Place_Application.SQLHelper.openconnection())
            //    {
            //        SqlParameter[] cmdmodel = {
            //                new SqlParameter("FILTER_DATE", dtunitsearch_status.ToString("yyyy-MM-dd")),
            //                new SqlParameter("SHIFT", cmbUnitStatus.Text)};
            //        DataSet ds1 = Pick_And_Place_Application.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_MACHINE_HEALTH_UNIT_DETAILS", cmdmodel);
            //        if (ds1.Tables[0].Rows.Count > 0)
            //        {
            //            txtinput.Text = ds1.Tables[0].Rows[0]["INPUT"].ToString();
            //            txtyield.Text = ds1.Tables[0].Rows[0]["YIELD"].ToString() + "%";
            //            txtpass.Text = ds1.Tables[0].Rows[0]["PASS"].ToString();
            //            txtfail.Text = ds1.Tables[0].Rows[0]["FAIL"].ToString();
            //            txtuph.Text = ds1.Tables[0].Rows[0]["UPH"].ToString();
            //            txtct.Text = ds1.Tables[0].Rows[0]["CT"].ToString() + "s";
            //        }
            //    }
            //}
            //catch(Exception ex)
            //{
            //    txtinput.Text = "";
            //    txtyield.Text = "";
            //    txtpass.Text = "";
            //    txtfail.Text = "";
            //    txtuph.Text = "";
            //    txtct.Text = "";                
            //}
        }

        private void btnUnitSearch_Click(object sender, EventArgs e)
        {
            try
            {
                //if (dtUnitSearch.Text != "")
                //{
                //    DateTime dtunitsearch_status = Convert.ToDateTime(dtUnitSearch.Text);
                //    //Pick_And_Place_Application.SQLHelper.get_ConnName();
                //    if (Pick_And_Place_Application.SQLHelper.openconnection())
                //    {
                //        SqlParameter[] cmdmodel = {
                //            new SqlParameter("FILTER_DATE", dtunitsearch_status.ToString("yyyy-MM-dd")),
                //            new SqlParameter("SHIFT", cmbUnitStatus.Text)};

                //        DataSet ds1 = Pick_And_Place_Application.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_MACHINE_HEALTH_UNIT_DETAILS", cmdmodel);
                //        if (ds1.Tables[0].Rows.Count > 0)
                //        {
                //            txtinput.Text = ds1.Tables[0].Rows[0]["INPUT"].ToString();
                //            txtyield.Text = ds1.Tables[0].Rows[0]["YIELD"].ToString()+"%";
                //            txtpass.Text = ds1.Tables[0].Rows[0]["PASS"].ToString();
                //            txtfail.Text = ds1.Tables[0].Rows[0]["FAIL"].ToString();
                //            txtuph.Text = ds1.Tables[0].Rows[0]["UPH"].ToString();
                //            txtct.Text = ds1.Tables[0].Rows[0]["CT"].ToString();
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {

            }
        }

        private DataTable CreateChartDataFC(DataSet dataSet)
        {
            try
            {
                DataSet dsfailure = dataSet;
                DataTable dtChart2 = new DataTable("ChartTable2");
                dtChart2.Columns.Add("Argument", typeof(string));
                dtChart2.Columns.Add("Value", typeof(Decimal));
                dtChart2.Columns.Add("Color", typeof(string));

                DataRow row = null;
                if (dsfailure.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < dsfailure.Tables[0].Rows.Count; i++)
                    {
                        row = dtChart2.NewRow();
                        row["Argument"] = dsfailure.Tables[0].Rows[i]["failure_cause"].ToString();
                        row["Value"] = Convert.ToDecimal(dsfailure.Tables[0].Rows[i]["failure_count"].ToString());
                        Color c1 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart2.Rows.Add(row);
                    }
                }

                return dtChart2;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private void loadunitperhour()
        {
            try
            {
                //DateTime dtmchealth = Convert.ToDateTime(dtMachineHealth.Text);
                ////Pick_And_Place_Application.SQLHelper.get_ConnName();
                //this.chartControl3.Series.Clear();
                //if (Pick_And_Place_Application.SQLHelper.openconnection())
                //{
                //    //SqlParameter[] cmdmodel = {
                //    //    new SqlParameter("FILTER_DATE", dtmchealth.ToString("yyyy-MM-dd"))};
                //    //DataSet ds = Pick_And_Place_Application.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_MACHINE_HEALTH_UNIT_PER_HOUR",cmdmodel);
                //    SqlParameter[] cmdmodel = {
                //        new SqlParameter("SHIFT", cmbMachineHealthShift.Text),
                //    new SqlParameter("FILTER_DATE", dtmchealth.ToString("yyyy-MM-dd"))};
                //    DataSet ds = Pick_And_Place_Application.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_CURRENT_SHIFT_HOUR_UPH_V1", cmdmodel);
                //    if (ds.Tables[0].Rows.Count > 0)
                //    {

                //        ////////////////////////////////////////////////////////////////////////////////////////////old 
                //        //this.chartControl3.Series.Clear();
                //        //Series uphBar = new Series("UPH", ViewType.StackedBar);
                //        //uphBar.ArgumentDataMember = "Argument";
                //        //uphBar.ValueDataMembers.AddRange(new string[] { "Value" });
                //        //uphBar.ColorDataMember = "Color";
                //        //uphBar.DataSource = CreateChartDataUPH(ds);

                //        //BarSeriesView view = (BarSeriesView)uphBar.View;
                //        //view.FillStyle.FillMode = FillMode.Solid;
                //        //this.chartControl3.Series.Add(uphBar);
                //        ////this.chartControl3.Legend.Visibility = DevExpress.Utils.DefaultBoolean.False;
                //        //this.chartControl3.Series[0].Label.TextPattern = " {V:N2} ";
                //        //////////////////////////////////////////////////////////////////////////////////////////
                //        this.chartControl3.Series.Clear();
                //        Series uphBar = new Series("UPH", ViewType.StackedBar);
                //        uphBar.ArgumentDataMember = "Argument";
                //        uphBar.ValueDataMembers.AddRange(new string[] { "Value" });
                //        uphBar.ColorDataMember = "Color";
                //        uphBar.DataSource = CreateChartDataUPH(ds);

                //        BarSeriesView view = (BarSeriesView)uphBar.View;
                //        view.FillStyle.FillMode = FillMode.Solid;
                //        this.chartControl3.Series.Add(uphBar);
                //        //this.chartControl3.Legend.Visibility = DevExpress.Utils.DefaultBoolean.False;
                //        this.chartControl3.Series[0].Label.TextPattern = " {V:N2} ";
                //        ((DevExpress.XtraCharts.XYDiagram)chartControl3.Diagram).AxisX.QualitativeScaleOptions.AutoGrid = false;
                //    }
                //    else
                //    {
                //        //DataSet sd = new DataSet();
                //        //sd.Tables[0].Rows.Add();
                //        //sd.Tables[0].Columns.Add("Shift")

                //    }
                //}
            }
            catch (Exception ex)
            {

            }
        }

        private DataTable CreateChartDataUPH_old(DataSet dataSet)
        {
            try
            {
                DataSet dsUPH = dataSet;
                DataTable dtChart3 = new DataTable("ChartTable2");
                dtChart3.Columns.Add("Argument", typeof(string));
                dtChart3.Columns.Add("Value", typeof(Decimal));
                dtChart3.Columns.Add("Color", typeof(string));

                DataRow row = null;
                if (dsUPH.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < dsUPH.Tables[0].Rows.Count; i++)
                    {
                        row = dtChart3.NewRow();
                        row["Argument"] = dsUPH.Tables[0].Rows[i]["_hours"].ToString() + "-" + (Convert.ToInt32(dsUPH.Tables[0].Rows[i]["_hours"].ToString()) + 1);
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[i]["_uph"].ToString());
                        Color c1 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                    }
                }

                return dtChart3;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        private DataTable CreateChartDataUPH(DataSet dataSet)
        {
            try
            {
                DataSet dsUPH = dataSet;
                DataTable dtChart3 = new DataTable("ChartTable2");
                dtChart3.Columns.Add("Argument", typeof(string));
                dtChart3.Columns.Add("Value", typeof(Decimal));
                dtChart3.Columns.Add("Color", typeof(string));

                DataRow row = null;
                if (dsUPH.Tables[0].Rows.Count > 0)
                {
                    if (dsUPH.Tables[0].Rows[0]["shift"].ToString() == "A")
                    {
                        row = dtChart3.NewRow();
                        row["Argument"] = "6 - 7";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["6 - 7"]).ToString();
                        Color c1 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "7 - 8";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["7 - 8"]).ToString();
                        Color c2 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "8 - 9";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["8 - 9"]).ToString();
                        Color c3 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "9 - 10";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["9 - 10"]).ToString();
                        Color c4 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "10 - 11";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["10 - 11"]).ToString();
                        Color c5 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "11 - 12";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["11 - 12"]).ToString();
                        Color c6 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "12 - 13";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["12 - 13"]).ToString();
                        Color c7 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "13 - 14";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["13 - 14"]).ToString();
                        Color c8 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                    }

                    if (dsUPH.Tables[0].Rows[0]["shift"].ToString() == "B")
                    {
                        row = dtChart3.NewRow();
                        row["Argument"] = "14 - 15";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["14 - 15"]).ToString();
                        Color c1 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "15 - 16";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["15 - 16"]).ToString();
                        Color c2 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "16 - 17";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["16 - 17"]).ToString();
                        Color c3 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "17 - 18";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["17 - 18"]).ToString();
                        Color c4 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "18 - 19";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["18 - 19"]).ToString();
                        Color c5 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "19 - 20";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["19 - 20"]).ToString();
                        Color c6 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "20 - 21";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["20 - 21"]).ToString();
                        Color c7 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "21 - 22";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["21 - 22"]).ToString();
                        Color c8 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                    }

                    if (dsUPH.Tables[0].Rows[0]["shift"].ToString() == "C")
                    {
                        row = dtChart3.NewRow();
                        row["Argument"] = "22 - 23";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["22 - 23"]).ToString();
                        Color c1 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "23 - 00";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["23 - 00"]).ToString();
                        Color c2 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "00 - 01";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["00 - 01"]).ToString();
                        Color c3 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "01 - 02";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["01 - 02"]).ToString();
                        Color c4 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "02 - 03";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["02 - 03"]).ToString();
                        Color c5 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "03 - 04";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["03 - 04"]).ToString();
                        Color c6 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "04 - 05";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["04 - 05"]).ToString();
                        Color c7 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                        row = dtChart3.NewRow();
                        row["Argument"] = "05 - 06";
                        row["Value"] = Convert.ToDecimal(dsUPH.Tables[0].Rows[0]["05 - 06"]).ToString();
                        Color c8 = Color.FromArgb(255, 60, 133, 231);
                        row["Color"] = "#" + c1.R.ToString("X2") + c1.G.ToString("X2") + c1.B.ToString("X2");
                        dtChart3.Rows.Add(row);
                    }
                }

                return dtChart3;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //this.Close();
            //Form frmtray = new cavity_Status();
            //frmtray.MdiParent = Form1.ActiveForm;
            //frmtray.Show();
        }

        private void panel5_Paint_1(object sender, PaintEventArgs e)
        {

        }
        #region"CavityUpdate"
        public int y_pic;
        int numRows = 17;//10
        int numCols = 14;//30
        int page = 0;


        int x = 0;
        int y = 260;
        int lblcavity_number = 1;
        bool start_left = false;
        private void labeladd()
        {
            try
            {
                page = 0;
                int labelWidth = 10;
                int labelHeight = 10;
                x = labelWidth;
                //int[] xCoordinates = { 49, 489, 921, 1329 };
                //Panel Panell = panel7;

                //for (int row = 0; row < AutoSequence.Total_No_of_Comp_in_col; row++)
                //{
                //    // y = 0;
                //    if(start_left)
                //    {
                //        start_left = false;
                //    }
                //    else
                //    {
                //        start_left = true;
                //    }
                //   // x = labelWidth;
                //    y = Convert.ToInt32(y - (1.2 * labelHeight));


                //    for (int col = 0; col <AutoSequence.Total_No_of_Comp_in_row; col++)
                //    {
                //        if(start_left)
                //        {
                //            if (col > 0)
                //            {

                //                x = Convert.ToInt32(x + 2.6 * labelHeight);
                //            }
                //        }
                //        else
                //        {
                //            if (col > 0)
                //            {

                //                x = Convert.ToInt32(x - 2.6 * labelHeight);
                //            }
                //        }


                //        page = page + 1;
                //        Label label = new Label
                //        {
                //            //Text = text_references[page.ToString()],
                //            BackColor = Color.YellowGreen,
                //            Width = labelWidth,
                //            Height = labelHeight,
                //            Location = new Point(x, y),
                //            TextAlign = ContentAlignment.TopLeft, // Center textCambria, 12pt
                //            Font = new System.Drawing.Font("Cambria", 12, System.Drawing.FontStyle.Bold), // Customize font
                //            Name = lblcavity_number.ToString(),

                //        };

                //        lblcavity_number++;
                //        Panell.Controls.Add(label);


                //    }
                //}
            }
            catch (Exception ex)
            {
                //Logger.WriteLog("IDIOConfig.O_diagnostics", "labeladd()", "Common", "Exception Error", ex.ToString());
            }
        }
        private void lblCavity_update()
        {

            //for (int i = 0; i < panel7.Controls.Count; i++)
            //{
            //    if (panel7.Controls[i] is Label)
            //    {
            //        Label dynamicLabel = (Label)panel7.Controls[i];

            //        dynamicLabel.BackColor = Color.MediumVioletRed;


            //    }
            //}


        }
        #endregion
        private void loadfailurecause()
        {
            //try
            //{
            //    this.chartControl2.Series.Clear();
            //    DateTime dtmchealth = Convert.ToDateTime(dtMachineHealth.Text);
            //    DataPoint1 dataPoint1 = new DataPoint1(); 
            //    chartControl2.DataSource = dataPoint1.GetDataPoints(Convert.ToDateTime(dtMachineHealth.Text), cmbMachineHealthShift.Text);
            //    chartControl2.SeriesTemplate.ChangeView(ViewType.StackedBar);
            //    chartControl2.SeriesTemplate.SeriesDataMember = "failureDesc";
            //    chartControl2.SeriesTemplate.SetDataMembers("hour", "failureRate");

            //    chartControl2.SeriesTemplate.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            //    chartControl2.SeriesTemplate.Label.TextPattern = "{V}M";
            //    ((BarSeriesLabel)chartControl2.SeriesTemplate.Label).Position = BarSeriesLabelPosition.Center;

            //    StackedBarSeriesView view = (StackedBarSeriesView)chartControl2.SeriesTemplate.View;
            //    view.BarWidth = 0.8;

            //    XYDiagram diagram = (XYDiagram)chartControl2.Diagram;
            //    diagram.AxisX.Tickmarks.MinorVisible = false;

            //    // Add a chart title:
            //    //chartControl2.Titles.Add(new ChartTitle { Text = "Failure Cause Rate" });

            //    // Specify legend settings:
            //    chartControl2.Legend.MarkerMode = LegendMarkerMode.CheckBoxAndMarker;
            //    chartControl2.Legend.AlignmentHorizontal = LegendAlignmentHorizontal.Center;
            //    chartControl2.Legend.AlignmentVertical = LegendAlignmentVertical.TopOutside;                
            //}
            //catch (Exception ex)
            //{

            //}
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        //private void panel7_Paint(object sender, PaintEventArgs e)
        //{

        //}
        public void Refresh_tray_array()
        {
            try
            {
                for (int i = 1; i < Cavity_update.Length; i++)
                {
                    // if(! string.IsNullOrEmpty( Cavity_update[i]))
                    // {
                    //     if (Cavity_update[i] == "1")
                    //     {
                    //         var label = (Label)this.panel7.Controls[(i)];
                    //         label.BackColor = System.Drawing.Color.Yellow;

                    //     }
                    //     else if (Cavity_update[i] == "2")
                    //     {
                    //         var label = (Label)this.panel7.Controls[(i)];
                    //         label.BackColor = System.Drawing.Color.Red;
                    //     }
                    //     else if (Cavity_update[i] == "3")
                    //     {
                    //         var label = (Label)this.panel7.Controls[(i)];
                    //         label.BackColor = System.Drawing.Color.Green;
                    //     }
                    //     else
                    //     {
                    //         var label = (Label)this.panel7.Controls[(i)];
                    //         label.BackColor = System.Drawing.Color.Gray;
                    //     }
                    // }
                    //else
                    // {
                    //     var label = (Label)this.panel7.Controls[(i)];
                    //     label.BackColor = System.Drawing.Color.Gray;
                    // }
                }

            }
            catch (Exception ex)
            {

            }

        }
        public static string[] Cavity_update = new string[301];

        //cmd priya
        //private void timer1_Tick_1(object sender, EventArgs e)
        //{
        //    if (SocketClient.ScanConnectPrc)
        //    {
        //        button3.BackColor = Color.Lime;
        //    }
        //    else
        //    {
        //        button3.BackColor = Color.Red;
        //    }


        //    if (SocketClient.RoboConnectPrc)
        //    {
        //        button5.BackColor = Color.Lime;
        //    }
        //    else
        //    {
        //        button5.BackColor = Color.Red;
        //    }

        //    if (SocketClient.CCDConnectPrc)
        //    {
        //        button4.BackColor = Color.Lime;
        //    }
        //    else
        //    {
        //        button4.BackColor = Color.Red;
        //    }
        //    //if(modeofoperations.Dry_Seq)
        //    //{
        //    //    label2.Text = "Dry Cycle Run";
        //    //}
        //    //else
        //    //{
        //    //    label2.Text = "Continous Cycle Run";
        //    //}
        //    //Refresh_tray_array();
        //}

        private void chartControl3_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        //private void Alarmone_Click(object sender, EventArgs e)
        //{
        //    Alarmdetails(); //call of alarm details
        //    string errordescription = "Emergency button Pressed";   ///need to pass error code from the function triggered
        //    findAlarmdetails(errordescription);
        //}

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    Update_C_Alarm();
        //}

        //////private void Alarmtwo_Click(object sender, EventArgs e)
        //////{
        //////    Alarmdetails(); //call of alarm details
        //////    string errordescription = "Tray empty in unloading, I0.1";   ///need to pass error code from the function triggered
        //////    findAlarmdetails(errordescription);
        //////}


        //Alarm logic Implement

        // bool CAlarm_intrlock = false;
        //public static List<string> C_alarm = new List<string>();
        //public void Add_C_Alarm(string msgAlarmdescription, string msgAlarmcode)
        //{
        //    string category = string.Empty; // to store the category data initially assigned as empty
        //    string shift = string.Empty;
        //    if (!CAlarm_intrlock)
        //    {
        //        CAlarm_intrlock = true;
        //        try
        //        {
        //            // Set category based on Alarm Code
        //            if (msgAlarmcode == "1000")
        //            {
        //                category = "Safety";
        //            }
        //            else
        //            {
        //                category = "Error";
        //            }

        //            bool alarmExists = false;
        //            using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
        //            {
        //                connection.Open();

        //                // Check if the alarm already exists in the database
        //                string checkAlarmQuery = "SELECT COUNT(*) FROM Alarm_Log_Data " +
        //                                         "WHERE Error_Description = @ErrorDescription AND End_Time IS NULL";
        //                using (SqlCommand checkCommand = new SqlCommand(checkAlarmQuery, connection))
        //                {
        //                    checkCommand.Parameters.AddWithValue("@ErrorDescription", msgAlarmdescription);
        //                    int count = (int)checkCommand.ExecuteScalar();
        //                    if (count > 0)
        //                    {
        //                        alarmExists = true;
        //                    }
        //                }
        //            }
        //            if (alarmExists)
        //            {
        //                AlarmDataingrid();
        //                return;
        //            }

        //            // If the alarm does not exist, proceed with insertion
        //            string[] dataalarmdescription = new string[] { msgAlarmdescription };
        //            string[] datalarmcode = new string[] { msgAlarmcode };
        //            string endTime = DBNull.Value.ToString(); // Ensure this is set as DBNull if needed
        //            C_alarm.Add(DateTime.Now.ToString("HH:mm:ss") + ": " + datalarmcode[0]);
        //            //For shift
        //            string connectionString = SQLHelper.get_ConnName();
        //            using (SqlConnection conn = new SqlConnection(connectionString))
        //            {
        //                using (SqlCommand cmd = new SqlCommand("SP_Shift", conn))
        //                {
        //                    cmd.CommandType = CommandType.StoredProcedure;
        //                    conn.Open();
        //                    var result = cmd.ExecuteScalar();
        //                    if (result != null)
        //                    {
        //                        shift = result.ToString();
        //                    }
        //                    else
        //                    {
        //                        MessageBox.Show("No result while retriving Shift");
        //                    }
        //                }
        //            }

        //            // Insert the new alarm into the database
        //            using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
        //            {
        //                connection.Open();

        //                string SqlQuery = "INSERT INTO Alarm_Log_Data (Start_Time, End_Time, Error_Code, Error_Description, Error_Category,Shift) " +
        //                                  "VALUES (@StartTime, @EndTime, @ErrorCode, @ErrorDescription, @ErrorCategory , @Shift)";

        //                using (SqlCommand command = new SqlCommand(SqlQuery, connection))
        //                {
        //                    command.Parameters.AddWithValue("@StartTime", DateTime.Now);
        //                    command.Parameters.AddWithValue("@EndTime", DBNull.Value);
        //                    command.Parameters.AddWithValue("@ErrorCode", datalarmcode[0]);
        //                    command.Parameters.AddWithValue("@ErrorDescription", dataalarmdescription[0]);
        //                    command.Parameters.AddWithValue("@ErrorCategory", category);
        //                    command.Parameters.AddWithValue("@Shift", shift);
        //                    command.ExecuteNonQuery();
        //                }
        //            }

        //            // After inserting, update the alarm grid
        //            Globalvariable.error_active = true;
        //            if (Globalvariable.error_active)
        //            {
        //                AlarmDataingrid();  // Show the alarm grid after inserting a new alarm

        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show("Home Screen--Error in this function:Add_C_Alarm()" + ex);
        //            return;
        //        }
        //        finally
        //        {
        //            CAlarm_intrlock = false;
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Alarm function is currently locked.");
        //        return;
        //    }
        //}

        //public void Update_C_Alarm()
        //{
        //    Alarmlive_dataGridView1.DataSource = null;
        //    try
        //    {
        //        using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
        //        {
        //            connection.Open();
        //            string almQry = "UPDATE Alarm_Log_Data SET End_Time = GETDATE() WHERE End_Time IS NULL";

        //            using (SqlCommand command = new SqlCommand(almQry, connection))
        //            {
        //                int result = command.ExecuteNonQuery();
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Home  screen:Error in this function:Update_C_Alarm()" + ex);
        //        return;
        //    }
        //}
        // private static Dictionary<string, string> Alarmlist = new Dictionary<string, string>();
        //private static void Alarmdetails()
        //{
        //    string projectDirectory = AppDomain.CurrentDomain.BaseDirectory;  //Location of Debug File
        //    string filePath = Path.Combine(projectDirectory, "..", "..", "Datafiles", "AHDP_Alarm_list.txt");//It come out and gives the outside bin file location
        //    filePath = Path.GetFullPath(filePath);  //Will be having Alarmlist file loacation
        //    try
        //    {
        //        string[] lines = File.ReadAllLines(filePath); //it will read exact data from the file
        //        foreach (var line in lines)  //1 line at at a time it will read as it is and stores in the line 
        //        {
        //            if (string.IsNullOrWhiteSpace(line))  //checks for null,empty,whitespace
        //                continue;
        //            string[] parts = line.Split(':'); //it will split as two rows

        //            if (parts.Length == 2)
        //            {
        //                string alarmDescription = parts[0].Trim();  //holding the alarm description data
        //                string alarmcode = parts[1].Trim();   //hold the alarm code data
        //                Alarmlist[alarmDescription] = alarmcode;  //will be there as key value pair, Key=Alarm description ,, Value=errorcode
        //                                                          //all will be holding one data at a time,only the dictionary will store the new values recursively
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Home  screen:Error in this function:Update_C_Alarm()" + ex);
        //        return;
        //    }
        //}
        //private void findAlarmdetails(string errordescription)
        //{
        //    try
        //    {
        //        if (Alarmlist.ContainsKey(errordescription)) //it checks whether the particlar alarm there or not
        //        {

        //            string msgAlarmcode = Alarmlist[errordescription]; //error code will be stored
        //            string msgAlarmdescription = errordescription; //error description will be stored
        //            Add_C_Alarm(msgAlarmdescription, msgAlarmcode);//calling the insert function

        //        }
        //        else
        //        {
        //            MessageBox.Show("Home  Screen Error:The Alarm Details not there in the File");
        //            return;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Home  screen:Error in this function:findAlarmdetails()" + ex);
        //        return;
        //    }
        //}
        //public async Task<object> AlarmDataingrid()
        //{
        //    string connectionString = SQLHelper.get_ConnName();
        //    using (SqlConnection conn = new SqlConnection(connectionString))
        //    {
        //        using (SqlCommand cmd = new SqlCommand("SP_Alarm_View", conn))
        //        {
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            try
        //            {
        //                await conn.OpenAsync();
        //                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
        //                {
        //                    DataTable dt = new DataTable();
        //                    adapter.Fill(dt);

        //                    // Check if there are any rows to display
        //                    if (dt.Rows.Count > 0)
        //                    {
        //                        Alarmlive_dataGridView1.DataSource = dt;
        //                        Alarmlive_dataGridView1.Show();
        //                        Alarmlive_dataGridView1.AutoGenerateColumns = true;
        //                        return dt;
        //                    }
        //                    else
        //                    {
        //                        MessageBox.Show("No Alarm as occured");
        //                        Alarmlive_dataGridView1.DataSource = null;
        //                        return null; // or handle accordingly
        //                    }
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                MessageBox.Show("Home screen:Error in this function:AlarmDataingrid()" + ex);
        //                return null;
        //            }
        //        }

        //    }

        //}

        private void Alarmlive_dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        public void UpdateRichTextBox(string Mes)
        {
            //// Check if there are more than 5 lines, then remove the first line
            //if (Update_richTextBox.Lines.Length >= 20)
            //{
            //    // Remove the first line
            //    var lines = Update_richTextBox.Lines.Skip(1).ToArray();
            //    Update_richTextBox.Lines = lines;
            //}

            //// Add the current step to the RichTextBox
            //// richTextBox1.Text = step.ToString();
            //Update_richTextBox.Text += DateTime.Now.ToString() + ":" + Mes + "\n";
            //// richTextBox1.AppendText(step.ToString()+"\n");

            ////// Select the current step line to highlight it
            //int start = Update_richTextBox.GetFirstCharIndexFromLine(Update_richTextBox.Lines.Length - 1);
            //int length = Update_richTextBox.Lines.Last().Length;
            //Update_richTextBox.Select(start, length);

            ////// Apply highlight color to current step
            //Update_richTextBox.SelectionBackColor = Color.Red;

            //// Scroll to the current step
            //Update_richTextBox.ScrollToCaret();
        }

        //private void richTextBox1_TextChanged(object sender, EventArgs e)
        //{

        //}

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void chartControl1_Click(object sender, EventArgs e)
        {

        }

        private void btnMachineHealth_Click_1(object sender, EventArgs e)
        {
            Add_sequence("check");
            if (!string.IsNullOrEmpty(dtMachineHealth.Text) && !string.IsNullOrEmpty(cmbMachineHealthShift.Text))
            {
                // Parse the date once at the beginning
                DateTime dtmchealth;
                if (!DateTime.TryParse(dtMachineHealth.Text, out dtmchealth))
                {
                    MessageBox.Show("Invalid date format.");
                    return;
                }

                string connectionString = SQLHelper.get_ConnName();

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    // Open the connection once
                    conn.Open();

                    // Fetch runtime
                    using (SqlCommand cmd = new SqlCommand("spGET_ALARM_MACHINE_HEALTH_STATUS_Runtime", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@START_TIME", dtmchealth.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@SHIFT", cmbMachineHealthShift.Text);

                        var result = cmd.ExecuteScalar();
                        lblruntime.Text = result != null ? result.ToString() : "0";
                    }

                    // Fetch downtime
                    using (SqlCommand cmd = new SqlCommand("spGET_ALARM_MACHINE_HEALTH_STATUS_ErrorTime", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@START_TIME", dtmchealth.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@SHIFT", cmbMachineHealthShift.Text);

                        var result = cmd.ExecuteScalar();
                        lbldowntime.Text = result != null ? result.ToString() : "0";
                    }

                    // Fetch Idletime
                    using (SqlCommand cmd = new SqlCommand("spGET_ALARM_MACHINE_HEALTH_STATUS_Idletime", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@START_TIME", dtmchealth.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@SHIFT", cmbMachineHealthShift.Text);

                        var result = cmd.ExecuteScalar();
                        lblidletime.Text = result != null ? result.ToString() : "0";
                    }

                    // Fetch TotalTime
                    using (SqlCommand cmd = new SqlCommand("spGET_ALARM_MACHINE_HEALTH_STATUS_Totaltime", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@START_TIME", dtmchealth.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@SHIFT", cmbMachineHealthShift.Text);

                        var result = cmd.ExecuteScalar();
                        lbltotaltime.Text = result != null ? result.ToString() : "0";
                    }
                }
            }
            else
            {
                MessageBox.Show("Select Date and Shift");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        //Runtime
        public Stopwatch stopwatch_Runtime;
        public DateTime startTime_Runtime;
        public DateTime storeStartTime_Runtime;
        public DateTime endTime_Runtime;
        public void Get_Runtime_Start()
        {
            stopwatch_Runtime = new Stopwatch();
            startTime_Runtime = DateTime.Now;
            stopwatch_Runtime.Start();
            storeStartTime_Runtime = startTime_Runtime;
        }
        public void Get_Runtime_Stop()
        {
            stopwatch_Runtime.Stop();
            endTime_Runtime = DateTime.Now;
            TimeSpan duration_Runtime = stopwatch_Runtime.Elapsed;
            InsertRuntimeData(storeStartTime_Runtime, endTime_Runtime, duration_Runtime.TotalMinutes);
        }
        public void InsertRuntimeData(DateTime startTime, DateTime endTime, double duration)
        {
            string query = "INSERT INTO OEE (date_time,cat,starttime, endtime, totaltime,Shift) VALUES (@date,@cat,@startTime, @endTime, @duration,@Shift)";
            string connectionString = SQLHelper.get_ConnName();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd"));
                    command.Parameters.AddWithValue("@Cat", "Runtime");
                    command.Parameters.AddWithValue("@startTime", startTime.ToString("yyyy-MM-dd HH:mm:ss"));
                    command.Parameters.AddWithValue("@endTime", endTime.ToString("yyyy-MM-dd HH:mm:ss"));
                    command.Parameters.AddWithValue("@duration", duration);
                    command.Parameters.AddWithValue("@Shift", Home_Shift);

                    try
                    {
                        // Open the connection
                        connection.Open();

                        // Execute the insert query
                        command.ExecuteNonQuery();

                        // Optionally, log a success message
                        Console.WriteLine("Data inserted successfully.");
                    }
                    catch (Exception ex)
                    {
                        // Handle any errors that occur during the insert operation
                        Console.WriteLine("Error inserting data: " + ex.Message);
                    }
                }
            }
        }
        //Idletime
        public Stopwatch stopwatch_Idle;
        public DateTime startTime_Idle;
        public DateTime storeStartTime_Idle;
        public DateTime endTime_Idle;
        public void Get_Idle_Start()
        {
            stopwatch_Idle = new Stopwatch();
            startTime_Idle = DateTime.Now;
            stopwatch_Idle.Start();
            storeStartTime_Idle = startTime_Idle;
        }
        public void Get_Idle_Stop()
        {
            stopwatch_Idle.Stop();
            endTime_Idle = DateTime.Now;
            TimeSpan duration_Idle = stopwatch_Idle.Elapsed;
            InsertIdleData(storeStartTime_Runtime, endTime_Runtime, duration_Idle.TotalMinutes);
        }
        public void InsertIdleData(DateTime startTime, DateTime endTime, double duration)
        {
            string query = "INSERT INTO OEE (date_time,cat,starttime, endtime, totaltime,Shift) VALUES (@date,@cat,@startTime, @endTime, @duration,@Shift)";
            string connectionString = SQLHelper.get_ConnName();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd"));
                    command.Parameters.AddWithValue("@Cat", "IdleTime");
                    command.Parameters.AddWithValue("@startTime", startTime.ToString("yyyy-MM-dd HH:mm:ss"));
                    command.Parameters.AddWithValue("@endTime", endTime.ToString("yyyy-MM-dd HH:mm:ss"));
                    command.Parameters.AddWithValue("@duration", duration);
                    command.Parameters.AddWithValue("@Shift", Home_Shift);

                    try
                    {
                        // Open the connection
                        connection.Open();

                        // Execute the insert query
                        command.ExecuteNonQuery();

                        // Optionally, log a success message
                        Console.WriteLine("Data inserted successfully.");
                    }
                    catch (Exception ex)
                    {
                        // Handle any errors that occur during the insert operation
                        Console.WriteLine("Error inserting data: " + ex.Message);
                    }
                }
            }
        }

        //Downtime
        public Stopwatch stopwatch_Downtime;
        public DateTime startTime_Downtime;
        public DateTime storeStartTime_Downtime;
        public DateTime endTime_Downtime;
        public void Get_DowntimeStart()
        {
            stopwatch_Downtime = new Stopwatch();
            startTime_Downtime = DateTime.Now;
            stopwatch_Downtime.Start();
            storeStartTime_Downtime = startTime_Runtime;
        }
        public void Get_Downtime_Stop()
        {
            stopwatch_Downtime.Stop();
            endTime_Downtime = DateTime.Now;
            TimeSpan duration_Dowtime = stopwatch_Runtime.Elapsed;
            InsertDowntimeData(storeStartTime_Runtime, endTime_Runtime, duration_Dowtime.TotalMinutes);
        }
        public void InsertDowntimeData(DateTime startTime, DateTime endTime, double duration)
        {
            string query = "INSERT INTO OEE (date_time,cat,starttime, endtime, totaltime,Shift) VALUES (@date,@cat,@startTime, @endTime, @duration,@Shift)";
            string connectionString = SQLHelper.get_ConnName();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@date", DateTime.Now.ToString("yyyy-MM-dd"));
                    command.Parameters.AddWithValue("@Cat", "IdleTime");
                    command.Parameters.AddWithValue("@startTime", startTime.ToString("yyyy-MM-dd HH:mm:ss"));
                    command.Parameters.AddWithValue("@endTime", endTime.ToString("yyyy-MM-dd HH:mm:ss"));
                    command.Parameters.AddWithValue("@duration", duration);
                    command.Parameters.AddWithValue("@Shift", Home_Shift);

                    try
                    {
                        // Open the connection
                        connection.Open();

                        // Execute the insert query
                        command.ExecuteNonQuery();

                        // Optionally, log a success message
                        Console.WriteLine("Data inserted successfully.");
                    }
                    catch (Exception ex)
                    {
                        // Handle any errors that occur during the insert operation
                        Console.WriteLine("Error inserting data: " + ex.Message);
                    }
                }
            }
        }

        private void dtUnitSearch_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_2(object sender, EventArgs e)
        {
            //try
            //{
            //    if (SocketClient.Vision1.client == null)
            //    {
            //        if (SocketClient.Connect_Vision())
            //        {
            //            button4.BackColor = Color.Lime;
            //        }
            //        else
            //            button4.BackColor = Color.Red;
            //    }
            //    else
            //    {
            //        button4.BackColor = Color.Lime;
            //    }

            //if (SocketClient.Scanner.client == null)
            //{
                if (SocketClient.ScanConnectPrc)
                {
                    button3.BackColor = Color.Lime;
                }
                else
                {
                    button3.BackColor = Color.Red;
                }


            //if (SocketClient.RoboConnectPrc)
            //{
            //    button5.BackColor = Color.Lime;
            //}
            //else
            //{
            //    button5.BackColor = Color.Red;
            //}

            if (SocketClient.CCDConnectPrc)
            {
                button4.BackColor = Color.Lime;
            }
            else
            {
                button4.BackColor = Color.Red;
            }
            //}
            //else
            //{
            //    button3.BackColor = Color.Lime;
            //}

            //    if (SocketClient.Robo.client == null)
            //    {
            //        if (SocketClient.Connect_Robo())
            //        {
            //            button5.BackColor = Color.Lime;
            //        }
            //        else
            //            button5.BackColor = Color.Red;
            //    }
            //    else
            //    {
            //        button5.BackColor = Color.Lime;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    // Logger.WriteLog("Camera ,Robo,scanner not connecting");
            //}
        }

        private void Homing_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do want start the Homing ?", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

            if (result == DialogResult.OK)
            {
                //PLC.WRITE_DO_TO_PLC(Variables.Program_selection_input_signal7_or_Denso_cmd_area2, 1);
                //PLC.WRITE_DO_TO_PLC(Variables.Operation_right_input3_or_Denso_data_area1, 1);
                //PLC.WRITE_DO_TO_PLC(Variables.Start_input2_or_Denso_data_area0, 0);
                //PLC.WRITE_DO_TO_PLC(Variables.Stop_input0_or_Denso_step_stop, 1);
                //PLC.WRITE_DO_TO_PLC(Variables.Program_reset_input1, 1);
                //PLC.WRITE_DO_TO_PLC(Variables.Stop_input0_or_Denso_step_stop, 0);
                //PLC.WRITE_DO_TO_PLC(Variables.Program_reset_input1, 0);
                //PLC.WRITE_DO_TO_PLC(Variables.Start_input2_or_Denso_data_area0, 1);
                Thread.Sleep(500);
                // PeelOffSticker.start_Thread_RoboHome_prcss();
                if (SocketClient.TCP_Senddata_Robo("Reset,1,1,1,1,1,1,1,1,1"))
                {
                    Home.Add_sequence("Robo Reset Command Send !!");
                }


            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (SocketClient.ScanConnectPrc)
            {
                button3.BackColor = Color.Lime;
            }
            else
            {
                button3.BackColor = Color.Red;
            }


            //if (SocketClient.RoboConnectPrc)
            //{
            //    button5.BackColor = Color.Lime;
            //}
            //else
            //{
            //    button5.BackColor = Color.Red;
            //}

            if (SocketClient.CCDConnectPrc)
            {
                button4.BackColor = Color.Lime;
            }
            else
            {
                button4.BackColor = Color.Red;
            }
        }
    }

    public class DataPoint1
    {
        public string hour { get; set; }
        public double failureRate { get; set; }
        public string failureDesc { get; set; }

        public DataPoint1()
        {

        }
        public DataPoint1(string hour, double failure_rate, string failure_desc)
        {
            this.hour = hour;
            this.failureRate = failure_rate;
            this.failureDesc = failure_desc;
        }
        public List<DataPoint1> GetDataPoints(DateTime filterdate, string shift)
        {
            try
            {
                //if (Pick_And_Place_Application.SQLHelper.openconnection())
                //{
                //    SqlParameter[] cmdmodel = {
                //        new SqlParameter("FILTER_DATE", filterdate.ToString("yyyy-MM-dd")),
                //        new SqlParameter("SHIFT", shift)};
                //    DataSet ds = Pick_And_Place_Application.SQLHelper.GetDatasets(CommandType.StoredProcedure, "spGET_MACHINE_HEALTH_FAILURE_CAUSE_HOUR", cmdmodel);
                //    if (ds.Tables[0].Rows.Count > 0)
                //    {
                //        List<DataPoint1> data = new List<DataPoint1>();                        
                //        for (int i = 0; i < ds.Tables[0].Rows.Count - 1; i++)
                //        {
                //            data.Add(new DataPoint1(string.Concat(ds.Tables[0].Rows[i]["_hour"].ToString(), "-", (Convert.ToInt32(ds.Tables[0].Rows[i]["_hour"].ToString()) + 1)), Convert.ToDouble(ds.Tables[0].Rows[i]["failure_rate"].ToString()), ds.Tables[0].Rows[i]["failure_desc"].ToString()));
                //        }
                //        return data;
                //    }
                //}
                List<DataPoint1> data1 = new List<DataPoint1>
                    {
                        new DataPoint1("",0,"")
                    };
                return data1;
            }
            catch (Exception ex)
            {
                List<DataPoint1> data1 = new List<DataPoint1>
                    {
                        new DataPoint1("",0,"")
                    };
                return data1;
            }
        }
    }

}
