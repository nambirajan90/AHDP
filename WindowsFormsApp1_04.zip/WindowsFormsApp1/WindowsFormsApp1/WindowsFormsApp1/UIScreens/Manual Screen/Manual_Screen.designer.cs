﻿
namespace AHDP.UIScreens.Manual_Screen
{
    partial class Manual_Screen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label28 = new System.Windows.Forms.Label();
            this.galleryDropDown1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox71 = new System.Windows.Forms.GroupBox();
            this.btn_Off = new System.Windows.Forms.Button();
            this.on_panel = new System.Windows.Forms.Panel();
            this.off_panel = new System.Windows.Forms.Panel();
            this.btn_ON = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.SL1_SPEED = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.SL1_STATUS = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.SL1_STOP = new System.Windows.Forms.Button();
            this.SL1_Start = new System.Windows.Forms.Button();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.Conveyor_Direction = new System.Windows.Forms.ComboBox();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.SL2_SPEED = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.SL2_STATUS = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.SL2_STOP = new System.Windows.Forms.Button();
            this.SL2_START = new System.Windows.Forms.Button();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.SL3_SPEED = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.SL3_STATUS = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.SL3_STOP = new System.Windows.Forms.Button();
            this.SL3_START = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox47 = new System.Windows.Forms.GroupBox();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.Servo_Break_On = new System.Windows.Forms.Button();
            this.Servo_Break_Off = new System.Windows.Forms.Button();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.Servo_Enable = new System.Windows.Forms.Button();
            this.Serfo_Error_Clear = new System.Windows.Forms.Button();
            this.Servo_Disable = new System.Windows.Forms.Button();
            this.groupBox50 = new System.Windows.Forms.GroupBox();
            this.label45 = new System.Windows.Forms.Label();
            this.X_Live_Position = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.Servo_Live_Status = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.X_Live_Velocity = new System.Windows.Forms.Label();
            this.groupBox51 = new System.Windows.Forms.GroupBox();
            this.PTP_Stop = new System.Windows.Forms.Button();
            this.PTP_Move = new System.Windows.Forms.Button();
            this.Iteration = new System.Windows.Forms.TextBox();
            this.Wait = new System.Windows.Forms.TextBox();
            this.PTP_Speed = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.PTP_End = new System.Windows.Forms.TextBox();
            this.label97 = new System.Windows.Forms.Label();
            this.PTP_Start = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.label128 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label129 = new System.Windows.Forms.Label();
            this.Jog_Negative = new System.Windows.Forms.Button();
            this.Jog_Postive = new System.Windows.Forms.Button();
            this.groupBox53 = new System.Windows.Forms.GroupBox();
            this.Home_Stop = new System.Windows.Forms.Button();
            this.Home_Move = new System.Windows.Forms.Button();
            this.groupBox54 = new System.Windows.Forms.GroupBox();
            this.Motion_Stop = new System.Windows.Forms.Button();
            this.Motion_Move = new System.Windows.Forms.Button();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.Motion_Speed = new System.Windows.Forms.TextBox();
            this.label152 = new System.Windows.Forms.Label();
            this.Motion_Pos = new System.Windows.Forms.TextBox();
            this.label153 = new System.Windows.Forms.Label();
            this.groupBox55 = new System.Windows.Forms.GroupBox();
            this.Positive = new System.Windows.Forms.Label();
            this.Servo_Error_Status = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.Origin = new System.Windows.Forms.Label();
            this.Servo_Home_Status = new System.Windows.Forms.Label();
            this.Servo_Running_Status = new System.Windows.Forms.Label();
            this.Servo_Ready_Status = new System.Windows.Forms.Label();
            this.Negative = new System.Windows.Forms.Label();
            this.Servo_Enable_Status = new System.Windows.Forms.Label();
            this.label213 = new System.Windows.Forms.Label();
            this.label214 = new System.Windows.Forms.Label();
            this.label236 = new System.Windows.Forms.Label();
            this.label237 = new System.Windows.Forms.Label();
            this.label248 = new System.Windows.Forms.Label();
            this.label249 = new System.Windows.Forms.Label();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.groupBox140 = new System.Windows.Forms.GroupBox();
            this.HSG2_VACUUM_FB = new System.Windows.Forms.Label();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.groupBox141 = new System.Windows.Forms.GroupBox();
            this.HSG3_VACUUM_FB = new System.Windows.Forms.Label();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.groupBox134 = new System.Windows.Forms.GroupBox();
            this.CCD_RECEIVE_DATA5 = new System.Windows.Forms.RichTextBox();
            this.CCD_RECEIVE_DATA4 = new System.Windows.Forms.RichTextBox();
            this.CCD_RECEIVE_DATA3 = new System.Windows.Forms.RichTextBox();
            this.CCD_STATUS = new System.Windows.Forms.Label();
            this.CCD_Connect = new System.Windows.Forms.Button();
            this.CCD_SEND_DATA = new System.Windows.Forms.RichTextBox();
            this.CCD_RECEIVE_DATA1 = new System.Windows.Forms.RichTextBox();
            this.label576 = new System.Windows.Forms.Label();
            this.CCD_TRIGGER = new System.Windows.Forms.Button();
            this.label577 = new System.Windows.Forms.Label();
            this.label578 = new System.Windows.Forms.Label();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.SCANNER_STATUS = new System.Windows.Forms.Label();
            this.SCANNER_CONNECT = new System.Windows.Forms.Button();
            this.SCANNER_SEND_DATA = new System.Windows.Forms.RichTextBox();
            this.SCANNER_RECEIVE_DATA = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.Input_Feedback = new System.Windows.Forms.Timer(this.components);
            this.Servo_live_values = new System.Windows.Forms.Timer(this.components);
            this.label280 = new System.Windows.Forms.Label();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox71.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox47.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.groupBox50.SuspendLayout();
            this.groupBox51.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.groupBox53.SuspendLayout();
            this.groupBox54.SuspendLayout();
            this.groupBox55.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage19.SuspendLayout();
            this.groupBox140.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.groupBox141.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.groupBox134.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.SuspendLayout();
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label28.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(127, 111);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(14, 13);
            this.label28.TabIndex = 50;
            this.label28.Text = "0";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // galleryDropDown1
            // 
            this.galleryDropDown1.Name = "galleryDropDown1";
            this.galleryDropDown1.Size = new System.Drawing.Size(61, 4);
            // 
            // tabControl2
            // 
            this.tabControl2.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage16);
            this.tabControl2.Controls.Add(this.tabPage12);
            this.tabControl2.Controls.Add(this.tabPage14);
            this.tabControl2.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl2.Location = new System.Drawing.Point(1, 89);
            this.tabControl2.Multiline = true;
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1270, 616);
            this.tabControl2.TabIndex = 1;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.White;
            this.tabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage6.Controls.Add(this.tabControl5);
            this.tabPage6.Location = new System.Drawing.Point(4, 30);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1262, 582);
            this.tabPage6.TabIndex = 4;
            this.tabPage6.Text = "Cylinders";
            // 
            // tabControl5
            // 
            this.tabControl5.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl5.Controls.Add(this.tabPage7);
            this.tabControl5.Location = new System.Drawing.Point(20, 29);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(1232, 468);
            this.tabControl5.TabIndex = 1;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.White;
            this.tabPage7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage7.Controls.Add(this.groupBox71);
            this.tabPage7.Location = new System.Drawing.Point(4, 30);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1224, 434);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Z axis cylinder";
            // 
            // groupBox71
            // 
            this.groupBox71.Controls.Add(this.btn_Off);
            this.groupBox71.Controls.Add(this.on_panel);
            this.groupBox71.Controls.Add(this.off_panel);
            this.groupBox71.Controls.Add(this.btn_ON);
            this.groupBox71.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox71.Location = new System.Drawing.Point(53, 38);
            this.groupBox71.Name = "groupBox71";
            this.groupBox71.Size = new System.Drawing.Size(217, 60);
            this.groupBox71.TabIndex = 13;
            this.groupBox71.TabStop = false;
            this.groupBox71.Text = "Streamline 1 Blocking";
            // 
            // btn_Off
            // 
            this.btn_Off.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_Off.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btn_Off.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.btn_Off.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Off.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_Off.Location = new System.Drawing.Point(109, 25);
            this.btn_Off.Name = "btn_Off";
            this.btn_Off.Size = new System.Drawing.Size(51, 25);
            this.btn_Off.TabIndex = 12;
            this.btn_Off.Text = "Close";
            this.btn_Off.UseVisualStyleBackColor = false;
            this.btn_Off.Click += new System.EventHandler(this.btn_Off_Click);
            // 
            // on_panel
            // 
            this.on_panel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.on_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.on_panel.Location = new System.Drawing.Point(3, 25);
            this.on_panel.Name = "on_panel";
            this.on_panel.Size = new System.Drawing.Size(51, 25);
            this.on_panel.TabIndex = 9;
            // 
            // off_panel
            // 
            this.off_panel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.off_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.off_panel.Location = new System.Drawing.Point(162, 25);
            this.off_panel.Name = "off_panel";
            this.off_panel.Size = new System.Drawing.Size(51, 25);
            this.off_panel.TabIndex = 10;
            // 
            // btn_ON
            // 
            this.btn_ON.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn_ON.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.btn_ON.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.btn_ON.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ON.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ON.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_ON.Location = new System.Drawing.Point(56, 25);
            this.btn_ON.Name = "btn_ON";
            this.btn_ON.Size = new System.Drawing.Size(51, 25);
            this.btn_ON.TabIndex = 11;
            this.btn_ON.Text = "Open";
            this.btn_ON.UseVisualStyleBackColor = false;
            this.btn_ON.Click += new System.EventHandler(this.btn_ON_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.groupBox12);
            this.tabPage1.Location = new System.Drawing.Point(4, 30);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1262, 582);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Stepper Motors";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.groupBox1);
            this.groupBox12.Controls.Add(this.groupBox46);
            this.groupBox12.Controls.Add(this.groupBox16);
            this.groupBox12.Controls.Add(this.groupBox44);
            this.groupBox12.Controls.Add(this.groupBox36);
            this.groupBox12.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(23, 34);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(1229, 268);
            this.groupBox12.TabIndex = 10;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Conveyor";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(946, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(263, 139);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "z axis conveyor";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Low Speed",
            "High Speed"});
            this.comboBox1.Location = new System.Drawing.Point(23, 105);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(125, 21);
            this.comboBox1.TabIndex = 5;
            this.comboBox1.Text = "Low Speed";
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(208, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 14);
            this.label1.TabIndex = 4;
            this.label1.Text = "Status";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(172, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 30);
            this.label2.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(172, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 30);
            this.label3.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button1.Font = new System.Drawing.Font("Cambria", 12F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(20, 69);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 30);
            this.button1.TabIndex = 1;
            this.button1.Text = "Stop";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button2.Font = new System.Drawing.Font("Cambria", 12F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(20, 30);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 30);
            this.button2.TabIndex = 0;
            this.button2.Text = "Start";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // groupBox46
            // 
            this.groupBox46.BackColor = System.Drawing.Color.White;
            this.groupBox46.Controls.Add(this.SL1_SPEED);
            this.groupBox46.Controls.Add(this.label31);
            this.groupBox46.Controls.Add(this.SL1_STATUS);
            this.groupBox46.Controls.Add(this.label44);
            this.groupBox46.Controls.Add(this.SL1_STOP);
            this.groupBox46.Controls.Add(this.SL1_Start);
            this.groupBox46.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox46.Location = new System.Drawing.Point(19, 41);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(264, 139);
            this.groupBox46.TabIndex = 0;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "Y1 axis conveyor";
            // 
            // SL1_SPEED
            // 
            this.SL1_SPEED.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SL1_SPEED.FormattingEnabled = true;
            this.SL1_SPEED.Items.AddRange(new object[] {
            "Low Speed",
            "High Speed"});
            this.SL1_SPEED.Location = new System.Drawing.Point(20, 106);
            this.SL1_SPEED.Name = "SL1_SPEED";
            this.SL1_SPEED.Size = new System.Drawing.Size(125, 21);
            this.SL1_SPEED.TabIndex = 5;
            this.SL1_SPEED.Text = "Low Speed";
            this.SL1_SPEED.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label31.Location = new System.Drawing.Point(209, 57);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(48, 14);
            this.label31.TabIndex = 4;
            this.label31.Text = "Status";
            // 
            // SL1_STATUS
            // 
            this.SL1_STATUS.BackColor = System.Drawing.Color.Red;
            this.SL1_STATUS.Location = new System.Drawing.Point(173, 50);
            this.SL1_STATUS.Name = "SL1_STATUS";
            this.SL1_STATUS.Size = new System.Drawing.Size(30, 30);
            this.SL1_STATUS.TabIndex = 3;
            // 
            // label44
            // 
            this.label44.BackColor = System.Drawing.Color.Maroon;
            this.label44.Location = new System.Drawing.Point(173, 50);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(30, 30);
            this.label44.TabIndex = 2;
            // 
            // SL1_STOP
            // 
            this.SL1_STOP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.SL1_STOP.Font = new System.Drawing.Font("Cambria", 12F);
            this.SL1_STOP.ForeColor = System.Drawing.Color.White;
            this.SL1_STOP.Location = new System.Drawing.Point(20, 69);
            this.SL1_STOP.Name = "SL1_STOP";
            this.SL1_STOP.Size = new System.Drawing.Size(125, 30);
            this.SL1_STOP.TabIndex = 1;
            this.SL1_STOP.Text = "Stop";
            this.SL1_STOP.UseVisualStyleBackColor = false;
            this.SL1_STOP.Click += new System.EventHandler(this.SL1_STOP_Click);
            // 
            // SL1_Start
            // 
            this.SL1_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.SL1_Start.Font = new System.Drawing.Font("Cambria", 12F);
            this.SL1_Start.ForeColor = System.Drawing.Color.White;
            this.SL1_Start.Location = new System.Drawing.Point(20, 30);
            this.SL1_Start.Name = "SL1_Start";
            this.SL1_Start.Size = new System.Drawing.Size(125, 30);
            this.SL1_Start.TabIndex = 0;
            this.SL1_Start.Text = "Start";
            this.SL1_Start.UseVisualStyleBackColor = false;
            this.SL1_Start.Click += new System.EventHandler(this.SL1_Start_Click);
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.Conveyor_Direction);
            this.groupBox16.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox16.Location = new System.Drawing.Point(550, 190);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(163, 62);
            this.groupBox16.TabIndex = 9;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Coveyor Direction";
            // 
            // Conveyor_Direction
            // 
            this.Conveyor_Direction.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Conveyor_Direction.FormattingEnabled = true;
            this.Conveyor_Direction.Items.AddRange(new object[] {
            "Right To Left",
            "Left To Right"});
            this.Conveyor_Direction.Location = new System.Drawing.Point(14, 26);
            this.Conveyor_Direction.Name = "Conveyor_Direction";
            this.Conveyor_Direction.Size = new System.Drawing.Size(125, 21);
            this.Conveyor_Direction.TabIndex = 5;
            this.Conveyor_Direction.Text = "Left to Right";
            this.Conveyor_Direction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            // 
            // groupBox44
            // 
            this.groupBox44.BackColor = System.Drawing.Color.White;
            this.groupBox44.Controls.Add(this.SL2_SPEED);
            this.groupBox44.Controls.Add(this.label26);
            this.groupBox44.Controls.Add(this.SL2_STATUS);
            this.groupBox44.Controls.Add(this.label30);
            this.groupBox44.Controls.Add(this.SL2_STOP);
            this.groupBox44.Controls.Add(this.SL2_START);
            this.groupBox44.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox44.Location = new System.Drawing.Point(324, 41);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Size = new System.Drawing.Size(266, 139);
            this.groupBox44.TabIndex = 1;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "Y2 axis conveyor";
            // 
            // SL2_SPEED
            // 
            this.SL2_SPEED.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SL2_SPEED.FormattingEnabled = true;
            this.SL2_SPEED.Items.AddRange(new object[] {
            "Low Speed",
            "High Speed"});
            this.SL2_SPEED.Location = new System.Drawing.Point(20, 107);
            this.SL2_SPEED.Name = "SL2_SPEED";
            this.SL2_SPEED.Size = new System.Drawing.Size(125, 21);
            this.SL2_SPEED.TabIndex = 5;
            this.SL2_SPEED.Text = "Low Speed";
            this.SL2_SPEED.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label26.Location = new System.Drawing.Point(209, 60);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 14);
            this.label26.TabIndex = 4;
            this.label26.Text = "Status";
            // 
            // SL2_STATUS
            // 
            this.SL2_STATUS.BackColor = System.Drawing.Color.Red;
            this.SL2_STATUS.Location = new System.Drawing.Point(173, 53);
            this.SL2_STATUS.Name = "SL2_STATUS";
            this.SL2_STATUS.Size = new System.Drawing.Size(30, 30);
            this.SL2_STATUS.TabIndex = 3;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.Maroon;
            this.label30.Location = new System.Drawing.Point(173, 53);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(30, 30);
            this.label30.TabIndex = 2;
            // 
            // SL2_STOP
            // 
            this.SL2_STOP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.SL2_STOP.Font = new System.Drawing.Font("Cambria", 12F);
            this.SL2_STOP.ForeColor = System.Drawing.Color.White;
            this.SL2_STOP.Location = new System.Drawing.Point(18, 72);
            this.SL2_STOP.Name = "SL2_STOP";
            this.SL2_STOP.Size = new System.Drawing.Size(125, 30);
            this.SL2_STOP.TabIndex = 1;
            this.SL2_STOP.Text = "Stop";
            this.SL2_STOP.UseVisualStyleBackColor = false;
            this.SL2_STOP.Click += new System.EventHandler(this.SL2_STOP_Click);
            // 
            // SL2_START
            // 
            this.SL2_START.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.SL2_START.Font = new System.Drawing.Font("Cambria", 12F);
            this.SL2_START.ForeColor = System.Drawing.Color.White;
            this.SL2_START.Location = new System.Drawing.Point(18, 30);
            this.SL2_START.Name = "SL2_START";
            this.SL2_START.Size = new System.Drawing.Size(125, 30);
            this.SL2_START.TabIndex = 0;
            this.SL2_START.Text = "Start";
            this.SL2_START.UseVisualStyleBackColor = false;
            this.SL2_START.Click += new System.EventHandler(this.SL2_START_Click);
            // 
            // groupBox36
            // 
            this.groupBox36.BackColor = System.Drawing.Color.White;
            this.groupBox36.Controls.Add(this.SL3_SPEED);
            this.groupBox36.Controls.Add(this.label20);
            this.groupBox36.Controls.Add(this.SL3_STATUS);
            this.groupBox36.Controls.Add(this.label24);
            this.groupBox36.Controls.Add(this.SL3_STOP);
            this.groupBox36.Controls.Add(this.SL3_START);
            this.groupBox36.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox36.Location = new System.Drawing.Point(635, 41);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(263, 139);
            this.groupBox36.TabIndex = 2;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "X axis conveyor";
            // 
            // SL3_SPEED
            // 
            this.SL3_SPEED.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SL3_SPEED.FormattingEnabled = true;
            this.SL3_SPEED.Items.AddRange(new object[] {
            "Low Speed",
            "High Speed"});
            this.SL3_SPEED.Location = new System.Drawing.Point(23, 105);
            this.SL3_SPEED.Name = "SL3_SPEED";
            this.SL3_SPEED.Size = new System.Drawing.Size(125, 21);
            this.SL3_SPEED.TabIndex = 5;
            this.SL3_SPEED.Text = "Low Speed";
            this.SL3_SPEED.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(208, 60);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 14);
            this.label20.TabIndex = 4;
            this.label20.Text = "Status";
            // 
            // SL3_STATUS
            // 
            this.SL3_STATUS.BackColor = System.Drawing.Color.Red;
            this.SL3_STATUS.Location = new System.Drawing.Point(172, 53);
            this.SL3_STATUS.Name = "SL3_STATUS";
            this.SL3_STATUS.Size = new System.Drawing.Size(30, 30);
            this.SL3_STATUS.TabIndex = 3;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.Maroon;
            this.label24.Location = new System.Drawing.Point(172, 53);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(30, 30);
            this.label24.TabIndex = 2;
            // 
            // SL3_STOP
            // 
            this.SL3_STOP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.SL3_STOP.Font = new System.Drawing.Font("Cambria", 12F);
            this.SL3_STOP.ForeColor = System.Drawing.Color.White;
            this.SL3_STOP.Location = new System.Drawing.Point(20, 69);
            this.SL3_STOP.Name = "SL3_STOP";
            this.SL3_STOP.Size = new System.Drawing.Size(125, 30);
            this.SL3_STOP.TabIndex = 1;
            this.SL3_STOP.Text = "Stop";
            this.SL3_STOP.UseVisualStyleBackColor = false;
            this.SL3_STOP.Click += new System.EventHandler(this.SL3_STOP_Click);
            // 
            // SL3_START
            // 
            this.SL3_START.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.SL3_START.Font = new System.Drawing.Font("Cambria", 12F);
            this.SL3_START.ForeColor = System.Drawing.Color.White;
            this.SL3_START.Location = new System.Drawing.Point(20, 30);
            this.SL3_START.Name = "SL3_START";
            this.SL3_START.Size = new System.Drawing.Size(125, 30);
            this.SL3_START.TabIndex = 0;
            this.SL3_START.Text = "Start";
            this.SL3_START.UseVisualStyleBackColor = false;
            this.SL3_START.Click += new System.EventHandler(this.SL3_START_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl3);
            this.tabPage2.Location = new System.Drawing.Point(4, 30);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1262, 582);
            this.tabPage2.TabIndex = 9;
            this.tabPage2.Text = "Gantry";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl3.Controls.Add(this.tabPage3);
            this.tabControl3.Controls.Add(this.tabPage22);
            this.tabControl3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl3.Location = new System.Drawing.Point(59, 28);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1083, 512);
            this.tabControl3.TabIndex = 40;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.groupBox47);
            this.tabPage3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 30);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1075, 478);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "X - Axis";
            // 
            // groupBox47
            // 
            this.groupBox47.BackColor = System.Drawing.Color.White;
            this.groupBox47.Controls.Add(this.groupBox48);
            this.groupBox47.Controls.Add(this.groupBox49);
            this.groupBox47.Controls.Add(this.groupBox50);
            this.groupBox47.Controls.Add(this.groupBox51);
            this.groupBox47.Controls.Add(this.groupBox52);
            this.groupBox47.Controls.Add(this.groupBox53);
            this.groupBox47.Controls.Add(this.groupBox54);
            this.groupBox47.Controls.Add(this.groupBox55);
            this.groupBox47.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox47.Location = new System.Drawing.Point(10, -3);
            this.groupBox47.Name = "groupBox47";
            this.groupBox47.Size = new System.Drawing.Size(1053, 485);
            this.groupBox47.TabIndex = 38;
            this.groupBox47.TabStop = false;
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.Servo_Break_On);
            this.groupBox48.Controls.Add(this.Servo_Break_Off);
            this.groupBox48.Enabled = false;
            this.groupBox48.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox48.Location = new System.Drawing.Point(16, 330);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Size = new System.Drawing.Size(177, 145);
            this.groupBox48.TabIndex = 76;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "Break Control";
            // 
            // Servo_Break_On
            // 
            this.Servo_Break_On.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Servo_Break_On.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Servo_Break_On.ForeColor = System.Drawing.Color.White;
            this.Servo_Break_On.Location = new System.Drawing.Point(9, 34);
            this.Servo_Break_On.Name = "Servo_Break_On";
            this.Servo_Break_On.Size = new System.Drawing.Size(148, 37);
            this.Servo_Break_On.TabIndex = 71;
            this.Servo_Break_On.Text = "Break Enable";
            this.Servo_Break_On.UseVisualStyleBackColor = false;
            // 
            // Servo_Break_Off
            // 
            this.Servo_Break_Off.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Servo_Break_Off.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Servo_Break_Off.ForeColor = System.Drawing.Color.White;
            this.Servo_Break_Off.Location = new System.Drawing.Point(9, 85);
            this.Servo_Break_Off.Name = "Servo_Break_Off";
            this.Servo_Break_Off.Size = new System.Drawing.Size(148, 37);
            this.Servo_Break_Off.TabIndex = 71;
            this.Servo_Break_Off.Text = "Break Disable";
            this.Servo_Break_Off.UseVisualStyleBackColor = false;
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.Servo_Enable);
            this.groupBox49.Controls.Add(this.Serfo_Error_Clear);
            this.groupBox49.Controls.Add(this.Servo_Disable);
            this.groupBox49.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox49.Location = new System.Drawing.Point(16, 150);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(177, 168);
            this.groupBox49.TabIndex = 75;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "Device Control";
            // 
            // Servo_Enable
            // 
            this.Servo_Enable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Servo_Enable.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Servo_Enable.ForeColor = System.Drawing.Color.White;
            this.Servo_Enable.Location = new System.Drawing.Point(11, 26);
            this.Servo_Enable.Name = "Servo_Enable";
            this.Servo_Enable.Size = new System.Drawing.Size(148, 37);
            this.Servo_Enable.TabIndex = 71;
            this.Servo_Enable.Text = "Servo Enable";
            this.Servo_Enable.UseVisualStyleBackColor = false;
            // 
            // Serfo_Error_Clear
            // 
            this.Serfo_Error_Clear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Serfo_Error_Clear.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Serfo_Error_Clear.ForeColor = System.Drawing.Color.White;
            this.Serfo_Error_Clear.Location = new System.Drawing.Point(11, 114);
            this.Serfo_Error_Clear.Name = "Serfo_Error_Clear";
            this.Serfo_Error_Clear.Size = new System.Drawing.Size(148, 37);
            this.Serfo_Error_Clear.TabIndex = 71;
            this.Serfo_Error_Clear.Text = "Servo Clear Error";
            this.Serfo_Error_Clear.UseVisualStyleBackColor = false;
            // 
            // Servo_Disable
            // 
            this.Servo_Disable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Servo_Disable.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Servo_Disable.ForeColor = System.Drawing.Color.White;
            this.Servo_Disable.Location = new System.Drawing.Point(11, 70);
            this.Servo_Disable.Name = "Servo_Disable";
            this.Servo_Disable.Size = new System.Drawing.Size(148, 37);
            this.Servo_Disable.TabIndex = 71;
            this.Servo_Disable.Text = "Servo Disable";
            this.Servo_Disable.UseVisualStyleBackColor = false;
            // 
            // groupBox50
            // 
            this.groupBox50.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox50.Controls.Add(this.label45);
            this.groupBox50.Controls.Add(this.X_Live_Position);
            this.groupBox50.Controls.Add(this.label66);
            this.groupBox50.Controls.Add(this.label67);
            this.groupBox50.Controls.Add(this.Servo_Live_Status);
            this.groupBox50.Controls.Add(this.label81);
            this.groupBox50.Controls.Add(this.label82);
            this.groupBox50.Controls.Add(this.X_Live_Velocity);
            this.groupBox50.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox50.Location = new System.Drawing.Point(732, 15);
            this.groupBox50.Name = "groupBox50";
            this.groupBox50.Size = new System.Drawing.Size(297, 128);
            this.groupBox50.TabIndex = 74;
            this.groupBox50.TabStop = false;
            this.groupBox50.Text = "Live Values";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(231, 66);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(47, 14);
            this.label45.TabIndex = 73;
            this.label45.Text = "(mm/s)";
            // 
            // X_Live_Position
            // 
            this.X_Live_Position.AutoSize = true;
            this.X_Live_Position.BackColor = System.Drawing.Color.WhiteSmoke;
            this.X_Live_Position.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.X_Live_Position.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.X_Live_Position.Location = new System.Drawing.Point(173, 39);
            this.X_Live_Position.Name = "X_Live_Position";
            this.X_Live_Position.Size = new System.Drawing.Size(18, 16);
            this.X_Live_Position.TabIndex = 53;
            this.X_Live_Position.Text = "0";
            this.X_Live_Position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(231, 39);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(37, 14);
            this.label66.TabIndex = 75;
            this.label66.Text = "(mm)";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(10, 95);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(87, 14);
            this.label67.TabIndex = 33;
            this.label67.Text = "Servo Status";
            this.label67.Visible = false;
            // 
            // Servo_Live_Status
            // 
            this.Servo_Live_Status.AutoSize = true;
            this.Servo_Live_Status.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Servo_Live_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Servo_Live_Status.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Servo_Live_Status.Location = new System.Drawing.Point(173, 95);
            this.Servo_Live_Status.Name = "Servo_Live_Status";
            this.Servo_Live_Status.Size = new System.Drawing.Size(18, 16);
            this.Servo_Live_Status.TabIndex = 50;
            this.Servo_Live_Status.Text = "0";
            this.Servo_Live_Status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Servo_Live_Status.Visible = false;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(9, 39);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(139, 14);
            this.label81.TabIndex = 52;
            this.label81.Text = "Servo Actual Position";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(9, 66);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(137, 14);
            this.label82.TabIndex = 54;
            this.label82.Text = "Servo Actual Velocity";
            // 
            // X_Live_Velocity
            // 
            this.X_Live_Velocity.AutoSize = true;
            this.X_Live_Velocity.BackColor = System.Drawing.Color.WhiteSmoke;
            this.X_Live_Velocity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.X_Live_Velocity.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.X_Live_Velocity.Location = new System.Drawing.Point(173, 66);
            this.X_Live_Velocity.Name = "X_Live_Velocity";
            this.X_Live_Velocity.Size = new System.Drawing.Size(18, 16);
            this.X_Live_Velocity.TabIndex = 55;
            this.X_Live_Velocity.Text = "0";
            this.X_Live_Velocity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox51
            // 
            this.groupBox51.Controls.Add(this.PTP_Stop);
            this.groupBox51.Controls.Add(this.PTP_Move);
            this.groupBox51.Controls.Add(this.Iteration);
            this.groupBox51.Controls.Add(this.Wait);
            this.groupBox51.Controls.Add(this.PTP_Speed);
            this.groupBox51.Controls.Add(this.label93);
            this.groupBox51.Controls.Add(this.label94);
            this.groupBox51.Controls.Add(this.PTP_End);
            this.groupBox51.Controls.Add(this.label97);
            this.groupBox51.Controls.Add(this.PTP_Start);
            this.groupBox51.Controls.Add(this.label99);
            this.groupBox51.Controls.Add(this.label102);
            this.groupBox51.Controls.Add(this.label103);
            this.groupBox51.Controls.Add(this.label104);
            this.groupBox51.Controls.Add(this.label105);
            this.groupBox51.Controls.Add(this.label116);
            this.groupBox51.Controls.Add(this.label117);
            this.groupBox51.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox51.Location = new System.Drawing.Point(247, 326);
            this.groupBox51.Name = "groupBox51";
            this.groupBox51.Size = new System.Drawing.Size(781, 150);
            this.groupBox51.TabIndex = 73;
            this.groupBox51.TabStop = false;
            this.groupBox51.Text = "Point To Point Control";
            // 
            // PTP_Stop
            // 
            this.PTP_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.PTP_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PTP_Stop.ForeColor = System.Drawing.Color.White;
            this.PTP_Stop.Location = new System.Drawing.Point(400, 103);
            this.PTP_Stop.Name = "PTP_Stop";
            this.PTP_Stop.Size = new System.Drawing.Size(83, 37);
            this.PTP_Stop.TabIndex = 71;
            this.PTP_Stop.Text = "Stop";
            this.PTP_Stop.UseVisualStyleBackColor = false;
            // 
            // PTP_Move
            // 
            this.PTP_Move.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.PTP_Move.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PTP_Move.ForeColor = System.Drawing.Color.White;
            this.PTP_Move.Location = new System.Drawing.Point(203, 103);
            this.PTP_Move.Name = "PTP_Move";
            this.PTP_Move.Size = new System.Drawing.Size(83, 37);
            this.PTP_Move.TabIndex = 70;
            this.PTP_Move.Text = "Move";
            this.PTP_Move.UseVisualStyleBackColor = false;
            // 
            // Iteration
            // 
            this.Iteration.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Iteration.Location = new System.Drawing.Point(603, 28);
            this.Iteration.Name = "Iteration";
            this.Iteration.Size = new System.Drawing.Size(66, 26);
            this.Iteration.TabIndex = 61;
            // 
            // Wait
            // 
            this.Wait.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Wait.Location = new System.Drawing.Point(336, 65);
            this.Wait.Name = "Wait";
            this.Wait.Size = new System.Drawing.Size(66, 26);
            this.Wait.TabIndex = 61;
            // 
            // PTP_Speed
            // 
            this.PTP_Speed.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PTP_Speed.Location = new System.Drawing.Point(336, 28);
            this.PTP_Speed.Name = "PTP_Speed";
            this.PTP_Speed.Size = new System.Drawing.Size(66, 26);
            this.PTP_Speed.TabIndex = 61;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(20, 77);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(84, 14);
            this.label93.TabIndex = 37;
            this.label93.Text = "End Position";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(12, 37);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(93, 14);
            this.label94.TabIndex = 37;
            this.label94.Text = "Start Position";
            // 
            // PTP_End
            // 
            this.PTP_End.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PTP_End.Location = new System.Drawing.Point(106, 72);
            this.PTP_End.Name = "PTP_End";
            this.PTP_End.Size = new System.Drawing.Size(66, 26);
            this.PTP_End.TabIndex = 59;
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(538, 37);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(62, 14);
            this.label97.TabIndex = 60;
            this.label97.Text = "Iteration";
            // 
            // PTP_Start
            // 
            this.PTP_Start.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PTP_Start.Location = new System.Drawing.Point(106, 33);
            this.PTP_Start.Name = "PTP_Start";
            this.PTP_Start.Size = new System.Drawing.Size(66, 26);
            this.PTP_Start.TabIndex = 59;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.Location = new System.Drawing.Point(295, 74);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(35, 14);
            this.label99.TabIndex = 60;
            this.label99.Text = "Wait";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(178, 77);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(37, 14);
            this.label102.TabIndex = 66;
            this.label102.Text = "(mm)";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(675, 37);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(39, 14);
            this.label103.TabIndex = 67;
            this.label103.Text = "count";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(286, 37);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(45, 14);
            this.label104.TabIndex = 60;
            this.label104.Text = "Speed";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(408, 74);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(25, 14);
            this.label105.TabIndex = 67;
            this.label105.Text = "sec";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(178, 37);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(37, 14);
            this.label116.TabIndex = 66;
            this.label116.Text = "(mm)";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(408, 37);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(47, 14);
            this.label117.TabIndex = 67;
            this.label117.Text = "(mm/s)";
            // 
            // groupBox52
            // 
            this.groupBox52.BackColor = System.Drawing.Color.White;
            this.groupBox52.Controls.Add(this.label128);
            this.groupBox52.Controls.Add(this.textBox8);
            this.groupBox52.Controls.Add(this.label129);
            this.groupBox52.Controls.Add(this.Jog_Negative);
            this.groupBox52.Controls.Add(this.Jog_Postive);
            this.groupBox52.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox52.Location = new System.Drawing.Point(794, 150);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Size = new System.Drawing.Size(234, 168);
            this.groupBox52.TabIndex = 72;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "Jog Control";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(174, 57);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(37, 14);
            this.label128.TabIndex = 77;
            this.label128.Text = "(mm)";
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(104, 50);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(66, 26);
            this.textBox8.TabIndex = 76;
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.Location = new System.Drawing.Point(18, 55);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(83, 14);
            this.label129.TabIndex = 75;
            this.label129.Text = "Jog Position";
            // 
            // Jog_Negative
            // 
            this.Jog_Negative.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Jog_Negative.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Jog_Negative.ForeColor = System.Drawing.Color.White;
            this.Jog_Negative.Location = new System.Drawing.Point(123, 104);
            this.Jog_Negative.Name = "Jog_Negative";
            this.Jog_Negative.Size = new System.Drawing.Size(83, 37);
            this.Jog_Negative.TabIndex = 74;
            this.Jog_Negative.Text = "Jog -";
            this.Jog_Negative.UseVisualStyleBackColor = false;
            // 
            // Jog_Postive
            // 
            this.Jog_Postive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Jog_Postive.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Jog_Postive.ForeColor = System.Drawing.Color.White;
            this.Jog_Postive.Location = new System.Drawing.Point(25, 104);
            this.Jog_Postive.Name = "Jog_Postive";
            this.Jog_Postive.Size = new System.Drawing.Size(83, 37);
            this.Jog_Postive.TabIndex = 73;
            this.Jog_Postive.Text = "Jog +";
            this.Jog_Postive.UseVisualStyleBackColor = false;
            // 
            // groupBox53
            // 
            this.groupBox53.BackColor = System.Drawing.Color.White;
            this.groupBox53.Controls.Add(this.Home_Stop);
            this.groupBox53.Controls.Add(this.Home_Move);
            this.groupBox53.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox53.Location = new System.Drawing.Point(506, 152);
            this.groupBox53.Name = "groupBox53";
            this.groupBox53.Size = new System.Drawing.Size(234, 168);
            this.groupBox53.TabIndex = 71;
            this.groupBox53.TabStop = false;
            this.groupBox53.Text = "Homing Control";
            // 
            // Home_Stop
            // 
            this.Home_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Home_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home_Stop.ForeColor = System.Drawing.Color.White;
            this.Home_Stop.Location = new System.Drawing.Point(124, 68);
            this.Home_Stop.Name = "Home_Stop";
            this.Home_Stop.Size = new System.Drawing.Size(83, 37);
            this.Home_Stop.TabIndex = 71;
            this.Home_Stop.Text = "Stop";
            this.Home_Stop.UseVisualStyleBackColor = false;
            // 
            // Home_Move
            // 
            this.Home_Move.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Home_Move.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home_Move.ForeColor = System.Drawing.Color.White;
            this.Home_Move.Location = new System.Drawing.Point(19, 68);
            this.Home_Move.Name = "Home_Move";
            this.Home_Move.Size = new System.Drawing.Size(83, 37);
            this.Home_Move.TabIndex = 72;
            this.Home_Move.Text = "Home";
            this.Home_Move.UseVisualStyleBackColor = false;
            // 
            // groupBox54
            // 
            this.groupBox54.BackColor = System.Drawing.Color.White;
            this.groupBox54.Controls.Add(this.Motion_Stop);
            this.groupBox54.Controls.Add(this.Motion_Move);
            this.groupBox54.Controls.Add(this.label139);
            this.groupBox54.Controls.Add(this.label140);
            this.groupBox54.Controls.Add(this.Motion_Speed);
            this.groupBox54.Controls.Add(this.label152);
            this.groupBox54.Controls.Add(this.Motion_Pos);
            this.groupBox54.Controls.Add(this.label153);
            this.groupBox54.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox54.Location = new System.Drawing.Point(247, 150);
            this.groupBox54.Name = "groupBox54";
            this.groupBox54.Size = new System.Drawing.Size(205, 168);
            this.groupBox54.TabIndex = 56;
            this.groupBox54.TabStop = false;
            this.groupBox54.Text = "Motion Control";
            // 
            // Motion_Stop
            // 
            this.Motion_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Motion_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Motion_Stop.ForeColor = System.Drawing.Color.White;
            this.Motion_Stop.Location = new System.Drawing.Point(111, 108);
            this.Motion_Stop.Name = "Motion_Stop";
            this.Motion_Stop.Size = new System.Drawing.Size(83, 37);
            this.Motion_Stop.TabIndex = 71;
            this.Motion_Stop.Text = "Stop";
            this.Motion_Stop.UseVisualStyleBackColor = false;
            // 
            // Motion_Move
            // 
            this.Motion_Move.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.Motion_Move.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Motion_Move.ForeColor = System.Drawing.Color.White;
            this.Motion_Move.Location = new System.Drawing.Point(18, 108);
            this.Motion_Move.Name = "Motion_Move";
            this.Motion_Move.Size = new System.Drawing.Size(83, 37);
            this.Motion_Move.TabIndex = 70;
            this.Motion_Move.Text = "Move";
            this.Motion_Move.UseVisualStyleBackColor = false;
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label139.Location = new System.Drawing.Point(147, 76);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(47, 14);
            this.label139.TabIndex = 67;
            this.label139.Text = "(mm/s)";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label140.Location = new System.Drawing.Point(147, 35);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(37, 14);
            this.label140.TabIndex = 66;
            this.label140.Text = "(mm)";
            // 
            // Motion_Speed
            // 
            this.Motion_Speed.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Motion_Speed.Location = new System.Drawing.Point(75, 67);
            this.Motion_Speed.Name = "Motion_Speed";
            this.Motion_Speed.Size = new System.Drawing.Size(66, 26);
            this.Motion_Speed.TabIndex = 61;
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label152.Location = new System.Drawing.Point(12, 72);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(45, 14);
            this.label152.TabIndex = 60;
            this.label152.Text = "Speed";
            // 
            // Motion_Pos
            // 
            this.Motion_Pos.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Motion_Pos.Location = new System.Drawing.Point(75, 30);
            this.Motion_Pos.Name = "Motion_Pos";
            this.Motion_Pos.Size = new System.Drawing.Size(66, 26);
            this.Motion_Pos.TabIndex = 59;
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label153.Location = new System.Drawing.Point(12, 34);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(57, 14);
            this.label153.TabIndex = 37;
            this.label153.Text = "Position";
            // 
            // groupBox55
            // 
            this.groupBox55.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox55.Controls.Add(this.Positive);
            this.groupBox55.Controls.Add(this.Servo_Error_Status);
            this.groupBox55.Controls.Add(this.label175);
            this.groupBox55.Controls.Add(this.label176);
            this.groupBox55.Controls.Add(this.Origin);
            this.groupBox55.Controls.Add(this.Servo_Home_Status);
            this.groupBox55.Controls.Add(this.Servo_Running_Status);
            this.groupBox55.Controls.Add(this.Servo_Ready_Status);
            this.groupBox55.Controls.Add(this.Negative);
            this.groupBox55.Controls.Add(this.Servo_Enable_Status);
            this.groupBox55.Controls.Add(this.label213);
            this.groupBox55.Controls.Add(this.label214);
            this.groupBox55.Controls.Add(this.label236);
            this.groupBox55.Controls.Add(this.label237);
            this.groupBox55.Controls.Add(this.label248);
            this.groupBox55.Controls.Add(this.label249);
            this.groupBox55.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox55.Location = new System.Drawing.Point(15, 15);
            this.groupBox55.Name = "groupBox55";
            this.groupBox55.Size = new System.Drawing.Size(688, 128);
            this.groupBox55.TabIndex = 37;
            this.groupBox55.TabStop = false;
            this.groupBox55.Text = "Device Status";
            // 
            // Positive
            // 
            this.Positive.BackColor = System.Drawing.Color.White;
            this.Positive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Positive.Location = new System.Drawing.Point(653, 87);
            this.Positive.Name = "Positive";
            this.Positive.Size = new System.Drawing.Size(26, 26);
            this.Positive.TabIndex = 59;
            // 
            // Servo_Error_Status
            // 
            this.Servo_Error_Status.BackColor = System.Drawing.Color.White;
            this.Servo_Error_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Servo_Error_Status.Location = new System.Drawing.Point(103, 87);
            this.Servo_Error_Status.Name = "Servo_Error_Status";
            this.Servo_Error_Status.Size = new System.Drawing.Size(26, 26);
            this.Servo_Error_Status.TabIndex = 58;
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label175.Location = new System.Drawing.Point(7, 93);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(93, 14);
            this.label175.TabIndex = 57;
            this.label175.Text = "Servo In Error";
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label176.Location = new System.Drawing.Point(558, 93);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(89, 14);
            this.label176.TabIndex = 56;
            this.label176.Text = "Positive Limit";
            // 
            // Origin
            // 
            this.Origin.BackColor = System.Drawing.Color.White;
            this.Origin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Origin.Location = new System.Drawing.Point(459, 90);
            this.Origin.Name = "Origin";
            this.Origin.Size = new System.Drawing.Size(26, 26);
            this.Origin.TabIndex = 48;
            // 
            // Servo_Home_Status
            // 
            this.Servo_Home_Status.BackColor = System.Drawing.Color.White;
            this.Servo_Home_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Servo_Home_Status.Location = new System.Drawing.Point(459, 36);
            this.Servo_Home_Status.Name = "Servo_Home_Status";
            this.Servo_Home_Status.Size = new System.Drawing.Size(26, 26);
            this.Servo_Home_Status.TabIndex = 48;
            // 
            // Servo_Running_Status
            // 
            this.Servo_Running_Status.BackColor = System.Drawing.Color.White;
            this.Servo_Running_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Servo_Running_Status.Location = new System.Drawing.Point(284, 87);
            this.Servo_Running_Status.Name = "Servo_Running_Status";
            this.Servo_Running_Status.Size = new System.Drawing.Size(26, 26);
            this.Servo_Running_Status.TabIndex = 47;
            // 
            // Servo_Ready_Status
            // 
            this.Servo_Ready_Status.BackColor = System.Drawing.Color.White;
            this.Servo_Ready_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Servo_Ready_Status.Location = new System.Drawing.Point(284, 33);
            this.Servo_Ready_Status.Name = "Servo_Ready_Status";
            this.Servo_Ready_Status.Size = new System.Drawing.Size(26, 26);
            this.Servo_Ready_Status.TabIndex = 46;
            // 
            // Negative
            // 
            this.Negative.BackColor = System.Drawing.Color.White;
            this.Negative.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Negative.Location = new System.Drawing.Point(653, 33);
            this.Negative.Name = "Negative";
            this.Negative.Size = new System.Drawing.Size(26, 26);
            this.Negative.TabIndex = 45;
            // 
            // Servo_Enable_Status
            // 
            this.Servo_Enable_Status.BackColor = System.Drawing.Color.White;
            this.Servo_Enable_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Servo_Enable_Status.Location = new System.Drawing.Point(103, 33);
            this.Servo_Enable_Status.Name = "Servo_Enable_Status";
            this.Servo_Enable_Status.Size = new System.Drawing.Size(26, 26);
            this.Servo_Enable_Status.TabIndex = 45;
            // 
            // label213
            // 
            this.label213.AutoSize = true;
            this.label213.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label213.Location = new System.Drawing.Point(410, 96);
            this.label213.Name = "label213";
            this.label213.Size = new System.Drawing.Size(43, 14);
            this.label213.TabIndex = 41;
            this.label213.Text = "Origin";
            // 
            // label214
            // 
            this.label214.AutoSize = true;
            this.label214.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label214.Location = new System.Drawing.Point(183, 93);
            this.label214.Name = "label214";
            this.label214.Size = new System.Drawing.Size(98, 14);
            this.label214.TabIndex = 43;
            this.label214.Text = "Servo Running";
            // 
            // label236
            // 
            this.label236.AutoSize = true;
            this.label236.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label236.Location = new System.Drawing.Point(375, 42);
            this.label236.Name = "label236";
            this.label236.Size = new System.Drawing.Size(81, 14);
            this.label236.TabIndex = 41;
            this.label236.Text = "Servo Home";
            // 
            // label237
            // 
            this.label237.AutoSize = true;
            this.label237.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label237.Location = new System.Drawing.Point(553, 39);
            this.label237.Name = "label237";
            this.label237.Size = new System.Drawing.Size(94, 14);
            this.label237.TabIndex = 37;
            this.label237.Text = "Negative Limit";
            // 
            // label248
            // 
            this.label248.AutoSize = true;
            this.label248.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label248.Location = new System.Drawing.Point(197, 39);
            this.label248.Name = "label248";
            this.label248.Size = new System.Drawing.Size(84, 14);
            this.label248.TabIndex = 39;
            this.label248.Text = "Servo Ready";
            // 
            // label249
            // 
            this.label249.AutoSize = true;
            this.label249.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label249.Location = new System.Drawing.Point(14, 39);
            this.label249.Name = "label249";
            this.label249.Size = new System.Drawing.Size(86, 14);
            this.label249.TabIndex = 37;
            this.label249.Text = "Servo Enable";
            // 
            // tabPage22
            // 
            this.tabPage22.BackColor = System.Drawing.Color.White;
            this.tabPage22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage22.Controls.Add(this.groupBox2);
            this.tabPage22.Location = new System.Drawing.Point(4, 30);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Size = new System.Drawing.Size(1075, 478);
            this.tabPage22.TabIndex = 1;
            this.tabPage22.Text = "Y - Axis";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox5);
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.groupBox7);
            this.groupBox2.Controls.Add(this.groupBox8);
            this.groupBox2.Controls.Add(this.groupBox9);
            this.groupBox2.Controls.Add(this.groupBox10);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(10, -5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1053, 485);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Enabled = false;
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(16, 330);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(177, 145);
            this.groupBox3.TabIndex = 76;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Break Control";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(9, 34);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(148, 37);
            this.button3.TabIndex = 71;
            this.button3.Text = "Break Enable";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(9, 85);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(148, 37);
            this.button4.TabIndex = 71;
            this.button4.Text = "Break Disable";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.button6);
            this.groupBox4.Controls.Add(this.button13);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(16, 150);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(177, 168);
            this.groupBox4.TabIndex = 75;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Device Control";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(11, 26);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(148, 37);
            this.button5.TabIndex = 71;
            this.button5.Text = "Servo Enable";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(11, 114);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(148, 37);
            this.button6.TabIndex = 71;
            this.button6.Text = "Servo Clear Error";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button13.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(11, 70);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(148, 37);
            this.button13.TabIndex = 71;
            this.button13.Text = "Servo Disable";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(732, 15);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(297, 128);
            this.groupBox5.TabIndex = 74;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Live Values";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(231, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 14);
            this.label4.TabIndex = 73;
            this.label4.Text = "(mm/s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(173, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 16);
            this.label5.TabIndex = 53;
            this.label5.Text = "0";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(231, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 14);
            this.label6.TabIndex = 75;
            this.label6.Text = "(mm)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(10, 95);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 14);
            this.label7.TabIndex = 33;
            this.label7.Text = "Servo Status";
            this.label7.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(173, 95);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 16);
            this.label8.TabIndex = 50;
            this.label8.Text = "0";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(9, 39);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(139, 14);
            this.label10.TabIndex = 52;
            this.label10.Text = "Servo Actual Position";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 14);
            this.label11.TabIndex = 54;
            this.label11.Text = "Servo Actual Velocity";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(173, 66);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 16);
            this.label12.TabIndex = 55;
            this.label12.Text = "0";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button15);
            this.groupBox6.Controls.Add(this.button16);
            this.groupBox6.Controls.Add(this.textBox1);
            this.groupBox6.Controls.Add(this.textBox2);
            this.groupBox6.Controls.Add(this.textBox3);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.label14);
            this.groupBox6.Controls.Add(this.textBox4);
            this.groupBox6.Controls.Add(this.label15);
            this.groupBox6.Controls.Add(this.textBox5);
            this.groupBox6.Controls.Add(this.label16);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label22);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(247, 326);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(781, 150);
            this.groupBox6.TabIndex = 73;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Point To Point Control";
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button15.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(400, 103);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(83, 37);
            this.button15.TabIndex = 71;
            this.button15.Text = "Stop";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button16.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(203, 103);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(83, 37);
            this.button16.TabIndex = 70;
            this.button16.Text = "Move";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(603, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(66, 26);
            this.textBox1.TabIndex = 61;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(336, 65);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(66, 26);
            this.textBox2.TabIndex = 61;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(336, 28);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(66, 26);
            this.textBox3.TabIndex = 61;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(20, 77);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 14);
            this.label13.TabIndex = 37;
            this.label13.Text = "End Position";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(12, 37);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 14);
            this.label14.TabIndex = 37;
            this.label14.Text = "Start Position";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(106, 72);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(66, 26);
            this.textBox4.TabIndex = 59;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(538, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 14);
            this.label15.TabIndex = 60;
            this.label15.Text = "Iteration";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(106, 33);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(66, 26);
            this.textBox5.TabIndex = 59;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(295, 74);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 14);
            this.label16.TabIndex = 60;
            this.label16.Text = "Wait";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(178, 77);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 14);
            this.label17.TabIndex = 66;
            this.label17.Text = "(mm)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(675, 37);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 14);
            this.label18.TabIndex = 67;
            this.label18.Text = "count";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(286, 37);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 14);
            this.label19.TabIndex = 60;
            this.label19.Text = "Speed";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(408, 74);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(25, 14);
            this.label22.TabIndex = 67;
            this.label22.Text = "sec";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(178, 37);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(37, 14);
            this.label23.TabIndex = 66;
            this.label23.Text = "(mm)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(408, 37);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(47, 14);
            this.label25.TabIndex = 67;
            this.label25.Text = "(mm/s)";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.White;
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.textBox6);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.button17);
            this.groupBox7.Controls.Add(this.button18);
            this.groupBox7.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(794, 150);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(234, 168);
            this.groupBox7.TabIndex = 72;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Jog Control";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(174, 57);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(37, 14);
            this.label27.TabIndex = 77;
            this.label27.Text = "(mm)";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(104, 50);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(66, 26);
            this.textBox6.TabIndex = 76;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(18, 55);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(83, 14);
            this.label32.TabIndex = 75;
            this.label32.Text = "Jog Position";
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button17.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Location = new System.Drawing.Point(123, 104);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(83, 37);
            this.button17.TabIndex = 74;
            this.button17.Text = "Jog -";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button18.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(25, 104);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(83, 37);
            this.button18.TabIndex = 73;
            this.button18.Text = "Jog +";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.White;
            this.groupBox8.Controls.Add(this.button19);
            this.groupBox8.Controls.Add(this.button20);
            this.groupBox8.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(506, 152);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(234, 168);
            this.groupBox8.TabIndex = 71;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Homing Control";
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button19.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.ForeColor = System.Drawing.Color.White;
            this.button19.Location = new System.Drawing.Point(124, 68);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(83, 37);
            this.button19.TabIndex = 71;
            this.button19.Text = "Stop";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button20.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.ForeColor = System.Drawing.Color.White;
            this.button20.Location = new System.Drawing.Point(19, 68);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(83, 37);
            this.button20.TabIndex = 72;
            this.button20.Text = "Home";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.White;
            this.groupBox9.Controls.Add(this.button21);
            this.groupBox9.Controls.Add(this.button22);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.textBox7);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Controls.Add(this.textBox9);
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(247, 150);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(205, 168);
            this.groupBox9.TabIndex = 56;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Motion Control";
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button21.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Location = new System.Drawing.Point(111, 108);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(83, 37);
            this.button21.TabIndex = 71;
            this.button21.Text = "Stop";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button22.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(18, 108);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(83, 37);
            this.button22.TabIndex = 70;
            this.button22.Text = "Move";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(147, 76);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(47, 14);
            this.label33.TabIndex = 67;
            this.label33.Text = "(mm/s)";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(147, 35);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(37, 14);
            this.label34.TabIndex = 66;
            this.label34.Text = "(mm)";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(75, 67);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(66, 26);
            this.textBox7.TabIndex = 61;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(12, 72);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(45, 14);
            this.label35.TabIndex = 60;
            this.label35.Text = "Speed";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(75, 30);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(66, 26);
            this.textBox9.TabIndex = 59;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(12, 34);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(57, 14);
            this.label36.TabIndex = 37;
            this.label36.Text = "Position";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox10.Controls.Add(this.label37);
            this.groupBox10.Controls.Add(this.label38);
            this.groupBox10.Controls.Add(this.label39);
            this.groupBox10.Controls.Add(this.label40);
            this.groupBox10.Controls.Add(this.label41);
            this.groupBox10.Controls.Add(this.label42);
            this.groupBox10.Controls.Add(this.label43);
            this.groupBox10.Controls.Add(this.label46);
            this.groupBox10.Controls.Add(this.label47);
            this.groupBox10.Controls.Add(this.label48);
            this.groupBox10.Controls.Add(this.label49);
            this.groupBox10.Controls.Add(this.label50);
            this.groupBox10.Controls.Add(this.label51);
            this.groupBox10.Controls.Add(this.label52);
            this.groupBox10.Controls.Add(this.label53);
            this.groupBox10.Controls.Add(this.label54);
            this.groupBox10.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(15, 15);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(688, 128);
            this.groupBox10.TabIndex = 37;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Device Status";
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.White;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Location = new System.Drawing.Point(653, 87);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(26, 26);
            this.label37.TabIndex = 59;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.White;
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Location = new System.Drawing.Point(103, 87);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(26, 26);
            this.label38.TabIndex = 58;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(7, 93);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(93, 14);
            this.label39.TabIndex = 57;
            this.label39.Text = "Servo In Error";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(558, 93);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(89, 14);
            this.label40.TabIndex = 56;
            this.label40.Text = "Positive Limit";
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.White;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label41.Location = new System.Drawing.Point(459, 90);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(26, 26);
            this.label41.TabIndex = 48;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.White;
            this.label42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label42.Location = new System.Drawing.Point(459, 36);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(26, 26);
            this.label42.TabIndex = 48;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.White;
            this.label43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label43.Location = new System.Drawing.Point(284, 87);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(26, 26);
            this.label43.TabIndex = 47;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.White;
            this.label46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label46.Location = new System.Drawing.Point(284, 33);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(26, 26);
            this.label46.TabIndex = 46;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.White;
            this.label47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label47.Location = new System.Drawing.Point(653, 33);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(26, 26);
            this.label47.TabIndex = 45;
            // 
            // label48
            // 
            this.label48.BackColor = System.Drawing.Color.White;
            this.label48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label48.Location = new System.Drawing.Point(103, 33);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(26, 26);
            this.label48.TabIndex = 45;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(410, 96);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(43, 14);
            this.label49.TabIndex = 41;
            this.label49.Text = "Origin";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(183, 93);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(98, 14);
            this.label50.TabIndex = 43;
            this.label50.Text = "Servo Running";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(375, 42);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(81, 14);
            this.label51.TabIndex = 41;
            this.label51.Text = "Servo Home";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(553, 39);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(94, 14);
            this.label52.TabIndex = 37;
            this.label52.Text = "Negative Limit";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(197, 39);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(84, 14);
            this.label53.TabIndex = 39;
            this.label53.Text = "Servo Ready";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(14, 39);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(86, 14);
            this.label54.TabIndex = 37;
            this.label54.Text = "Servo Enable";
            // 
            // tabPage16
            // 
            this.tabPage16.BackColor = System.Drawing.Color.White;
            this.tabPage16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage16.Controls.Add(this.tabControl6);
            this.tabPage16.Location = new System.Drawing.Point(4, 30);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Size = new System.Drawing.Size(1262, 582);
            this.tabPage16.TabIndex = 8;
            this.tabPage16.Text = "Vacuum";
            // 
            // tabControl6
            // 
            this.tabControl6.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl6.Controls.Add(this.tabPage19);
            this.tabControl6.Controls.Add(this.tabPage21);
            this.tabControl6.Location = new System.Drawing.Point(30, 31);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(1211, 468);
            this.tabControl6.TabIndex = 2;
            // 
            // tabPage19
            // 
            this.tabPage19.BackColor = System.Drawing.Color.White;
            this.tabPage19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage19.Controls.Add(this.groupBox140);
            this.tabPage19.Location = new System.Drawing.Point(4, 30);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Size = new System.Drawing.Size(1203, 434);
            this.tabPage19.TabIndex = 9;
            this.tabPage19.Text = "Streamline 2";
            // 
            // groupBox140
            // 
            this.groupBox140.BackColor = System.Drawing.Color.White;
            this.groupBox140.Controls.Add(this.HSG2_VACUUM_FB);
            this.groupBox140.Controls.Add(this.button107);
            this.groupBox140.Controls.Add(this.button108);
            this.groupBox140.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox140.Location = new System.Drawing.Point(45, 34);
            this.groupBox140.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox140.Name = "groupBox140";
            this.groupBox140.Padding = new System.Windows.Forms.Padding(5, 0, 5, 2);
            this.groupBox140.Size = new System.Drawing.Size(182, 88);
            this.groupBox140.TabIndex = 12;
            this.groupBox140.TabStop = false;
            this.groupBox140.Text = "HSG Suction";
            // 
            // HSG2_VACUUM_FB
            // 
            this.HSG2_VACUUM_FB.BackColor = System.Drawing.Color.WhiteSmoke;
            this.HSG2_VACUUM_FB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HSG2_VACUUM_FB.Font = new System.Drawing.Font("Microsoft YaHei", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HSG2_VACUUM_FB.Location = new System.Drawing.Point(20, 53);
            this.HSG2_VACUUM_FB.Name = "HSG2_VACUUM_FB";
            this.HSG2_VACUUM_FB.Size = new System.Drawing.Size(74, 16);
            this.HSG2_VACUUM_FB.TabIndex = 12;
            this.HSG2_VACUUM_FB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button107.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button107.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button107.Location = new System.Drawing.Point(20, 28);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(74, 25);
            this.button107.TabIndex = 7;
            this.button107.Text = "Vacuum";
            this.button107.UseVisualStyleBackColor = false;
            this.button107.Click += new System.EventHandler(this.button107_Click);
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button108.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button108.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button108.Location = new System.Drawing.Point(100, 28);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(59, 25);
            this.button108.TabIndex = 11;
            this.button108.Text = "Close";
            this.button108.UseVisualStyleBackColor = false;
            this.button108.Click += new System.EventHandler(this.button108_Click);
            // 
            // tabPage21
            // 
            this.tabPage21.BackColor = System.Drawing.Color.White;
            this.tabPage21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage21.Controls.Add(this.groupBox141);
            this.tabPage21.Location = new System.Drawing.Point(4, 30);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Size = new System.Drawing.Size(1203, 434);
            this.tabPage21.TabIndex = 10;
            this.tabPage21.Text = "Streamline 3";
            // 
            // groupBox141
            // 
            this.groupBox141.BackColor = System.Drawing.Color.White;
            this.groupBox141.Controls.Add(this.HSG3_VACUUM_FB);
            this.groupBox141.Controls.Add(this.button109);
            this.groupBox141.Controls.Add(this.button110);
            this.groupBox141.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox141.Location = new System.Drawing.Point(46, 33);
            this.groupBox141.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox141.Name = "groupBox141";
            this.groupBox141.Padding = new System.Windows.Forms.Padding(5, 0, 5, 2);
            this.groupBox141.Size = new System.Drawing.Size(182, 88);
            this.groupBox141.TabIndex = 13;
            this.groupBox141.TabStop = false;
            this.groupBox141.Text = "HSG Suction";
            // 
            // HSG3_VACUUM_FB
            // 
            this.HSG3_VACUUM_FB.BackColor = System.Drawing.Color.WhiteSmoke;
            this.HSG3_VACUUM_FB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HSG3_VACUUM_FB.Font = new System.Drawing.Font("Microsoft YaHei", 7.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.HSG3_VACUUM_FB.Location = new System.Drawing.Point(20, 53);
            this.HSG3_VACUUM_FB.Name = "HSG3_VACUUM_FB";
            this.HSG3_VACUUM_FB.Size = new System.Drawing.Size(74, 16);
            this.HSG3_VACUUM_FB.TabIndex = 12;
            this.HSG3_VACUUM_FB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button109
            // 
            this.button109.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button109.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button109.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button109.Location = new System.Drawing.Point(20, 28);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(74, 25);
            this.button109.TabIndex = 7;
            this.button109.Text = "Vacuum";
            this.button109.UseVisualStyleBackColor = false;
            this.button109.Click += new System.EventHandler(this.button109_Click);
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.Color.WhiteSmoke;
            this.button110.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button110.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button110.Location = new System.Drawing.Point(100, 28);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(59, 25);
            this.button110.TabIndex = 11;
            this.button110.Text = "Close";
            this.button110.UseVisualStyleBackColor = false;
            this.button110.Click += new System.EventHandler(this.button110_Click);
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.Color.White;
            this.tabPage12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tabPage12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage12.Controls.Add(this.groupBox134);
            this.tabPage12.Location = new System.Drawing.Point(4, 30);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(1262, 582);
            this.tabPage12.TabIndex = 5;
            this.tabPage12.Text = "Camera";
            // 
            // groupBox134
            // 
            this.groupBox134.Controls.Add(this.CCD_RECEIVE_DATA5);
            this.groupBox134.Controls.Add(this.CCD_RECEIVE_DATA4);
            this.groupBox134.Controls.Add(this.CCD_RECEIVE_DATA3);
            this.groupBox134.Controls.Add(this.CCD_STATUS);
            this.groupBox134.Controls.Add(this.CCD_Connect);
            this.groupBox134.Controls.Add(this.CCD_SEND_DATA);
            this.groupBox134.Controls.Add(this.CCD_RECEIVE_DATA1);
            this.groupBox134.Controls.Add(this.label576);
            this.groupBox134.Controls.Add(this.CCD_TRIGGER);
            this.groupBox134.Controls.Add(this.label577);
            this.groupBox134.Controls.Add(this.label578);
            this.groupBox134.Location = new System.Drawing.Point(317, 129);
            this.groupBox134.Name = "groupBox134";
            this.groupBox134.Size = new System.Drawing.Size(820, 289);
            this.groupBox134.TabIndex = 157;
            this.groupBox134.TabStop = false;
            this.groupBox134.Text = "CCD";
            // 
            // CCD_RECEIVE_DATA5
            // 
            this.CCD_RECEIVE_DATA5.AccessibleName = "";
            this.CCD_RECEIVE_DATA5.BackColor = System.Drawing.Color.White;
            this.CCD_RECEIVE_DATA5.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD_RECEIVE_DATA5.Location = new System.Drawing.Point(680, 96);
            this.CCD_RECEIVE_DATA5.Name = "CCD_RECEIVE_DATA5";
            this.CCD_RECEIVE_DATA5.ReadOnly = true;
            this.CCD_RECEIVE_DATA5.Size = new System.Drawing.Size(113, 122);
            this.CCD_RECEIVE_DATA5.TabIndex = 160;
            this.CCD_RECEIVE_DATA5.Text = "";
            // 
            // CCD_RECEIVE_DATA4
            // 
            this.CCD_RECEIVE_DATA4.AccessibleName = "";
            this.CCD_RECEIVE_DATA4.BackColor = System.Drawing.Color.White;
            this.CCD_RECEIVE_DATA4.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD_RECEIVE_DATA4.Location = new System.Drawing.Point(561, 96);
            this.CCD_RECEIVE_DATA4.Name = "CCD_RECEIVE_DATA4";
            this.CCD_RECEIVE_DATA4.ReadOnly = true;
            this.CCD_RECEIVE_DATA4.Size = new System.Drawing.Size(113, 122);
            this.CCD_RECEIVE_DATA4.TabIndex = 159;
            this.CCD_RECEIVE_DATA4.Text = "";
            // 
            // CCD_RECEIVE_DATA3
            // 
            this.CCD_RECEIVE_DATA3.AccessibleName = "";
            this.CCD_RECEIVE_DATA3.BackColor = System.Drawing.Color.White;
            this.CCD_RECEIVE_DATA3.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD_RECEIVE_DATA3.Location = new System.Drawing.Point(442, 96);
            this.CCD_RECEIVE_DATA3.Name = "CCD_RECEIVE_DATA3";
            this.CCD_RECEIVE_DATA3.ReadOnly = true;
            this.CCD_RECEIVE_DATA3.Size = new System.Drawing.Size(113, 122);
            this.CCD_RECEIVE_DATA3.TabIndex = 158;
            this.CCD_RECEIVE_DATA3.Text = "";
            this.CCD_RECEIVE_DATA3.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // CCD_STATUS
            // 
            this.CCD_STATUS.BackColor = System.Drawing.Color.Maroon;
            this.CCD_STATUS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CCD_STATUS.Location = new System.Drawing.Point(755, 24);
            this.CCD_STATUS.Name = "CCD_STATUS";
            this.CCD_STATUS.Size = new System.Drawing.Size(26, 26);
            this.CCD_STATUS.TabIndex = 157;
            // 
            // CCD_Connect
            // 
            this.CCD_Connect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.CCD_Connect.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD_Connect.ForeColor = System.Drawing.Color.White;
            this.CCD_Connect.Location = new System.Drawing.Point(206, 236);
            this.CCD_Connect.Name = "CCD_Connect";
            this.CCD_Connect.Size = new System.Drawing.Size(99, 35);
            this.CCD_Connect.TabIndex = 152;
            this.CCD_Connect.Text = "Connect";
            this.CCD_Connect.UseVisualStyleBackColor = false;
            this.CCD_Connect.Click += new System.EventHandler(this.CCD_Connect_Click);
            // 
            // CCD_SEND_DATA
            // 
            this.CCD_SEND_DATA.AccessibleName = "";
            this.CCD_SEND_DATA.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD_SEND_DATA.Location = new System.Drawing.Point(16, 95);
            this.CCD_SEND_DATA.Name = "CCD_SEND_DATA";
            this.CCD_SEND_DATA.Size = new System.Drawing.Size(281, 122);
            this.CCD_SEND_DATA.TabIndex = 154;
            this.CCD_SEND_DATA.Text = "";
            // 
            // CCD_RECEIVE_DATA1
            // 
            this.CCD_RECEIVE_DATA1.AccessibleName = "";
            this.CCD_RECEIVE_DATA1.BackColor = System.Drawing.Color.White;
            this.CCD_RECEIVE_DATA1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD_RECEIVE_DATA1.Location = new System.Drawing.Point(323, 95);
            this.CCD_RECEIVE_DATA1.Name = "CCD_RECEIVE_DATA1";
            this.CCD_RECEIVE_DATA1.ReadOnly = true;
            this.CCD_RECEIVE_DATA1.Size = new System.Drawing.Size(113, 122);
            this.CCD_RECEIVE_DATA1.TabIndex = 154;
            this.CCD_RECEIVE_DATA1.Text = "";
            this.CCD_RECEIVE_DATA1.TextChanged += new System.EventHandler(this.CCD_RECEIVE_DATA_TextChanged);
            // 
            // label576
            // 
            this.label576.AutoSize = true;
            this.label576.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label576.Location = new System.Drawing.Point(133, 78);
            this.label576.Name = "label576";
            this.label576.Size = new System.Drawing.Size(38, 14);
            this.label576.TabIndex = 152;
            this.label576.Text = "Send";
            // 
            // CCD_TRIGGER
            // 
            this.CCD_TRIGGER.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.CCD_TRIGGER.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD_TRIGGER.ForeColor = System.Drawing.Color.White;
            this.CCD_TRIGGER.Location = new System.Drawing.Point(311, 236);
            this.CCD_TRIGGER.Name = "CCD_TRIGGER";
            this.CCD_TRIGGER.Size = new System.Drawing.Size(99, 35);
            this.CCD_TRIGGER.TabIndex = 144;
            this.CCD_TRIGGER.Text = "Trigger";
            this.CCD_TRIGGER.UseVisualStyleBackColor = false;
            this.CCD_TRIGGER.Click += new System.EventHandler(this.CCD_TRIGGER_Click);
            // 
            // label577
            // 
            this.label577.AutoSize = true;
            this.label577.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label577.Location = new System.Drawing.Point(677, 24);
            this.label577.Name = "label577";
            this.label577.Size = new System.Drawing.Size(77, 28);
            this.label577.TabIndex = 152;
            this.label577.Text = "Connection\r\nStatus";
            this.label577.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label578
            // 
            this.label578.AutoSize = true;
            this.label578.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label578.Location = new System.Drawing.Point(530, 78);
            this.label578.Name = "label578";
            this.label578.Size = new System.Drawing.Size(61, 14);
            this.label578.TabIndex = 152;
            this.label578.Text = "Received";
            // 
            // tabPage14
            // 
            this.tabPage14.BackColor = System.Drawing.Color.White;
            this.tabPage14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage14.Controls.Add(this.groupBox14);
            this.tabPage14.Location = new System.Drawing.Point(4, 30);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Size = new System.Drawing.Size(1262, 582);
            this.tabPage14.TabIndex = 6;
            this.tabPage14.Text = "Scanner";
            this.tabPage14.Click += new System.EventHandler(this.tabPage14_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.SCANNER_STATUS);
            this.groupBox14.Controls.Add(this.SCANNER_CONNECT);
            this.groupBox14.Controls.Add(this.SCANNER_SEND_DATA);
            this.groupBox14.Controls.Add(this.SCANNER_RECEIVE_DATA);
            this.groupBox14.Controls.Add(this.label9);
            this.groupBox14.Controls.Add(this.button14);
            this.groupBox14.Controls.Add(this.label21);
            this.groupBox14.Controls.Add(this.label29);
            this.groupBox14.Location = new System.Drawing.Point(315, 134);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(623, 289);
            this.groupBox14.TabIndex = 158;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Scanner";
            // 
            // SCANNER_STATUS
            // 
            this.SCANNER_STATUS.BackColor = System.Drawing.Color.Maroon;
            this.SCANNER_STATUS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SCANNER_STATUS.Location = new System.Drawing.Point(579, 24);
            this.SCANNER_STATUS.Name = "SCANNER_STATUS";
            this.SCANNER_STATUS.Size = new System.Drawing.Size(26, 26);
            this.SCANNER_STATUS.TabIndex = 157;
            // 
            // SCANNER_CONNECT
            // 
            this.SCANNER_CONNECT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.SCANNER_CONNECT.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SCANNER_CONNECT.ForeColor = System.Drawing.Color.White;
            this.SCANNER_CONNECT.Location = new System.Drawing.Point(206, 236);
            this.SCANNER_CONNECT.Name = "SCANNER_CONNECT";
            this.SCANNER_CONNECT.Size = new System.Drawing.Size(99, 35);
            this.SCANNER_CONNECT.TabIndex = 152;
            this.SCANNER_CONNECT.Text = "Connect";
            this.SCANNER_CONNECT.UseVisualStyleBackColor = false;
            this.SCANNER_CONNECT.Click += new System.EventHandler(this.SCANNER_CONNECT_Click);
            // 
            // SCANNER_SEND_DATA
            // 
            this.SCANNER_SEND_DATA.AccessibleName = "";
            this.SCANNER_SEND_DATA.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SCANNER_SEND_DATA.Location = new System.Drawing.Point(16, 95);
            this.SCANNER_SEND_DATA.Name = "SCANNER_SEND_DATA";
            this.SCANNER_SEND_DATA.Size = new System.Drawing.Size(281, 122);
            this.SCANNER_SEND_DATA.TabIndex = 154;
            this.SCANNER_SEND_DATA.Text = "";
            // 
            // SCANNER_RECEIVE_DATA
            // 
            this.SCANNER_RECEIVE_DATA.AccessibleName = "";
            this.SCANNER_RECEIVE_DATA.BackColor = System.Drawing.Color.White;
            this.SCANNER_RECEIVE_DATA.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SCANNER_RECEIVE_DATA.Location = new System.Drawing.Point(323, 95);
            this.SCANNER_RECEIVE_DATA.Name = "SCANNER_RECEIVE_DATA";
            this.SCANNER_RECEIVE_DATA.ReadOnly = true;
            this.SCANNER_RECEIVE_DATA.Size = new System.Drawing.Size(275, 122);
            this.SCANNER_RECEIVE_DATA.TabIndex = 154;
            this.SCANNER_RECEIVE_DATA.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(133, 78);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 14);
            this.label9.TabIndex = 152;
            this.label9.Text = "Send";
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button14.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(311, 236);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(99, 35);
            this.button14.TabIndex = 144;
            this.button14.Text = "Trigger";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(501, 24);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 28);
            this.label21.TabIndex = 152;
            this.label21.Text = "Connection\r\nStatus";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(429, 78);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(61, 14);
            this.label29.TabIndex = 152;
            this.label29.Text = "Received";
            // 
            // Input_Feedback
            // 
            this.Input_Feedback.Enabled = true;
            this.Input_Feedback.Tick += new System.EventHandler(this.Input_Feedback_Tick);
            // 
            // label280
            // 
            this.label280.AutoSize = true;
            this.label280.BackColor = System.Drawing.Color.Gainsboro;
            this.label280.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold);
            this.label280.Location = new System.Drawing.Point(562, 9);
            this.label280.Name = "label280";
            this.label280.Size = new System.Drawing.Size(215, 29);
            this.label280.TabIndex = 2;
            this.label280.Text = "MANUAL MODE";
            // 
            // Manual_Screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1270, 788);
            this.Controls.Add(this.label280);
            this.Controls.Add(this.tabControl2);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(6, 140);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1270, 839);
            this.MinimizeBox = false;
            this.Name = "Manual_Screen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Manual_Screen";
            this.Load += new System.EventHandler(this.Manual_Screen_Load);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.groupBox71.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox44.ResumeLayout(false);
            this.groupBox44.PerformLayout();
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox47.ResumeLayout(false);
            this.groupBox48.ResumeLayout(false);
            this.groupBox49.ResumeLayout(false);
            this.groupBox50.ResumeLayout(false);
            this.groupBox50.PerformLayout();
            this.groupBox51.ResumeLayout(false);
            this.groupBox51.PerformLayout();
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.groupBox53.ResumeLayout(false);
            this.groupBox54.ResumeLayout(false);
            this.groupBox54.PerformLayout();
            this.groupBox55.ResumeLayout(false);
            this.groupBox55.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage19.ResumeLayout(false);
            this.groupBox140.ResumeLayout(false);
            this.tabPage21.ResumeLayout(false);
            this.groupBox141.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.groupBox134.ResumeLayout(false);
            this.groupBox134.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label28;
        //private DevExpress.XtraBars.Ribbon.GalleryDropDown galleryDropDown1;
        private System.Windows.Forms.ContextMenuStrip galleryDropDown1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label SL3_STATUS;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button SL3_STOP;
        private System.Windows.Forms.Button SL3_START;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label SL2_STATUS;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button SL2_STOP;
        private System.Windows.Forms.Button SL2_START;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.ComboBox Conveyor_Direction;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label SL1_STATUS;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button SL1_STOP;
        private System.Windows.Forms.Button SL1_Start;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox71;
        private System.Windows.Forms.Button btn_Off;
        private System.Windows.Forms.Panel on_panel;
        private System.Windows.Forms.Panel off_panel;
        private System.Windows.Forms.Button btn_ON;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.GroupBox groupBox134;
        private System.Windows.Forms.Label CCD_STATUS;
        private System.Windows.Forms.Button CCD_Connect;
        public System.Windows.Forms.RichTextBox CCD_SEND_DATA;
        public System.Windows.Forms.RichTextBox CCD_RECEIVE_DATA1;
        private System.Windows.Forms.Label label576;
        private System.Windows.Forms.Button CCD_TRIGGER;
        private System.Windows.Forms.Label label577;
        private System.Windows.Forms.Label label578;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.ComboBox SL3_SPEED;
        private System.Windows.Forms.ComboBox SL2_SPEED;
        private System.Windows.Forms.ComboBox SL1_SPEED;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.GroupBox groupBox140;
        private System.Windows.Forms.Label HSG2_VACUUM_FB;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.GroupBox groupBox141;
        private System.Windows.Forms.Label HSG3_VACUUM_FB;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Timer Input_Feedback;
        private System.Windows.Forms.Timer Servo_live_values;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label SCANNER_STATUS;
        private System.Windows.Forms.Button SCANNER_CONNECT;
        public System.Windows.Forms.RichTextBox SCANNER_SEND_DATA;
        public System.Windows.Forms.RichTextBox SCANNER_RECEIVE_DATA;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label280;
        public System.Windows.Forms.RichTextBox CCD_RECEIVE_DATA5;
        public System.Windows.Forms.RichTextBox CCD_RECEIVE_DATA4;
        public System.Windows.Forms.RichTextBox CCD_RECEIVE_DATA3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox47;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.Button Servo_Break_On;
        private System.Windows.Forms.Button Servo_Break_Off;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.Button Servo_Enable;
        private System.Windows.Forms.Button Serfo_Error_Clear;
        private System.Windows.Forms.Button Servo_Disable;
        private System.Windows.Forms.GroupBox groupBox50;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label X_Live_Position;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label Servo_Live_Status;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label X_Live_Velocity;
        private System.Windows.Forms.GroupBox groupBox51;
        private System.Windows.Forms.Button PTP_Stop;
        private System.Windows.Forms.Button PTP_Move;
        private System.Windows.Forms.TextBox Iteration;
        private System.Windows.Forms.TextBox Wait;
        private System.Windows.Forms.TextBox PTP_Speed;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.TextBox PTP_End;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.TextBox PTP_Start;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Button Jog_Negative;
        private System.Windows.Forms.Button Jog_Postive;
        private System.Windows.Forms.GroupBox groupBox53;
        private System.Windows.Forms.Button Home_Stop;
        private System.Windows.Forms.Button Home_Move;
        private System.Windows.Forms.GroupBox groupBox54;
        private System.Windows.Forms.Button Motion_Stop;
        private System.Windows.Forms.Button Motion_Move;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.TextBox Motion_Speed;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.TextBox Motion_Pos;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.GroupBox groupBox55;
        private System.Windows.Forms.Label Positive;
        private System.Windows.Forms.Label Servo_Error_Status;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label Origin;
        private System.Windows.Forms.Label Servo_Home_Status;
        private System.Windows.Forms.Label Servo_Running_Status;
        private System.Windows.Forms.Label Servo_Ready_Status;
        private System.Windows.Forms.Label Negative;
        private System.Windows.Forms.Label Servo_Enable_Status;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.Label label236;
        private System.Windows.Forms.Label label237;
        private System.Windows.Forms.Label label248;
        private System.Windows.Forms.Label label249;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
    }
}