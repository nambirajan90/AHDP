﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using csLTDMC;


namespace AHDP.UIScreens.Manual_Screen
{
    public partial class Manual_Screen : Form
    {
        public Manual_Screen()
        {
            InitializeComponent();
            //XY_Gantry_Save.Hide();
            //XYZ_Roller_PT_Save.Hide();
            //XY_FI_PT_Save.Hide();
        }

        private void Manual_Screen_Load(object sender, EventArgs e)
        {

        }
        int homedone = 0;

        public bool gantry_timer_thread_lock = false;

        //public bool roller_timer_thread_lock = false;
        //public bool FI_timer_thread_lock = false;

        private void SL1_Start_Click(object sender, EventArgs e)
        {
            // PLC.LAST_DO_VALUES();
            //if (Conveyor_Direction.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 0;
            //}

            //if (SL1_SPEED.SelectedIndex == 0)
            //{
            //    PLC.WRITE_DO_TO_PLC(Variables.Streamline_1_High_speed, 1);
            //}
            //else
            //{
            //    PLC.WRITE_DO_TO_PLC(Variables.Streamline_1_High_speed, 0);
            //}

            //PLC.DO_WRITE[Variables.Streamline_1_starts] = 1;
            //PLC.WRITE_DO_TO_PLC(Variables.Streamline_1_High_speed, 1);
           // PLC.WRITE_DO_TO_PLC(Variables.Streamline_1_starts, 1);
            // PLC.Write_to_PLC(PLC.DO_WRITE);
            SL1_STATUS.BackColor = Color.Lime;


        }

        private void SL1_STOP_Click(object sender, EventArgs e)
        {
            //PLC.LAST_DO_VALUES();
            //if (Conveyor_Direction.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 0;
            //}

            //if (SL1_SPEED.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_High_speed] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_High_speed] = 0;
            //}
            //PLC.DO_WRITE[Variables.Streamline_1_starts] = 0;
           // PLC.WRITE_DO_TO_PLC(Variables.Streamline_1_starts, 0);
           // PLC.Write_to_PLC(PLC.DO_WRITE);
            SL1_STATUS.BackColor = Color.Red;

        }

        private void SL2_START_Click(object sender, EventArgs e)
        {
            // PLC.LAST_DO_VALUES();
            //if (Conveyor_Direction.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 0;
            //}

            //if (SL2_SPEED.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_2_High_speed] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_2_High_speed] = 0;
            //}
            //PLC.DO_WRITE[Variables.Streamline_2_High_speed] = 1;
            //PLC.DO_WRITE[Variables.Streamline_2_starts] = 1;
        //    PLC.WRITE_DO_TO_PLC(Variables.Streamline_1_2_3_Direction, 1);


        //    PLC.WRITE_DO_TO_PLC(Variables.Streamline_2_High_speed, 1);
           // PLC.WRITE_DO_TO_PLC(Variables.Streamline_2_starts, 1);
            //PLC.Write_to_PLC(PLC.DO_WRITE);
            SL2_STATUS.BackColor = Color.Lime;
        }

        private void SL2_STOP_Click(object sender, EventArgs e)
        {
            //PLC.LAST_DO_VALUES();
            //if (Conveyor_Direction.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 0;
            //}

            //if (SL2_SPEED.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_2_High_speed] = 0;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_2_High_speed] = 1;
            //}

          //  PLC.DO_WRITE[Variables.Streamline_2_starts] = 0;
            //PLC.WRITE_DO_TO_PLC(Variables.Streamline_2_starts, 0);
            //PLC.Write_to_PLC(PLC.DO_WRITE);
            SL2_STATUS.BackColor = Color.Red;
        }

        private void SL3_START_Click(object sender, EventArgs e)
        {
            //PLC.LAST_DO_VALUES();
            //if (Conveyor_Direction.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 0;
            //}

            //if (SL3_SPEED.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_3_High_speed] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_3_High_speed] = 0;
            //}

          //  PLC.DO_WRITE[Variables.Streamline_3_starts] = 1;
          
            // PLC.WRITE_DO_TO_PLC(Variables.Streamline_3_High_speed, 1);
            //PLC.WRITE_DO_TO_PLC(Variables.Streamline_3_starts, 1);
            //PLC.Write_to_PLC(PLC.DO_WRITE);
            SL3_STATUS.BackColor = Color.Lime;
        }

        private void SL3_STOP_Click(object sender, EventArgs e)
        {
            //PLC.LAST_DO_VALUES();
            //if (Conveyor_Direction.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 1;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_1_2_3_Direction] = 0;
            //}

            //if (SL3_SPEED.SelectedIndex == 0)
            //{
            //    PLC.DO_WRITE[Variables.Streamline_3_High_speed] = 0;
            //}
            //else
            //{
            //    PLC.DO_WRITE[Variables.Streamline_3_High_speed] = 1;
            //}

            //PLC.DO_WRITE[Variables.Streamline_3_starts] = 0;
            //PLC.WRITE_DO_TO_PLC(Variables.Streamline_3_starts, 0);
            //PLC.Write_to_PLC(PLC.DO_WRITE);
            SL3_STATUS.BackColor = Color.Red;

        }

        private void T_LOAD_MOVE_MouseDown(object sender, MouseEventArgs e)
        {
            //if (PLC.DIO_Read[Variables.Tray_loading_stepping_positive_limit_PE] != 1 && PLC.DIO_Read[Variables.Tray_loading_stepping_negative_limit_PE] != 1)
            //{
                PLC.LAST_DO_VALUES();
                //if (LOAD_DIR.SelectedIndex == 0)
                //{
                //   // PLC.DO_WRITE[Variables.Tray_loading_step_pulse_1] = 1;
                //    PLC.DO_WRITE[Variables.Tray_loading_step_direction_1] = 0;
                //    //PLC.Write_to_PLC(PLC.DO_WRITE);
                //}

                //else
                //{
                //    //PLC.DO_WRITE[Variables.Tray_loading_step_pulse_1] = 1;

                //    PLC.DO_WRITE[Variables.Tray_loading_step_direction_1] = 1;

                //    //PLC.Write_to_PLC(PLC.DO_WRITE);
                //}
            //}
            //else
            //{
            //    MessageBox.Show("Loading Stepper Limit Reached !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}

        }
        private void TRAY_UNLOAD_MOVE_MouseDown(object sender, MouseEventArgs e)
        {
            //if (PLC.DIO_Read[Variables.Tray_discharge_step_positive_limit_PE] != 1 && PLC.DIO_Read[Variables.Tray_discharge_step_negative_limit_PE] != 1)
            //{
                PLC.LAST_DO_VALUES();
             //   if (UNLOAD_DIR.SelectedIndex == 0)
             //   {
             //   // PLC.WRITE_DO_TO_PLC(Variables.Streamline_1_starts, 1);

             // //  PLC.WRITE_DO_TO_PLC(Variables.Tray_discharge_step_pulse_0, 1);

             //   PLC.WRITE_DO_TO_PLC(Variables.Tray_outfeed_step_direction_0, 0);

             //   //PLC.DO_WRITE[Variables.Tray_discharge_step_pulse_0] = 1;
             //  // PLC.DO_WRITE[Variables.Tray_outfeed_step_direction_0] = 0;
             //       //PLC.Write_to_PLC(PLC.DO_WRITE);
             //   }
             //   else
             //   {

             ////   PLC.WRITE_DO_TO_PLC(Variables.Tray_discharge_step_pulse_0, 1);
             //   PLC.WRITE_DO_TO_PLC(Variables.Tray_outfeed_step_direction_0, 1);

             //   //PLC.DO_WRITE[Variables.Tray_discharge_step_pulse_0] = 1;
             //       //PLC.DO_WRITE[Variables.Tray_outfeed_step_direction_0] = 1;
             //       //PLC.Write_to_PLC(PLC.DO_WRITE);
             //   }
            //}
            //else
            //{
            //    MessageBox.Show("Discharge Stepper Limit Reached !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }

       

        private void btn_ON_Click(object sender, EventArgs e)
        {
          //  PLC.LAST_DO_VALUES();

            //PLC.ddoo = PLC.Last_DO_Values;

           // PLC.DO_WRITE[Variables.Streamline1_blocking_cylinder] = 0;


            //PLC.WRITE_DO_TO_PLC(Variables.Streamline1_blocking_cylinder, 0);

            //PLC.Write_to_PLC(PLC.DO_WRITE);
        }

        private void btn_Off_Click(object sender, EventArgs e)
        {
          //  PLC.LAST_DO_VALUES();


            //PLC.Last_DO_Values[Variables.Streamline1_blocking_cylinder] = 1;
            //PLC.Write_to_PLC(PLC.DO_WRITE);
            //PLC.ddoo = PLC.Last_DO_Values;

          //  PLC.DO_WRITE[Variables.Streamline1_blocking_cylinder] = 1;


           // PLC.WRITE_DO_TO_PLC(Variables.Streamline1_blocking_cylinder, 1);

            //PLC.Last_DO_Values[Variables.Streamline1_blocking_cylinder] = 1;
        }
  

        private void button107_Click(object sender, EventArgs e)
        {
            PLC.LAST_DO_VALUES();
           // PLC.DO_WRITE[Variables.HSG_vsccum_suction] = 1;
            //PLC.Write_to_PLC(PLC.DO_WRITE);
        }

        private void button108_Click(object sender, EventArgs e)
        {
            PLC.LAST_DO_VALUES();
           // PLC.DO_WRITE[Variables.HSG_vsccum_suction] = 0;
            //PLC.Write_to_PLC(PLC.DO_WRITE);
        }



        private void Input_Feedback_Tick(object sender, EventArgs e)
        {
            CCD_RECEIVE_DATA1.Text = SocketClient.V_ReceiveData_T1;
            CCD_RECEIVE_DATA3.Text = SocketClient.V_ReceiveData_T3;
            CCD_RECEIVE_DATA4.Text = SocketClient.V_ReceiveData_T4;
            CCD_RECEIVE_DATA5.Text = SocketClient.V_ReceiveData_T5;

            SCANNER_RECEIVE_DATA.Text = SocketClient.V_ReceiveSCData2;
           
            if(SocketClient.ScanConnectPrc)
            {
                SCANNER_STATUS.BackColor = Color.Lime;
            }
            else
            {
                SCANNER_STATUS.BackColor = Color.Red;
            }
           
            if (SocketClient.CCDConnectPrc)
            {
                CCD_STATUS.BackColor = Color.Lime;
            }
            else
            {
                CCD_STATUS.BackColor = Color.Red;
            }

            if (CCD_STATUS.BackColor == Color.Lime)
            {
                CCD_Connect.Enabled = false;
            }
            if (SCANNER_STATUS.BackColor == Color.Lime)
            {
                SCANNER_CONNECT.Enabled = false;
            }
           


            //if (PLC.DIO_Read[Variables.Streamline1_blocks_the_cylinder_from_extending] == 1)
            //{
            //    on_panel.BackColor = Color.Lime;
            //}
            //else
            //{
            //    on_panel.BackColor = Color.White;
            //}


            //if (PLC.DIO_Read[Variables.Streamline1_blocks_the_cylinder_from_retracting] == 1)
            //{
            //    off_panel.BackColor = Color.Lime;
            //}
            //else
            //{
            //    off_panel.BackColor = Color.White;
            //}

          

            //if (PLC.DIO_Read[Variables.Streamline2_HSG_vacumm_test] == 1)
            //{
            //    HSG2_VACUUM_FB.BackColor = Color.Lime;
            //}
            //else
            //{
            //    HSG2_VACUUM_FB.BackColor = Color.White;
            //}

            //if (PLC.DIO_Read[Variables.Re_check_HSG_Vaccum_test] == 1)
            //{
            //    HSG3_VACUUM_FB.BackColor = Color.Lime;
            //}
            //else
            //{
            //    HSG3_VACUUM_FB.BackColor = Color.White;
            //}


        }

        private void CCD_TRIGGER_Click(object sender, EventArgs e)
        {
            SocketClient.TCP_Senddata_Vision_T1(CCD_SEND_DATA.Text.ToString());
           SocketClient.TCP_Senddata_Vision_T3(CCD_SEND_DATA.Text.ToString());
          SocketClient.TCP_Senddata_Vision_T4(CCD_SEND_DATA.Text.ToString());
           SocketClient.TCP_Senddata_Vision_T5(CCD_SEND_DATA.Text.ToString());
        }

        private void button14_Click(object sender, EventArgs e)
        {
            SocketClient.TCP_Senddata_Scanner(SCANNER_SEND_DATA.Text.ToString());
        }



        private void button109_Click(object sender, EventArgs e)
        {
            PLC.LAST_DO_VALUES();
           // PLC.DO_WRITE[Variables.Recheck_HSG_vaccum_suction] = 1;
            //PLC.Write_to_PLC(PLC.DO_WRITE);
        }

        private void button110_Click(object sender, EventArgs e)
        {
            PLC.LAST_DO_VALUES();
           // PLC.DO_WRITE[Variables.Recheck_HSG_vaccum_suction] = 0;
            //PLC.Write_to_PLC(PLC.DO_WRITE);
        }


      

        private void SCANNER_CONNECT_Click(object sender, EventArgs e)
        {
            if(SocketClient.Connect_Scnr())
            {
                SCANNER_STATUS.BackColor = Color.Lime;
                MessageBox.Show("Scanner Connected Successfully", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                SCANNER_STATUS.BackColor = Color.Red;
                MessageBox.Show("Scanner Connection Error", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }

     
        private void CCD_Connect_Click(object sender, EventArgs e)
        {
            if (SocketClient.Connect_Vision())
            {
                CCD_STATUS.BackColor = Color.Lime;
                MessageBox.Show("CCD Connected Successfully", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                CCD_STATUS.BackColor = Color.Red;
                MessageBox.Show("CCD Connection Error", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }




        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void CCD_RECEIVE_DATA_TextChanged(object sender, EventArgs e)
        {

        }



        private void tabPage14_Click(object sender, EventArgs e)
        {

        }
    }
}
