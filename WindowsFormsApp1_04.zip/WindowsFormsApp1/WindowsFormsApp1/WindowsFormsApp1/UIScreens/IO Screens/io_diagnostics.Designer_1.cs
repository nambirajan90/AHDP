﻿
namespace B3I.UIScreens.IO_Screens
{
    partial class io_diagnostics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.simpleButton65 = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.simpleButton66 = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.labelControl67 = new System.Windows.Forms.Label();
            this.simpleButton67 = new System.Windows.Forms.Button();
            this.labelControl68 = new System.Windows.Forms.Label();
            this.simpleButton68 = new System.Windows.Forms.Button();
            this.labelControl69 = new System.Windows.Forms.Label();
            this.simpleButton69 = new System.Windows.Forms.Button();
            this.labelControl70 = new System.Windows.Forms.Label();
            this.simpleButton70 = new System.Windows.Forms.Button();
            this.labelControl71 = new System.Windows.Forms.Label();
            this.simpleButton71 = new System.Windows.Forms.Button();
            this.labelControl72 = new System.Windows.Forms.Label();
            this.simpleButton72 = new System.Windows.Forms.Button();
            this.labelControl73 = new System.Windows.Forms.Label();
            this.simpleButton73 = new System.Windows.Forms.Button();
            this.labelControl74 = new System.Windows.Forms.Label();
            this.simpleButton74 = new System.Windows.Forms.Button();
            this.labelControl75 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.simpleButton75 = new System.Windows.Forms.Button();
            this.simpleButton76 = new System.Windows.Forms.Button();
            this.labelControl76 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.labelControl77 = new System.Windows.Forms.Label();
            this.simpleButton77 = new System.Windows.Forms.Button();
            this.labelControl78 = new System.Windows.Forms.Label();
            this.simpleButton78 = new System.Windows.Forms.Button();
            this.labelControl79 = new System.Windows.Forms.Label();
            this.simpleButton79 = new System.Windows.Forms.Button();
            this.labelControl80 = new System.Windows.Forms.Label();
            this.simpleButton80 = new System.Windows.Forms.Button();
            this.labelControl81 = new System.Windows.Forms.Label();
            this.simpleButton81 = new System.Windows.Forms.Button();
            this.labelControl82 = new System.Windows.Forms.Label();
            this.simpleButton82 = new System.Windows.Forms.Button();
            this.labelControl83 = new System.Windows.Forms.Label();
            this.simpleButton83 = new System.Windows.Forms.Button();
            this.labelControl84 = new System.Windows.Forms.Label();
            this.simpleButton84 = new System.Windows.Forms.Button();
            this.labelControl85 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.simpleButton85 = new System.Windows.Forms.Button();
            this.simpleButton86 = new System.Windows.Forms.Button();
            this.labelControl86 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.labelControl87 = new System.Windows.Forms.Label();
            this.simpleButton87 = new System.Windows.Forms.Button();
            this.labelControl88 = new System.Windows.Forms.Label();
            this.simpleButton88 = new System.Windows.Forms.Button();
            this.labelControl89 = new System.Windows.Forms.Label();
            this.simpleButton89 = new System.Windows.Forms.Button();
            this.labelControl90 = new System.Windows.Forms.Label();
            this.simpleButton90 = new System.Windows.Forms.Button();
            this.labelControl91 = new System.Windows.Forms.Label();
            this.simpleButton91 = new System.Windows.Forms.Button();
            this.labelControl92 = new System.Windows.Forms.Label();
            this.simpleButton92 = new System.Windows.Forms.Button();
            this.labelControl93 = new System.Windows.Forms.Label();
            this.simpleButton93 = new System.Windows.Forms.Button();
            this.labelControl94 = new System.Windows.Forms.Label();
            this.simpleButton94 = new System.Windows.Forms.Button();
            this.labelControl95 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.simpleButton95 = new System.Windows.Forms.Button();
            this.simpleButton96 = new System.Windows.Forms.Button();
            this.labelControl96 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.IO_sts_Timer = new System.Windows.Forms.Timer(this.components);
            this.AI_TIMER = new System.Windows.Forms.Timer(this.components);
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.grpboxCamera = new System.Windows.Forms.GroupBox();
            this.chkCCD5 = new System.Windows.Forms.CheckBox();
            this.chkCCD4 = new System.Windows.Forms.CheckBox();
            this.chkCCD3 = new System.Windows.Forms.CheckBox();
            this.chkCCD1 = new System.Windows.Forms.CheckBox();
            this.richTextBox_Calib = new System.Windows.Forms.RichTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.lblServo_Conn_Status_X = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCamera_Stop = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btnCamera_Start = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.Cam1_path = new System.Windows.Forms.TextBox();
            this.lblactualpos_ccd1_y = new System.Windows.Forms.Label();
            this.lblactualpos_ccd1_x = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.CCD1count = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.CCD1Speed = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lblRunningCount = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbTestMode = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.Cam3_path = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.CCD3count = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.button8 = new System.Windows.Forms.Button();
            this.Cam4_path = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.CCD4count = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.txttriggerpos = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtonflyintervel = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.Cam5__path = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.CCD5count = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.CCD5Speed = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.CCD5TestMode = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.Load_Caliration = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnSaveSlope = new System.Windows.Forms.Button();
            this.btnEdtSlope = new System.Windows.Forms.Button();
            this.txtoffset4 = new System.Windows.Forms.TextBox();
            this.txtoffset0 = new System.Windows.Forms.TextBox();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.txtmstrvlt = new System.Windows.Forms.TextBox();
            this.txt_mstrload = new System.Windows.Forms.TextBox();
            this.label132 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.txtoffset1 = new System.Windows.Forms.TextBox();
            this.txtSlope4 = new System.Windows.Forms.TextBox();
            this.txtSlope1 = new System.Windows.Forms.TextBox();
            this.txtSlope0 = new System.Windows.Forms.TextBox();
            this.btn_Nozzle_Z_Stop = new System.Windows.Forms.Button();
            this.btn_Nozzle_Z_Move = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label111 = new System.Windows.Forms.Label();
            this.txtloadvlt2 = new System.Windows.Forms.TextBox();
            this.label108 = new System.Windows.Forms.Label();
            this.txtloadvlt1 = new System.Windows.Forms.TextBox();
            this.label104 = new System.Windows.Forms.Label();
            this.txtLoadcell2 = new System.Windows.Forms.TextBox();
            this.txtLoadcell1 = new System.Windows.Forms.TextBox();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.Motion_Card_IO = new System.Windows.Forms.TabPage();
            this.Motion_Card_Output = new System.Windows.Forms.TabPage();
            this.tabPage0 = new System.Windows.Forms.TabPage();
            this.Axis_datagridview = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.offlinemode = new System.Windows.Forms.RadioButton();
            this.onlinemode = new System.Windows.Forms.RadioButton();
            this.productionmode = new System.Windows.Forms.RadioButton();
            this.dryrun = new System.Windows.Forms.RadioButton();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.labelControl13 = new System.Windows.Forms.Label();
            this.labelControl9 = new System.Windows.Forms.Label();
            this.labelControl8 = new System.Windows.Forms.Label();
            this.labelControl7 = new System.Windows.Forms.Label();
            this.labelControl12 = new System.Windows.Forms.Label();
            this.labelControl11 = new System.Windows.Forms.Label();
            this.labelControl10 = new System.Windows.Forms.Label();
            this.labelControl6 = new System.Windows.Forms.Label();
            this.labelControl5 = new System.Windows.Forms.Label();
            this.lblRoboIP = new System.Windows.Forms.Label();
            this.LabelCCD5 = new System.Windows.Forms.Label();
            this.LabelCCD4 = new System.Windows.Forms.Label();
            this.LabelCCD3 = new System.Windows.Forms.Label();
            this.lblPDCAIP = new System.Windows.Forms.Label();
            this.lblSFCIP = new System.Windows.Forms.Label();
            this.lblScannerIP = new System.Windows.Forms.Label();
            this.LabelCCD1 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.tabPage11.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpboxCamera.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.Load_Caliration.SuspendLayout();
            this.tabPage0.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Axis_datagridview)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // simpleButton65
            // 
            this.simpleButton65.BackColor = System.Drawing.Color.Red;
            this.simpleButton65.Location = new System.Drawing.Point(1351, 444);
            this.simpleButton65.Name = "simpleButton65";
            this.simpleButton65.Size = new System.Drawing.Size(30, 24);
            this.simpleButton65.TabIndex = 152;
            this.simpleButton65.UseVisualStyleBackColor = false;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(1097, 448);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(175, 16);
            this.label67.TabIndex = 150;
            this.label67.Text = "I10_WC_Main_Press_Swt_FB";
            // 
            // simpleButton66
            // 
            this.simpleButton66.BackColor = System.Drawing.Color.Red;
            this.simpleButton66.Location = new System.Drawing.Point(1351, 390);
            this.simpleButton66.Name = "simpleButton66";
            this.simpleButton66.Size = new System.Drawing.Size(30, 24);
            this.simpleButton66.TabIndex = 149;
            this.simpleButton66.UseVisualStyleBackColor = false;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(1097, 394);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(123, 16);
            this.label68.TabIndex = 147;
            this.label68.Text = "I10_WC_Spare_X50";
            // 
            // labelControl67
            // 
            this.labelControl67.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl67.Location = new System.Drawing.Point(1392, 340);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(22, 16);
            this.labelControl67.TabIndex = 146;
            this.labelControl67.Text = "X49";
            // 
            // simpleButton67
            // 
            this.simpleButton67.BackColor = System.Drawing.Color.Red;
            this.simpleButton67.Location = new System.Drawing.Point(1351, 336);
            this.simpleButton67.Name = "simpleButton67";
            this.simpleButton67.Size = new System.Drawing.Size(30, 24);
            this.simpleButton67.TabIndex = 145;
            this.simpleButton67.UseVisualStyleBackColor = false;
            // 
            // labelControl68
            // 
            this.labelControl68.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl68.Location = new System.Drawing.Point(1392, 283);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(22, 16);
            this.labelControl68.TabIndex = 144;
            this.labelControl68.Text = "X48";
            // 
            // simpleButton68
            // 
            this.simpleButton68.BackColor = System.Drawing.Color.Red;
            this.simpleButton68.Location = new System.Drawing.Point(1351, 279);
            this.simpleButton68.Name = "simpleButton68";
            this.simpleButton68.Size = new System.Drawing.Size(30, 24);
            this.simpleButton68.TabIndex = 143;
            this.simpleButton68.UseVisualStyleBackColor = false;
            // 
            // labelControl69
            // 
            this.labelControl69.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl69.Location = new System.Drawing.Point(1392, 229);
            this.labelControl69.Name = "labelControl69";
            this.labelControl69.Size = new System.Drawing.Size(22, 16);
            this.labelControl69.TabIndex = 142;
            this.labelControl69.Text = "X47";
            // 
            // simpleButton69
            // 
            this.simpleButton69.BackColor = System.Drawing.Color.Red;
            this.simpleButton69.Location = new System.Drawing.Point(1351, 225);
            this.simpleButton69.Name = "simpleButton69";
            this.simpleButton69.Size = new System.Drawing.Size(30, 24);
            this.simpleButton69.TabIndex = 141;
            this.simpleButton69.UseVisualStyleBackColor = false;
            // 
            // labelControl70
            // 
            this.labelControl70.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl70.Location = new System.Drawing.Point(1392, 178);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(22, 16);
            this.labelControl70.TabIndex = 140;
            this.labelControl70.Text = "X46";
            // 
            // simpleButton70
            // 
            this.simpleButton70.BackColor = System.Drawing.Color.Red;
            this.simpleButton70.Location = new System.Drawing.Point(1351, 174);
            this.simpleButton70.Name = "simpleButton70";
            this.simpleButton70.Size = new System.Drawing.Size(30, 24);
            this.simpleButton70.TabIndex = 139;
            this.simpleButton70.UseVisualStyleBackColor = false;
            // 
            // labelControl71
            // 
            this.labelControl71.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl71.Location = new System.Drawing.Point(1392, 124);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(22, 16);
            this.labelControl71.TabIndex = 138;
            this.labelControl71.Text = "X45";
            // 
            // simpleButton71
            // 
            this.simpleButton71.BackColor = System.Drawing.Color.Red;
            this.simpleButton71.Location = new System.Drawing.Point(1351, 120);
            this.simpleButton71.Name = "simpleButton71";
            this.simpleButton71.Size = new System.Drawing.Size(30, 24);
            this.simpleButton71.TabIndex = 137;
            this.simpleButton71.UseVisualStyleBackColor = false;
            // 
            // labelControl72
            // 
            this.labelControl72.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl72.Location = new System.Drawing.Point(1392, 71);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(22, 16);
            this.labelControl72.TabIndex = 136;
            this.labelControl72.Text = "X44";
            // 
            // simpleButton72
            // 
            this.simpleButton72.BackColor = System.Drawing.Color.Red;
            this.simpleButton72.Location = new System.Drawing.Point(1351, 67);
            this.simpleButton72.Name = "simpleButton72";
            this.simpleButton72.Size = new System.Drawing.Size(30, 24);
            this.simpleButton72.TabIndex = 135;
            this.simpleButton72.UseVisualStyleBackColor = false;
            // 
            // labelControl73
            // 
            this.labelControl73.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl73.Location = new System.Drawing.Point(1044, 448);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(22, 16);
            this.labelControl73.TabIndex = 134;
            this.labelControl73.Text = "X43";
            // 
            // simpleButton73
            // 
            this.simpleButton73.BackColor = System.Drawing.Color.Red;
            this.simpleButton73.Location = new System.Drawing.Point(1003, 444);
            this.simpleButton73.Name = "simpleButton73";
            this.simpleButton73.Size = new System.Drawing.Size(30, 24);
            this.simpleButton73.TabIndex = 133;
            this.simpleButton73.UseVisualStyleBackColor = false;
            // 
            // labelControl74
            // 
            this.labelControl74.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl74.Location = new System.Drawing.Point(1044, 394);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(22, 16);
            this.labelControl74.TabIndex = 132;
            this.labelControl74.Text = "X42";
            // 
            // simpleButton74
            // 
            this.simpleButton74.BackColor = System.Drawing.Color.Red;
            this.simpleButton74.Location = new System.Drawing.Point(1003, 390);
            this.simpleButton74.Name = "simpleButton74";
            this.simpleButton74.Size = new System.Drawing.Size(30, 24);
            this.simpleButton74.TabIndex = 131;
            this.simpleButton74.UseVisualStyleBackColor = false;
            // 
            // labelControl75
            // 
            this.labelControl75.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl75.Location = new System.Drawing.Point(1044, 340);
            this.labelControl75.Name = "labelControl75";
            this.labelControl75.Size = new System.Drawing.Size(22, 16);
            this.labelControl75.TabIndex = 130;
            this.labelControl75.Text = "X41";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(1097, 340);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(123, 16);
            this.label69.TabIndex = 129;
            this.label69.Text = "I10_WC_Spare_X49";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(1097, 283);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(123, 16);
            this.label70.TabIndex = 128;
            this.label70.Text = "I10_WC_Spare_X48";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(1097, 229);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(133, 16);
            this.label71.TabIndex = 127;
            this.label71.Text = "I10_WC_Estop_PB_FB";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(1097, 178);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(123, 16);
            this.label72.TabIndex = 126;
            this.label72.Text = "I10_WC_Spare_X46";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(1097, 124);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(260, 16);
            this.label73.TabIndex = 125;
            this.label73.Text = "I10_WC_Received_Tray_FB_From_Unloader";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(1097, 71);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(245, 16);
            this.label74.TabIndex = 124;
            this.label74.Text = "I10_WC_Rdy_to_Receive_From_Unloader";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(749, 448);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(250, 16);
            this.label75.TabIndex = 123;
            this.label75.Text = "I10_WC_RH_Feeder_Stopper_Cylinder_Up";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(749, 394);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(248, 16);
            this.label76.TabIndex = 122;
            this.label76.Text = "I10_WC_LH_Feeder_Stopper_Cylinder_Up";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(749, 340);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(217, 16);
            this.label77.TabIndex = 121;
            this.label77.Text = "I10_WC_Vacuum_Press_Switch4_FB";
            // 
            // simpleButton75
            // 
            this.simpleButton75.BackColor = System.Drawing.Color.Red;
            this.simpleButton75.Location = new System.Drawing.Point(1003, 336);
            this.simpleButton75.Name = "simpleButton75";
            this.simpleButton75.Size = new System.Drawing.Size(30, 24);
            this.simpleButton75.TabIndex = 120;
            this.simpleButton75.UseVisualStyleBackColor = false;
            // 
            // simpleButton76
            // 
            this.simpleButton76.BackColor = System.Drawing.Color.Red;
            this.simpleButton76.Location = new System.Drawing.Point(1003, 279);
            this.simpleButton76.Name = "simpleButton76";
            this.simpleButton76.Size = new System.Drawing.Size(30, 24);
            this.simpleButton76.TabIndex = 119;
            this.simpleButton76.UseVisualStyleBackColor = false;
            // 
            // labelControl76
            // 
            this.labelControl76.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl76.Location = new System.Drawing.Point(1044, 283);
            this.labelControl76.Name = "labelControl76";
            this.labelControl76.Size = new System.Drawing.Size(22, 16);
            this.labelControl76.TabIndex = 118;
            this.labelControl76.Text = "X40";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(749, 283);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(217, 16);
            this.label78.TabIndex = 117;
            this.label78.Text = "I10_WC_Vacuum_Press_Switch3_FB";
            // 
            // labelControl77
            // 
            this.labelControl77.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl77.Location = new System.Drawing.Point(1044, 229);
            this.labelControl77.Name = "labelControl77";
            this.labelControl77.Size = new System.Drawing.Size(22, 16);
            this.labelControl77.TabIndex = 116;
            this.labelControl77.Text = "X39";
            // 
            // simpleButton77
            // 
            this.simpleButton77.BackColor = System.Drawing.Color.Red;
            this.simpleButton77.Location = new System.Drawing.Point(1003, 225);
            this.simpleButton77.Name = "simpleButton77";
            this.simpleButton77.Size = new System.Drawing.Size(30, 24);
            this.simpleButton77.TabIndex = 115;
            this.simpleButton77.UseVisualStyleBackColor = true;
            // 
            // labelControl78
            // 
            this.labelControl78.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl78.Location = new System.Drawing.Point(1044, 178);
            this.labelControl78.Name = "labelControl78";
            this.labelControl78.Size = new System.Drawing.Size(22, 16);
            this.labelControl78.TabIndex = 114;
            this.labelControl78.Text = "X38";
            // 
            // simpleButton78
            // 
            this.simpleButton78.BackColor = System.Drawing.Color.Red;
            this.simpleButton78.Location = new System.Drawing.Point(1003, 174);
            this.simpleButton78.Name = "simpleButton78";
            this.simpleButton78.Size = new System.Drawing.Size(30, 24);
            this.simpleButton78.TabIndex = 113;
            this.simpleButton78.UseVisualStyleBackColor = true;
            // 
            // labelControl79
            // 
            this.labelControl79.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl79.Location = new System.Drawing.Point(1044, 124);
            this.labelControl79.Name = "labelControl79";
            this.labelControl79.Size = new System.Drawing.Size(22, 16);
            this.labelControl79.TabIndex = 112;
            this.labelControl79.Text = "X37";
            // 
            // simpleButton79
            // 
            this.simpleButton79.BackColor = System.Drawing.Color.Red;
            this.simpleButton79.Location = new System.Drawing.Point(1003, 120);
            this.simpleButton79.Name = "simpleButton79";
            this.simpleButton79.Size = new System.Drawing.Size(30, 24);
            this.simpleButton79.TabIndex = 111;
            this.simpleButton79.UseVisualStyleBackColor = true;
            // 
            // labelControl80
            // 
            this.labelControl80.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl80.Location = new System.Drawing.Point(1044, 71);
            this.labelControl80.Name = "labelControl80";
            this.labelControl80.Size = new System.Drawing.Size(22, 16);
            this.labelControl80.TabIndex = 110;
            this.labelControl80.Text = "X36";
            // 
            // simpleButton80
            // 
            this.simpleButton80.BackColor = System.Drawing.Color.Red;
            this.simpleButton80.Location = new System.Drawing.Point(1003, 67);
            this.simpleButton80.Name = "simpleButton80";
            this.simpleButton80.Size = new System.Drawing.Size(30, 24);
            this.simpleButton80.TabIndex = 109;
            this.simpleButton80.UseVisualStyleBackColor = false;
            // 
            // labelControl81
            // 
            this.labelControl81.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl81.Location = new System.Drawing.Point(684, 448);
            this.labelControl81.Name = "labelControl81";
            this.labelControl81.Size = new System.Drawing.Size(22, 16);
            this.labelControl81.TabIndex = 108;
            this.labelControl81.Text = "X35";
            // 
            // simpleButton81
            // 
            this.simpleButton81.BackColor = System.Drawing.Color.Red;
            this.simpleButton81.Location = new System.Drawing.Point(643, 444);
            this.simpleButton81.Name = "simpleButton81";
            this.simpleButton81.Size = new System.Drawing.Size(30, 24);
            this.simpleButton81.TabIndex = 107;
            this.simpleButton81.UseVisualStyleBackColor = false;
            // 
            // labelControl82
            // 
            this.labelControl82.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl82.Location = new System.Drawing.Point(684, 394);
            this.labelControl82.Name = "labelControl82";
            this.labelControl82.Size = new System.Drawing.Size(22, 16);
            this.labelControl82.TabIndex = 106;
            this.labelControl82.Text = "X34";
            // 
            // simpleButton82
            // 
            this.simpleButton82.BackColor = System.Drawing.Color.Red;
            this.simpleButton82.Location = new System.Drawing.Point(643, 390);
            this.simpleButton82.Name = "simpleButton82";
            this.simpleButton82.Size = new System.Drawing.Size(30, 24);
            this.simpleButton82.TabIndex = 105;
            this.simpleButton82.UseVisualStyleBackColor = false;
            // 
            // labelControl83
            // 
            this.labelControl83.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl83.Location = new System.Drawing.Point(684, 340);
            this.labelControl83.Name = "labelControl83";
            this.labelControl83.Size = new System.Drawing.Size(22, 16);
            this.labelControl83.TabIndex = 104;
            this.labelControl83.Text = "X33";
            // 
            // simpleButton83
            // 
            this.simpleButton83.BackColor = System.Drawing.Color.Red;
            this.simpleButton83.Location = new System.Drawing.Point(643, 336);
            this.simpleButton83.Name = "simpleButton83";
            this.simpleButton83.Size = new System.Drawing.Size(30, 24);
            this.simpleButton83.TabIndex = 103;
            this.simpleButton83.UseVisualStyleBackColor = false;
            // 
            // labelControl84
            // 
            this.labelControl84.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl84.Location = new System.Drawing.Point(684, 283);
            this.labelControl84.Name = "labelControl84";
            this.labelControl84.Size = new System.Drawing.Size(22, 16);
            this.labelControl84.TabIndex = 102;
            this.labelControl84.Text = "X32";
            // 
            // simpleButton84
            // 
            this.simpleButton84.BackColor = System.Drawing.Color.Red;
            this.simpleButton84.Location = new System.Drawing.Point(643, 279);
            this.simpleButton84.Name = "simpleButton84";
            this.simpleButton84.Size = new System.Drawing.Size(30, 24);
            this.simpleButton84.TabIndex = 101;
            this.simpleButton84.UseVisualStyleBackColor = false;
            // 
            // labelControl85
            // 
            this.labelControl85.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl85.Location = new System.Drawing.Point(684, 229);
            this.labelControl85.Name = "labelControl85";
            this.labelControl85.Size = new System.Drawing.Size(22, 16);
            this.labelControl85.TabIndex = 100;
            this.labelControl85.Text = "X31";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(749, 229);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(217, 16);
            this.label79.TabIndex = 99;
            this.label79.Text = "I10_WC_Vacuum_Press_Switch2_FB";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(749, 178);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(194, 16);
            this.label80.TabIndex = 98;
            this.label80.Text = "I10_WC_RH_Fdr_Foam_Pres_FB";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(749, 124);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(192, 16);
            this.label81.TabIndex = 97;
            this.label81.Text = "I10_WC_LH_Fdr_Foam_Pres_FB";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(749, 71);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(200, 16);
            this.label82.TabIndex = 96;
            this.label82.Text = "I10_WC_RH_Fdr_Push_Button_FB";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(389, 448);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(198, 16);
            this.label83.TabIndex = 95;
            this.label83.Text = "I10_WC_LH_Fdr_Push_Button_FB";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(389, 394);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(217, 16);
            this.label84.TabIndex = 94;
            this.label84.Text = "I10_WC_Vacuum_Press_Switch1_FB";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(389, 340);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(199, 16);
            this.label85.TabIndex = 93;
            this.label85.Text = "I10_WC_Empty_FB_From_Loader";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(389, 283);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(247, 16);
            this.label86.TabIndex = 92;
            this.label86.Text = "I10_WC_Strt_Tray_Tranfer_From_Loader";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(389, 229);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(248, 16);
            this.label87.TabIndex = 91;
            this.label87.Text = "I10_WC_Outp_Cnvy_Speed_Cntrl_Sen_FB";
            // 
            // simpleButton85
            // 
            this.simpleButton85.BackColor = System.Drawing.Color.Red;
            this.simpleButton85.Location = new System.Drawing.Point(643, 225);
            this.simpleButton85.Name = "simpleButton85";
            this.simpleButton85.Size = new System.Drawing.Size(30, 24);
            this.simpleButton85.TabIndex = 90;
            this.simpleButton85.UseVisualStyleBackColor = false;
            // 
            // simpleButton86
            // 
            this.simpleButton86.BackColor = System.Drawing.Color.Red;
            this.simpleButton86.Location = new System.Drawing.Point(643, 174);
            this.simpleButton86.Name = "simpleButton86";
            this.simpleButton86.Size = new System.Drawing.Size(30, 24);
            this.simpleButton86.TabIndex = 89;
            this.simpleButton86.UseVisualStyleBackColor = false;
            // 
            // labelControl86
            // 
            this.labelControl86.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl86.Location = new System.Drawing.Point(684, 178);
            this.labelControl86.Name = "labelControl86";
            this.labelControl86.Size = new System.Drawing.Size(22, 16);
            this.labelControl86.TabIndex = 88;
            this.labelControl86.Text = "X30";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(389, 178);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(186, 16);
            this.label88.TabIndex = 87;
            this.label88.Text = "I10_WC_Workcell_Stpr_Cyl_Up";
            // 
            // labelControl87
            // 
            this.labelControl87.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl87.Location = new System.Drawing.Point(684, 124);
            this.labelControl87.Name = "labelControl87";
            this.labelControl87.Size = new System.Drawing.Size(22, 16);
            this.labelControl87.TabIndex = 86;
            this.labelControl87.Text = "X29";
            // 
            // simpleButton87
            // 
            this.simpleButton87.BackColor = System.Drawing.Color.Red;
            this.simpleButton87.Location = new System.Drawing.Point(643, 120);
            this.simpleButton87.Name = "simpleButton87";
            this.simpleButton87.Size = new System.Drawing.Size(30, 24);
            this.simpleButton87.TabIndex = 85;
            this.simpleButton87.UseVisualStyleBackColor = false;
            // 
            // labelControl88
            // 
            this.labelControl88.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl88.Location = new System.Drawing.Point(684, 71);
            this.labelControl88.Name = "labelControl88";
            this.labelControl88.Size = new System.Drawing.Size(22, 16);
            this.labelControl88.TabIndex = 84;
            this.labelControl88.Text = "X28";
            // 
            // simpleButton88
            // 
            this.simpleButton88.BackColor = System.Drawing.Color.Red;
            this.simpleButton88.Location = new System.Drawing.Point(643, 67);
            this.simpleButton88.Name = "simpleButton88";
            this.simpleButton88.Size = new System.Drawing.Size(30, 24);
            this.simpleButton88.TabIndex = 83;
            this.simpleButton88.UseVisualStyleBackColor = false;
            // 
            // labelControl89
            // 
            this.labelControl89.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl89.Location = new System.Drawing.Point(312, 448);
            this.labelControl89.Name = "labelControl89";
            this.labelControl89.Size = new System.Drawing.Size(22, 16);
            this.labelControl89.TabIndex = 82;
            this.labelControl89.Text = "X27";
            // 
            // simpleButton89
            // 
            this.simpleButton89.BackColor = System.Drawing.Color.Red;
            this.simpleButton89.Location = new System.Drawing.Point(271, 444);
            this.simpleButton89.Name = "simpleButton89";
            this.simpleButton89.Size = new System.Drawing.Size(30, 24);
            this.simpleButton89.TabIndex = 81;
            this.simpleButton89.UseVisualStyleBackColor = false;
            // 
            // labelControl90
            // 
            this.labelControl90.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl90.Location = new System.Drawing.Point(312, 394);
            this.labelControl90.Name = "labelControl90";
            this.labelControl90.Size = new System.Drawing.Size(22, 16);
            this.labelControl90.TabIndex = 80;
            this.labelControl90.Text = "X26";
            // 
            // simpleButton90
            // 
            this.simpleButton90.BackColor = System.Drawing.Color.Red;
            this.simpleButton90.Location = new System.Drawing.Point(271, 390);
            this.simpleButton90.Name = "simpleButton90";
            this.simpleButton90.Size = new System.Drawing.Size(30, 24);
            this.simpleButton90.TabIndex = 79;
            this.simpleButton90.UseVisualStyleBackColor = false;
            // 
            // labelControl91
            // 
            this.labelControl91.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl91.Location = new System.Drawing.Point(312, 340);
            this.labelControl91.Name = "labelControl91";
            this.labelControl91.Size = new System.Drawing.Size(22, 16);
            this.labelControl91.TabIndex = 78;
            this.labelControl91.Text = "X25";
            // 
            // simpleButton91
            // 
            this.simpleButton91.BackColor = System.Drawing.Color.Red;
            this.simpleButton91.Location = new System.Drawing.Point(271, 336);
            this.simpleButton91.Name = "simpleButton91";
            this.simpleButton91.Size = new System.Drawing.Size(30, 24);
            this.simpleButton91.TabIndex = 77;
            this.simpleButton91.UseVisualStyleBackColor = false;
            // 
            // labelControl92
            // 
            this.labelControl92.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl92.Location = new System.Drawing.Point(312, 283);
            this.labelControl92.Name = "labelControl92";
            this.labelControl92.Size = new System.Drawing.Size(22, 16);
            this.labelControl92.TabIndex = 76;
            this.labelControl92.Text = "X24";
            // 
            // simpleButton92
            // 
            this.simpleButton92.BackColor = System.Drawing.Color.Red;
            this.simpleButton92.Location = new System.Drawing.Point(271, 279);
            this.simpleButton92.Name = "simpleButton92";
            this.simpleButton92.Size = new System.Drawing.Size(30, 24);
            this.simpleButton92.TabIndex = 75;
            this.simpleButton92.UseVisualStyleBackColor = false;
            // 
            // labelControl93
            // 
            this.labelControl93.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl93.Location = new System.Drawing.Point(312, 229);
            this.labelControl93.Name = "labelControl93";
            this.labelControl93.Size = new System.Drawing.Size(22, 16);
            this.labelControl93.TabIndex = 74;
            this.labelControl93.Text = "X23";
            // 
            // simpleButton93
            // 
            this.simpleButton93.BackColor = System.Drawing.Color.Red;
            this.simpleButton93.Location = new System.Drawing.Point(271, 225);
            this.simpleButton93.Name = "simpleButton93";
            this.simpleButton93.Size = new System.Drawing.Size(30, 24);
            this.simpleButton93.TabIndex = 73;
            this.simpleButton93.UseVisualStyleBackColor = false;
            // 
            // labelControl94
            // 
            this.labelControl94.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl94.Location = new System.Drawing.Point(312, 178);
            this.labelControl94.Name = "labelControl94";
            this.labelControl94.Size = new System.Drawing.Size(22, 16);
            this.labelControl94.TabIndex = 72;
            this.labelControl94.Text = "X22";
            // 
            // simpleButton94
            // 
            this.simpleButton94.BackColor = System.Drawing.Color.Red;
            this.simpleButton94.Location = new System.Drawing.Point(271, 174);
            this.simpleButton94.Name = "simpleButton94";
            this.simpleButton94.Size = new System.Drawing.Size(30, 24);
            this.simpleButton94.TabIndex = 71;
            this.simpleButton94.UseVisualStyleBackColor = false;
            // 
            // labelControl95
            // 
            this.labelControl95.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl95.Location = new System.Drawing.Point(312, 124);
            this.labelControl95.Name = "labelControl95";
            this.labelControl95.Size = new System.Drawing.Size(22, 16);
            this.labelControl95.TabIndex = 70;
            this.labelControl95.Text = "X21";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(389, 124);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(144, 16);
            this.label89.TabIndex = 69;
            this.label89.Text = "I10_WC_Plt_Lift_Cyl_Up";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(389, 71);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(231, 16);
            this.label90.TabIndex = 68;
            this.label90.Text = "I10_WC_Outp_Buff_Tray_Pres_Sen_FB";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(17, 448);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(239, 16);
            this.label91.TabIndex = 67;
            this.label91.Text = "I10_WC_Inp_Cnvy_Speed_Cntrl_Sen_FB";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(17, 394);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(202, 16);
            this.label92.TabIndex = 66;
            this.label92.Text = "I10_WC_Cnvy_Tray_Pres_Sen_FB";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(17, 340);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(222, 16);
            this.label93.TabIndex = 65;
            this.label93.Text = "I10_WC_Inp_Buff_Tray_Pres_Sen_FB";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(17, 283);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(245, 16);
            this.label94.TabIndex = 64;
            this.label94.Text = "I10_WC_RH_Foam_Fdr_Trly_Latching_FB";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(17, 229);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(243, 16);
            this.label95.TabIndex = 63;
            this.label95.Text = "I10_WC_LH_Foam_Fdr_Trly_Latching_FB";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(17, 178);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(127, 16);
            this.label96.TabIndex = 62;
            this.label96.Text = "I10_WC_Sfty_Rly_FB";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(17, 124);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(99, 16);
            this.label97.TabIndex = 61;
            this.label97.Text = "I10_WC_Rst_PB";
            // 
            // simpleButton95
            // 
            this.simpleButton95.BackColor = System.Drawing.Color.Red;
            this.simpleButton95.Location = new System.Drawing.Point(271, 120);
            this.simpleButton95.Name = "simpleButton95";
            this.simpleButton95.Size = new System.Drawing.Size(30, 24);
            this.simpleButton95.TabIndex = 60;
            this.simpleButton95.UseVisualStyleBackColor = false;
            // 
            // simpleButton96
            // 
            this.simpleButton96.BackColor = System.Drawing.Color.Red;
            this.simpleButton96.Location = new System.Drawing.Point(271, 67);
            this.simpleButton96.Name = "simpleButton96";
            this.simpleButton96.Size = new System.Drawing.Size(30, 24);
            this.simpleButton96.TabIndex = 57;
            this.simpleButton96.UseVisualStyleBackColor = false;
            // 
            // labelControl96
            // 
            this.labelControl96.Location = new System.Drawing.Point(312, 71);
            this.labelControl96.Name = "labelControl96";
            this.labelControl96.Size = new System.Drawing.Size(22, 16);
            this.labelControl96.TabIndex = 56;
            this.labelControl96.Text = "X20";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(17, 71);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(129, 16);
            this.label98.TabIndex = 55;
            this.label98.Text = "I10_WC_Cyc_Strt_FB";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Verdana", 16F);
            this.label99.Location = new System.Drawing.Point(15, 18);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(206, 26);
            this.label99.TabIndex = 50;
            this.label99.Text = "PLC Input";
            // 
            // IO_sts_Timer
            // 
            this.IO_sts_Timer.Interval = 10;
            this.IO_sts_Timer.Tick += new System.EventHandler(this.IO_sts_Timer_Tick);
            // 
            // AI_TIMER
            // 
            this.AI_TIMER.Interval = 10;
            this.AI_TIMER.Tick += new System.EventHandler(this.AI_TIMER_Tick);
            // 
            // tabPage9
            // 
            this.tabPage9.Location = new System.Drawing.Point(0, 0);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(200, 100);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "Calibration";
            // 
            // tabPage10
            // 
            this.tabPage10.Location = new System.Drawing.Point(0, 0);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(200, 100);
            this.tabPage10.TabIndex = 0;
            this.tabPage10.Text = "GRR";
            // 
            // tabPage12
            // 
            this.tabPage12.Location = new System.Drawing.Point(4, 25);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(1285, 583);
            this.tabPage12.TabIndex = 3;
            this.tabPage12.Text = "GRR";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.groupBox2);
            this.tabPage11.Location = new System.Drawing.Point(4, 25);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(1285, 583);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "Calibration";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.grpboxCamera);
            this.groupBox2.Controls.Add(this.richTextBox_Calib);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.lblServo_Conn_Status_X);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnCamera_Stop);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.btnCamera_Start);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(20, 82);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1200, 278);
            this.groupBox2.TabIndex = 152;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Camera";
            // 
            // grpboxCamera
            // 
            this.grpboxCamera.BackColor = System.Drawing.Color.WhiteSmoke;
            this.grpboxCamera.Controls.Add(this.chkCCD5);
            this.grpboxCamera.Controls.Add(this.chkCCD4);
            this.grpboxCamera.Controls.Add(this.chkCCD3);
            this.grpboxCamera.Controls.Add(this.chkCCD1);
            this.grpboxCamera.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxCamera.Location = new System.Drawing.Point(31, 157);
            this.grpboxCamera.Name = "grpboxCamera";
            this.grpboxCamera.Size = new System.Drawing.Size(365, 51);
            this.grpboxCamera.TabIndex = 152;
            this.grpboxCamera.TabStop = false;
            this.grpboxCamera.Text = "Choose Camera";
            // 
            // chkCCD5
            // 
            this.chkCCD5.AutoSize = true;
            this.chkCCD5.Location = new System.Drawing.Point(280, 22);
            this.chkCCD5.Name = "chkCCD5";
            this.chkCCD5.Size = new System.Drawing.Size(67, 20);
            this.chkCCD5.TabIndex = 90;
            this.chkCCD5.Text = "CCD 5";
            this.chkCCD5.UseVisualStyleBackColor = true;
            // 
            // chkCCD4
            // 
            this.chkCCD4.AutoSize = true;
            this.chkCCD4.Location = new System.Drawing.Point(207, 22);
            this.chkCCD4.Name = "chkCCD4";
            this.chkCCD4.Size = new System.Drawing.Size(67, 20);
            this.chkCCD4.TabIndex = 89;
            this.chkCCD4.Text = "CCD 4";
            this.chkCCD4.UseVisualStyleBackColor = true;
            // 
            // chkCCD3
            // 
            this.chkCCD3.AutoSize = true;
            this.chkCCD3.Location = new System.Drawing.Point(115, 22);
            this.chkCCD3.Name = "chkCCD3";
            this.chkCCD3.Size = new System.Drawing.Size(67, 20);
            this.chkCCD3.TabIndex = 88;
            this.chkCCD3.Text = "CCD 3";
            this.chkCCD3.UseVisualStyleBackColor = true;
            // 
            // chkCCD1
            // 
            this.chkCCD1.AutoSize = true;
            this.chkCCD1.Location = new System.Drawing.Point(28, 22);
            this.chkCCD1.Name = "chkCCD1";
            this.chkCCD1.Size = new System.Drawing.Size(67, 20);
            this.chkCCD1.TabIndex = 87;
            this.chkCCD1.Text = "CCD 1";
            this.chkCCD1.UseVisualStyleBackColor = true;
            // 
            // richTextBox_Calib
            // 
            this.richTextBox_Calib.Location = new System.Drawing.Point(469, 45);
            this.richTextBox_Calib.Name = "richTextBox_Calib";
            this.richTextBox_Calib.Size = new System.Drawing.Size(720, 216);
            this.richTextBox_Calib.TabIndex = 144;
            this.richTextBox_Calib.Text = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(28, 45);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(133, 14);
            this.label21.TabIndex = 60;
            this.label21.Text = "Camera Conn Status";
            // 
            // lblServo_Conn_Status_X
            // 
            this.lblServo_Conn_Status_X.BackColor = System.Drawing.Color.Maroon;
            this.lblServo_Conn_Status_X.Location = new System.Drawing.Point(198, 38);
            this.lblServo_Conn_Status_X.Name = "lblServo_Conn_Status_X";
            this.lblServo_Conn_Status_X.Size = new System.Drawing.Size(26, 26);
            this.lblServo_Conn_Status_X.TabIndex = 61;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 14);
            this.label3.TabIndex = 85;
            this.label3.Text = "Running Steps";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 14);
            this.label2.TabIndex = 143;
            this.label2.Text = "Vision Calibration :";
            // 
            // btnCamera_Stop
            // 
            this.btnCamera_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnCamera_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamera_Stop.ForeColor = System.Drawing.Color.White;
            this.btnCamera_Stop.Location = new System.Drawing.Point(202, 226);
            this.btnCamera_Stop.Name = "btnCamera_Stop";
            this.btnCamera_Stop.Size = new System.Drawing.Size(99, 35);
            this.btnCamera_Stop.TabIndex = 90;
            this.btnCamera_Stop.Text = "Stop";
            this.btnCamera_Stop.UseVisualStyleBackColor = false;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(189, 79);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(119, 26);
            this.textBox4.TabIndex = 142;
            // 
            // btnCamera_Start
            // 
            this.btnCamera_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnCamera_Start.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamera_Start.ForeColor = System.Drawing.Color.White;
            this.btnCamera_Start.Location = new System.Drawing.Point(27, 226);
            this.btnCamera_Start.Name = "btnCamera_Start";
            this.btnCamera_Start.Size = new System.Drawing.Size(99, 35);
            this.btnCamera_Start.TabIndex = 89;
            this.btnCamera_Start.Text = "Start";
            this.btnCamera_Start.UseVisualStyleBackColor = false;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.tabControl3);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1285, 583);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "SOP";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage13);
            this.tabControl3.Controls.Add(this.tabPage14);
            this.tabControl3.Controls.Add(this.tabPage15);
            this.tabControl3.Controls.Add(this.tabPage16);
            this.tabControl3.Location = new System.Drawing.Point(20, 18);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(888, 472);
            this.tabControl3.TabIndex = 88;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.label4);
            this.tabPage13.Controls.Add(this.label5);
            this.tabPage13.Controls.Add(this.label6);
            this.tabPage13.Controls.Add(this.label7);
            this.tabPage13.Controls.Add(this.textBox28);
            this.tabPage13.Controls.Add(this.textBox29);
            this.tabPage13.Controls.Add(this.label8);
            this.tabPage13.Controls.Add(this.button10);
            this.tabPage13.Controls.Add(this.Cam1_path);
            this.tabPage13.Controls.Add(this.lblactualpos_ccd1_y);
            this.tabPage13.Controls.Add(this.lblactualpos_ccd1_x);
            this.tabPage13.Controls.Add(this.label9);
            this.tabPage13.Controls.Add(this.label10);
            this.tabPage13.Controls.Add(this.label11);
            this.tabPage13.Controls.Add(this.label12);
            this.tabPage13.Controls.Add(this.button11);
            this.tabPage13.Controls.Add(this.button12);
            this.tabPage13.Controls.Add(this.CCD1count);
            this.tabPage13.Controls.Add(this.label13);
            this.tabPage13.Controls.Add(this.CCD1Speed);
            this.tabPage13.Controls.Add(this.label14);
            this.tabPage13.Controls.Add(this.textBox33);
            this.tabPage13.Controls.Add(this.textBox34);
            this.tabPage13.Controls.Add(this.label25);
            this.tabPage13.Controls.Add(this.label28);
            this.tabPage13.Controls.Add(this.textBox35);
            this.tabPage13.Controls.Add(this.label29);
            this.tabPage13.Controls.Add(this.textBox36);
            this.tabPage13.Controls.Add(this.label15);
            this.tabPage13.Controls.Add(this.lblRunningCount);
            this.tabPage13.Controls.Add(this.label16);
            this.tabPage13.Controls.Add(this.cmbTestMode);
            this.tabPage13.Controls.Add(this.label17);
            this.tabPage13.Location = new System.Drawing.Point(4, 25);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(880, 443);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "CCD1";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(289, 253);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.TabIndex = 143;
            this.label4.Text = "(mm/s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(438, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 16);
            this.label5.TabIndex = 142;
            this.label5.Text = "(mm)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(438, 175);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 16);
            this.label6.TabIndex = 141;
            this.label6.Text = "(mm)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(438, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 16);
            this.label7.TabIndex = 140;
            this.label7.Text = "(mm)";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(292, 211);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(63, 23);
            this.textBox28.TabIndex = 139;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(215, 208);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(63, 23);
            this.textBox29.TabIndex = 138;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(58, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 16);
            this.label8.TabIndex = 137;
            this.label8.Text = "Static Pos";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button10.Enabled = false;
            this.button10.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(359, 357);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(83, 29);
            this.button10.TabIndex = 136;
            this.button10.Text = "Browse";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // Cam1_path
            // 
            this.Cam1_path.Enabled = false;
            this.Cam1_path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam1_path.Location = new System.Drawing.Point(61, 363);
            this.Cam1_path.Name = "Cam1_path";
            this.Cam1_path.Size = new System.Drawing.Size(201, 23);
            this.Cam1_path.TabIndex = 135;
            // 
            // lblactualpos_ccd1_y
            // 
            this.lblactualpos_ccd1_y.AutoSize = true;
            this.lblactualpos_ccd1_y.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblactualpos_ccd1_y.Location = new System.Drawing.Point(476, 72);
            this.lblactualpos_ccd1_y.Name = "lblactualpos_ccd1_y";
            this.lblactualpos_ccd1_y.Size = new System.Drawing.Size(16, 16);
            this.lblactualpos_ccd1_y.TabIndex = 134;
            this.lblactualpos_ccd1_y.Text = "0";
            // 
            // lblactualpos_ccd1_x
            // 
            this.lblactualpos_ccd1_x.AutoSize = true;
            this.lblactualpos_ccd1_x.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblactualpos_ccd1_x.Location = new System.Drawing.Point(438, 71);
            this.lblactualpos_ccd1_x.Name = "lblactualpos_ccd1_x";
            this.lblactualpos_ccd1_x.Size = new System.Drawing.Size(16, 16);
            this.lblactualpos_ccd1_x.TabIndex = 133;
            this.lblactualpos_ccd1_x.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(476, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 16);
            this.label9.TabIndex = 132;
            this.label9.Text = "Y";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(438, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(17, 16);
            this.label10.TabIndex = 131;
            this.label10.Text = "X";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(288, 71);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 16);
            this.label11.TabIndex = 130;
            this.label11.Text = "Actual Position";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(58, 329);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 16);
            this.label12.TabIndex = 129;
            this.label12.Text = "CSV File Save Path";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button11.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(61, 400);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(83, 37);
            this.button11.TabIndex = 128;
            this.button11.Text = "Start";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button12.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(179, 399);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(83, 37);
            this.button12.TabIndex = 127;
            this.button12.Text = "Stop";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // CCD1count
            // 
            this.CCD1count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD1count.Location = new System.Drawing.Point(215, 291);
            this.CCD1count.Name = "CCD1count";
            this.CCD1count.Size = new System.Drawing.Size(63, 23);
            this.CCD1count.TabIndex = 126;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(58, 295);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 16);
            this.label13.TabIndex = 125;
            this.label13.Text = "No of Counts";
            // 
            // CCD1Speed
            // 
            this.CCD1Speed.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD1Speed.Location = new System.Drawing.Point(215, 250);
            this.CCD1Speed.Name = "CCD1Speed";
            this.CCD1Speed.Size = new System.Drawing.Size(63, 23);
            this.CCD1Speed.TabIndex = 124;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(58, 253);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 16);
            this.label14.TabIndex = 123;
            this.label14.Text = "Speed";
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(292, 168);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(63, 23);
            this.textBox33.TabIndex = 122;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(292, 129);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(63, 23);
            this.textBox34.TabIndex = 121;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(315, 100);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 16);
            this.label25.TabIndex = 120;
            this.label25.Text = "Y";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(237, 100);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 16);
            this.label28.TabIndex = 119;
            this.label28.Text = "X";
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(215, 168);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(63, 23);
            this.textBox35.TabIndex = 118;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(58, 168);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(104, 16);
            this.label29.TabIndex = 117;
            this.label29.Text = "Dynamic Pos 2";
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(215, 129);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(63, 23);
            this.textBox36.TabIndex = 116;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(58, 129);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 16);
            this.label15.TabIndex = 115;
            this.label15.Text = "Dynamic Pos 1";
            // 
            // lblRunningCount
            // 
            this.lblRunningCount.AutoSize = true;
            this.lblRunningCount.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRunningCount.Location = new System.Drawing.Point(204, 71);
            this.lblRunningCount.Name = "lblRunningCount";
            this.lblRunningCount.Size = new System.Drawing.Size(16, 16);
            this.lblRunningCount.TabIndex = 114;
            this.lblRunningCount.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(58, 72);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 16);
            this.label16.TabIndex = 113;
            this.label16.Text = "Running Count";
            // 
            // cmbTestMode
            // 
            this.cmbTestMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTestMode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTestMode.FormattingEnabled = true;
            this.cmbTestMode.Items.AddRange(new object[] {
            "Dynamic",
            "Static"});
            this.cmbTestMode.Location = new System.Drawing.Point(207, 17);
            this.cmbTestMode.Name = "cmbTestMode";
            this.cmbTestMode.Size = new System.Drawing.Size(154, 24);
            this.cmbTestMode.TabIndex = 112;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(58, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 16);
            this.label17.TabIndex = 111;
            this.label17.Text = "Test Mode";
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.button5);
            this.tabPage14.Controls.Add(this.Cam3_path);
            this.tabPage14.Controls.Add(this.label46);
            this.tabPage14.Controls.Add(this.button6);
            this.tabPage14.Controls.Add(this.button7);
            this.tabPage14.Controls.Add(this.CCD3count);
            this.tabPage14.Controls.Add(this.label47);
            this.tabPage14.Location = new System.Drawing.Point(4, 25);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(880, 443);
            this.tabPage14.TabIndex = 1;
            this.tabPage14.Text = "CCD3";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button5.Enabled = false;
            this.button5.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(317, 218);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(83, 29);
            this.button5.TabIndex = 88;
            this.button5.Text = "Browse";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // Cam3_path
            // 
            this.Cam3_path.Enabled = false;
            this.Cam3_path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam3_path.Location = new System.Drawing.Point(57, 224);
            this.Cam3_path.Name = "Cam3_path";
            this.Cam3_path.Size = new System.Drawing.Size(201, 23);
            this.Cam3_path.TabIndex = 87;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(53, 147);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(135, 16);
            this.label46.TabIndex = 86;
            this.label46.Text = "CSV File Save Path";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(87, 380);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(83, 37);
            this.button6.TabIndex = 85;
            this.button6.Text = "Start";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button7.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(209, 377);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(83, 37);
            this.button7.TabIndex = 84;
            this.button7.Text = "Stop";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // CCD3count
            // 
            this.CCD3count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD3count.Location = new System.Drawing.Point(240, 84);
            this.CCD3count.Name = "CCD3count";
            this.CCD3count.Size = new System.Drawing.Size(63, 23);
            this.CCD3count.TabIndex = 83;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(53, 84);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(94, 16);
            this.label47.TabIndex = 82;
            this.label47.Text = "No of Counts";
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.button8);
            this.tabPage15.Controls.Add(this.Cam4_path);
            this.tabPage15.Controls.Add(this.label66);
            this.tabPage15.Controls.Add(this.button9);
            this.tabPage15.Controls.Add(this.button13);
            this.tabPage15.Controls.Add(this.CCD4count);
            this.tabPage15.Controls.Add(this.label18);
            this.tabPage15.Location = new System.Drawing.Point(4, 25);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Size = new System.Drawing.Size(880, 443);
            this.tabPage15.TabIndex = 2;
            this.tabPage15.Text = "CCD4";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button8.Enabled = false;
            this.button8.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(304, 205);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(83, 29);
            this.button8.TabIndex = 88;
            this.button8.Text = "Browse";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // Cam4_path
            // 
            this.Cam4_path.Enabled = false;
            this.Cam4_path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam4_path.Location = new System.Drawing.Point(59, 221);
            this.Cam4_path.Name = "Cam4_path";
            this.Cam4_path.Size = new System.Drawing.Size(201, 23);
            this.Cam4_path.TabIndex = 87;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(56, 151);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(135, 16);
            this.label66.TabIndex = 86;
            this.label66.Text = "CSV File Save Path";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button9.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(114, 359);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(83, 37);
            this.button9.TabIndex = 85;
            this.button9.Text = "Start";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button13.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(227, 359);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(83, 37);
            this.button13.TabIndex = 84;
            this.button13.Text = "Stop";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // CCD4count
            // 
            this.CCD4count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD4count.Location = new System.Drawing.Point(247, 82);
            this.CCD4count.Name = "CCD4count";
            this.CCD4count.Size = new System.Drawing.Size(63, 23);
            this.CCD4count.TabIndex = 83;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(56, 82);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(94, 16);
            this.label18.TabIndex = 82;
            this.label18.Text = "No of Counts";
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.txttriggerpos);
            this.tabPage16.Controls.Add(this.label19);
            this.tabPage16.Controls.Add(this.txtonflyintervel);
            this.tabPage16.Controls.Add(this.label20);
            this.tabPage16.Controls.Add(this.label22);
            this.tabPage16.Controls.Add(this.label23);
            this.tabPage16.Controls.Add(this.label24);
            this.tabPage16.Controls.Add(this.label26);
            this.tabPage16.Controls.Add(this.textBox19);
            this.tabPage16.Controls.Add(this.textBox20);
            this.tabPage16.Controls.Add(this.label27);
            this.tabPage16.Controls.Add(this.button14);
            this.tabPage16.Controls.Add(this.Cam5__path);
            this.tabPage16.Controls.Add(this.label30);
            this.tabPage16.Controls.Add(this.label31);
            this.tabPage16.Controls.Add(this.label32);
            this.tabPage16.Controls.Add(this.label33);
            this.tabPage16.Controls.Add(this.label34);
            this.tabPage16.Controls.Add(this.label35);
            this.tabPage16.Controls.Add(this.button15);
            this.tabPage16.Controls.Add(this.button16);
            this.tabPage16.Controls.Add(this.CCD5count);
            this.tabPage16.Controls.Add(this.label36);
            this.tabPage16.Controls.Add(this.CCD5Speed);
            this.tabPage16.Controls.Add(this.label37);
            this.tabPage16.Controls.Add(this.textBox24);
            this.tabPage16.Controls.Add(this.textBox25);
            this.tabPage16.Controls.Add(this.label38);
            this.tabPage16.Controls.Add(this.label39);
            this.tabPage16.Controls.Add(this.textBox26);
            this.tabPage16.Controls.Add(this.label40);
            this.tabPage16.Controls.Add(this.textBox27);
            this.tabPage16.Controls.Add(this.label41);
            this.tabPage16.Controls.Add(this.label42);
            this.tabPage16.Controls.Add(this.label43);
            this.tabPage16.Controls.Add(this.CCD5TestMode);
            this.tabPage16.Controls.Add(this.label44);
            this.tabPage16.Location = new System.Drawing.Point(4, 25);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Size = new System.Drawing.Size(880, 443);
            this.tabPage16.TabIndex = 3;
            this.tabPage16.Text = "CCD5";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // txttriggerpos
            // 
            this.txttriggerpos.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttriggerpos.Location = new System.Drawing.Point(557, 314);
            this.txttriggerpos.Name = "txttriggerpos";
            this.txttriggerpos.Size = new System.Drawing.Size(63, 23);
            this.txttriggerpos.TabIndex = 159;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(445, 317);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(81, 16);
            this.label19.TabIndex = 158;
            this.label19.Text = "Trigger pos";
            // 
            // txtonflyintervel
            // 
            this.txtonflyintervel.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtonflyintervel.Location = new System.Drawing.Point(557, 283);
            this.txtonflyintervel.Name = "txtonflyintervel";
            this.txtonflyintervel.Size = new System.Drawing.Size(63, 23);
            this.txtonflyintervel.TabIndex = 157;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(445, 286);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(103, 16);
            this.label20.TabIndex = 156;
            this.label20.Text = "On-fly interval";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(292, 248);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 16);
            this.label22.TabIndex = 155;
            this.label22.Text = "(mm/s)";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(368, 209);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 16);
            this.label23.TabIndex = 154;
            this.label23.Text = "(mm)";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(368, 170);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(40, 16);
            this.label24.TabIndex = 153;
            this.label24.Text = "(mm)";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(368, 131);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 16);
            this.label26.TabIndex = 152;
            this.label26.Text = "(mm)";
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(295, 206);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(63, 23);
            this.textBox19.TabIndex = 151;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(218, 203);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(63, 23);
            this.textBox20.TabIndex = 150;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(60, 206);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(76, 16);
            this.label27.TabIndex = 149;
            this.label27.Text = "Static Pos";
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button14.Enabled = false;
            this.button14.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(340, 355);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(83, 29);
            this.button14.TabIndex = 148;
            this.button14.Text = "Browse";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // Cam5__path
            // 
            this.Cam5__path.Enabled = false;
            this.Cam5__path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam5__path.Location = new System.Drawing.Point(63, 358);
            this.Cam5__path.Name = "Cam5__path";
            this.Cam5__path.Size = new System.Drawing.Size(201, 23);
            this.Cam5__path.TabIndex = 147;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(530, 66);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(16, 16);
            this.label30.TabIndex = 146;
            this.label30.Text = "0";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(485, 66);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(16, 16);
            this.label31.TabIndex = 145;
            this.label31.Text = "0";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(530, 35);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(17, 16);
            this.label32.TabIndex = 144;
            this.label32.Text = "Y";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(484, 35);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(17, 16);
            this.label33.TabIndex = 143;
            this.label33.Text = "X";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(304, 66);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(106, 16);
            this.label34.TabIndex = 142;
            this.label34.Text = "Actual Position";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(60, 324);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(135, 16);
            this.label35.TabIndex = 141;
            this.label35.Text = "CSV File Save Path";
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button15.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(70, 394);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(83, 37);
            this.button15.TabIndex = 140;
            this.button15.Text = "Start";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button16.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(181, 394);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(83, 37);
            this.button16.TabIndex = 139;
            this.button16.Text = "Stop";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // CCD5count
            // 
            this.CCD5count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD5count.Location = new System.Drawing.Point(218, 286);
            this.CCD5count.Name = "CCD5count";
            this.CCD5count.Size = new System.Drawing.Size(63, 23);
            this.CCD5count.TabIndex = 138;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(60, 290);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(94, 16);
            this.label36.TabIndex = 137;
            this.label36.Text = "No of Counts";
            // 
            // CCD5Speed
            // 
            this.CCD5Speed.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD5Speed.Location = new System.Drawing.Point(218, 245);
            this.CCD5Speed.Name = "CCD5Speed";
            this.CCD5Speed.Size = new System.Drawing.Size(63, 23);
            this.CCD5Speed.TabIndex = 136;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(60, 248);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(49, 16);
            this.label37.TabIndex = 135;
            this.label37.Text = "Speed";
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(295, 163);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(63, 23);
            this.textBox24.TabIndex = 134;
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(295, 124);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(63, 23);
            this.textBox25.TabIndex = 133;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(318, 95);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(17, 16);
            this.label38.TabIndex = 132;
            this.label38.Text = "Y";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(240, 95);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(17, 16);
            this.label39.TabIndex = 131;
            this.label39.Text = "X";
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(218, 163);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(63, 23);
            this.textBox26.TabIndex = 130;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(60, 163);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(104, 16);
            this.label40.TabIndex = 129;
            this.label40.Text = "Dynamic Pos 2";
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(218, 124);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(63, 23);
            this.textBox27.TabIndex = 128;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(60, 124);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(104, 16);
            this.label41.TabIndex = 127;
            this.label41.Text = "Dynamic Pos 1";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(217, 66);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(16, 16);
            this.label42.TabIndex = 126;
            this.label42.Text = "0";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(60, 68);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(103, 16);
            this.label43.TabIndex = 125;
            this.label43.Text = "Running Count";
            // 
            // CCD5TestMode
            // 
            this.CCD5TestMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CCD5TestMode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD5TestMode.FormattingEnabled = true;
            this.CCD5TestMode.Items.AddRange(new object[] {
            "Dynamic",
            "Static"});
            this.CCD5TestMode.Location = new System.Drawing.Point(220, 15);
            this.CCD5TestMode.Name = "CCD5TestMode";
            this.CCD5TestMode.Size = new System.Drawing.Size(154, 24);
            this.CCD5TestMode.TabIndex = 124;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(60, 21);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(77, 16);
            this.label44.TabIndex = 123;
            this.label44.Text = "Test Mode";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.tabControl1);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1285, 583);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "IO Diagnostic";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.Motion_Card_IO);
            this.tabControl1.Controls.Add(this.Motion_Card_Output);
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold);
            this.tabControl1.Location = new System.Drawing.Point(6, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(958, 602);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(950, 573);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "PLC Input";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(950, 573);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "PLC Input";
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(950, 573);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "PLC Output";
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(950, 573);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "PLC Output";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.Load_Caliration);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(950, 573);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Loadcell Calibration";
            // 
            // Load_Caliration
            // 
            this.Load_Caliration.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Load_Caliration.Controls.Add(this.textBox1);
            this.Load_Caliration.Controls.Add(this.textBox2);
            this.Load_Caliration.Controls.Add(this.btnSaveSlope);
            this.Load_Caliration.Controls.Add(this.btnEdtSlope);
            this.Load_Caliration.Controls.Add(this.txtoffset4);
            this.Load_Caliration.Controls.Add(this.txtoffset0);
            this.Load_Caliration.Controls.Add(this.label130);
            this.Load_Caliration.Controls.Add(this.label131);
            this.Load_Caliration.Controls.Add(this.txtmstrvlt);
            this.Load_Caliration.Controls.Add(this.txt_mstrload);
            this.Load_Caliration.Controls.Add(this.label132);
            this.Load_Caliration.Controls.Add(this.label105);
            this.Load_Caliration.Controls.Add(this.label129);
            this.Load_Caliration.Controls.Add(this.label128);
            this.Load_Caliration.Controls.Add(this.label127);
            this.Load_Caliration.Controls.Add(this.label126);
            this.Load_Caliration.Controls.Add(this.label124);
            this.Load_Caliration.Controls.Add(this.label123);
            this.Load_Caliration.Controls.Add(this.txtoffset1);
            this.Load_Caliration.Controls.Add(this.txtSlope4);
            this.Load_Caliration.Controls.Add(this.txtSlope1);
            this.Load_Caliration.Controls.Add(this.txtSlope0);
            this.Load_Caliration.Controls.Add(this.btn_Nozzle_Z_Stop);
            this.Load_Caliration.Controls.Add(this.btn_Nozzle_Z_Move);
            this.Load_Caliration.Controls.Add(this.button2);
            this.Load_Caliration.Controls.Add(this.button1);
            this.Load_Caliration.Controls.Add(this.label111);
            this.Load_Caliration.Controls.Add(this.txtloadvlt2);
            this.Load_Caliration.Controls.Add(this.label108);
            this.Load_Caliration.Controls.Add(this.txtloadvlt1);
            this.Load_Caliration.Controls.Add(this.label104);
            this.Load_Caliration.Controls.Add(this.txtLoadcell2);
            this.Load_Caliration.Controls.Add(this.txtLoadcell1);
            this.Load_Caliration.Controls.Add(this.label102);
            this.Load_Caliration.Controls.Add(this.label103);
            this.Load_Caliration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Load_Caliration.Location = new System.Drawing.Point(0, 0);
            this.Load_Caliration.Name = "Load_Caliration";
            this.Load_Caliration.Size = new System.Drawing.Size(950, 573);
            this.Load_Caliration.TabIndex = 154;
            this.Load_Caliration.Paint += new System.Windows.Forms.PaintEventHandler(this.Load_Caliration_Paint);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(366, 367);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 159;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(366, 290);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 23);
            this.textBox2.TabIndex = 158;
            // 
            // btnSaveSlope
            // 
            this.btnSaveSlope.Location = new System.Drawing.Point(1196, 138);
            this.btnSaveSlope.Name = "btnSaveSlope";
            this.btnSaveSlope.Size = new System.Drawing.Size(105, 28);
            this.btnSaveSlope.TabIndex = 157;
            this.btnSaveSlope.Text = "SaveSlope";
            this.btnSaveSlope.UseVisualStyleBackColor = true;
            // 
            // btnEdtSlope
            // 
            this.btnEdtSlope.Location = new System.Drawing.Point(1196, 79);
            this.btnEdtSlope.Name = "btnEdtSlope";
            this.btnEdtSlope.Size = new System.Drawing.Size(98, 29);
            this.btnEdtSlope.TabIndex = 156;
            this.btnEdtSlope.Text = "EditSlope";
            this.btnEdtSlope.UseVisualStyleBackColor = true;
            // 
            // txtoffset4
            // 
            this.txtoffset4.Location = new System.Drawing.Point(1049, 207);
            this.txtoffset4.Name = "txtoffset4";
            this.txtoffset4.Size = new System.Drawing.Size(100, 23);
            this.txtoffset4.TabIndex = 155;
            // 
            // txtoffset0
            // 
            this.txtoffset0.Location = new System.Drawing.Point(1049, 81);
            this.txtoffset0.Name = "txtoffset0";
            this.txtoffset0.Size = new System.Drawing.Size(100, 23);
            this.txtoffset0.TabIndex = 154;
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label130.Location = new System.Drawing.Point(512, 217);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(32, 16);
            this.label130.TabIndex = 114;
            this.label130.Text = "(Kg)";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.Location = new System.Drawing.Point(764, 212);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(37, 16);
            this.label131.TabIndex = 113;
            this.label131.Text = "(mA)";
            // 
            // txtmstrvlt
            // 
            this.txtmstrvlt.Location = new System.Drawing.Point(614, 212);
            this.txtmstrvlt.Name = "txtmstrvlt";
            this.txtmstrvlt.Size = new System.Drawing.Size(100, 23);
            this.txtmstrvlt.TabIndex = 112;
            // 
            // txt_mstrload
            // 
            this.txt_mstrload.Location = new System.Drawing.Point(366, 216);
            this.txt_mstrload.Name = "txt_mstrload";
            this.txt_mstrload.Size = new System.Drawing.Size(100, 23);
            this.txt_mstrload.TabIndex = 111;
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.Location = new System.Drawing.Point(202, 217);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(93, 16);
            this.label132.TabIndex = 110;
            this.label132.Text = "MasterLoadcell";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.Location = new System.Drawing.Point(512, 150);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(32, 16);
            this.label105.TabIndex = 107;
            this.label105.Text = "(Kg)";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.Location = new System.Drawing.Point(512, 368);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(40, 16);
            this.label129.TabIndex = 106;
            this.label129.Text = "(mm)";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.Location = new System.Drawing.Point(512, 291);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(40, 16);
            this.label128.TabIndex = 105;
            this.label128.Text = "(mm)";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.Location = new System.Drawing.Point(202, 368);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(144, 16);
            this.label127.TabIndex = 104;
            this.label127.Text = "Final Inspection Z Down";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label126.Location = new System.Drawing.Point(202, 291);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(127, 16);
            this.label126.TabIndex = 103;
            this.label126.Text = "Final Inspection Z Up";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.Location = new System.Drawing.Point(1067, 32);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(42, 16);
            this.label124.TabIndex = 101;
            this.label124.Text = "Offset";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(901, 36);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(40, 16);
            this.label123.TabIndex = 100;
            this.label123.Text = "Slope";
            // 
            // txtoffset1
            // 
            this.txtoffset1.Location = new System.Drawing.Point(1049, 141);
            this.txtoffset1.Name = "txtoffset1";
            this.txtoffset1.Size = new System.Drawing.Size(100, 23);
            this.txtoffset1.TabIndex = 99;
            // 
            // txtSlope4
            // 
            this.txtSlope4.Location = new System.Drawing.Point(882, 207);
            this.txtSlope4.Name = "txtSlope4";
            this.txtSlope4.Size = new System.Drawing.Size(100, 23);
            this.txtSlope4.TabIndex = 96;
            // 
            // txtSlope1
            // 
            this.txtSlope1.Location = new System.Drawing.Point(882, 145);
            this.txtSlope1.Name = "txtSlope1";
            this.txtSlope1.Size = new System.Drawing.Size(100, 23);
            this.txtSlope1.TabIndex = 93;
            // 
            // txtSlope0
            // 
            this.txtSlope0.Location = new System.Drawing.Point(882, 79);
            this.txtSlope0.Name = "txtSlope0";
            this.txtSlope0.Size = new System.Drawing.Size(100, 23);
            this.txtSlope0.TabIndex = 92;
            // 
            // btn_Nozzle_Z_Stop
            // 
            this.btn_Nozzle_Z_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btn_Nozzle_Z_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Nozzle_Z_Stop.ForeColor = System.Drawing.Color.White;
            this.btn_Nozzle_Z_Stop.Location = new System.Drawing.Point(450, 451);
            this.btn_Nozzle_Z_Stop.Name = "btn_Nozzle_Z_Stop";
            this.btn_Nozzle_Z_Stop.Size = new System.Drawing.Size(83, 37);
            this.btn_Nozzle_Z_Stop.TabIndex = 89;
            this.btn_Nozzle_Z_Stop.Text = "Stop";
            this.btn_Nozzle_Z_Stop.UseVisualStyleBackColor = false;
            // 
            // btn_Nozzle_Z_Move
            // 
            this.btn_Nozzle_Z_Move.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btn_Nozzle_Z_Move.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Nozzle_Z_Move.ForeColor = System.Drawing.Color.White;
            this.btn_Nozzle_Z_Move.Location = new System.Drawing.Point(288, 451);
            this.btn_Nozzle_Z_Move.Name = "btn_Nozzle_Z_Move";
            this.btn_Nozzle_Z_Move.Size = new System.Drawing.Size(83, 37);
            this.btn_Nozzle_Z_Move.TabIndex = 88;
            this.btn_Nozzle_Z_Move.Text = "Move";
            this.btn_Nozzle_Z_Move.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1051, 258);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 31);
            this.button2.TabIndex = 85;
            this.button2.Text = "Analog Scan off";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(882, 258);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 31);
            this.button1.TabIndex = 84;
            this.button1.Text = "Analog Scan on";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(764, 138);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(26, 16);
            this.label111.TabIndex = 83;
            this.label111.Text = "(V)";
            // 
            // txtloadvlt2
            // 
            this.txtloadvlt2.Location = new System.Drawing.Point(614, 140);
            this.txtloadvlt2.Name = "txtloadvlt2";
            this.txtloadvlt2.Size = new System.Drawing.Size(100, 23);
            this.txtloadvlt2.TabIndex = 82;
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(764, 86);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(26, 16);
            this.label108.TabIndex = 77;
            this.label108.Text = "(V)";
            // 
            // txtloadvlt1
            // 
            this.txtloadvlt1.Location = new System.Drawing.Point(614, 81);
            this.txtloadvlt1.Name = "txtloadvlt1";
            this.txtloadvlt1.Size = new System.Drawing.Size(100, 23);
            this.txtloadvlt1.TabIndex = 76;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(512, 86);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(32, 16);
            this.label104.TabIndex = 72;
            this.label104.Text = "(Kg)";
            // 
            // txtLoadcell2
            // 
            this.txtLoadcell2.Location = new System.Drawing.Point(366, 145);
            this.txtLoadcell2.Name = "txtLoadcell2";
            this.txtLoadcell2.Size = new System.Drawing.Size(100, 23);
            this.txtLoadcell2.TabIndex = 69;
            // 
            // txtLoadcell1
            // 
            this.txtLoadcell1.Location = new System.Drawing.Point(366, 86);
            this.txtLoadcell1.Name = "txtLoadcell1";
            this.txtLoadcell1.Size = new System.Drawing.Size(100, 23);
            this.txtLoadcell1.TabIndex = 68;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(202, 146);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(67, 16);
            this.label102.TabIndex = 65;
            this.label102.Text = "LoadCell 2";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(202, 87);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(67, 16);
            this.label103.TabIndex = 64;
            this.label103.Text = "LoadCell 1";
            // 
            // Motion_Card_IO
            // 
            this.Motion_Card_IO.Location = new System.Drawing.Point(4, 25);
            this.Motion_Card_IO.Name = "Motion_Card_IO";
            this.Motion_Card_IO.Size = new System.Drawing.Size(950, 573);
            this.Motion_Card_IO.TabIndex = 1;
            this.Motion_Card_IO.Text = "Motion Card DI";
            this.Motion_Card_IO.UseVisualStyleBackColor = true;
            // 
            // Motion_Card_Output
            // 
            this.Motion_Card_Output.Location = new System.Drawing.Point(4, 25);
            this.Motion_Card_Output.Name = "Motion_Card_Output";
            this.Motion_Card_Output.Size = new System.Drawing.Size(950, 573);
            this.Motion_Card_Output.TabIndex = 2;
            this.Motion_Card_Output.Text = "Motion Card DO Output";
            this.Motion_Card_Output.UseVisualStyleBackColor = true;
            // 
            // tabPage0
            // 
            this.tabPage0.Controls.Add(this.Axis_datagridview);
            this.tabPage0.Location = new System.Drawing.Point(4, 25);
            this.tabPage0.Name = "tabPage0";
            this.tabPage0.Size = new System.Drawing.Size(1285, 583);
            this.tabPage0.TabIndex = 0;
            this.tabPage0.Text = "Axis parameter settings";
            this.tabPage0.UseVisualStyleBackColor = true;
            this.tabPage0.Click += new System.EventHandler(this.tabPage1_Click_1);
            // 
            // Axis_datagridview
            // 
            this.Axis_datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Axis_datagridview.Location = new System.Drawing.Point(16, 14);
            this.Axis_datagridview.Name = "Axis_datagridview";
            this.Axis_datagridview.Size = new System.Drawing.Size(1209, 524);
            this.Axis_datagridview.TabIndex = 0;
            this.Axis_datagridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox1);
            this.tabPage7.Controls.Add(this.groupBox4);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1285, 583);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "System Settings";
            this.tabPage7.UseVisualStyleBackColor = true;
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.checkBox9);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.offlinemode);
            this.groupBox1.Controls.Add(this.onlinemode);
            this.groupBox1.Controls.Add(this.productionmode);
            this.groupBox1.Controls.Add(this.dryrun);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(524, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(270, 482);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "System Settings";
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox9.Location = new System.Drawing.Point(15, 381);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(60, 20);
            this.checkBox9.TabIndex = 33;
            this.checkBox9.Text = "Hive";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.Location = new System.Drawing.Point(13, 199);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(123, 20);
            this.radioButton2.TabIndex = 32;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Conv Dry Run";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(13, 170);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(167, 20);
            this.radioButton1.TabIndex = 31;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Conv Run With Tray";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // offlinemode
            // 
            this.offlinemode.AutoSize = true;
            this.offlinemode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.offlinemode.Location = new System.Drawing.Point(13, 140);
            this.offlinemode.Name = "offlinemode";
            this.offlinemode.Size = new System.Drawing.Size(116, 20);
            this.offlinemode.TabIndex = 30;
            this.offlinemode.TabStop = true;
            this.offlinemode.Text = "Offline Mode";
            this.offlinemode.UseVisualStyleBackColor = true;
            // 
            // onlinemode
            // 
            this.onlinemode.AutoSize = true;
            this.onlinemode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.onlinemode.Location = new System.Drawing.Point(12, 106);
            this.onlinemode.Name = "onlinemode";
            this.onlinemode.Size = new System.Drawing.Size(115, 20);
            this.onlinemode.TabIndex = 29;
            this.onlinemode.TabStop = true;
            this.onlinemode.Text = "Online Mode";
            this.onlinemode.UseVisualStyleBackColor = true;
            // 
            // productionmode
            // 
            this.productionmode.AutoSize = true;
            this.productionmode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productionmode.Location = new System.Drawing.Point(12, 73);
            this.productionmode.Name = "productionmode";
            this.productionmode.Size = new System.Drawing.Size(147, 20);
            this.productionmode.TabIndex = 28;
            this.productionmode.TabStop = true;
            this.productionmode.Text = "Production Mode";
            this.productionmode.UseVisualStyleBackColor = true;
            // 
            // dryrun
            // 
            this.dryrun.AutoSize = true;
            this.dryrun.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dryrun.Location = new System.Drawing.Point(12, 41);
            this.dryrun.Name = "dryrun";
            this.dryrun.Size = new System.Drawing.Size(82, 20);
            this.dryrun.TabIndex = 27;
            this.dryrun.TabStop = true;
            this.dryrun.Text = "Dry Run";
            this.dryrun.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(15, 346);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(123, 20);
            this.checkBox4.TabIndex = 26;
            this.checkBox4.Text = "PDCA Bypass";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(15, 308);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(112, 20);
            this.checkBox3.TabIndex = 25;
            this.checkBox3.Text = "SFC Bypass";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(15, 273);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(169, 20);
            this.checkBox2.TabIndex = 24;
            this.checkBox2.Text = "Safety Door Bypass";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(15, 236);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(143, 20);
            this.checkBox1.TabIndex = 23;
            this.checkBox1.Text = "Scanner Bypass";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.White;
            this.groupBox4.Controls.Add(this.labelControl13);
            this.groupBox4.Controls.Add(this.labelControl9);
            this.groupBox4.Controls.Add(this.labelControl8);
            this.groupBox4.Controls.Add(this.labelControl7);
            this.groupBox4.Controls.Add(this.labelControl12);
            this.groupBox4.Controls.Add(this.labelControl11);
            this.groupBox4.Controls.Add(this.labelControl10);
            this.groupBox4.Controls.Add(this.labelControl6);
            this.groupBox4.Controls.Add(this.labelControl5);
            this.groupBox4.Controls.Add(this.lblRoboIP);
            this.groupBox4.Controls.Add(this.LabelCCD5);
            this.groupBox4.Controls.Add(this.LabelCCD4);
            this.groupBox4.Controls.Add(this.LabelCCD3);
            this.groupBox4.Controls.Add(this.lblPDCAIP);
            this.groupBox4.Controls.Add(this.lblSFCIP);
            this.groupBox4.Controls.Add(this.lblScannerIP);
            this.groupBox4.Controls.Add(this.LabelCCD1);
            this.groupBox4.Controls.Add(this.linkLabel1);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(77, 41);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 487);
            this.groupBox4.TabIndex = 62;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Device IP Details";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // labelControl13
            // 
            this.labelControl13.AutoSize = true;
            this.labelControl13.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(35, 249);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(59, 16);
            this.labelControl13.TabIndex = 37;
            this.labelControl13.Text = "Robot :";
            // 
            // labelControl9
            // 
            this.labelControl9.AutoSize = true;
            this.labelControl9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Location = new System.Drawing.Point(35, 223);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(56, 16);
            this.labelControl9.TabIndex = 36;
            this.labelControl9.Text = "PDCA :";
            // 
            // labelControl8
            // 
            this.labelControl8.AutoSize = true;
            this.labelControl8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Location = new System.Drawing.Point(36, 197);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(45, 16);
            this.labelControl8.TabIndex = 35;
            this.labelControl8.Text = "SFC :";
            // 
            // labelControl7
            // 
            this.labelControl7.AutoSize = true;
            this.labelControl7.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(36, 175);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(76, 16);
            this.labelControl7.TabIndex = 34;
            this.labelControl7.Text = "Scanner :";
            // 
            // labelControl12
            // 
            this.labelControl12.AutoSize = true;
            this.labelControl12.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Location = new System.Drawing.Point(36, 152);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(56, 16);
            this.labelControl12.TabIndex = 33;
            this.labelControl12.Text = "CCD5 :";
            // 
            // labelControl11
            // 
            this.labelControl11.AutoSize = true;
            this.labelControl11.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(36, 127);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(56, 16);
            this.labelControl11.TabIndex = 32;
            this.labelControl11.Text = "CCD4 :";
            // 
            // labelControl10
            // 
            this.labelControl10.AutoSize = true;
            this.labelControl10.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Location = new System.Drawing.Point(36, 101);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(56, 16);
            this.labelControl10.TabIndex = 31;
            this.labelControl10.Text = "CCD3 :";
            // 
            // labelControl6
            // 
            this.labelControl6.AutoSize = true;
            this.labelControl6.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(36, 75);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(56, 16);
            this.labelControl6.TabIndex = 30;
            this.labelControl6.Text = "CCD1 :";
            // 
            // labelControl5
            // 
            this.labelControl5.AutoSize = true;
            this.labelControl5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Location = new System.Drawing.Point(36, 39);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(130, 16);
            this.labelControl5.TabIndex = 29;
            this.labelControl5.Text = "Device IP Details";
            // 
            // lblRoboIP
            // 
            this.lblRoboIP.AutoSize = true;
            this.lblRoboIP.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoboIP.Location = new System.Drawing.Point(128, 248);
            this.lblRoboIP.Name = "lblRoboIP";
            this.lblRoboIP.Size = new System.Drawing.Size(52, 16);
            this.lblRoboIP.TabIndex = 28;
            this.lblRoboIP.Text = "label6";
            // 
            // LabelCCD5
            // 
            this.LabelCCD5.AutoSize = true;
            this.LabelCCD5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCCD5.Location = new System.Drawing.Point(128, 152);
            this.LabelCCD5.Name = "LabelCCD5";
            this.LabelCCD5.Size = new System.Drawing.Size(52, 16);
            this.LabelCCD5.TabIndex = 26;
            this.LabelCCD5.Text = "label6";
            // 
            // LabelCCD4
            // 
            this.LabelCCD4.AutoSize = true;
            this.LabelCCD4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCCD4.Location = new System.Drawing.Point(128, 127);
            this.LabelCCD4.Name = "LabelCCD4";
            this.LabelCCD4.Size = new System.Drawing.Size(52, 16);
            this.LabelCCD4.TabIndex = 24;
            this.LabelCCD4.Text = "label6";
            // 
            // LabelCCD3
            // 
            this.LabelCCD3.AutoSize = true;
            this.LabelCCD3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCCD3.Location = new System.Drawing.Point(128, 101);
            this.LabelCCD3.Name = "LabelCCD3";
            this.LabelCCD3.Size = new System.Drawing.Size(52, 16);
            this.LabelCCD3.TabIndex = 22;
            this.LabelCCD3.Text = "label6";
            // 
            // lblPDCAIP
            // 
            this.lblPDCAIP.AutoSize = true;
            this.lblPDCAIP.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPDCAIP.Location = new System.Drawing.Point(128, 222);
            this.lblPDCAIP.Name = "lblPDCAIP";
            this.lblPDCAIP.Size = new System.Drawing.Size(52, 16);
            this.lblPDCAIP.TabIndex = 20;
            this.lblPDCAIP.Text = "label6";
            // 
            // lblSFCIP
            // 
            this.lblSFCIP.AutoSize = true;
            this.lblSFCIP.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSFCIP.Location = new System.Drawing.Point(128, 196);
            this.lblSFCIP.Name = "lblSFCIP";
            this.lblSFCIP.Size = new System.Drawing.Size(52, 16);
            this.lblSFCIP.TabIndex = 19;
            this.lblSFCIP.Text = "label6";
            // 
            // lblScannerIP
            // 
            this.lblScannerIP.AutoSize = true;
            this.lblScannerIP.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScannerIP.Location = new System.Drawing.Point(129, 174);
            this.lblScannerIP.Name = "lblScannerIP";
            this.lblScannerIP.Size = new System.Drawing.Size(52, 16);
            this.lblScannerIP.TabIndex = 18;
            this.lblScannerIP.Text = "label6";
            // 
            // LabelCCD1
            // 
            this.LabelCCD1.AutoSize = true;
            this.LabelCCD1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCCD1.Location = new System.Drawing.Point(128, 75);
            this.LabelCCD1.Name = "LabelCCD1";
            this.LabelCCD1.Size = new System.Drawing.Size(52, 16);
            this.LabelCCD1.TabIndex = 17;
            this.LabelCCD1.Text = "label6";
            // 
            // linkLabel1
            // 
            this.linkLabel1.Location = new System.Drawing.Point(6, 429);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(296, 45);
            this.linkLabel1.TabIndex = 16;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Note: For Changing device IP go to below path \"D:\\TEAL\\NOVA\\DLL\\ConnectionDetails" +
    ".XML\"";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage0);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage11);
            this.tabControl2.Controls.Add(this.tabPage12);
            this.tabControl2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold);
            this.tabControl2.Location = new System.Drawing.Point(26, 32);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1293, 612);
            this.tabControl2.TabIndex = 4;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnEdit);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.label45);
            this.groupBox5.Controls.Add(this.btnSave);
            this.groupBox5.Location = new System.Drawing.Point(107, 650);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(963, 70);
            this.groupBox5.TabIndex = 67;
            this.groupBox5.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(585, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Save";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(358, 31);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(32, 13);
            this.label45.TabIndex = 2;
            this.label45.Text = "Edit";
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.LightGray;
            this.btnEdit.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Edit5;
            this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEdit.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnEdit.Location = new System.Drawing.Point(392, 13);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(50, 50);
            this.btnEdit.TabIndex = 56;
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.LightGray;
            this.btnSave.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Save3;
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSave.Location = new System.Drawing.Point(534, 13);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(50, 50);
            this.btnSave.TabIndex = 57;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // io_diagnostics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1366, 749);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.tabControl2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 145);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1366, 749);
            this.MinimizeBox = false;
            this.Name = "io_diagnostics";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "io_diagnostics";
            this.Load += new System.EventHandler(this.io_diagnostics_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.io_diagnostics_MouseMove);
            this.tabPage11.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpboxCamera.ResumeLayout(false);
            this.grpboxCamera.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.Load_Caliration.ResumeLayout(false);
            this.Load_Caliration.PerformLayout();
            this.tabPage0.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Axis_datagridview)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button simpleButton65;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl65;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button simpleButton66;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl66;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label labelControl67;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton67;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl68;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton68;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl69;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton69;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl70;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton70;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl71;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton71;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl72;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton72;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl73;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton73;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl74;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton74;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl75;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Button simpleButton75;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Button simpleButton76;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl76;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label labelControl77;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton77;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl78;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton78;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl79;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton79;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl80;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton80;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl81;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton81;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl82;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton82;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl83;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton83;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl84;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton84;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl85;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Button simpleButton85;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Button simpleButton86;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl86;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label labelControl87;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton87;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl88;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton88;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl89;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton89;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl90;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton90;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl91;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton91;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl92;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton92;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl93;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton93;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl94;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton94;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl95;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Button simpleButton95;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Button simpleButton96;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl96;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Timer IO_sts_Timer;
        private System.Windows.Forms.Timer AI_TIMER;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox grpboxCamera;
        private System.Windows.Forms.CheckBox chkCCD5;
        private System.Windows.Forms.CheckBox chkCCD4;
        private System.Windows.Forms.CheckBox chkCCD3;
        private System.Windows.Forms.CheckBox chkCCD1;
        private System.Windows.Forms.RichTextBox richTextBox_Calib;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblServo_Conn_Status_X;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCamera_Stop;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button btnCamera_Start;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox Cam1_path;
        private System.Windows.Forms.Label lblactualpos_ccd1_y;
        private System.Windows.Forms.Label lblactualpos_ccd1_x;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox CCD1count;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox CCD1Speed;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblRunningCount;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbTestMode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox Cam3_path;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox CCD3count;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox Cam4_path;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox CCD4count;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TextBox txttriggerpos;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtonflyintervel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox Cam5__path;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.TextBox CCD5count;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox CCD5Speed;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox CCD5TestMode;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel Load_Caliration;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnSaveSlope;
        private System.Windows.Forms.Button btnEdtSlope;
        private System.Windows.Forms.TextBox txtoffset4;
        private System.Windows.Forms.TextBox txtoffset0;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.TextBox txtmstrvlt;
        private System.Windows.Forms.TextBox txt_mstrload;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.TextBox txtoffset1;
        private System.Windows.Forms.TextBox txtSlope4;
        private System.Windows.Forms.TextBox txtSlope1;
        private System.Windows.Forms.TextBox txtSlope0;
        private System.Windows.Forms.Button btn_Nozzle_Z_Stop;
        private System.Windows.Forms.Button btn_Nozzle_Z_Move;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.TextBox txtloadvlt2;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.TextBox txtloadvlt1;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.TextBox txtLoadcell2;
        private System.Windows.Forms.TextBox txtLoadcell1;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.TabPage Motion_Card_IO;
        private System.Windows.Forms.TabPage Motion_Card_Output;
        private System.Windows.Forms.TabPage tabPage0;
        private System.Windows.Forms.DataGridView Axis_datagridview;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton offlinemode;
        private System.Windows.Forms.RadioButton onlinemode;
        private System.Windows.Forms.RadioButton productionmode;
        private System.Windows.Forms.RadioButton dryrun;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label labelControl13;
        private System.Windows.Forms.Label labelControl9;
        private System.Windows.Forms.Label labelControl8;
        private System.Windows.Forms.Label labelControl7;
        private System.Windows.Forms.Label labelControl12;
        private System.Windows.Forms.Label labelControl11;
        private System.Windows.Forms.Label labelControl10;
        private System.Windows.Forms.Label labelControl6;
        private System.Windows.Forms.Label labelControl5;
        private System.Windows.Forms.Label lblRoboIP;
        private System.Windows.Forms.Label LabelCCD5;
        private System.Windows.Forms.Label LabelCCD4;
        private System.Windows.Forms.Label LabelCCD3;
        private System.Windows.Forms.Label lblPDCAIP;
        private System.Windows.Forms.Label lblSFCIP;
        private System.Windows.Forms.Label lblScannerIP;
        private System.Windows.Forms.Label LabelCCD1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button btnSave;
    }
}