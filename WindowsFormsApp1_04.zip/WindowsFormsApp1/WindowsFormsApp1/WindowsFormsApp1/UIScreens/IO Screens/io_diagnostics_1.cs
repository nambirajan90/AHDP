﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B3I.UIScreens.IO_Screens
{
    public partial class io_diagnostics : Form
    {

        //Declarations
        //public int connect_plc_status;
        // public string filepath = Environment.CurrentDirectory + @"\DIlist.txt";
        public int y;
        public int y_pic;
        int numRows = 2;
        int numCols = 20;
        int page = 0;
        int OP_ButtonNumber = 0;
        string numStr = "";
        string result = "";
        int IP_Lblnumber = 0;
        Dictionary<string, string> IP_label_name_list = new Dictionary<string, string>();
        Dictionary<string, string> IP_label_name_list1 = new Dictionary<string, string>();
        Dictionary<string, string> IP_label_name_list2 = new Dictionary<string, string>();
        Dictionary<string, string> OP_label_name_list = new Dictionary<string, string>();
        Dictionary<string, string> OP_label_name_list1 = new Dictionary<string, string>();
        Dictionary<string, string> MC_IP_label_name_list = new Dictionary<string, string>();
        Dictionary<string, string> MC_OP_label_name_list = new Dictionary<string, string>();

        public io_diagnostics()
        {
            InitializeComponent();
            ON_FormLoad();
            // Attach the event handler
            tabControl2.SelectedIndexChanged += tabControl2_SelectedIndexChanged;
            btnEdit.Enabled = false;
            btnSave.Enabled = false;

        }
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );
        private void io_diagnostics_Load(object sender, EventArgs e)
        {
            Axis_datagridview.Enabled = false;
        }

        //Mod0612
        private void tabControl2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if the selected tab is tabPage0
            if (tabControl2.SelectedTab == tabPage0)
            {
                LoadAxisConfigurationData(); // Call method to load data for Axis Parameters
            }
        }

        private void LoadAxisConfigurationData()
        {
            try
            {
                string sqlQuery = "SELECT * FROM AxisConfiguration"; // Query to fetch data
                DataSet ds = SQLHelper.GetData(sqlQuery); // Fetch data using your SQLHelper class
                //SqlDataAdapter adapter = new SqlDataAdapter(cmd)
                //DataTable dt = new DataTable();
                //adapter.Fill(dt);
                if (ds != null && ds.Tables.Count > 0)
                {
                    Axis_datagridview.DataSource = ds.Tables[0].DefaultView; // Bind data to DataGridView
                   // Axis_datagridview.Enabled = true; // Enable the DataGridView
                }
                else
                {
                    MessageBox.Show("No data found in AxisConfiguration table.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void Analog_Update()
        {


        }
        public void TextBox_Analog_Update()
        {


        }
        private void IO_sts_Timer_Tick(object sender, EventArgs e)
        {

        }
        private void ON_FormLoad()
        {
            read_data_confic();
            labeladd(IP_label_name_list, 0);
            labeladd_IP(IP_label_name_list, 0);
            labeladd(IP_label_name_list1, 1);
            labeladd_IP(IP_label_name_list1, 1);
            labeladd(IP_label_name_list2, 2);
            labeladd_IP(IP_label_name_list2, 2);
            labeladd(OP_label_name_list, 3);
            button(OP_label_name_list, 3);
            labeladd(OP_label_name_list1, 4);
            button(OP_label_name_list1, 4);
            this.tabControl1.TabPages.Remove(this.tabPage6);
            this.tabControl1.TabPages.Remove(this.Motion_Card_IO);
            this.tabControl1.TabPages.Remove(this.Motion_Card_Output);
        }
        private void read_data_confic()  //  reads the  textfile for displaying  the names
        {
            try
            {

                if (File.Exists(Environment.CurrentDirectory + @"\DIlist1.txt"))
                {
                    string[] filereaddata = File.ReadAllLines(Environment.CurrentDirectory + @"\DIlist1.txt", Encoding.UTF8);
                    for (int j = 0; j < filereaddata.Count(); j++)
                    {

                        string[] datafile = filereaddata[j].Split(';');
                        IP_label_name_list.Add(datafile[0].ToString(), datafile[1].ToString());

                    }
                }
                if (File.Exists(Environment.CurrentDirectory + @"\DIlist2.txt"))
                {
                    string[] filereaddata = File.ReadAllLines(Environment.CurrentDirectory + @"\DIlist2.txt", Encoding.UTF8);
                    for (int j = 0; j < filereaddata.Count(); j++)
                    {

                        string[] datafile = filereaddata[j].Split(';');
                        IP_label_name_list1.Add(datafile[0].ToString(), datafile[1].ToString());

                    }
                }
                if (File.Exists(Environment.CurrentDirectory + @"\DIlist3.txt"))
                {
                    string[] filereaddata = File.ReadAllLines(Environment.CurrentDirectory + @"\DIlist3.txt", Encoding.UTF8);
                    for (int j = 0; j < filereaddata.Count(); j++)
                    {

                        string[] datafile = filereaddata[j].Split(';');
                        IP_label_name_list2.Add(datafile[0].ToString(), datafile[1].ToString());

                    }
                }
                if (File.Exists(Environment.CurrentDirectory + @"\DOlist1.txt"))
                {
                    string[] filereaddata = File.ReadAllLines(Environment.CurrentDirectory + @"\DOlist1.txt", Encoding.UTF8);
                    for (int j = 0; j < filereaddata.Count(); j++)
                    {

                        string[] datafile = filereaddata[j].Split(';');
                        OP_label_name_list.Add(datafile[0].ToString(), datafile[1].ToString());

                    }
                }
                if (File.Exists(Environment.CurrentDirectory + @"\DOlist2.txt"))
                {
                    string[] filereaddata = File.ReadAllLines(Environment.CurrentDirectory + @"\DOlist2.txt", Encoding.UTF8);
                    for (int j = 0; j < filereaddata.Count(); j++)
                    {

                        string[] datafile = filereaddata[j].Split(';');
                        OP_label_name_list1.Add(datafile[0].ToString(), datafile[1].ToString());

                    }
                }

                if (File.Exists(Environment.CurrentDirectory + @"\MC_DI_list.txt"))//MC_DI_list
                {
                    string[] filereaddata = File.ReadAllLines(Environment.CurrentDirectory + @"\MC_DI_list.txt", Encoding.UTF8);
                    for (int j = 0; j < filereaddata.Count(); j++)
                    {

                        string[] datafile = filereaddata[j].Split(';');
                        MC_IP_label_name_list.Add(datafile[0].ToString(), datafile[1].ToString());

                    }
                }

                if (File.Exists(Environment.CurrentDirectory + @"\MC_OP_list.txt"))//MC_OP_list
                {
                    string[] filereaddata = File.ReadAllLines(Environment.CurrentDirectory + @"\MC_OP_list.txt", Encoding.UTF8);
                    for (int j = 0; j < filereaddata.Count(); j++)
                    {

                        string[] datafile = filereaddata[j].Split(';');
                        MC_OP_label_name_list.Add(datafile[0].ToString(), datafile[1].ToString());

                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog("IDIOConfig.O_diagnostics", "read_data_confic()", "Common", "Exception Error", ex.ToString());
            }

        }
        private void labeladd(Dictionary<string, string> text_references, int tagnumber)     //adds  the  label text
        {

            try
            {
                page = 0;
                int labelWidth = 500;
                int labelHeight = 19;
                int[] xCoordinates = { 20, 650 };
                TabPage tabPage1 = tabControl1.TabPages[tagnumber];
                for (int row = 0; row < numRows; row++)
                {
                    y = 0;
                    for (int col = 0; col < numCols; col++)
                    {
                        if (page < text_references.Count())
                        {
                            int x = xCoordinates[row];
                            y = y + 30;
                            page = page + 1;
                            numStr = tagnumber.ToString();

                            // Map each digit to its corresponding letter using ASCII codes
                            result = string.Join("", numStr.Select(digit => (char)('A' + int.Parse(digit.ToString()) - 1)));

                            Label label = new Label
                            {
                                Text = text_references[page.ToString()],
                                Width = labelWidth,
                                Height = labelHeight,
                                Location = new Point(x, y),
                                TextAlign = ContentAlignment.TopLeft, // Center textCambria, 12pt
                                Font = new System.Drawing.Font("Cambria", 12, global::System.Drawing.FontStyle.Bold), // Customize font
                                Name = "lbl" + page.ToString() + result,

                            };


                            tabPage1.Controls.Add(label);



                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog("IDIOConfig.O_diagnostics", "labeladd()", "Common", "Exception Error", ex.ToString());
            }


        }
        private void labeladd_IP(Dictionary<string, string> text_references, int tagnumber)    //adds  the  status button
        {
            try
            {
                page = 0;
                int labelWidth = 30;
                int labelHeight = 22;
                int[] xCoordinates = { 540, 1150 };
                TabPage tabPage1 = tabControl1.TabPages[tagnumber];
                for (int row = 0; row < numRows; row++)
                {
                    y = 0;
                    for (int col = 0; col < numCols; col++)
                    {
                        if (page < text_references.Count())
                        {
                            int x = xCoordinates[row];
                            y = y + 30;
                            page = page + 1;
                            RoundLabel label = new RoundLabel
                            {
                                Text = "OFF",
                                Width = labelWidth,
                                Height = labelHeight,
                                Location = new Point(x, y),
                                TextAlign = ContentAlignment.MiddleCenter, // Center textCambria, 12pt
                                BorderStyle = BorderStyle.None,                              //  Font = new System.Drawing.Font("Cambria", 12, System.Drawing.FontStyle.Bold), // Customize font
                                ForeColor = Color.White,
                                Name = IP_Lblnumber.ToString(),
                                BackColor = Color.Red,
                            };

                            IP_Lblnumber++;
                            tabPage1.Controls.Add(label);

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog("IDIOConfig.O_diagnostics", "labeladd()", "Common", "Exception Error", ex.ToString());
            }

        }
        private void button(Dictionary<string, string> text_references, int tagnumber)   //displays status symbol for  PLC  Output
        {
            try
            {
                page = 0;
                int buttonwidth = 30;
                int buttonheiight = 22;
                int[] xCoordinates = { 540, 1150 };
                TabPage tabPage1 = tabControl1.TabPages[tagnumber];
                for (int row = 0; row < numRows; row++)
                {
                    y_pic = 0;
                    for (int col = 0; col < numCols; col++)
                    {
                        if (page < text_references.Count())
                        {
                            int x = xCoordinates[row];
                            y_pic = y_pic + 30;

                            page = page + 1;
                            RoundButton button = new RoundButton
                            {

                                Location = new Point(x, y_pic),
                                Width = buttonwidth,
                                Height = buttonheiight,
                                BackColor = Color.Red,
                                Name = OP_ButtonNumber.ToString() // Set a unique identifier for each button
                            };

                            tabPage1.Controls.Add(button);
                            button.Click += CommonButtonClickHandler;
                            OP_ButtonNumber++;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog("IDIOConfig.O_diagnostics", "picturebox()", "Common", "Exception Error", ex.ToString());
            }


        }
        private void CommonButtonClickHandler(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                string buttonName = clickedButton.Name;
                int btn_name = Int32.Parse(buttonName);
                if (PLC.DIO_Read[btn_name] == 1)
                {
                    PLC.DIO_Read[btn_name] = 0;
                    PLC.Write_to_PLC(PLC.DIO_Read);

                }
                else
                {
                    PLC.DIO_Read[btn_name] = 1;
                    PLC.Write_to_PLC(PLC.DIO_Read);
                }
            }


        }
        #region "Loadcell SOP"
        private void rdpN1_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void rdpN2_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void rdpN3_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void rdpN4_CheckedChanged(object sender, EventArgs e)
        {

        }
        public void Load_loadcell_sop_variables(string Loadcell_calibration_settings_path)
        {

        }
        private void btnEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Do you want to enable editing recipe ?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                Axis_datagridview.Enabled = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Do you want to save and download the recipe ?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            
        }
        //private void btnSaveSettings_Click(object sender, EventArgs e)
        //{

        //}
        private void loadCalibrationtext_togrid()
        {

        }
        #endregion
        public void Load_Ai_slope_to_textbox()
        {


        }
        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnEdtSlope_Click(object sender, EventArgs e)
        {

        }
        private void btnSaveSlope_Click(object sender, EventArgs e)
        {

        }
        private void io_diagnostics_MouseMove(object sender, MouseEventArgs e)
        {

        }
        private void tabControl1_MouseMove(object sender, MouseEventArgs e)
        {

        }
        private void tabPage1_MouseMove(object sender, MouseEventArgs e)
        {

        }
        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        private void label126_Click(object sender, EventArgs e)
        {

        }
        private void txtSlope0_TextChanged(object sender, EventArgs e)
        {

        }
        private void tabPage1_Click_1(object sender, EventArgs e)
        {

        }
        public bool timer_lock_2 = false;
        private void AI_TIMER_Tick(object sender, EventArgs e)
        {
            if (!timer_lock_2)
            {
                timer_lock_2 = true;
                try
                {
                    lbl_update_Tab0();
                    lbl_update_Tab1();
                    lbl_update_Tab2();
                    lbl_update_Tab3();
                    lbl_update_Tab4();
                }
                catch (Exception ex)
                {
                    timer_lock_2 = false;
                    MessageBox.Show("IO Diagnosis:Error-" + ex);

                }

            }
            timer_lock_2 = false;
        }
        private void tabPage4_Click(object sender, EventArgs e)
        {

        }
        private void lbl_update_Tab0()//It updates the status of round label after reading the data from the PLC in Tabpage0 [Input]
        {
            for (int i = 0; i < tabPage0.Controls.Count; i++)
            {
                if (tabPage0.Controls[i] is RoundLabel)
                {
                    RoundLabel dynamicLabel = (RoundLabel)tabPage0.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Green;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }


        }
        private void lbl_update_Tab1()//It updates the status of round label after reading the data from the PLC in Tabpage1 [Input]
        {
            for (int i = 0; i < tabPage1.Controls.Count; i++)
            {
                if (tabPage1.Controls[i] is RoundLabel)
                {
                    RoundLabel dynamicLabel = (RoundLabel)tabPage1.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Green;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }


        }
        private void lbl_update_Tab2()//It updates the status of round label after reading the data from the PLC in Tabpage2 [Input]
        {
            for (int i = 0; i < tabPage2.Controls.Count; i++)
            {
                if (tabPage2.Controls[i] is RoundLabel)
                {
                    RoundLabel dynamicLabel = (RoundLabel)tabPage2.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Green;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }


        }
        private void lbl_update_Tab3()//It updates the status of round label after reading the data from the PLC in Tabpage3 [Output]
        {
            for (int i = 0; i < tabPage3.Controls.Count; i++)
            {
                if (tabPage3.Controls[i] is RoundLabel)
                {
                    RoundLabel dynamicLabel = (RoundLabel)tabPage3.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Green;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }


        }
        private void lbl_update_Tab4()//It updates the status of round label after reading the data from the PLC in Tabpage4 [Output]
        {
            for (int i = 0; i < tabPage4.Controls.Count; i++)
            {
                if (tabPage4.Controls[i] is RoundLabel)
                {
                    RoundLabel dynamicLabel = (RoundLabel)tabPage4.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Green;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }
        }

        private void Load_Caliration_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage7_Click(object sender, EventArgs e)
        {

        }

        private void labelControl6_Click(object sender, EventArgs e)
        {

        }

        private void labelControl5_Click(object sender, EventArgs e)
        {

        }

        private void LabelCCD1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        //private void button17_Click(object sender, EventArgs e)
        //{

        //}
    }

}
