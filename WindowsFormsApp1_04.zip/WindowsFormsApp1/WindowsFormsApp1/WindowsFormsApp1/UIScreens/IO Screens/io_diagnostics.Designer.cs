﻿
namespace AHDP.UIScreens.IO_Screens
{
    partial class io_diagnostics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.simpleButton65 = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.simpleButton66 = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.labelControl67 = new System.Windows.Forms.Label();
            this.simpleButton67 = new System.Windows.Forms.Button();
            this.labelControl68 = new System.Windows.Forms.Label();
            this.simpleButton68 = new System.Windows.Forms.Button();
            this.labelControl69 = new System.Windows.Forms.Label();
            this.simpleButton69 = new System.Windows.Forms.Button();
            this.labelControl70 = new System.Windows.Forms.Label();
            this.simpleButton70 = new System.Windows.Forms.Button();
            this.labelControl71 = new System.Windows.Forms.Label();
            this.simpleButton71 = new System.Windows.Forms.Button();
            this.labelControl72 = new System.Windows.Forms.Label();
            this.simpleButton72 = new System.Windows.Forms.Button();
            this.labelControl73 = new System.Windows.Forms.Label();
            this.simpleButton73 = new System.Windows.Forms.Button();
            this.labelControl74 = new System.Windows.Forms.Label();
            this.simpleButton74 = new System.Windows.Forms.Button();
            this.labelControl75 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.simpleButton75 = new System.Windows.Forms.Button();
            this.simpleButton76 = new System.Windows.Forms.Button();
            this.labelControl76 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.labelControl77 = new System.Windows.Forms.Label();
            this.simpleButton77 = new System.Windows.Forms.Button();
            this.labelControl78 = new System.Windows.Forms.Label();
            this.simpleButton78 = new System.Windows.Forms.Button();
            this.labelControl79 = new System.Windows.Forms.Label();
            this.simpleButton79 = new System.Windows.Forms.Button();
            this.labelControl80 = new System.Windows.Forms.Label();
            this.simpleButton80 = new System.Windows.Forms.Button();
            this.labelControl81 = new System.Windows.Forms.Label();
            this.simpleButton81 = new System.Windows.Forms.Button();
            this.labelControl82 = new System.Windows.Forms.Label();
            this.simpleButton82 = new System.Windows.Forms.Button();
            this.labelControl83 = new System.Windows.Forms.Label();
            this.simpleButton83 = new System.Windows.Forms.Button();
            this.labelControl84 = new System.Windows.Forms.Label();
            this.simpleButton84 = new System.Windows.Forms.Button();
            this.labelControl85 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.simpleButton85 = new System.Windows.Forms.Button();
            this.simpleButton86 = new System.Windows.Forms.Button();
            this.labelControl86 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.labelControl87 = new System.Windows.Forms.Label();
            this.simpleButton87 = new System.Windows.Forms.Button();
            this.labelControl88 = new System.Windows.Forms.Label();
            this.simpleButton88 = new System.Windows.Forms.Button();
            this.labelControl89 = new System.Windows.Forms.Label();
            this.simpleButton89 = new System.Windows.Forms.Button();
            this.labelControl90 = new System.Windows.Forms.Label();
            this.simpleButton90 = new System.Windows.Forms.Button();
            this.labelControl91 = new System.Windows.Forms.Label();
            this.simpleButton91 = new System.Windows.Forms.Button();
            this.labelControl92 = new System.Windows.Forms.Label();
            this.simpleButton92 = new System.Windows.Forms.Button();
            this.labelControl93 = new System.Windows.Forms.Label();
            this.simpleButton93 = new System.Windows.Forms.Button();
            this.labelControl94 = new System.Windows.Forms.Label();
            this.simpleButton94 = new System.Windows.Forms.Button();
            this.labelControl95 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.simpleButton95 = new System.Windows.Forms.Button();
            this.simpleButton96 = new System.Windows.Forms.Button();
            this.labelControl96 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.IO_sts_Timer = new System.Windows.Forms.Timer(this.components);
            this.AI_TIMER = new System.Windows.Forms.Timer(this.components);
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.grpboxCamera = new System.Windows.Forms.GroupBox();
            this.chkCCD1 = new System.Windows.Forms.CheckBox();
            this.richTextBox_Calib = new System.Windows.Forms.RichTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.lblServo_Conn_Status_X = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCamera_Stop = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btnCamera_Start = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.Cam1_path = new System.Windows.Forms.TextBox();
            this.lblactualpos_ccd1_y = new System.Windows.Forms.Label();
            this.lblactualpos_ccd1_x = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.CCD1count = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.CCD1Speed = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lblRunningCount = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbTestMode = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView_IP2 = new System.Windows.Forms.DataGridView();
            this.dataGridView_IP1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView_IP4 = new System.Windows.Forms.DataGridView();
            this.dataGridView_IP3 = new System.Windows.Forms.DataGridView();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.dataGridView_IP5 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView_OP2 = new System.Windows.Forms.DataGridView();
            this.dataGridView_OP1 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dataGridView_OP4 = new System.Windows.Forms.DataGridView();
            this.dataGridView_OP3 = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.Motion_Card_IO = new System.Windows.Forms.TabPage();
            this.dataGridView_MIP1 = new System.Windows.Forms.DataGridView();
            this.Motion_Card_Output = new System.Windows.Forms.TabPage();
            this.dataGridView_MOP1 = new System.Windows.Forms.DataGridView();
            this.tabPage0 = new System.Windows.Forms.TabPage();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.Axis_datagridview = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.productionmode = new System.Windows.Forms.CheckBox();
            this.dryrun = new System.Windows.Forms.CheckBox();
            this.convdryrun = new System.Windows.Forms.RadioButton();
            this.convruwithtray = new System.Windows.Forms.RadioButton();
            this.offlinemode = new System.Windows.Forms.RadioButton();
            this.onlinemode = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.labelControl13 = new System.Windows.Forms.Label();
            this.labelControl9 = new System.Windows.Forms.Label();
            this.labelControl8 = new System.Windows.Forms.Label();
            this.labelControl7 = new System.Windows.Forms.Label();
            this.labelControl6 = new System.Windows.Forms.Label();
            this.labelControl5 = new System.Windows.Forms.Label();
            this.lblRoboIP = new System.Windows.Forms.Label();
            this.lblPDCAIP = new System.Windows.Forms.Label();
            this.lblSFCIP = new System.Windows.Forms.Label();
            this.lblScannerIP = new System.Windows.Forms.Label();
            this.LabelCCD1 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.Static_timer = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Dyanamic_timer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage11.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grpboxCamera.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP3)).BeginInit();
            this.tabPage17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP5)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_OP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_OP1)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_OP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_OP3)).BeginInit();
            this.Motion_Card_IO.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_MIP1)).BeginInit();
            this.Motion_Card_Output.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_MOP1)).BeginInit();
            this.tabPage0.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Axis_datagridview)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // simpleButton65
            // 
            this.simpleButton65.BackColor = System.Drawing.Color.Red;
            this.simpleButton65.Location = new System.Drawing.Point(1351, 444);
            this.simpleButton65.Name = "simpleButton65";
            this.simpleButton65.Size = new System.Drawing.Size(30, 24);
            this.simpleButton65.TabIndex = 152;
            this.simpleButton65.UseVisualStyleBackColor = false;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(1097, 448);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(175, 16);
            this.label67.TabIndex = 150;
            this.label67.Text = "I10_WC_Main_Press_Swt_FB";
            // 
            // simpleButton66
            // 
            this.simpleButton66.BackColor = System.Drawing.Color.Red;
            this.simpleButton66.Location = new System.Drawing.Point(1351, 390);
            this.simpleButton66.Name = "simpleButton66";
            this.simpleButton66.Size = new System.Drawing.Size(30, 24);
            this.simpleButton66.TabIndex = 149;
            this.simpleButton66.UseVisualStyleBackColor = false;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(1097, 394);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(123, 16);
            this.label68.TabIndex = 147;
            this.label68.Text = "I10_WC_Spare_X50";
            // 
            // labelControl67
            // 
            this.labelControl67.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl67.Location = new System.Drawing.Point(1392, 340);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(22, 16);
            this.labelControl67.TabIndex = 146;
            this.labelControl67.Text = "X49";
            // 
            // simpleButton67
            // 
            this.simpleButton67.BackColor = System.Drawing.Color.Red;
            this.simpleButton67.Location = new System.Drawing.Point(1351, 336);
            this.simpleButton67.Name = "simpleButton67";
            this.simpleButton67.Size = new System.Drawing.Size(30, 24);
            this.simpleButton67.TabIndex = 145;
            this.simpleButton67.UseVisualStyleBackColor = false;
            // 
            // labelControl68
            // 
            this.labelControl68.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl68.Location = new System.Drawing.Point(1392, 283);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(22, 16);
            this.labelControl68.TabIndex = 144;
            this.labelControl68.Text = "X48";
            // 
            // simpleButton68
            // 
            this.simpleButton68.BackColor = System.Drawing.Color.Red;
            this.simpleButton68.Location = new System.Drawing.Point(1351, 279);
            this.simpleButton68.Name = "simpleButton68";
            this.simpleButton68.Size = new System.Drawing.Size(30, 24);
            this.simpleButton68.TabIndex = 143;
            this.simpleButton68.UseVisualStyleBackColor = false;
            // 
            // labelControl69
            // 
            this.labelControl69.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl69.Location = new System.Drawing.Point(1392, 229);
            this.labelControl69.Name = "labelControl69";
            this.labelControl69.Size = new System.Drawing.Size(22, 16);
            this.labelControl69.TabIndex = 142;
            this.labelControl69.Text = "X47";
            // 
            // simpleButton69
            // 
            this.simpleButton69.BackColor = System.Drawing.Color.Red;
            this.simpleButton69.Location = new System.Drawing.Point(1351, 225);
            this.simpleButton69.Name = "simpleButton69";
            this.simpleButton69.Size = new System.Drawing.Size(30, 24);
            this.simpleButton69.TabIndex = 141;
            this.simpleButton69.UseVisualStyleBackColor = false;
            // 
            // labelControl70
            // 
            this.labelControl70.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl70.Location = new System.Drawing.Point(1392, 178);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(22, 16);
            this.labelControl70.TabIndex = 140;
            this.labelControl70.Text = "X46";
            // 
            // simpleButton70
            // 
            this.simpleButton70.BackColor = System.Drawing.Color.Red;
            this.simpleButton70.Location = new System.Drawing.Point(1351, 174);
            this.simpleButton70.Name = "simpleButton70";
            this.simpleButton70.Size = new System.Drawing.Size(30, 24);
            this.simpleButton70.TabIndex = 139;
            this.simpleButton70.UseVisualStyleBackColor = false;
            // 
            // labelControl71
            // 
            this.labelControl71.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl71.Location = new System.Drawing.Point(1392, 124);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(22, 16);
            this.labelControl71.TabIndex = 138;
            this.labelControl71.Text = "X45";
            // 
            // simpleButton71
            // 
            this.simpleButton71.BackColor = System.Drawing.Color.Red;
            this.simpleButton71.Location = new System.Drawing.Point(1351, 120);
            this.simpleButton71.Name = "simpleButton71";
            this.simpleButton71.Size = new System.Drawing.Size(30, 24);
            this.simpleButton71.TabIndex = 137;
            this.simpleButton71.UseVisualStyleBackColor = false;
            // 
            // labelControl72
            // 
            this.labelControl72.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl72.Location = new System.Drawing.Point(1392, 71);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(22, 16);
            this.labelControl72.TabIndex = 136;
            this.labelControl72.Text = "X44";
            // 
            // simpleButton72
            // 
            this.simpleButton72.BackColor = System.Drawing.Color.Red;
            this.simpleButton72.Location = new System.Drawing.Point(1351, 67);
            this.simpleButton72.Name = "simpleButton72";
            this.simpleButton72.Size = new System.Drawing.Size(30, 24);
            this.simpleButton72.TabIndex = 135;
            this.simpleButton72.UseVisualStyleBackColor = false;
            // 
            // labelControl73
            // 
            this.labelControl73.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl73.Location = new System.Drawing.Point(1044, 448);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(22, 16);
            this.labelControl73.TabIndex = 134;
            this.labelControl73.Text = "X43";
            // 
            // simpleButton73
            // 
            this.simpleButton73.BackColor = System.Drawing.Color.Red;
            this.simpleButton73.Location = new System.Drawing.Point(1003, 444);
            this.simpleButton73.Name = "simpleButton73";
            this.simpleButton73.Size = new System.Drawing.Size(30, 24);
            this.simpleButton73.TabIndex = 133;
            this.simpleButton73.UseVisualStyleBackColor = false;
            // 
            // labelControl74
            // 
            this.labelControl74.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl74.Location = new System.Drawing.Point(1044, 394);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(22, 16);
            this.labelControl74.TabIndex = 132;
            this.labelControl74.Text = "X42";
            // 
            // simpleButton74
            // 
            this.simpleButton74.BackColor = System.Drawing.Color.Red;
            this.simpleButton74.Location = new System.Drawing.Point(1003, 390);
            this.simpleButton74.Name = "simpleButton74";
            this.simpleButton74.Size = new System.Drawing.Size(30, 24);
            this.simpleButton74.TabIndex = 131;
            this.simpleButton74.UseVisualStyleBackColor = false;
            // 
            // labelControl75
            // 
            this.labelControl75.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl75.Location = new System.Drawing.Point(1044, 340);
            this.labelControl75.Name = "labelControl75";
            this.labelControl75.Size = new System.Drawing.Size(22, 16);
            this.labelControl75.TabIndex = 130;
            this.labelControl75.Text = "X41";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(1097, 340);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(123, 16);
            this.label69.TabIndex = 129;
            this.label69.Text = "I10_WC_Spare_X49";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(1097, 283);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(123, 16);
            this.label70.TabIndex = 128;
            this.label70.Text = "I10_WC_Spare_X48";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(1097, 229);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(133, 16);
            this.label71.TabIndex = 127;
            this.label71.Text = "I10_WC_Estop_PB_FB";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(1097, 178);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(123, 16);
            this.label72.TabIndex = 126;
            this.label72.Text = "I10_WC_Spare_X46";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(1097, 124);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(260, 16);
            this.label73.TabIndex = 125;
            this.label73.Text = "I10_WC_Received_Tray_FB_From_Unloader";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.Location = new System.Drawing.Point(1097, 71);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(245, 16);
            this.label74.TabIndex = 124;
            this.label74.Text = "I10_WC_Rdy_to_Receive_From_Unloader";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.Location = new System.Drawing.Point(749, 448);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(250, 16);
            this.label75.TabIndex = 123;
            this.label75.Text = "I10_WC_RH_Feeder_Stopper_Cylinder_Up";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(749, 394);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(248, 16);
            this.label76.TabIndex = 122;
            this.label76.Text = "I10_WC_LH_Feeder_Stopper_Cylinder_Up";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(749, 340);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(217, 16);
            this.label77.TabIndex = 121;
            this.label77.Text = "I10_WC_Vacuum_Press_Switch4_FB";
            // 
            // simpleButton75
            // 
            this.simpleButton75.BackColor = System.Drawing.Color.Red;
            this.simpleButton75.Location = new System.Drawing.Point(1003, 336);
            this.simpleButton75.Name = "simpleButton75";
            this.simpleButton75.Size = new System.Drawing.Size(30, 24);
            this.simpleButton75.TabIndex = 120;
            this.simpleButton75.UseVisualStyleBackColor = false;
            // 
            // simpleButton76
            // 
            this.simpleButton76.BackColor = System.Drawing.Color.Red;
            this.simpleButton76.Location = new System.Drawing.Point(1003, 279);
            this.simpleButton76.Name = "simpleButton76";
            this.simpleButton76.Size = new System.Drawing.Size(30, 24);
            this.simpleButton76.TabIndex = 119;
            this.simpleButton76.UseVisualStyleBackColor = false;
            // 
            // labelControl76
            // 
            this.labelControl76.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl76.Location = new System.Drawing.Point(1044, 283);
            this.labelControl76.Name = "labelControl76";
            this.labelControl76.Size = new System.Drawing.Size(22, 16);
            this.labelControl76.TabIndex = 118;
            this.labelControl76.Text = "X40";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(749, 283);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(217, 16);
            this.label78.TabIndex = 117;
            this.label78.Text = "I10_WC_Vacuum_Press_Switch3_FB";
            // 
            // labelControl77
            // 
            this.labelControl77.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl77.Location = new System.Drawing.Point(1044, 229);
            this.labelControl77.Name = "labelControl77";
            this.labelControl77.Size = new System.Drawing.Size(22, 16);
            this.labelControl77.TabIndex = 116;
            this.labelControl77.Text = "X39";
            // 
            // simpleButton77
            // 
            this.simpleButton77.BackColor = System.Drawing.Color.Red;
            this.simpleButton77.Location = new System.Drawing.Point(1003, 225);
            this.simpleButton77.Name = "simpleButton77";
            this.simpleButton77.Size = new System.Drawing.Size(30, 24);
            this.simpleButton77.TabIndex = 115;
            this.simpleButton77.UseVisualStyleBackColor = true;
            // 
            // labelControl78
            // 
            this.labelControl78.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl78.Location = new System.Drawing.Point(1044, 178);
            this.labelControl78.Name = "labelControl78";
            this.labelControl78.Size = new System.Drawing.Size(22, 16);
            this.labelControl78.TabIndex = 114;
            this.labelControl78.Text = "X38";
            // 
            // simpleButton78
            // 
            this.simpleButton78.BackColor = System.Drawing.Color.Red;
            this.simpleButton78.Location = new System.Drawing.Point(1003, 174);
            this.simpleButton78.Name = "simpleButton78";
            this.simpleButton78.Size = new System.Drawing.Size(30, 24);
            this.simpleButton78.TabIndex = 113;
            this.simpleButton78.UseVisualStyleBackColor = true;
            // 
            // labelControl79
            // 
            this.labelControl79.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl79.Location = new System.Drawing.Point(1044, 124);
            this.labelControl79.Name = "labelControl79";
            this.labelControl79.Size = new System.Drawing.Size(22, 16);
            this.labelControl79.TabIndex = 112;
            this.labelControl79.Text = "X37";
            // 
            // simpleButton79
            // 
            this.simpleButton79.BackColor = System.Drawing.Color.Red;
            this.simpleButton79.Location = new System.Drawing.Point(1003, 120);
            this.simpleButton79.Name = "simpleButton79";
            this.simpleButton79.Size = new System.Drawing.Size(30, 24);
            this.simpleButton79.TabIndex = 111;
            this.simpleButton79.UseVisualStyleBackColor = true;
            // 
            // labelControl80
            // 
            this.labelControl80.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl80.Location = new System.Drawing.Point(1044, 71);
            this.labelControl80.Name = "labelControl80";
            this.labelControl80.Size = new System.Drawing.Size(22, 16);
            this.labelControl80.TabIndex = 110;
            this.labelControl80.Text = "X36";
            // 
            // simpleButton80
            // 
            this.simpleButton80.BackColor = System.Drawing.Color.Red;
            this.simpleButton80.Location = new System.Drawing.Point(1003, 67);
            this.simpleButton80.Name = "simpleButton80";
            this.simpleButton80.Size = new System.Drawing.Size(30, 24);
            this.simpleButton80.TabIndex = 109;
            this.simpleButton80.UseVisualStyleBackColor = false;
            // 
            // labelControl81
            // 
            this.labelControl81.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl81.Location = new System.Drawing.Point(684, 448);
            this.labelControl81.Name = "labelControl81";
            this.labelControl81.Size = new System.Drawing.Size(22, 16);
            this.labelControl81.TabIndex = 108;
            this.labelControl81.Text = "X35";
            // 
            // simpleButton81
            // 
            this.simpleButton81.BackColor = System.Drawing.Color.Red;
            this.simpleButton81.Location = new System.Drawing.Point(643, 444);
            this.simpleButton81.Name = "simpleButton81";
            this.simpleButton81.Size = new System.Drawing.Size(30, 24);
            this.simpleButton81.TabIndex = 107;
            this.simpleButton81.UseVisualStyleBackColor = false;
            // 
            // labelControl82
            // 
            this.labelControl82.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl82.Location = new System.Drawing.Point(684, 394);
            this.labelControl82.Name = "labelControl82";
            this.labelControl82.Size = new System.Drawing.Size(22, 16);
            this.labelControl82.TabIndex = 106;
            this.labelControl82.Text = "X34";
            // 
            // simpleButton82
            // 
            this.simpleButton82.BackColor = System.Drawing.Color.Red;
            this.simpleButton82.Location = new System.Drawing.Point(643, 390);
            this.simpleButton82.Name = "simpleButton82";
            this.simpleButton82.Size = new System.Drawing.Size(30, 24);
            this.simpleButton82.TabIndex = 105;
            this.simpleButton82.UseVisualStyleBackColor = false;
            // 
            // labelControl83
            // 
            this.labelControl83.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl83.Location = new System.Drawing.Point(684, 340);
            this.labelControl83.Name = "labelControl83";
            this.labelControl83.Size = new System.Drawing.Size(22, 16);
            this.labelControl83.TabIndex = 104;
            this.labelControl83.Text = "X33";
            // 
            // simpleButton83
            // 
            this.simpleButton83.BackColor = System.Drawing.Color.Red;
            this.simpleButton83.Location = new System.Drawing.Point(643, 336);
            this.simpleButton83.Name = "simpleButton83";
            this.simpleButton83.Size = new System.Drawing.Size(30, 24);
            this.simpleButton83.TabIndex = 103;
            this.simpleButton83.UseVisualStyleBackColor = false;
            // 
            // labelControl84
            // 
            this.labelControl84.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl84.Location = new System.Drawing.Point(684, 283);
            this.labelControl84.Name = "labelControl84";
            this.labelControl84.Size = new System.Drawing.Size(22, 16);
            this.labelControl84.TabIndex = 102;
            this.labelControl84.Text = "X32";
            // 
            // simpleButton84
            // 
            this.simpleButton84.BackColor = System.Drawing.Color.Red;
            this.simpleButton84.Location = new System.Drawing.Point(643, 279);
            this.simpleButton84.Name = "simpleButton84";
            this.simpleButton84.Size = new System.Drawing.Size(30, 24);
            this.simpleButton84.TabIndex = 101;
            this.simpleButton84.UseVisualStyleBackColor = false;
            // 
            // labelControl85
            // 
            this.labelControl85.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl85.Location = new System.Drawing.Point(684, 229);
            this.labelControl85.Name = "labelControl85";
            this.labelControl85.Size = new System.Drawing.Size(22, 16);
            this.labelControl85.TabIndex = 100;
            this.labelControl85.Text = "X31";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.Location = new System.Drawing.Point(749, 229);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(217, 16);
            this.label79.TabIndex = 99;
            this.label79.Text = "I10_WC_Vacuum_Press_Switch2_FB";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.Location = new System.Drawing.Point(749, 178);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(194, 16);
            this.label80.TabIndex = 98;
            this.label80.Text = "I10_WC_RH_Fdr_Foam_Pres_FB";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.Location = new System.Drawing.Point(749, 124);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(192, 16);
            this.label81.TabIndex = 97;
            this.label81.Text = "I10_WC_LH_Fdr_Foam_Pres_FB";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.Location = new System.Drawing.Point(749, 71);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(200, 16);
            this.label82.TabIndex = 96;
            this.label82.Text = "I10_WC_RH_Fdr_Push_Button_FB";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(389, 448);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(198, 16);
            this.label83.TabIndex = 95;
            this.label83.Text = "I10_WC_LH_Fdr_Push_Button_FB";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.Location = new System.Drawing.Point(389, 394);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(217, 16);
            this.label84.TabIndex = 94;
            this.label84.Text = "I10_WC_Vacuum_Press_Switch1_FB";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.Location = new System.Drawing.Point(389, 340);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(199, 16);
            this.label85.TabIndex = 93;
            this.label85.Text = "I10_WC_Empty_FB_From_Loader";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.Location = new System.Drawing.Point(389, 283);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(247, 16);
            this.label86.TabIndex = 92;
            this.label86.Text = "I10_WC_Strt_Tray_Tranfer_From_Loader";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(389, 229);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(248, 16);
            this.label87.TabIndex = 91;
            this.label87.Text = "I10_WC_Outp_Cnvy_Speed_Cntrl_Sen_FB";
            // 
            // simpleButton85
            // 
            this.simpleButton85.BackColor = System.Drawing.Color.Red;
            this.simpleButton85.Location = new System.Drawing.Point(643, 225);
            this.simpleButton85.Name = "simpleButton85";
            this.simpleButton85.Size = new System.Drawing.Size(30, 24);
            this.simpleButton85.TabIndex = 90;
            this.simpleButton85.UseVisualStyleBackColor = false;
            // 
            // simpleButton86
            // 
            this.simpleButton86.BackColor = System.Drawing.Color.Red;
            this.simpleButton86.Location = new System.Drawing.Point(643, 174);
            this.simpleButton86.Name = "simpleButton86";
            this.simpleButton86.Size = new System.Drawing.Size(30, 24);
            this.simpleButton86.TabIndex = 89;
            this.simpleButton86.UseVisualStyleBackColor = false;
            // 
            // labelControl86
            // 
            this.labelControl86.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl86.Location = new System.Drawing.Point(684, 178);
            this.labelControl86.Name = "labelControl86";
            this.labelControl86.Size = new System.Drawing.Size(22, 16);
            this.labelControl86.TabIndex = 88;
            this.labelControl86.Text = "X30";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(389, 178);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(186, 16);
            this.label88.TabIndex = 87;
            this.label88.Text = "I10_WC_Workcell_Stpr_Cyl_Up";
            // 
            // labelControl87
            // 
            this.labelControl87.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl87.Location = new System.Drawing.Point(684, 124);
            this.labelControl87.Name = "labelControl87";
            this.labelControl87.Size = new System.Drawing.Size(22, 16);
            this.labelControl87.TabIndex = 86;
            this.labelControl87.Text = "X29";
            // 
            // simpleButton87
            // 
            this.simpleButton87.BackColor = System.Drawing.Color.Red;
            this.simpleButton87.Location = new System.Drawing.Point(643, 120);
            this.simpleButton87.Name = "simpleButton87";
            this.simpleButton87.Size = new System.Drawing.Size(30, 24);
            this.simpleButton87.TabIndex = 85;
            this.simpleButton87.UseVisualStyleBackColor = false;
            // 
            // labelControl88
            // 
            this.labelControl88.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl88.Location = new System.Drawing.Point(684, 71);
            this.labelControl88.Name = "labelControl88";
            this.labelControl88.Size = new System.Drawing.Size(22, 16);
            this.labelControl88.TabIndex = 84;
            this.labelControl88.Text = "X28";
            // 
            // simpleButton88
            // 
            this.simpleButton88.BackColor = System.Drawing.Color.Red;
            this.simpleButton88.Location = new System.Drawing.Point(643, 67);
            this.simpleButton88.Name = "simpleButton88";
            this.simpleButton88.Size = new System.Drawing.Size(30, 24);
            this.simpleButton88.TabIndex = 83;
            this.simpleButton88.UseVisualStyleBackColor = false;
            // 
            // labelControl89
            // 
            this.labelControl89.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl89.Location = new System.Drawing.Point(312, 448);
            this.labelControl89.Name = "labelControl89";
            this.labelControl89.Size = new System.Drawing.Size(22, 16);
            this.labelControl89.TabIndex = 82;
            this.labelControl89.Text = "X27";
            // 
            // simpleButton89
            // 
            this.simpleButton89.BackColor = System.Drawing.Color.Red;
            this.simpleButton89.Location = new System.Drawing.Point(271, 444);
            this.simpleButton89.Name = "simpleButton89";
            this.simpleButton89.Size = new System.Drawing.Size(30, 24);
            this.simpleButton89.TabIndex = 81;
            this.simpleButton89.UseVisualStyleBackColor = false;
            // 
            // labelControl90
            // 
            this.labelControl90.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl90.Location = new System.Drawing.Point(312, 394);
            this.labelControl90.Name = "labelControl90";
            this.labelControl90.Size = new System.Drawing.Size(22, 16);
            this.labelControl90.TabIndex = 80;
            this.labelControl90.Text = "X26";
            // 
            // simpleButton90
            // 
            this.simpleButton90.BackColor = System.Drawing.Color.Red;
            this.simpleButton90.Location = new System.Drawing.Point(271, 390);
            this.simpleButton90.Name = "simpleButton90";
            this.simpleButton90.Size = new System.Drawing.Size(30, 24);
            this.simpleButton90.TabIndex = 79;
            this.simpleButton90.UseVisualStyleBackColor = false;
            // 
            // labelControl91
            // 
            this.labelControl91.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl91.Location = new System.Drawing.Point(312, 340);
            this.labelControl91.Name = "labelControl91";
            this.labelControl91.Size = new System.Drawing.Size(22, 16);
            this.labelControl91.TabIndex = 78;
            this.labelControl91.Text = "X25";
            // 
            // simpleButton91
            // 
            this.simpleButton91.BackColor = System.Drawing.Color.Red;
            this.simpleButton91.Location = new System.Drawing.Point(271, 336);
            this.simpleButton91.Name = "simpleButton91";
            this.simpleButton91.Size = new System.Drawing.Size(30, 24);
            this.simpleButton91.TabIndex = 77;
            this.simpleButton91.UseVisualStyleBackColor = false;
            // 
            // labelControl92
            // 
            this.labelControl92.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl92.Location = new System.Drawing.Point(312, 283);
            this.labelControl92.Name = "labelControl92";
            this.labelControl92.Size = new System.Drawing.Size(22, 16);
            this.labelControl92.TabIndex = 76;
            this.labelControl92.Text = "X24";
            // 
            // simpleButton92
            // 
            this.simpleButton92.BackColor = System.Drawing.Color.Red;
            this.simpleButton92.Location = new System.Drawing.Point(271, 279);
            this.simpleButton92.Name = "simpleButton92";
            this.simpleButton92.Size = new System.Drawing.Size(30, 24);
            this.simpleButton92.TabIndex = 75;
            this.simpleButton92.UseVisualStyleBackColor = false;
            // 
            // labelControl93
            // 
            this.labelControl93.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl93.Location = new System.Drawing.Point(312, 229);
            this.labelControl93.Name = "labelControl93";
            this.labelControl93.Size = new System.Drawing.Size(22, 16);
            this.labelControl93.TabIndex = 74;
            this.labelControl93.Text = "X23";
            // 
            // simpleButton93
            // 
            this.simpleButton93.BackColor = System.Drawing.Color.Red;
            this.simpleButton93.Location = new System.Drawing.Point(271, 225);
            this.simpleButton93.Name = "simpleButton93";
            this.simpleButton93.Size = new System.Drawing.Size(30, 24);
            this.simpleButton93.TabIndex = 73;
            this.simpleButton93.UseVisualStyleBackColor = false;
            // 
            // labelControl94
            // 
            this.labelControl94.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl94.Location = new System.Drawing.Point(312, 178);
            this.labelControl94.Name = "labelControl94";
            this.labelControl94.Size = new System.Drawing.Size(22, 16);
            this.labelControl94.TabIndex = 72;
            this.labelControl94.Text = "X22";
            // 
            // simpleButton94
            // 
            this.simpleButton94.BackColor = System.Drawing.Color.Red;
            this.simpleButton94.Location = new System.Drawing.Point(271, 174);
            this.simpleButton94.Name = "simpleButton94";
            this.simpleButton94.Size = new System.Drawing.Size(30, 24);
            this.simpleButton94.TabIndex = 71;
            this.simpleButton94.UseVisualStyleBackColor = false;
            // 
            // labelControl95
            // 
            this.labelControl95.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl95.Location = new System.Drawing.Point(312, 124);
            this.labelControl95.Name = "labelControl95";
            this.labelControl95.Size = new System.Drawing.Size(22, 16);
            this.labelControl95.TabIndex = 70;
            this.labelControl95.Text = "X21";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.Location = new System.Drawing.Point(389, 124);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(144, 16);
            this.label89.TabIndex = 69;
            this.label89.Text = "I10_WC_Plt_Lift_Cyl_Up";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(389, 71);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(231, 16);
            this.label90.TabIndex = 68;
            this.label90.Text = "I10_WC_Outp_Buff_Tray_Pres_Sen_FB";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.Location = new System.Drawing.Point(17, 448);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(239, 16);
            this.label91.TabIndex = 67;
            this.label91.Text = "I10_WC_Inp_Cnvy_Speed_Cntrl_Sen_FB";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.Location = new System.Drawing.Point(17, 394);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(202, 16);
            this.label92.TabIndex = 66;
            this.label92.Text = "I10_WC_Cnvy_Tray_Pres_Sen_FB";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.Location = new System.Drawing.Point(17, 340);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(222, 16);
            this.label93.TabIndex = 65;
            this.label93.Text = "I10_WC_Inp_Buff_Tray_Pres_Sen_FB";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.Location = new System.Drawing.Point(17, 283);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(245, 16);
            this.label94.TabIndex = 64;
            this.label94.Text = "I10_WC_RH_Foam_Fdr_Trly_Latching_FB";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(17, 229);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(243, 16);
            this.label95.TabIndex = 63;
            this.label95.Text = "I10_WC_LH_Foam_Fdr_Trly_Latching_FB";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(17, 178);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(127, 16);
            this.label96.TabIndex = 62;
            this.label96.Text = "I10_WC_Sfty_Rly_FB";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(17, 124);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(99, 16);
            this.label97.TabIndex = 61;
            this.label97.Text = "I10_WC_Rst_PB";
            // 
            // simpleButton95
            // 
            this.simpleButton95.BackColor = System.Drawing.Color.Red;
            this.simpleButton95.Location = new System.Drawing.Point(271, 120);
            this.simpleButton95.Name = "simpleButton95";
            this.simpleButton95.Size = new System.Drawing.Size(30, 24);
            this.simpleButton95.TabIndex = 60;
            this.simpleButton95.UseVisualStyleBackColor = false;
            // 
            // simpleButton96
            // 
            this.simpleButton96.BackColor = System.Drawing.Color.Red;
            this.simpleButton96.Location = new System.Drawing.Point(271, 67);
            this.simpleButton96.Name = "simpleButton96";
            this.simpleButton96.Size = new System.Drawing.Size(30, 24);
            this.simpleButton96.TabIndex = 57;
            this.simpleButton96.UseVisualStyleBackColor = false;
            // 
            // labelControl96
            // 
            this.labelControl96.Location = new System.Drawing.Point(312, 71);
            this.labelControl96.Name = "labelControl96";
            this.labelControl96.Size = new System.Drawing.Size(22, 16);
            this.labelControl96.TabIndex = 56;
            this.labelControl96.Text = "X20";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.Location = new System.Drawing.Point(17, 71);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(129, 16);
            this.label98.TabIndex = 55;
            this.label98.Text = "I10_WC_Cyc_Strt_FB";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Verdana", 16F);
            this.label99.Location = new System.Drawing.Point(15, 18);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(206, 26);
            this.label99.TabIndex = 50;
            this.label99.Text = "PLC Input";
            // 
            // IO_sts_Timer
            // 
            this.IO_sts_Timer.Interval = 10;
            this.IO_sts_Timer.Tick += new System.EventHandler(this.IO_sts_Timer_Tick);
            // 
            // AI_TIMER
            // 
            this.AI_TIMER.Enabled = true;
            this.AI_TIMER.Interval = 10;
            this.AI_TIMER.Tick += new System.EventHandler(this.AI_TIMER_Tick);
            // 
            // tabPage9
            // 
            this.tabPage9.Location = new System.Drawing.Point(0, 0);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(200, 100);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "Calibration";
            // 
            // tabPage10
            // 
            this.tabPage10.Location = new System.Drawing.Point(0, 0);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(200, 100);
            this.tabPage10.TabIndex = 0;
            this.tabPage10.Text = "GRR";
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.Color.White;
            this.tabPage12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage12.Location = new System.Drawing.Point(4, 28);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(1254, 598);
            this.tabPage12.TabIndex = 3;
            this.tabPage12.Text = "GRR";
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.White;
            this.tabPage11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage11.Controls.Add(this.groupBox2);
            this.tabPage11.Location = new System.Drawing.Point(4, 28);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Size = new System.Drawing.Size(1254, 598);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "Calibration";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.White;
            this.groupBox2.Controls.Add(this.grpboxCamera);
            this.groupBox2.Controls.Add(this.richTextBox_Calib);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.lblServo_Conn_Status_X);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnCamera_Stop);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.btnCamera_Start);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(20, 48);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1200, 339);
            this.groupBox2.TabIndex = 152;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Camera";
            // 
            // grpboxCamera
            // 
            this.grpboxCamera.BackColor = System.Drawing.Color.White;
            this.grpboxCamera.Controls.Add(this.chkCCD1);
            this.grpboxCamera.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxCamera.Location = new System.Drawing.Point(31, 179);
            this.grpboxCamera.Name = "grpboxCamera";
            this.grpboxCamera.Size = new System.Drawing.Size(365, 51);
            this.grpboxCamera.TabIndex = 152;
            this.grpboxCamera.TabStop = false;
            this.grpboxCamera.Text = "Choose Camera";
            this.grpboxCamera.Enter += new System.EventHandler(this.grpboxCamera_Enter);
            // 
            // chkCCD1
            // 
            this.chkCCD1.AutoSize = true;
            this.chkCCD1.Location = new System.Drawing.Point(28, 22);
            this.chkCCD1.Name = "chkCCD1";
            this.chkCCD1.Size = new System.Drawing.Size(67, 20);
            this.chkCCD1.TabIndex = 87;
            this.chkCCD1.Text = "CCD 1";
            this.chkCCD1.UseVisualStyleBackColor = true;
            this.chkCCD1.CheckedChanged += new System.EventHandler(this.chkCCD1_CheckedChanged_1);
            // 
            // richTextBox_Calib
            // 
            this.richTextBox_Calib.Location = new System.Drawing.Point(469, 67);
            this.richTextBox_Calib.Name = "richTextBox_Calib";
            this.richTextBox_Calib.Size = new System.Drawing.Size(720, 216);
            this.richTextBox_Calib.TabIndex = 144;
            this.richTextBox_Calib.Text = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(28, 67);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(133, 14);
            this.label21.TabIndex = 60;
            this.label21.Text = "Camera Conn Status";
            // 
            // lblServo_Conn_Status_X
            // 
            this.lblServo_Conn_Status_X.BackColor = System.Drawing.Color.Maroon;
            this.lblServo_Conn_Status_X.Location = new System.Drawing.Point(198, 59);
            this.lblServo_Conn_Status_X.Name = "lblServo_Conn_Status_X";
            this.lblServo_Conn_Status_X.Size = new System.Drawing.Size(26, 26);
            this.lblServo_Conn_Status_X.TabIndex = 61;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 14);
            this.label3.TabIndex = 85;
            this.label3.Text = "Running Steps";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 14);
            this.label2.TabIndex = 143;
            this.label2.Text = "Vision Calibration :";
            // 
            // btnCamera_Stop
            // 
            this.btnCamera_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnCamera_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamera_Stop.ForeColor = System.Drawing.Color.White;
            this.btnCamera_Stop.Location = new System.Drawing.Point(202, 248);
            this.btnCamera_Stop.Name = "btnCamera_Stop";
            this.btnCamera_Stop.Size = new System.Drawing.Size(99, 35);
            this.btnCamera_Stop.TabIndex = 90;
            this.btnCamera_Stop.Text = "Stop";
            this.btnCamera_Stop.UseVisualStyleBackColor = false;
            this.btnCamera_Stop.Click += new System.EventHandler(this.btnCamera_Stop_Click);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(189, 101);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(119, 26);
            this.textBox4.TabIndex = 142;
            // 
            // btnCamera_Start
            // 
            this.btnCamera_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnCamera_Start.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamera_Start.ForeColor = System.Drawing.Color.White;
            this.btnCamera_Start.Location = new System.Drawing.Point(27, 248);
            this.btnCamera_Start.Name = "btnCamera_Start";
            this.btnCamera_Start.Size = new System.Drawing.Size(99, 35);
            this.btnCamera_Start.TabIndex = 89;
            this.btnCamera_Start.Text = "Start";
            this.btnCamera_Start.UseVisualStyleBackColor = false;
            this.btnCamera_Start.Click += new System.EventHandler(this.btnCamera_Start_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.White;
            this.tabPage8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage8.Controls.Add(this.tabControl3);
            this.tabPage8.Location = new System.Drawing.Point(4, 28);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(1254, 598);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "SOP";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage13);
            this.tabControl3.Location = new System.Drawing.Point(20, 19);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(888, 472);
            this.tabControl3.TabIndex = 88;
            // 
            // tabPage13
            // 
            this.tabPage13.BackColor = System.Drawing.Color.White;
            this.tabPage13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage13.Controls.Add(this.label4);
            this.tabPage13.Controls.Add(this.label5);
            this.tabPage13.Controls.Add(this.label6);
            this.tabPage13.Controls.Add(this.label7);
            this.tabPage13.Controls.Add(this.textBox28);
            this.tabPage13.Controls.Add(this.textBox29);
            this.tabPage13.Controls.Add(this.label8);
            this.tabPage13.Controls.Add(this.button10);
            this.tabPage13.Controls.Add(this.Cam1_path);
            this.tabPage13.Controls.Add(this.lblactualpos_ccd1_y);
            this.tabPage13.Controls.Add(this.lblactualpos_ccd1_x);
            this.tabPage13.Controls.Add(this.label9);
            this.tabPage13.Controls.Add(this.label10);
            this.tabPage13.Controls.Add(this.label11);
            this.tabPage13.Controls.Add(this.label12);
            this.tabPage13.Controls.Add(this.button11);
            this.tabPage13.Controls.Add(this.button12);
            this.tabPage13.Controls.Add(this.CCD1count);
            this.tabPage13.Controls.Add(this.label13);
            this.tabPage13.Controls.Add(this.CCD1Speed);
            this.tabPage13.Controls.Add(this.label14);
            this.tabPage13.Controls.Add(this.textBox33);
            this.tabPage13.Controls.Add(this.textBox34);
            this.tabPage13.Controls.Add(this.label25);
            this.tabPage13.Controls.Add(this.label28);
            this.tabPage13.Controls.Add(this.textBox35);
            this.tabPage13.Controls.Add(this.label29);
            this.tabPage13.Controls.Add(this.textBox36);
            this.tabPage13.Controls.Add(this.label15);
            this.tabPage13.Controls.Add(this.lblRunningCount);
            this.tabPage13.Controls.Add(this.label16);
            this.tabPage13.Controls.Add(this.cmbTestMode);
            this.tabPage13.Controls.Add(this.label17);
            this.tabPage13.Location = new System.Drawing.Point(4, 25);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage13.Size = new System.Drawing.Size(880, 443);
            this.tabPage13.TabIndex = 0;
            this.tabPage13.Text = "CCD1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(289, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 16);
            this.label4.TabIndex = 143;
            this.label4.Text = "(mm/s)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(438, 214);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 16);
            this.label5.TabIndex = 142;
            this.label5.Text = "(mm)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(438, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 16);
            this.label6.TabIndex = 141;
            this.label6.Text = "(mm)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(438, 136);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 16);
            this.label7.TabIndex = 140;
            this.label7.Text = "(mm)";
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(292, 211);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(63, 23);
            this.textBox28.TabIndex = 139;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(215, 208);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(63, 23);
            this.textBox29.TabIndex = 138;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(58, 211);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 16);
            this.label8.TabIndex = 137;
            this.label8.Text = "Static Pos";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button10.Font = new System.Drawing.Font("Cambria", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(359, 358);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(83, 29);
            this.button10.TabIndex = 136;
            this.button10.Text = "Browse";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // Cam1_path
            // 
            this.Cam1_path.Enabled = false;
            this.Cam1_path.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cam1_path.Location = new System.Drawing.Point(61, 363);
            this.Cam1_path.Name = "Cam1_path";
            this.Cam1_path.Size = new System.Drawing.Size(201, 23);
            this.Cam1_path.TabIndex = 135;
            // 
            // lblactualpos_ccd1_y
            // 
            this.lblactualpos_ccd1_y.AutoSize = true;
            this.lblactualpos_ccd1_y.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblactualpos_ccd1_y.Location = new System.Drawing.Point(476, 72);
            this.lblactualpos_ccd1_y.Name = "lblactualpos_ccd1_y";
            this.lblactualpos_ccd1_y.Size = new System.Drawing.Size(16, 16);
            this.lblactualpos_ccd1_y.TabIndex = 134;
            this.lblactualpos_ccd1_y.Text = "0";
            // 
            // lblactualpos_ccd1_x
            // 
            this.lblactualpos_ccd1_x.AutoSize = true;
            this.lblactualpos_ccd1_x.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblactualpos_ccd1_x.Location = new System.Drawing.Point(438, 72);
            this.lblactualpos_ccd1_x.Name = "lblactualpos_ccd1_x";
            this.lblactualpos_ccd1_x.Size = new System.Drawing.Size(16, 16);
            this.lblactualpos_ccd1_x.TabIndex = 133;
            this.lblactualpos_ccd1_x.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(476, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 16);
            this.label9.TabIndex = 132;
            this.label9.Text = "Y";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(438, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(17, 16);
            this.label10.TabIndex = 131;
            this.label10.Text = "X";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(288, 72);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(106, 16);
            this.label11.TabIndex = 130;
            this.label11.Text = "Actual Position";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(58, 329);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 16);
            this.label12.TabIndex = 129;
            this.label12.Text = "CSV File Save Path";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button11.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(61, 400);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(83, 37);
            this.button11.TabIndex = 128;
            this.button11.Text = "Start";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button12.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(179, 399);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(83, 37);
            this.button12.TabIndex = 127;
            this.button12.Text = "Stop";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // CCD1count
            // 
            this.CCD1count.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD1count.Location = new System.Drawing.Point(215, 292);
            this.CCD1count.Name = "CCD1count";
            this.CCD1count.Size = new System.Drawing.Size(63, 23);
            this.CCD1count.TabIndex = 126;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(58, 295);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 16);
            this.label13.TabIndex = 125;
            this.label13.Text = "No of Counts";
            // 
            // CCD1Speed
            // 
            this.CCD1Speed.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CCD1Speed.Location = new System.Drawing.Point(215, 250);
            this.CCD1Speed.Name = "CCD1Speed";
            this.CCD1Speed.Size = new System.Drawing.Size(63, 23);
            this.CCD1Speed.TabIndex = 124;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(58, 254);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 16);
            this.label14.TabIndex = 123;
            this.label14.Text = "Speed";
            // 
            // textBox33
            // 
            this.textBox33.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(292, 168);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(63, 23);
            this.textBox33.TabIndex = 122;
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(292, 129);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(63, 23);
            this.textBox34.TabIndex = 121;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(315, 100);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(17, 16);
            this.label25.TabIndex = 120;
            this.label25.Text = "Y";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(237, 100);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 16);
            this.label28.TabIndex = 119;
            this.label28.Text = "X";
            // 
            // textBox35
            // 
            this.textBox35.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(215, 168);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(63, 23);
            this.textBox35.TabIndex = 118;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(58, 168);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(104, 16);
            this.label29.TabIndex = 117;
            this.label29.Text = "Dynamic Pos 2";
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(215, 129);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(63, 23);
            this.textBox36.TabIndex = 116;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(58, 129);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 16);
            this.label15.TabIndex = 115;
            this.label15.Text = "Dynamic Pos 1";
            // 
            // lblRunningCount
            // 
            this.lblRunningCount.AutoSize = true;
            this.lblRunningCount.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRunningCount.Location = new System.Drawing.Point(204, 72);
            this.lblRunningCount.Name = "lblRunningCount";
            this.lblRunningCount.Size = new System.Drawing.Size(16, 16);
            this.lblRunningCount.TabIndex = 114;
            this.lblRunningCount.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(58, 72);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 16);
            this.label16.TabIndex = 113;
            this.label16.Text = "Running Count";
            // 
            // cmbTestMode
            // 
            this.cmbTestMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTestMode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTestMode.FormattingEnabled = true;
            this.cmbTestMode.Items.AddRange(new object[] {
            "Dynamic",
            "Static"});
            this.cmbTestMode.Location = new System.Drawing.Point(207, 17);
            this.cmbTestMode.Name = "cmbTestMode";
            this.cmbTestMode.Size = new System.Drawing.Size(154, 24);
            this.cmbTestMode.TabIndex = 112;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(58, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 16);
            this.label17.TabIndex = 111;
            this.label17.Text = "Test Mode";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.White;
            this.tabPage5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage5.Controls.Add(this.tabControl1);
            this.tabPage5.Location = new System.Drawing.Point(4, 28);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage5.Size = new System.Drawing.Size(1254, 598);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "IO Diagnostic";
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage17);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.Motion_Card_IO);
            this.tabControl1.Controls.Add(this.Motion_Card_Output);
            this.tabControl1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold);
            this.tabControl1.Location = new System.Drawing.Point(3, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1335, 560);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.dataGridView_IP2);
            this.tabPage1.Controls.Add(this.dataGridView_IP1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1327, 528);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "PLC Input";
            // 
            // dataGridView_IP2
            // 
            this.dataGridView_IP2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_IP2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_IP2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_IP2.Enabled = false;
            this.dataGridView_IP2.Location = new System.Drawing.Point(610, 17);
            this.dataGridView_IP2.Name = "dataGridView_IP2";
            this.dataGridView_IP2.ReadOnly = true;
            this.dataGridView_IP2.RowHeadersVisible = false;
            this.dataGridView_IP2.RowHeadersWidth = 51;
            this.dataGridView_IP2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_IP2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_IP2.Size = new System.Drawing.Size(570, 462);
            this.dataGridView_IP2.TabIndex = 2;
            // 
            // dataGridView_IP1
            // 
            this.dataGridView_IP1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_IP1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_IP1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_IP1.Enabled = false;
            this.dataGridView_IP1.Location = new System.Drawing.Point(7, 17);
            this.dataGridView_IP1.Name = "dataGridView_IP1";
            this.dataGridView_IP1.ReadOnly = true;
            this.dataGridView_IP1.RowHeadersVisible = false;
            this.dataGridView_IP1.RowHeadersWidth = 51;
            this.dataGridView_IP1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_IP1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_IP1.Size = new System.Drawing.Size(570, 462);
            this.dataGridView_IP1.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage2.Controls.Add(this.dataGridView_IP4);
            this.tabPage2.Controls.Add(this.dataGridView_IP3);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1327, 528);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Text = "PLC Input";
            // 
            // dataGridView_IP4
            // 
            this.dataGridView_IP4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_IP4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_IP4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_IP4.Enabled = false;
            this.dataGridView_IP4.Location = new System.Drawing.Point(610, 17);
            this.dataGridView_IP4.Name = "dataGridView_IP4";
            this.dataGridView_IP4.ReadOnly = true;
            this.dataGridView_IP4.RowHeadersVisible = false;
            this.dataGridView_IP4.RowHeadersWidth = 51;
            this.dataGridView_IP4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_IP4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_IP4.Size = new System.Drawing.Size(570, 462);
            this.dataGridView_IP4.TabIndex = 3;
            // 
            // dataGridView_IP3
            // 
            this.dataGridView_IP3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_IP3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_IP3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_IP3.Enabled = false;
            this.dataGridView_IP3.Location = new System.Drawing.Point(7, 17);
            this.dataGridView_IP3.Name = "dataGridView_IP3";
            this.dataGridView_IP3.ReadOnly = true;
            this.dataGridView_IP3.RowHeadersVisible = false;
            this.dataGridView_IP3.RowHeadersWidth = 51;
            this.dataGridView_IP3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_IP3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_IP3.Size = new System.Drawing.Size(570, 462);
            this.dataGridView_IP3.TabIndex = 2;
            // 
            // tabPage17
            // 
            this.tabPage17.BackColor = System.Drawing.Color.White;
            this.tabPage17.Controls.Add(this.dataGridView_IP5);
            this.tabPage17.Location = new System.Drawing.Point(4, 28);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Size = new System.Drawing.Size(1327, 528);
            this.tabPage17.TabIndex = 5;
            this.tabPage17.Text = "PLC Input";
            // 
            // dataGridView_IP5
            // 
            this.dataGridView_IP5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_IP5.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_IP5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_IP5.Enabled = false;
            this.dataGridView_IP5.Location = new System.Drawing.Point(7, 17);
            this.dataGridView_IP5.Name = "dataGridView_IP5";
            this.dataGridView_IP5.ReadOnly = true;
            this.dataGridView_IP5.RowHeadersVisible = false;
            this.dataGridView_IP5.RowHeadersWidth = 51;
            this.dataGridView_IP5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_IP5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_IP5.Size = new System.Drawing.Size(518, 462);
            this.dataGridView_IP5.TabIndex = 4;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.dataGridView_OP2);
            this.tabPage3.Controls.Add(this.dataGridView_OP1);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1327, 528);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "PLC Output";
            // 
            // dataGridView_OP2
            // 
            this.dataGridView_OP2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_OP2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_OP2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_OP2.Enabled = false;
            this.dataGridView_OP2.Location = new System.Drawing.Point(611, 19);
            this.dataGridView_OP2.Name = "dataGridView_OP2";
            this.dataGridView_OP2.ReadOnly = true;
            this.dataGridView_OP2.RowHeadersVisible = false;
            this.dataGridView_OP2.RowHeadersWidth = 51;
            this.dataGridView_OP2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_OP2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_OP2.Size = new System.Drawing.Size(518, 462);
            this.dataGridView_OP2.TabIndex = 6;
            // 
            // dataGridView_OP1
            // 
            this.dataGridView_OP1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_OP1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_OP1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_OP1.Enabled = false;
            this.dataGridView_OP1.Location = new System.Drawing.Point(7, 17);
            this.dataGridView_OP1.Name = "dataGridView_OP1";
            this.dataGridView_OP1.ReadOnly = true;
            this.dataGridView_OP1.RowHeadersVisible = false;
            this.dataGridView_OP1.RowHeadersWidth = 51;
            this.dataGridView_OP1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_OP1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_OP1.Size = new System.Drawing.Size(518, 462);
            this.dataGridView_OP1.TabIndex = 5;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.White;
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage4.Controls.Add(this.dataGridView_OP4);
            this.tabPage4.Controls.Add(this.dataGridView_OP3);
            this.tabPage4.Location = new System.Drawing.Point(4, 28);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1327, 528);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "PLC Output";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // dataGridView_OP4
            // 
            this.dataGridView_OP4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_OP4.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_OP4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_OP4.Enabled = false;
            this.dataGridView_OP4.Location = new System.Drawing.Point(563, 17);
            this.dataGridView_OP4.Name = "dataGridView_OP4";
            this.dataGridView_OP4.ReadOnly = true;
            this.dataGridView_OP4.RowHeadersVisible = false;
            this.dataGridView_OP4.RowHeadersWidth = 51;
            this.dataGridView_OP4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_OP4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_OP4.Size = new System.Drawing.Size(518, 462);
            this.dataGridView_OP4.TabIndex = 6;
            // 
            // dataGridView_OP3
            // 
            this.dataGridView_OP3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_OP3.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_OP3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_OP3.Enabled = false;
            this.dataGridView_OP3.Location = new System.Drawing.Point(7, 17);
            this.dataGridView_OP3.Name = "dataGridView_OP3";
            this.dataGridView_OP3.ReadOnly = true;
            this.dataGridView_OP3.RowHeadersVisible = false;
            this.dataGridView_OP3.RowHeadersWidth = 51;
            this.dataGridView_OP3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_OP3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_OP3.Size = new System.Drawing.Size(518, 462);
            this.dataGridView_OP3.TabIndex = 5;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.White;
            this.tabPage6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage6.Location = new System.Drawing.Point(4, 28);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(1327, 528);
            this.tabPage6.TabIndex = 4;
            this.tabPage6.Text = "PLC Analog Input";
            // 
            // Motion_Card_IO
            // 
            this.Motion_Card_IO.BackColor = System.Drawing.Color.White;
            this.Motion_Card_IO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Motion_Card_IO.Controls.Add(this.dataGridView_MIP1);
            this.Motion_Card_IO.Location = new System.Drawing.Point(4, 28);
            this.Motion_Card_IO.Name = "Motion_Card_IO";
            this.Motion_Card_IO.Size = new System.Drawing.Size(1327, 528);
            this.Motion_Card_IO.TabIndex = 1;
            this.Motion_Card_IO.Text = "Motion Card DI";
            // 
            // dataGridView_MIP1
            // 
            this.dataGridView_MIP1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_MIP1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_MIP1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_MIP1.Enabled = false;
            this.dataGridView_MIP1.Location = new System.Drawing.Point(7, 17);
            this.dataGridView_MIP1.Name = "dataGridView_MIP1";
            this.dataGridView_MIP1.ReadOnly = true;
            this.dataGridView_MIP1.RowHeadersVisible = false;
            this.dataGridView_MIP1.RowHeadersWidth = 51;
            this.dataGridView_MIP1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_MIP1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_MIP1.Size = new System.Drawing.Size(518, 462);
            this.dataGridView_MIP1.TabIndex = 6;
            // 
            // Motion_Card_Output
            // 
            this.Motion_Card_Output.BackColor = System.Drawing.Color.White;
            this.Motion_Card_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Motion_Card_Output.Controls.Add(this.dataGridView_MOP1);
            this.Motion_Card_Output.Location = new System.Drawing.Point(4, 28);
            this.Motion_Card_Output.Name = "Motion_Card_Output";
            this.Motion_Card_Output.Size = new System.Drawing.Size(1327, 528);
            this.Motion_Card_Output.TabIndex = 2;
            this.Motion_Card_Output.Text = "Motion Card DO Output";
            // 
            // dataGridView_MOP1
            // 
            this.dataGridView_MOP1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_MOP1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_MOP1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_MOP1.Enabled = false;
            this.dataGridView_MOP1.Location = new System.Drawing.Point(7, 17);
            this.dataGridView_MOP1.Name = "dataGridView_MOP1";
            this.dataGridView_MOP1.ReadOnly = true;
            this.dataGridView_MOP1.RowHeadersVisible = false;
            this.dataGridView_MOP1.RowHeadersWidth = 51;
            this.dataGridView_MOP1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView_MOP1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_MOP1.Size = new System.Drawing.Size(518, 462);
            this.dataGridView_MOP1.TabIndex = 7;
            // 
            // tabPage0
            // 
            this.tabPage0.BackColor = System.Drawing.Color.White;
            this.tabPage0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage0.Controls.Add(this.btnSave);
            this.tabPage0.Controls.Add(this.btnEdit);
            this.tabPage0.Controls.Add(this.Axis_datagridview);
            this.tabPage0.Location = new System.Drawing.Point(4, 28);
            this.tabPage0.Name = "tabPage0";
            this.tabPage0.Size = new System.Drawing.Size(1254, 598);
            this.tabPage0.TabIndex = 0;
            this.tabPage0.Text = "Axis Parameter Setting";
            this.tabPage0.Click += new System.EventHandler(this.tabPage1_Click_1);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnSave.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(763, 488);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 35);
            this.btnSave.TabIndex = 104;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnEdit.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.Location = new System.Drawing.Point(581, 488);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(99, 35);
            this.btnEdit.TabIndex = 103;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // Axis_datagridview
            // 
            this.Axis_datagridview.AllowUserToAddRows = false;
            this.Axis_datagridview.AllowUserToDeleteRows = false;
            this.Axis_datagridview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.Axis_datagridview.BackgroundColor = System.Drawing.Color.White;
            this.Axis_datagridview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.Axis_datagridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Axis_datagridview.DefaultCellStyle = dataGridViewCellStyle3;
            this.Axis_datagridview.GridColor = System.Drawing.Color.Black;
            this.Axis_datagridview.Location = new System.Drawing.Point(11, 20);
            this.Axis_datagridview.Name = "Axis_datagridview";
            this.Axis_datagridview.RowHeadersWidth = 51;
            this.Axis_datagridview.Size = new System.Drawing.Size(1231, 462);
            this.Axis_datagridview.TabIndex = 0;
            this.Axis_datagridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.White;
            this.tabPage7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage7.Controls.Add(this.groupBox3);
            this.tabPage7.Controls.Add(this.button3);
            this.tabPage7.Controls.Add(this.button4);
            this.tabPage7.Controls.Add(this.groupBox1);
            this.tabPage7.Controls.Add(this.groupBox4);
            this.tabPage7.Location = new System.Drawing.Point(4, 28);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage7.Size = new System.Drawing.Size(1254, 598);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "System Setting";
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox4);
            this.groupBox3.Controls.Add(this.checkBox2);
            this.groupBox3.Controls.Add(this.checkBox1);
            this.groupBox3.Controls.Add(this.checkBox3);
            this.groupBox3.Controls.Add(this.checkBox9);
            this.groupBox3.Location = new System.Drawing.Point(455, 46);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(270, 276);
            this.groupBox3.TabIndex = 104;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "System Bypass";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(21, 145);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(123, 20);
            this.checkBox4.TabIndex = 26;
            this.checkBox4.Text = "PDCA Bypass";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(21, 72);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(169, 20);
            this.checkBox2.TabIndex = 24;
            this.checkBox2.Text = "Safety Door Bypass";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(21, 35);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(143, 20);
            this.checkBox1.TabIndex = 23;
            this.checkBox1.Text = "Scanner Bypass";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(21, 107);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(112, 20);
            this.checkBox3.TabIndex = 25;
            this.checkBox3.Text = "SFC Bypass";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox9.Location = new System.Drawing.Point(21, 180);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(60, 20);
            this.checkBox9.TabIndex = 33;
            this.checkBox9.Text = "Hive";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(628, 419);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 35);
            this.button3.TabIndex = 103;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(474, 419);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(99, 35);
            this.button4.TabIndex = 102;
            this.button4.Text = "Edit";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.productionmode);
            this.groupBox1.Controls.Add(this.dryrun);
            this.groupBox1.Controls.Add(this.convdryrun);
            this.groupBox1.Controls.Add(this.convruwithtray);
            this.groupBox1.Controls.Add(this.offlinemode);
            this.groupBox1.Controls.Add(this.onlinemode);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(44, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(270, 280);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "System Settings";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // productionmode
            // 
            this.productionmode.AutoSize = true;
            this.productionmode.Location = new System.Drawing.Point(34, 62);
            this.productionmode.Name = "productionmode";
            this.productionmode.Size = new System.Drawing.Size(148, 20);
            this.productionmode.TabIndex = 37;
            this.productionmode.Text = "Production Mode";
            this.productionmode.UseVisualStyleBackColor = true;
            this.productionmode.CheckedChanged += new System.EventHandler(this.productionmode_CheckedChanged);
            // 
            // dryrun
            // 
            this.dryrun.AutoSize = true;
            this.dryrun.Location = new System.Drawing.Point(35, 36);
            this.dryrun.Name = "dryrun";
            this.dryrun.Size = new System.Drawing.Size(83, 20);
            this.dryrun.TabIndex = 36;
            this.dryrun.Text = "Dry Run";
            this.dryrun.UseVisualStyleBackColor = true;
            this.dryrun.CheckedChanged += new System.EventHandler(this.dryrun_CheckedChanged);
            // 
            // convdryrun
            // 
            this.convdryrun.AutoSize = true;
            this.convdryrun.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convdryrun.Location = new System.Drawing.Point(34, 240);
            this.convdryrun.Name = "convdryrun";
            this.convdryrun.Size = new System.Drawing.Size(123, 20);
            this.convdryrun.TabIndex = 35;
            this.convdryrun.TabStop = true;
            this.convdryrun.Text = "Conv Dry Run";
            this.convdryrun.UseVisualStyleBackColor = true;
            this.convdryrun.CheckedChanged += new System.EventHandler(this.convdryrun_CheckedChanged);
            // 
            // convruwithtray
            // 
            this.convruwithtray.AutoSize = true;
            this.convruwithtray.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.convruwithtray.Location = new System.Drawing.Point(34, 210);
            this.convruwithtray.Name = "convruwithtray";
            this.convruwithtray.Size = new System.Drawing.Size(167, 20);
            this.convruwithtray.TabIndex = 34;
            this.convruwithtray.TabStop = true;
            this.convruwithtray.Text = "Conv Run With Tray";
            this.convruwithtray.UseVisualStyleBackColor = true;
            this.convruwithtray.CheckedChanged += new System.EventHandler(this.convruwithtray_CheckedChanged);
            // 
            // offlinemode
            // 
            this.offlinemode.AutoSize = true;
            this.offlinemode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.offlinemode.Location = new System.Drawing.Point(36, 150);
            this.offlinemode.Name = "offlinemode";
            this.offlinemode.Size = new System.Drawing.Size(116, 20);
            this.offlinemode.TabIndex = 30;
            this.offlinemode.TabStop = true;
            this.offlinemode.Text = "Offline Mode";
            this.offlinemode.UseVisualStyleBackColor = true;
            this.offlinemode.CheckedChanged += new System.EventHandler(this.offlinemode_CheckedChanged);
            // 
            // onlinemode
            // 
            this.onlinemode.AutoSize = true;
            this.onlinemode.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.onlinemode.Location = new System.Drawing.Point(35, 118);
            this.onlinemode.Name = "onlinemode";
            this.onlinemode.Size = new System.Drawing.Size(115, 20);
            this.onlinemode.TabIndex = 29;
            this.onlinemode.TabStop = true;
            this.onlinemode.Text = "Online Mode";
            this.onlinemode.UseVisualStyleBackColor = true;
            this.onlinemode.CheckedChanged += new System.EventHandler(this.onlinemode_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.White;
            this.groupBox4.Controls.Add(this.labelControl13);
            this.groupBox4.Controls.Add(this.labelControl9);
            this.groupBox4.Controls.Add(this.labelControl8);
            this.groupBox4.Controls.Add(this.labelControl7);
            this.groupBox4.Controls.Add(this.labelControl6);
            this.groupBox4.Controls.Add(this.labelControl5);
            this.groupBox4.Controls.Add(this.lblRoboIP);
            this.groupBox4.Controls.Add(this.lblPDCAIP);
            this.groupBox4.Controls.Add(this.lblSFCIP);
            this.groupBox4.Controls.Add(this.lblScannerIP);
            this.groupBox4.Controls.Add(this.LabelCCD1);
            this.groupBox4.Controls.Add(this.linkLabel1);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(866, 46);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 276);
            this.groupBox4.TabIndex = 62;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Device IP Details";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // labelControl13
            // 
            this.labelControl13.AutoSize = true;
            this.labelControl13.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(36, 101);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(59, 16);
            this.labelControl13.TabIndex = 37;
            this.labelControl13.Text = "Robot :";
            // 
            // labelControl9
            // 
            this.labelControl9.AutoSize = true;
            this.labelControl9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Location = new System.Drawing.Point(35, 179);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(56, 16);
            this.labelControl9.TabIndex = 36;
            this.labelControl9.Text = "PDCA :";
            // 
            // labelControl8
            // 
            this.labelControl8.AutoSize = true;
            this.labelControl8.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Location = new System.Drawing.Point(36, 153);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(45, 16);
            this.labelControl8.TabIndex = 35;
            this.labelControl8.Text = "SFC :";
            // 
            // labelControl7
            // 
            this.labelControl7.AutoSize = true;
            this.labelControl7.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(36, 127);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(76, 16);
            this.labelControl7.TabIndex = 34;
            this.labelControl7.Text = "Scanner :";
            // 
            // labelControl6
            // 
            this.labelControl6.AutoSize = true;
            this.labelControl6.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(36, 75);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(43, 16);
            this.labelControl6.TabIndex = 30;
            this.labelControl6.Text = "CCD:";
            // 
            // labelControl5
            // 
            this.labelControl5.AutoSize = true;
            this.labelControl5.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Location = new System.Drawing.Point(36, 39);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(130, 16);
            this.labelControl5.TabIndex = 29;
            this.labelControl5.Text = "Device IP Details";
            // 
            // lblRoboIP
            // 
            this.lblRoboIP.AutoSize = true;
            this.lblRoboIP.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoboIP.Location = new System.Drawing.Point(129, 101);
            this.lblRoboIP.Name = "lblRoboIP";
            this.lblRoboIP.Size = new System.Drawing.Size(52, 16);
            this.lblRoboIP.TabIndex = 28;
            this.lblRoboIP.Text = "label6";
            // 
            // lblPDCAIP
            // 
            this.lblPDCAIP.AutoSize = true;
            this.lblPDCAIP.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPDCAIP.Location = new System.Drawing.Point(128, 179);
            this.lblPDCAIP.Name = "lblPDCAIP";
            this.lblPDCAIP.Size = new System.Drawing.Size(52, 16);
            this.lblPDCAIP.TabIndex = 20;
            this.lblPDCAIP.Text = "label6";
            // 
            // lblSFCIP
            // 
            this.lblSFCIP.AutoSize = true;
            this.lblSFCIP.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSFCIP.Location = new System.Drawing.Point(128, 153);
            this.lblSFCIP.Name = "lblSFCIP";
            this.lblSFCIP.Size = new System.Drawing.Size(52, 16);
            this.lblSFCIP.TabIndex = 19;
            this.lblSFCIP.Text = "label6";
            // 
            // lblScannerIP
            // 
            this.lblScannerIP.AutoSize = true;
            this.lblScannerIP.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScannerIP.Location = new System.Drawing.Point(129, 127);
            this.lblScannerIP.Name = "lblScannerIP";
            this.lblScannerIP.Size = new System.Drawing.Size(52, 16);
            this.lblScannerIP.TabIndex = 18;
            this.lblScannerIP.Text = "label6";
            // 
            // LabelCCD1
            // 
            this.LabelCCD1.AutoSize = true;
            this.LabelCCD1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCCD1.Location = new System.Drawing.Point(128, 75);
            this.LabelCCD1.Name = "LabelCCD1";
            this.LabelCCD1.Size = new System.Drawing.Size(52, 16);
            this.LabelCCD1.TabIndex = 17;
            this.LabelCCD1.Text = "label6";
            this.LabelCCD1.Click += new System.EventHandler(this.LabelCCD1_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Location = new System.Drawing.Point(6, 223);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(296, 46);
            this.linkLabel1.TabIndex = 16;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Note: For Changing device IP go to below path \"D:\\TEAL\\NOVA\\DLL\\ConnectionDetails" +
    ".XML\"";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // tabControl2
            // 
            this.tabControl2.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage0);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage11);
            this.tabControl2.Controls.Add(this.tabPage18);
            this.tabControl2.Controls.Add(this.tabPage12);
            this.tabControl2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold);
            this.tabControl2.Location = new System.Drawing.Point(5, 64);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1262, 630);
            this.tabControl2.TabIndex = 4;
            // 
            // tabPage18
            // 
            this.tabPage18.BackColor = System.Drawing.Color.White;
            this.tabPage18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage18.Location = new System.Drawing.Point(4, 28);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Size = new System.Drawing.Size(1254, 598);
            this.tabPage18.TabIndex = 4;
            this.tabPage18.Text = "CPK";
            // 
            // Static_timer
            // 
            this.Static_timer.Tick += new System.EventHandler(this.Static_timer_Tick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Dyanamic_timer
            // 
            this.Dyanamic_timer.Tick += new System.EventHandler(this.Dyanamic_timer_Tick);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Gainsboro;
            this.label1.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(562, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 29);
            this.label1.TabIndex = 46;
            this.label1.Text = "SETTINGS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // io_diagnostics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1040, 640);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl2);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(6, 140);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1270, 838);
            this.MinimizeBox = false;
            this.Name = "io_diagnostics";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "io_diagnostics";
            this.Load += new System.EventHandler(this.io_diagnostics_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.io_diagnostics_MouseMove);
            this.tabPage11.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grpboxCamera.ResumeLayout(false);
            this.grpboxCamera.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP3)).EndInit();
            this.tabPage17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_IP5)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_OP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_OP1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_OP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_OP3)).EndInit();
            this.Motion_Card_IO.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_MIP1)).EndInit();
            this.Motion_Card_Output.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_MOP1)).EndInit();
            this.tabPage0.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Axis_datagridview)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button simpleButton65;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl65;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button simpleButton66;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl66;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label labelControl67;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton67;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl68;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton68;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl69;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton69;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl70;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton70;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl71;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton71;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl72;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton72;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl73;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton73;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl74;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton74;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl75;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Button simpleButton75;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Button simpleButton76;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl76;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label labelControl77;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton77;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl78;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton78;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl79;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton79;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl80;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton80;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl81;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton81;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl82;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton82;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl83;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton83;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl84;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton84;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl85;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Button simpleButton85;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Button simpleButton86;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl86;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label labelControl87;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton87;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl88;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton88;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl89;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton89;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl90;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton90;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl91;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton91;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl92;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton92;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl93;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton93;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl94;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Button simpleButton94;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl95;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Button simpleButton95;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Button simpleButton96;  // Replaced DevExpress SimpleButton with Windows Forms Button
        private System.Windows.Forms.Label labelControl96;   // Replaced DevExpress LabelControl with Windows Forms Label
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Timer IO_sts_Timer;
        private System.Windows.Forms.Timer AI_TIMER;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox grpboxCamera;
        private System.Windows.Forms.CheckBox chkCCD1;
        private System.Windows.Forms.RichTextBox richTextBox_Calib;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblServo_Conn_Status_X;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCamera_Stop;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button btnCamera_Start;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox Cam1_path;
        private System.Windows.Forms.Label lblactualpos_ccd1_y;
        private System.Windows.Forms.Label lblactualpos_ccd1_x;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox CCD1count;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox CCD1Speed;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblRunningCount;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbTestMode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage Motion_Card_IO;
        private System.Windows.Forms.TabPage Motion_Card_Output;
        private System.Windows.Forms.TabPage tabPage0;
        private System.Windows.Forms.DataGridView Axis_datagridview;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.RadioButton offlinemode;
        private System.Windows.Forms.RadioButton onlinemode;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label labelControl13;
        private System.Windows.Forms.Label labelControl9;
        private System.Windows.Forms.Label labelControl8;
        private System.Windows.Forms.Label labelControl7;
        private System.Windows.Forms.Label labelControl6;
        private System.Windows.Forms.Label labelControl5;
        private System.Windows.Forms.Label lblRoboIP;
        private System.Windows.Forms.Label lblPDCAIP;
        private System.Windows.Forms.Label lblSFCIP;
        private System.Windows.Forms.Label lblScannerIP;
        private System.Windows.Forms.Label LabelCCD1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer Dyanamic_timer;
        private System.Windows.Forms.Timer Static_timer;
        private System.Windows.Forms.RadioButton convdryrun;
        private System.Windows.Forms.RadioButton convruwithtray;
        private System.Windows.Forms.CheckBox productionmode;
        private System.Windows.Forms.CheckBox dryrun;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView dataGridView_IP2;
        private System.Windows.Forms.DataGridView dataGridView_IP1;
        private System.Windows.Forms.DataGridView dataGridView_IP4;
        private System.Windows.Forms.DataGridView dataGridView_IP3;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.DataGridView dataGridView_IP5;
        private System.Windows.Forms.DataGridView dataGridView_OP2;
        private System.Windows.Forms.DataGridView dataGridView_OP1;
        private System.Windows.Forms.DataGridView dataGridView_OP3;
        private System.Windows.Forms.DataGridView dataGridView_MIP1;
        private System.Windows.Forms.DataGridView dataGridView_MOP1;
        private System.Windows.Forms.Label label1;
        private RoundButton roundButton1;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.DataGridView dataGridView_OP4;
    }
}