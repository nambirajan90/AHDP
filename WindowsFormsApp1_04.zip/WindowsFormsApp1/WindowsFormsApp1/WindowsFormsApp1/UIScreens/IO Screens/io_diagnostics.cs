﻿using AHDP.UIScreens.ParameterSetting_Screens;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace AHDP.UIScreens.IO_Screens
{
    public partial class io_diagnostics : Form
    {

        //Declarations
        //public int connect_plc_status;
        // public string filepath = Environment.CurrentDirectory + @"\DIlist.txt";
        public int y;
        public int y_pic;
        int numRows = 2;
        int numCols = 20;
        int page = 0;
        int OP_ButtonNumber = 0;
        string numStr = "";
        string result = "";
        int IP_Lblnumber = 0;
        Dictionary<string, string> IP_label_name_list = new Dictionary<string, string>();
        Dictionary<string, string> IP_label_name_list1 = new Dictionary<string, string>();
        Dictionary<string, string> IP_label_name_list2 = new Dictionary<string, string>();
        Dictionary<string, string> OP_label_name_list = new Dictionary<string, string>();
        Dictionary<string, string> OP_label_name_list1 = new Dictionary<string, string>();
        Dictionary<string, string> MC_IP_label_name_list = new Dictionary<string, string>();
        Dictionary<string, string> MC_OP_label_name_list = new Dictionary<string, string>();

        public io_diagnostics()
        {
            InitializeComponent();
            ON_FormLoad();
            // Attach the event handler
            //tabControl2.SelectedIndexChanged += tabControl2_SelectedIndexChanged;
            LoadAxisConfigurationData(); // Call method to load data for Axis Parameters
                                         //btnEdit.Enabled = false;
                                         //btnSave.Enabled = false;
            Axis_datagridview.Columns["Axis_ID"].Frozen = true;
            Axis_datagridview.Columns["Axis_Name"].Frozen = true;



        }
        public static bool check3 = false;
        public static bool check4 = false;
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,
            int nTopRect,
            int nRightRect,
            int nBottomRect,
            int nWidthEllipse,
            int nHeightEllipse
        );
        private void io_diagnostics_Load(object sender, EventArgs e)
        {

            //system settings
            dryrun.Enabled = false;
            productionmode.Enabled = false;
            onlinemode.Enabled = false;
            offlinemode.Enabled = false;
            convruwithtray.Enabled = false;
            convdryrun.Enabled = false;
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            checkBox3.Enabled = false;
            checkBox4.Enabled = false;
            checkBox9.Enabled = false;

            //DeviceIP
            LabelCCD1.Text = Globalvariable.D_CCD1.ToString();
            //LabelCCD3.Text = Globalvariable.D_CCD3.ToString();
            //LabelCCD4.Text = Globalvariable.D_CCD4.ToString();
            //LabelCCD5.Text = Globalvariable.D_CCD5.ToString();
            lblScannerIP.Text = Globalvariable.D_Scanner.ToString();
            lblSFCIP.Text = Globalvariable.D_SFC.ToString();
            lblPDCAIP.Text = Globalvariable.D_PDCA.ToString();
            lblRoboIP.Text = Globalvariable.D_RObot.ToString();

            //IO Diagnostic
            Axis_datagridview.Enabled = false;

            //calibration
            btnCamera_Start.Enabled = true;
            btnCamera_Stop.Enabled = false;

            //CPK and GRR
            this.tabControl2.TabPages.Remove(this.tabPage18);
            this.tabControl2.TabPages.Remove(this.tabPage12);
        }

        //Mod0612
        //private void tabControl2_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    // Check if the selected tab is tabPage0
        //    if (tabControl2.SelectedTab == tabPage0)
        //    {
        //        LoadAxisConfigurationData(); // Call method to load data for Axis Parameters
        //    }
        //}

        private void LoadAxisConfigurationData()
        {
            try
            {
                string sqlQuery = "SELECT Axis_ID,Axis_Name,Pitch, Pulse_Per_mm,Manual_Speed,Jog_Speed,Homing_Speed,Manual_Acceleration_Time_sec,Manual_Deacceleration_Time_sec,Homing_Method,Homing_Mode  FROM Axis_Parameter_Configuration"; // Query to fetch data          
                DataSet ds = SQLHelper.GetData(sqlQuery); // Fetch data using your SQLHelper class
                //SqlDataAdapter adapter = new SqlDataAdapter(cmd)
                //DataTable dt = new DataTable();
                //adapter.Fill(dt);
                if (ds != null && ds.Tables.Count > 0)
                {
                    Axis_datagridview.DataSource = ds.Tables[0].DefaultView; // Bind data to DataGridView
                                                                             // Axis_datagridview.Enabled = true; // Enable the DataGridView
                }
                else
                {
                    MessageBox.Show("No data found in AxisConfiguration table.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void IO_sts_Timer_Tick(object sender, EventArgs e)
        {
            int[] PLC_IP1 = new int[20];
            int[] PLC_IP2 = new int[20];
            int[] PLC_IP3 = new int[20];
            int[] PLC_IP4 = new int[20];
            int[] PLC_IP5 = new int[20];

            int[] PLC_OP1 = new int[20];
            int[] PLC_OP2 = new int[20];
            int[] PLC_OP3 = new int[20];
            int[] PLC_OP4 = new int[20];

            Array.Copy(PLC.DIO_Read, 0, PLC_IP1, 0, 20);
            Array.Copy(PLC.DIO_Read, 20, PLC_IP2, 0, 20);
            Array.Copy(PLC.DIO_Read, 40, PLC_IP3, 0, 20);
            Array.Copy(PLC.DIO_Read, 60, PLC_IP4, 0, 20);
            Array.Copy(PLC.DIO_Read, 80, PLC_IP5, 0, 16);
            

            IOSTATUS(IP1_NAMES, dataGridView_IP1,PLC_IP1);
            IOSTATUS(IP2_NAMES, dataGridView_IP2,PLC_IP2);
            IOSTATUS(IP3_NAMES, dataGridView_IP3,PLC_IP3);
            IOSTATUS(IP4_NAMES, dataGridView_IP4,PLC_IP4);
            IOSTATUS(IP5_NAMES, dataGridView_IP5,PLC_IP5);
            

            IOSTATUS(OP1_NAMES, dataGridView_OP1,PLC_OP1);
            IOSTATUS(OP2_NAMES, dataGridView_OP2,PLC_OP2);
            IOSTATUS(OP3_NAMES, dataGridView_OP3,PLC_OP3);
            IOSTATUS(OP4_NAMES, dataGridView_OP4,PLC_OP4);




         //   IOSTATUS(MI_1_NAMES, dataGridView_MIP1, Convert.ToInt32(Globalvariable.MC_Read_DI));
          //  IOSTATUS(MO_1_NAMES, dataGridView_MOP1, Convert.ToInt32(Globalvariable.MC_Read_DO));

        }

        //Newly added 17-12-2024
        private List<string> ConvertDictionaryToList(Dictionary<string, string> dictionary)
        {
            return dictionary.Values.ToList();
        }
        //End
        private void ON_FormLoad()
        {
            read_data_confic();
            ////labeladd(IP_label_name_list, 0);       //17-12-2024
            //labeladd_IP(IP_label_name_list, 0);
            //// labeladd(IP_label_name_list1, 1);    //17-12-2024
            //labeladd_IP(IP_label_name_list1, 1);
            //// labeladd(IP_label_name_list2, 2);   //17-12-2024
            //labeladd_IP(IP_label_name_list2, 2);
            ////labeladd(OP_label_name_list, 3);     //17-12-2024
            //labeladd_IP(OP_label_name_list, 3);
            ////labeladd(OP_label_name_list1, 4);   //17-12-2024
            //labeladd_IP(OP_label_name_list1, 4);
            ////this.tabControl1.TabPages.Remove(this.tabPage6);      //17-12-2024
            ////this.tabControl1.TabPages.Remove(this.Motion_Card_IO);   //17-12-2024
            ////this.tabControl1.TabPages.Remove(this.Motion_Card_Output);  //17-12-2024

            ////added newly
            //labeladd_IP(MC_IP_label_name_list, 6);
            //labeladd_IP(MC_OP_label_name_list, 7);
            //end
            
            IOLABELS(IP1_NAMES, dataGridView_IP1);
            IOLABELS(IP2_NAMES, dataGridView_IP2);
            IOLABELS(IP3_NAMES, dataGridView_IP3);
            IOLABELS(IP4_NAMES, dataGridView_IP4);
            IOLABELS(IP5_NAMES, dataGridView_IP5);
            

            IOLABELS(OP1_NAMES, dataGridView_OP1);
            IOLABELS(OP2_NAMES, dataGridView_OP2);
            IOLABELS(OP3_NAMES, dataGridView_OP3);
            IOLABELS(OP4_NAMES, dataGridView_OP4);

            IOLABELS(MI_1_NAMES, dataGridView_MIP1);
            IOLABELS(MO_1_NAMES, dataGridView_MOP1);

            //Added Newly 17-12-2024
            //var IPlist1 = ConvertDictionaryToList(IP_label_name_list);
            //var limitedIPlist = IPlist1.Take(20).ToList();
            //dataGridView_IP1.DataSource = limitedIPlist.Select(value => new { Value = value }).ToList();
            //dataGridView_IP1.ColumnHeadersVisible = false;

            //var IPlist2 = ConvertDictionaryToList(IP_label_name_list);
            //var limitedIPlist2 = IPlist2.Skip(20).Take(20).ToList();
            //dataGridView_IP2.DataSource = limitedIPlist2.Select(value => new { Value = value }).ToList();
            //dataGridView_IP2.ColumnHeadersVisible = false;

            //var IPlist3 = ConvertDictionaryToList(IP_label_name_list1);
            //var limitedIPlist3 = IPlist3.Take(20).ToList();
            //dataGridView_IP3.DataSource = limitedIPlist3.Select(value => new { Value = value }).ToList();
            //dataGridView_IP3.ColumnHeadersVisible = false;

            //var IPlist4 = ConvertDictionaryToList(IP_label_name_list1);
            //var limitedIPlist4 = IPlist3.Skip(20).Take(20).ToList();
            //dataGridView_IP4.DataSource = limitedIPlist4.Select(value => new { Value = value }).ToList();
            //dataGridView_IP4.ColumnHeadersVisible = false;

            //var IPlist5 = ConvertDictionaryToList(IP_label_name_list2);
            //var limitedIPlist5 = IPlist5.Take(20).ToList();
            //dataGridView_IP5.DataSource = limitedIPlist5.Select(value => new { Value = value }).ToList();
            //dataGridView_IP5.ColumnHeadersVisible = false;


            //var OPlist1 = ConvertDictionaryToList(OP_label_name_list);
            //var OPlimitedIPlist1 = OPlist1.Take(20).ToList();
            //dataGridView_OP1.DataSource = OPlimitedIPlist1.Select(value => new { Value = value }).ToList();
            //dataGridView_OP1.ColumnHeadersVisible = false;

            //var OPlist2 = ConvertDictionaryToList(OP_label_name_list);
            //var OPlimitedIPlist2 = OPlist2.Skip(20).Take(20).ToList();
            //dataGridView_OP2.DataSource = OPlimitedIPlist2.Select(value => new { Value = value }).ToList();
            //dataGridView_OP2.ColumnHeadersVisible = false;

            //var OPlist3 = ConvertDictionaryToList(OP_label_name_list1);
            //var OPlimitedIPlist3 = OPlist3.Take(20).ToList();
            //dataGridView_OP3.DataSource = OPlimitedIPlist3.Select(value => new { Value = value }).ToList();
            //dataGridView_OP3.ColumnHeadersVisible = false;

            //var MIPlist1 = ConvertDictionaryToList(MC_IP_label_name_list);
            //var MIPlimitedIPlist1 = MIPlist1.Take(20).ToList();
            //dataGridView_MIP1.DataSource = MIPlimitedIPlist1.Select(value => new { Value = value }).ToList();
            //dataGridView_MIP1.ColumnHeadersVisible = false;

            //var MOPlist1 = ConvertDictionaryToList(MC_OP_label_name_list);
            //var MOPlimitedIPlist1 = MOPlist1.Take(20).ToList();
            //dataGridView_MOP1.DataSource = MOPlimitedIPlist1.Select(value => new { Value = value }).ToList();
            //dataGridView_MOP1.ColumnHeadersVisible = false;
            ////End


        }

        private void button4_Click(object sender, EventArgs e)
        {
            dryrun.Enabled = true;
            productionmode.Enabled = true;
            onlinemode.Enabled = true;
            offlinemode.Enabled = true;
            convruwithtray.Enabled = true;
            convdryrun.Enabled = true;
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
            checkBox3.Enabled = true;
            checkBox4.Enabled = true;
            checkBox9.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dryrun.Enabled = false;
            productionmode.Enabled = false;
            onlinemode.Enabled = false;
            offlinemode.Enabled = false;
            convruwithtray.Enabled = false;
            convdryrun.Enabled = false;
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            checkBox3.Enabled = false;
            checkBox4.Enabled = false;
            checkBox9.Enabled = false;

            if (checkBox1.Checked == true)
            {
                Globalvariable.Scanner_Bypass = true;
            }
            //if (Chk_Safety_Door.Checked == true)
            //{
            //    Globalvariable.Safety_Door_Bypass = true;
            //}
            //if (chk_SFC_Bypass.Checked == true)
            //{
            //    Globalvariable.SFC_Bypass = true;
            //}
            //if (chk_PDCA_Bypass.Checked == true)
            //{
            //    Globalvariable.PDCA_Bypass = true;
            //}
            // Dry Run and Production Mode

            bool Dryrun = dryrun.Checked;
            if (Dryrun)
            {
                Globalvariable.Dry_run = true;
                Globalvariable.dry_cycle_enable = true;
                Globalvariable.Production_mode = false;

            }
            else
            {
                Globalvariable.Dry_run = false;
                Globalvariable.Production_mode = true;
                Globalvariable.dry_cycle_enable = false;

            }

            // Online and Offline Modes
            bool Online_Mode = onlinemode.Checked;
            if (Online_Mode)
            {
                Globalvariable.Online_mode = true;
                Globalvariable.Offline_mode = false;
            }
            else
            {
                Globalvariable.Online_mode = false;
                Globalvariable.Offline_mode = true;
            }

            // Conveyor with Tray and Conveyor Dry Run Modes
            bool ConvRUWithTray = convruwithtray.Checked;
            if (ConvRUWithTray)
            {
                Globalvariable.Conveyor_Run_with_Tray = true;
                Globalvariable.Conveyor_Run_without_Tray = false;
            }
            else
            {
                Globalvariable.Conveyor_Run_with_Tray = false;
                Globalvariable.Conveyor_Run_without_Tray = true;
            }


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Globalvariable.Scanner_Bypass = true;
            }
            else
            {
                Globalvariable.Scanner_Bypass = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                Globalvariable.Safety_Door_Bypass = true;
            }
            else
            {
                Globalvariable.Safety_Door_Bypass = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                Globalvariable.SFC_Bypass = true;
            }
            else
            {
                Globalvariable.SFC_Bypass = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                Globalvariable.PDCA_Bypass = true;
            }
            else
            {
                Globalvariable.PDCA_Bypass = false;
            }
        }

 
        public static string[] IP1_NAMES = new string[20];
        public static string[] IP2_NAMES = new string[20];
        public static string[] IP3_NAMES = new string[20];
        public static string[] IP4_NAMES = new string[20];
        public static string[] IP5_NAMES = new string[20];

        public static string[] OP1_NAMES = new string[20];
        public static string[] OP2_NAMES = new string[20];
        public static string[] OP3_NAMES = new string[20];
        public static string[] OP4_NAMES = new string[20];

        public static string[] MI_1_NAMES = new string[20];
        public static string[] MO_1_NAMES = new string[20];

        private void read_data_confic()  //  reads the  textfile for displaying  the names
        {
            try
            {

                if (File.Exists(Environment.CurrentDirectory + @"\DIlist1.txt"))
                {
                    IP1_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DIlist1.txt", Encoding.UTF8);
                    
                }
                if (File.Exists(Environment.CurrentDirectory + @"\DIlist2.txt"))
                {
                    IP2_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DIlist2.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\DIlist3.txt"))
                {
                    IP3_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DIlist3.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\DIlist4.txt"))
                {
                    IP4_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DIlist4.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\DIlist5.txt"))
                {
                    IP5_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DIlist5.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\D0list1.txt"))
                {
                    OP1_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DOlist1.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\DOlist2.txt"))
                {
                    OP2_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DOlist2.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\DOlist3.txt"))
                {
                    OP3_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DOlist3.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\DOlist4.txt"))
                {
                    OP3_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\DOlist4.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\MCI1list1.txt"))
                {
                    MI_1_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\MCI1list1.txt", Encoding.UTF8);

                }
                if (File.Exists(Environment.CurrentDirectory + @"\MCO1list1.txt"))
                {
                    MO_1_NAMES = File.ReadAllLines(Environment.CurrentDirectory + @"\MCO1list1.txt", Encoding.UTF8);

                }


            }
            catch (Exception ex)
            {
                Logger.WriteLog("IDIOConfig.O_diagnostics", "read_data_confic()", "Common", "Exception Error", ex.ToString());
            }

        }
     
        private void IOSTATUS(string[] Input_Names, DataGridView Table, int[] IO_Status)
        {
            for (int i = 0; i < Input_Names.Length; i++)
            {
                if (IO_Status[i] == 1)
                {
                    Table.Rows[i].Cells[1].Style.BackColor = Color.Lime;
                }
                else
                {
                   Table.Rows[i].Cells[1].Style.BackColor = Color.Red;
                }
            }
            
        }
        private void IOLABELS(string[] Input_Names, DataGridView Table)
        {
            DataGridViewTextBoxColumn textColumn = new DataGridViewTextBoxColumn();
            textColumn.HeaderText = "Name";
            textColumn.Width = 700;
            Table.Columns.Add(textColumn);


            DataGridViewButtonColumn buttonColumn = new DataGridViewButtonColumn();
            buttonColumn.HeaderText = "Status";
            buttonColumn.FlatStyle = FlatStyle.Popup;
            buttonColumn.Width = 20;
            Table.Columns.Add(buttonColumn);

            Table.Enabled = false;
            Table.ScrollBars = ScrollBars.None;
            Table.ClearSelection();
            Table.AllowUserToAddRows = false;


            for (int i = 0; i < Input_Names.Length; i++)
            {
                int rowIndex = Table.Rows.Add();
                Table.Rows[rowIndex].Cells[0].Value = Input_Names[i];
            }
        }
  
        #region "Loadcell SOP"
        private void btnEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Do you want to enable editing recipe ?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                Axis_datagridview.Enabled = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Do you want to save and download the recipe?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    // Add logic here to save data from the DataGridView back to the database or Excel sheet.
                    SaveDataFromDataGridView();

                    // Disable the DataGridView after saving.
                    Axis_datagridview.Enabled = false;

                    // Optionally, reload the data to reflect saved changes (if needed).
                    LoadAxisConfigurationData();
                    Download_Data_Axis_Param();

                    //MessageBox.Show("Recipe saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error saving data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public async void Download_Data_Axis_Param()
        {
            DataView dataView = (DataView)Axis_datagridview.DataSource;
            DataTable dt = dataView.Table;  
            
            if (dt.Rows.Count > 0)
            {
                try
                {
                    
                    Globalvariable.AP_Pitch[5] = Convert.ToDouble(dt.Rows[0][2]);
                    Globalvariable.AP_Pitch[6] = Convert.ToDouble(dt.Rows[1][2]);
                    Globalvariable.AP_Pitch[2] = Convert.ToDouble(dt.Rows[2][2]);
                    Globalvariable.AP_Pitch[3] = Convert.ToDouble(dt.Rows[3][2]);
                    Globalvariable.AP_Pitch[4] = Convert.ToDouble(dt.Rows[4][2]);
                    Globalvariable.AP_Pitch[0] = Convert.ToDouble(dt.Rows[5][2]);
                    Globalvariable.AP_Pitch[1] = Convert.ToDouble(dt.Rows[6][2]);

                    //existing
                    //Globalvariable.AP_Pulse[5]= Convert.ToDouble(dt.Rows[0][3]);
                    //Globalvariable.AP_Pulse[6] = Convert.ToDouble(dt.Rows[1][3]);
                    //Globalvariable.AP_Pulse[2] = Convert.ToDouble(dt.Rows[2][3]);
                    //Globalvariable.AP_Pulse[3] = Convert.ToDouble(dt.Rows[3][3]);
                    //Globalvariable.AP_Pulse[4] = Convert.ToDouble(dt.Rows[4][3]);
                    //Globalvariable.AP_Pulse[0] = Convert.ToDouble(dt.Rows[5][3]);
                    //Globalvariable.AP_Pulse[1] = Convert.ToDouble(dt.Rows[6][3]);


                    //by allen  301224
                    Globalvariable.AP_Pulse[0] = Convert.ToDouble(dt.Rows[0][3]);
                    Globalvariable.AP_Pulse[1] = Convert.ToDouble(dt.Rows[1][3]);
                    Globalvariable.AP_Pulse[2] = Convert.ToDouble(dt.Rows[2][3]);
                    Globalvariable.AP_Pulse[3] = Convert.ToDouble(dt.Rows[3][3]);
                    Globalvariable.AP_Pulse[4] = Convert.ToDouble(dt.Rows[4][3]);
                    Globalvariable.AP_Pulse[5] = Convert.ToDouble(dt.Rows[5][3]);
                    Globalvariable.AP_Pulse[6] = Convert.ToDouble(dt.Rows[6][3]);


                    Globalvariable.AP_Manual_Speed[5] = Convert.ToDouble(dt.Rows[0][4]);
                    Globalvariable.AP_Manual_Speed[6] = Convert.ToDouble(dt.Rows[1][4]);
                    Globalvariable.AP_Manual_Speed[2] = Convert.ToDouble(dt.Rows[2][4]);
                    Globalvariable.AP_Manual_Speed[3] = Convert.ToDouble(dt.Rows[3][4]);
                    Globalvariable.AP_Manual_Speed[4] = Convert.ToDouble(dt.Rows[4][4]);
                    Globalvariable.AP_Manual_Speed[0] = Convert.ToDouble(dt.Rows[5][4]);
                    Globalvariable.AP_Manual_Speed[1] = Convert.ToDouble(dt.Rows[6][4]);

                    
                    Globalvariable.AP_Jog_Speed[5] = Convert.ToDouble(dt.Rows[0][5]);
                    Globalvariable.AP_Jog_Speed[6] = Convert.ToDouble(dt.Rows[1][5]);
                    Globalvariable.AP_Jog_Speed[2] = Convert.ToDouble(dt.Rows[2][5]);
                    Globalvariable.AP_Jog_Speed[3] = Convert.ToDouble(dt.Rows[3][5]);
                    Globalvariable.AP_Jog_Speed[4] = Convert.ToDouble(dt.Rows[4][5]);
                    Globalvariable.AP_Jog_Speed[0] = Convert.ToDouble(dt.Rows[5][5]);
                    Globalvariable.AP_Jog_Speed[1] = Convert.ToDouble(dt.Rows[6][5]);

                    
                    Globalvariable.AP_Homing_Speed[5] = Convert.ToDouble(dt.Rows[0][6]);
                    Globalvariable.AP_Homing_Speed[6] = Convert.ToDouble(dt.Rows[1][6]);
                    Globalvariable.AP_Homing_Speed[2] = Convert.ToDouble(dt.Rows[2][6]);
                    Globalvariable.AP_Homing_Speed[3] = Convert.ToDouble(dt.Rows[3][6]);
                    Globalvariable.AP_Homing_Speed[4] = Convert.ToDouble(dt.Rows[4][6]);
                    Globalvariable.AP_Homing_Speed[0] = Convert.ToDouble(dt.Rows[5][6]);
                    Globalvariable.AP_Homing_Speed[1] = Convert.ToDouble(dt.Rows[6][6]);

                    
                    Globalvariable.AP_Manual_Acc[5] = Convert.ToDouble(dt.Rows[0][7]);
                    Globalvariable.AP_Manual_Acc[6] = Convert.ToDouble(dt.Rows[1][7]);
                    Globalvariable.AP_Manual_Acc[2] = Convert.ToDouble(dt.Rows[2][7]);
                    Globalvariable.AP_Manual_Acc[3] = Convert.ToDouble(dt.Rows[3][7]);
                    Globalvariable.AP_Manual_Acc[4] = Convert.ToDouble(dt.Rows[4][7]);
                    Globalvariable.AP_Manual_Acc[0] = Convert.ToDouble(dt.Rows[5][7]);
                    Globalvariable.AP_Manual_Acc[1] = Convert.ToDouble(dt.Rows[6][7]);


                    Globalvariable.AP_Manual_Deacc[5] = Convert.ToDouble(dt.Rows[0][8]);
                    Globalvariable.AP_Manual_Deacc[6] = Convert.ToDouble(dt.Rows[1][8]);
                    Globalvariable.AP_Manual_Deacc[2] = Convert.ToDouble(dt.Rows[2][8]);
                    Globalvariable.AP_Manual_Deacc[3] = Convert.ToDouble(dt.Rows[3][8]);
                    Globalvariable.AP_Manual_Deacc[4] = Convert.ToDouble(dt.Rows[4][8]);
                    Globalvariable.AP_Manual_Deacc[0] = Convert.ToDouble(dt.Rows[5][8]);
                    Globalvariable.AP_Manual_Deacc[1] = Convert.ToDouble(dt.Rows[6][8]);


                    Globalvariable.AP_Homing_method[5] = Convert.ToDouble(dt.Rows[0][9]);
                    Globalvariable.AP_Homing_method[6] = Convert.ToDouble(dt.Rows[1][9]);
                    Globalvariable.AP_Homing_method[2] = Convert.ToDouble(dt.Rows[2][9]);
                    Globalvariable.AP_Homing_method[3] = Convert.ToDouble(dt.Rows[3][9]);
                    Globalvariable.AP_Homing_method[4] = Convert.ToDouble(dt.Rows[4][9]);
                    Globalvariable.AP_Homing_method[0] = Convert.ToDouble(dt.Rows[5][9]);
                    Globalvariable.AP_Homing_method[1] = Convert.ToDouble(dt.Rows[6][9]);


                    Globalvariable.AP_Homing_mode[5] = Convert.ToDouble(dt.Rows[0][10]);
                    Globalvariable.AP_Homing_mode[6] = Convert.ToDouble(dt.Rows[1][10]);
                    Globalvariable.AP_Homing_mode[2] = Convert.ToDouble(dt.Rows[2][10]);
                    Globalvariable.AP_Homing_mode[3] = Convert.ToDouble(dt.Rows[3][10]);
                    Globalvariable.AP_Homing_mode[4] = Convert.ToDouble(dt.Rows[4][10]);
                    Globalvariable.AP_Homing_mode[0] = Convert.ToDouble(dt.Rows[5][10]);
                    Globalvariable.AP_Homing_mode[1] = Convert.ToDouble(dt.Rows[6][10]);
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Axis_Parameter_Screen--Error in this function:DownloadData()" + ex);
                    return;
                }
            }
            else
            {
                MessageBox.Show("No data available to Assign.");
                return;
            }
        }
        private void SaveDataFromDataGridView()
        {
            //try
            //{
            //    string connectionString = SQLHelper.get_ConnName(); // Get the connection string

            //    using (SqlConnection connection = new SqlConnection(connectionString))
            //    {
            //        connection.Open();

            //        // Loop through the rows in the DataGridView
            //        foreach (DataGridViewRow row in Axis_datagridview.Rows)
            //        {
            //            if (row.IsNewRow) continue; // Skip the new (empty) row

            //            // Extract data from each column
            //            string axisId = row.Cells["Axis_ID"].Value.ToString(); // Adjust column name
            //            string axisName = row.Cells["Axis_Name"].Value.ToString();
            //            string pitch = row.Cells["Pitch"].Value.ToString();
            //            string pulse = row.Cells["Pulse_Per_mm"].Value.ToString();                        
            //            string manualSpeed = row.Cells["Manual_Speed"].Value.ToString();
            //            string jogSpeed = row.Cells["Jog_Speed"].Value.ToString();
            //            string homingSpeed = row.Cells["Homing_Speed"].Value.ToString();
            //            string M_acceleration = row.Cells["Manual_Acceleration"].Value.ToString();
            //            string M_deacceleration = row.Cells["Manual_Deacceleration"].Value.ToString();
            //            //string J_acceleration = row.Cells["Jog_Acceleration"].Value.ToString();
            //            //string J_deceleration = row.Cells["Jog_Deceleration"].Value.ToString();
            //            //string H_acceleration = row.Cells["Home_Acceleration"].Value.ToString();
            //            //string H_deceleration = row.Cells["Home_Deceleration"].Value.ToString();
            //            string homingMethod = row.Cells["Homing_Method"].Value.ToString();
            //            string homingMode = row.Cells["Homing_Mode"].Value.ToString();

            //            //string SqlQuery = "Update Axis_Parameter_Configuration set Axis_ID='" + row.Cells["Axis_ID"].Value.ToString() ;
            //            //int RES = SQLHelper.Executequery(SqlQuery);

            //            //connection.Open();
            //                // Build the update query
            //                string sqlQuery = @"
            //            UPDATE Axis_Parameter_Configuration
            //            SET Axis_Name = @Axis_Name, 
            //            Pitch = @Pitch, 
            //            Pulse_Per_mm = @Pulse_Per_mm, 
            //            Manual_Speed = @Manual_Speed, 
            //            Jog_Speed = @Jog_Speed, 
            //            Homing_Speed = @Homing_Speed, 
            //            Manual_Acceleration = @Manual_Acceleration, 
            //            Manual_Deacceleration = @Manual_Deacceleration, 
            //            Homing_Method = @Homing_Method, 
            //            Homing_Mode = @Homing_Mode
            //            WHERE Axis_ID = @Axis_ID";

            //            // Create and execute the SQL command
            //            using (SqlCommand command = new SqlCommand(sqlQuery, connection))
            //            {

            //                command.Parameters.AddWithValue("@Axis_ID", axisId);
            //                command.Parameters.AddWithValue("@Axis_Name", axisName);
            //                command.Parameters.AddWithValue("@Pitch", pitch);
            //                command.Parameters.AddWithValue("@Pulse_Per_mm", pulse);
            //                command.Parameters.AddWithValue("@Manual_Speed", manualSpeed);
            //                command.Parameters.AddWithValue("@Jog_Speed", jogSpeed);
            //                command.Parameters.AddWithValue("@Homing_Speed", homingSpeed);
            //                command.Parameters.AddWithValue("@Manual_Acceleration", M_acceleration);
            //                command.Parameters.AddWithValue("@Manual_Deacceleration", M_deacceleration);                           
            //                command.Parameters.AddWithValue("@Homing_Method", homingMethod);
            //                command.Parameters.AddWithValue("@Homing_Mode", homingMode);
            //                command.ExecuteNonQuery();


            //            }
            //        }
            //    }

            //    MessageBox.Show("Data saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show($"Error saving data to the database: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            try
            {

                // Assuming your DataGridView is set up to reflect the structure you provided
                //dataTable = (DataTable)XY_Gantry_dataGridView.DataSource;
                DataView dataView = (DataView)Axis_datagridview.DataSource;
                DataTable dataTable = dataView.Table;



                // Loop through the rows in the DataTable
                foreach (DataRow row in dataTable.Rows)
                {
                    // Extract the values from each column
                    //string position = row["Position"].ToString();
                    //string xGantry = row["X_Axis"].ToString();
                    //string yGantry = row["Y_Axis"].ToString();
                    //string xAcceleration = row["X_Acceleration"].ToString();
                    //string yAcceleration = row["Y_Acceleration"].ToString();
                    //string xDeacceleration = row["X_Deacceleration"].ToString();
                    //string yDeacceleration = row["Y_Deacceleration"].ToString();
                    //string xspeed = row["X_Speed"].ToString();
                    //string yspeed = row["Y_Speed"].ToString();
                    //string xoffset = row["X_Axis_Offset"].ToString();
                    //string yoffset = row["Y_Axis_Offset"].ToString();
                    string axisId = row["Axis_ID"].ToString(); // Adjust column name
                    string axisName = row["Axis_Name"].ToString();
                    string pitch = row["Pitch"].ToString();
                    string pulse = row["Pulse_Per_mm"].ToString();
                    string manualSpeed = row["Manual_Speed"].ToString();
                    string jogSpeed = row["Jog_Speed"].ToString();
                    string homingSpeed = row["Homing_Speed"].ToString();
                    string M_acceleration = row["Manual_Acceleration_Time_sec"].ToString();
                    string M_deacceleration = row["Manual_Deacceleration_Time_sec"].ToString();
                    //string J_acceleration = row.Cells["Jog_Acceleration"].Value.ToString();
                    //string J_deceleration = row.Cells["Jog_Deceleration"].Value.ToString();
                    //string H_acceleration = row.Cells["Home_Acceleration"].Value.ToString();
                    //string H_deceleration = row.Cells["Home_Deceleration"].Value.ToString();
                    string homingMethod = row["Homing_Method"].ToString();
                    string homingMode = row["Homing_Mode"].ToString();
                    // Update the database using a SQL command
                    using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
                    {
                        connection.Open();
                        //string query = "UPDATE Battery_Pick_Gantry SET " +
                        //               "X_Axis = @X_Axis, " +
                        //               "Y_Axis = @Y_Axis, " +
                        //               "X_Acceleration = @X_Acceleration, " +
                        //               "Y_Acceleration = @Y_Acceleration, " +
                        //               "X_Deacceleration = @X_Deacceleration, " +
                        //               "Y_Deacceleration = @Y_Deacceleration, " +
                        //               "X_Speed = @X_Speed," +
                        //               "Y_Speed = @Y_Speed," +
                        //               "X_Axis_Offset = @X_Axis_Offset," +
                        //               "Y_Axis_Offset = @Y_Axis_Offset " +
                        //               "WHERE Position = @Position"; // Ensure Position is unique or modify as needed


         string query = "UPDATE Axis_Parameter_Configuration SET "+ 
                        "Axis_Name = @Axis_Name,"+
                        "Pitch = @Pitch,"+
                        "Pulse_Per_mm = @Pulse_Per_mm," +
                        "Manual_Speed = @Manual_Speed, " +
                        "Jog_Speed = @Jog_Speed, " +
                       " Homing_Speed = @Homing_Speed," +
                       " Manual_Acceleration_Time_sec = @Manual_Acceleration_Time_sec," +
                       " Manual_Deacceleration_Time_sec = @Manual_Deacceleration_Time_sec, " +
                       " Homing_Method = @Homing_Method, " +
                       " Homing_Mode = @Homing_Mode" +
                       " WHERE Axis_ID = @Axis_ID";


                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Axis_ID", axisId);
                            command.Parameters.AddWithValue("@Axis_Name", axisName);
                            command.Parameters.AddWithValue("@Pitch", pitch);
                            command.Parameters.AddWithValue("@Pulse_Per_mm", pulse);
                            command.Parameters.AddWithValue("@Manual_Speed", manualSpeed);
                            command.Parameters.AddWithValue("@Jog_Speed", jogSpeed);
                            command.Parameters.AddWithValue("@Homing_Speed", homingSpeed);
                            command.Parameters.AddWithValue("@Manual_Acceleration_Time_sec", M_acceleration);
                            command.Parameters.AddWithValue("@Manual_Deacceleration_Time_sec", M_deacceleration);
                            command.Parameters.AddWithValue("@Homing_Method", homingMethod);
                            command.Parameters.AddWithValue("@Homing_Mode", homingMode);
                            command.ExecuteNonQuery();
                            //command.Parameters.AddWithValue("@X_Axis", xGantry);
                            //command.Parameters.AddWithValue("@Y_Axis", yGantry);
                            //command.Parameters.AddWithValue("@X_Acceleration", xAcceleration);
                            //command.Parameters.AddWithValue("@Y_Acceleration", yAcceleration);
                            //command.Parameters.AddWithValue("@X_Deacceleration", xDeacceleration);
                            //command.Parameters.AddWithValue("@Y_Deacceleration", yDeacceleration);
                            //command.Parameters.AddWithValue("@X_Speed", xspeed);
                            //command.Parameters.AddWithValue("@Y_Speed", yspeed);
                            //command.Parameters.AddWithValue("@X_Axis_Offset", xoffset);
                            //command.Parameters.AddWithValue("@Y_Axis_Offset", yoffset);
                            //command.Parameters.AddWithValue("@Position", position);

                            //command.ExecuteNonQuery();
                        }
                    }
                }

                // Refresh the DataGrid after saving
                
                MessageBox.Show("Axis Parameter Setting Saved Successfully !");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Axis Parameter Setting--Error in this function:Save()" + ex);
                return;
            }
        }


        public bool timer_lock_2 = false;
        private void AI_TIMER_Tick(object sender, EventArgs e)
        {
            if (!timer_lock_2)
            {
                timer_lock_2 = true;
                try
                {
                    lbl_update_Tab0();
                    lbl_update_Tab1();
                    lbl_update_Tab2();
                    lbl_update_Tab3();
                    lbl_update_Tab4();
                }
                catch (Exception ex)
                {
                    timer_lock_2 = false;
                    MessageBox.Show("IO Diagnosis:Error-" + ex);

                }

            }
            timer_lock_2 = false;
        }
        private void tabPage4_Click(object sender, EventArgs e)
        {

        }
        private void lbl_update_Tab0()//It updates the status of round label after reading the data from the PLC in Tabpage0 [Input]
        {
            for (int i = 0; i < tabPage1.Controls.Count; i++)
            {
                if (tabPage1.Controls[i] is Label)
                {
                    Label dynamicLabel = (Label)tabPage1.Controls[i];  //Changed from tabpage0 to tabpage17   17-12-2024
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Lime;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }


        }
        private void lbl_update_Tab1()//It updates the status of round label after reading the data from the PLC in Tabpage1 [Input]
        {
            for (int i = 0; i < tabPage2.Controls.Count; i++)
            {
                if (tabPage2.Controls[i] is Label)
                {
                    Label dynamicLabel = (Label)tabPage2.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Lime;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }


        }
        private void lbl_update_Tab2()//It updates the status of round label after reading the data from the PLC in Tabpage2 [Input]
        {
            for (int i = 0; i < tabPage17.Controls.Count; i++)
            {
                if (tabPage17.Controls[i] is Label)
                {
                    Label dynamicLabel = (Label)tabPage17.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Lime;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }


        }
        private void lbl_update_Tab3()//It updates the status of round label after reading the data from the PLC in Tabpage3 [Output]
        {
            for (int i = 0; i < tabPage3.Controls.Count; i++)
            {
                if (tabPage3.Controls[i] is Label)
                {
                    Label dynamicLabel = (Label)tabPage3.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Lime;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }


        }
        private void lbl_update_Tab4()//It updates the status of round label after reading the data from the PLC in Tabpage4 [Output]
        {
            for (int i = 0; i < tabPage4.Controls.Count; i++)
            {
                if (tabPage4.Controls[i] is Label)
                {
                        Label dynamicLabel = (Label)tabPage4.Controls[i];
                    if (!dynamicLabel.Name.ToUpper().Contains("L"))
                    {
                        int dynamicname = Int32.Parse(dynamicLabel.Name);
                        if (PLC.DIO_Read[dynamicname] == 1)
                        {
                            dynamicLabel.BackColor = Color.Lime;
                            dynamicLabel.ForeColor = Color.Black;
                            dynamicLabel.Text = "ON";
                        }
                        else
                        {
                            dynamicLabel.BackColor = Color.Red;
                            dynamicLabel.ForeColor = Color.White;
                            dynamicLabel.Text = "OFF";
                        }
                    }


                }
            }
        }

        //calibration
        private void btnCamera_Start_Click(object sender, EventArgs e)
        {
            ////listboxCamera.Items.Clear();
            ////VisionCalibration.CalibrationStep = 1;


            var Vision1 = new TCPIPClient.TCPIPClient("Vision1");
            //IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
            //string text = hostEntry.AddressList[hostEntry.AddressList.Length - 1].ToString();
            //string[] array = text.Split('.');
            //var Text = array[0] + "." + array[1] + "." + array[2] + "." + array[3];

            //if (File.Exists("D:\\TEAL\\NOVA\\DLL\\ConnectionDetails.xml"))
            //{
            //    var c = "strig";
            //}
            // SocketClient.Connect_Vision();





            bool CCD1 = chkCCD1.Checked;
          
            if (CCD1)
            {
                //VisionCalibration.start_thread_CCD1();
            }
            else
            {
                MessageBox.Show("Please Choose camera");
                return;
            }
            btnCamera_Start.Enabled = false;
            btnCamera_Stop.Enabled = true;
            timer1.Enabled = true;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            // VisionCalibration.Start_Calibration_sequence();
            //Vision.Recieve_VisionData();
            // VisionCalibration.TTN_Nozzle_calibration();
            //if (CamData !=Vision.V_ReceiveData2)
            //  {
            //      CamData = Vision.V_ReceiveData2;
            //      //listboxCamera.Items.Add("CAM-"+CamData);
            //  }
            //  if (CamData_PC != Vision.send_data)
            //  {
            //      CamData_PC = Vision.send_data;
            //      //listboxCamera.Items.Add("PC-" + CamData_PC);
            //  }
        }
        private void btnCamera_Stop_Click(object sender, EventArgs e)
        {
            bool CCD1 = chkCCD1.Checked;
       

            if (CCD1)
            {
                //VisionCalibration.stop_thread_CCD1();
            }
            else
            {
                MessageBox.Show("Please Choose camera");
                return;
            }
            timer1.Enabled = false;
            //Interface.Kill_All_Motions();
            // VisionCalibration.Load_all_values();

            btnCamera_Start.Enabled = true;
            btnCamera_Stop.Enabled = false;
        }

        public void UpdateRichTextBox1(string step)
        {

            // Check if there are more than 5 lines, then remove the first line
            if (richTextBox_Calib.Lines.Length >= 20)
            {
                // Remove the first line
                var lines = richTextBox_Calib.Lines.Skip(1).ToArray();
                richTextBox_Calib.Lines = lines;
            }

            // Add the current step to the RichTextBox
            // richTextBox1.Text = step.ToString();
            richTextBox_Calib.Text += step.ToString() + "\n";
            // richTextBox1.AppendText(step.ToString()+"\n");
            var v = richTextBox_Calib.Lines.Length;

            //// Select the current step line to highlight it
            int start = richTextBox_Calib.GetFirstCharIndexFromLine(richTextBox_Calib.Lines.Length - 1);
            int length = richTextBox_Calib.Lines.Last().Length;
            richTextBox_Calib.Select(start, length);

            //// Apply highlight color to current step
            richTextBox_Calib.SelectionBackColor = Color.Red;

            // Scroll to the current step
            richTextBox_Calib.ScrollToCaret();
        }

        private void chkCCD1_CheckedChanged_1(object sender, EventArgs e)
        {
            if (chkCCD1.Checked)
            {
                //grpBoxCCD1.Enabled = true;
                //grpBoxCCD2.Enabled = false;
               // Static_and_Dynamic_test.Cam1_Active_Dy = true;
                //Static_and_Dynamic_test.Cam2_Active_Dy = false;
                //Static_and_Dynamic_test.Cam1_Active_Dyf = true;
                //Static_and_Dynamic_test.Cam2_Active_Dyf = false;
               // Static_and_Dynamic_test.Cam1_Active = true;
               // Static_and_Dynamic_test.Cam2_Active = false;
              

            }

        }
        private void grpboxCamera_Enter(object sender, EventArgs e)
        {

        }
        private void tabPage1_Click_1(object sender, EventArgs e)
        {

        }


        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage7_Click(object sender, EventArgs e)
        {

        }

        private void LabelCCD1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // The path you want to open in File Explorer

            string path = @"D:\TEAL\NOVA\DLL\";
            // Check if the path exists before attempting to open it
            if (Directory.Exists(path))
            {
                // Open File Explorer with the specified directory
                Process.Start("explorer.exe", path);
            }
            else
            {
                MessageBox.Show("The specified path does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

   
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        //Sop
        private void button11_Click(object sender, EventArgs e)
        {
            if ((CCD1Speed.Text == "" && CCD1count.Text == "" && Cam1_path.Text == "") && ((textBox36.Text == "" && textBox34.Text == "" && textBox35.Text == "" && textBox33.Text == "") || (textBox29.Text == "" && textBox28.Text == "")))
            {
                MessageBox.Show("please Select All field");
                return;
            }
            if (CCD1Speed.Text=="" && CCD1count.Text=="" && textBox36.Text=="")
            {
                MessageBox.Show("please select all fields");
                return;
            }
            //Static_and_Dynamic_test.Trig_cam = 0;
            //Static_and_Dynamic_test.Trig_cam_Dy = 0;
            //Static_and_Dynamic_test.Gantry_vel = double.Parse(CCD1Speed.Text);
            machine_settings.Repeatcnt = int.Parse(CCD1count.Text);
            //  DIOConfig.WriteOPS(false, DIOConfig.O_Camera_Trig);

            

            if (cmbTestMode.Text == "Dynamic")
            {

                Dyanamic_timer.Enabled = true;
                Static_timer.Enabled = false;
                //Array.Clear(Static_and_Dynamic_test.Csv_Values_Dy, 0, Static_and_Dynamic_test.Csv_Values_Dy.Length - 1);
                //Static_and_Dynamic_test.DynamicStep = 1;
                //Static_and_Dynamic_test.Staticstep = 0;
            }
            else if (cmbTestMode.Text == "Static")
            {
                //Static_and_Dynamic_test.Staticstep = 1;
                //Static_and_Dynamic_test.DynamicStep = 0;
                Dyanamic_timer.Enabled = false;
                Static_timer.Enabled = true;
            }
        }
        private void button12_Click(object sender, EventArgs e)
        {
            Dyanamic_timer.Enabled = false;
            Static_timer.Enabled = false;
        }
        private void button10_Click(object sender, EventArgs e)
        {

            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                Cam1_path.Text = folderBrowserDialog.SelectedPath;
               // Static_and_Dynamic_test.Cam1_path = folderBrowserDialog.SelectedPath;


            }

        }

        private void Dyanamic_timer_Tick(object sender, EventArgs e)
        {
            if (cmbTestMode.Text == "Dynamic")
            {
                //Static_and_Dynamic_test.Dynamic_gantry_test();
                //lblRunningCount.Text = Static_and_Dynamic_test.Trig_cam_Dy.ToString();
                //lblactualpos_ccd1_x.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, XY_Gantry.Gantry_X_axis)).ToString() + "mm";

                string currstate = string.Empty;
                double Act_Vel = 0.0;
                double Act_pos = 0.0;
                LeadShineInterface.ToGetCurrentPos(1, out Act_pos, out currstate, out Act_Vel);
              //  lblactualpos_ccd1_y.Text = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, XY_Gantry.Gantry_Y_axis).ToString() + "mm";


            }
            //if (CCD5TestMode.Text == "Dynamic")
            //{
            //    Static_and_Dynamic_test.Dynamic_gantry_test_CCD5();
            //    lblRunningCount.Text = Static_and_Dynamic_test.Trig_cam_Dy.ToString();
            //    // lblactualpos_ccd5_x.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.FI_X_axis)).ToString() + "mm";

            //    string currstate = string.Empty;
            //    double Act_Vel = 0.0;
            //    double Act_pos = 0.0;
            //    LeadShineInterface.ToGetCurrentPos(1, out Act_pos, out currstate, out Act_Vel);
            //    //  lblactualpos_ccd5_y.Text = LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.FI_Y_axis).ToString() + "mm";


            //}



        }

        private void Static_timer_Tick(object sender, EventArgs e)
        {
           // Static_and_Dynamic_test.Static_gantry_test();
            // lblRunningCount.Text = Static_and_Dynamic_test.Trig_cam.ToString();
            //lblccd2runningcount.Text = Static_and_Dynamic_test.Trig_cam.ToString();
            //double[] process = Gantry.TogetCurrentPos();
            // lblactualpos_ccd1_x.Text = process[0].ToString() + " mm";
            // lblactualposition_ccd2x.Text = process[0].ToString() + " mm";
            string currstate = string.Empty;
            double Act_Vel = 0.0;
            double Act_pos = 0.0;
            // Interface.ToGetCurrentPos(1, out Act_pos, out currstate, out Act_Vel);
            //lblactualpos_ccd1_y.Text = process[1].ToString() + " mm";
            // lblactualpostion_ccd2y.Text = process[1].ToString() + " mm";
        }

       #endregion
       
        private void io_diagnostics_MouseMove(object sender, MouseEventArgs e)
        {

        }
      
        private void dryrun_CheckedChanged(object sender, EventArgs e)
        {
            if (dryrun.Checked)
           {
                productionmode.Enabled = false;
                onlinemode.Checked = false;
                onlinemode.Enabled = false;
                offlinemode.Checked = false;
                offlinemode.Enabled = false;
            }
            else
            {
                productionmode.Enabled = true;
                convruwithtray.Checked = false;
                convdryrun.Checked = false;
                onlinemode.Enabled = true;
                offlinemode.Enabled = true;
            }
        }

        private void productionmode_CheckedChanged(object sender, EventArgs e)
        {
            if (productionmode.Checked)
            {
                dryrun.Enabled = false;
                convruwithtray.Checked = false;
                convruwithtray.Enabled = false;
                convdryrun.Checked = false;
                convdryrun.Enabled = false;
            }
            else
            {
                dryrun.Enabled = true;
                onlinemode.Checked = false;
                offlinemode.Checked = false;
                convruwithtray.Enabled = true;
                convdryrun.Enabled = true;
            }
        }

        private void onlinemode_CheckedChanged(object sender, EventArgs e)
        {
            if (productionmode.Checked && !offlinemode.Checked)
                onlinemode.Checked = true;
            else
            {
                if (offlinemode.Checked)
                    offlinemode.Checked = false;
                else
                {
                    onlinemode.Checked = false;
                    MessageBox.Show("Please select productionmode");
                }
            }
        }

        private void offlinemode_CheckedChanged(object sender, EventArgs e)
        {
            if (productionmode.Checked && !onlinemode.Checked)
                offlinemode.Checked = true;
            else
            {
                if (onlinemode.Checked)
                    onlinemode.Checked = false;
                else
                {
                    offlinemode.Checked = false;
                    MessageBox.Show("Please select productionmode");
                }
            }
        }

        private void convruwithtray_CheckedChanged(object sender, EventArgs e)
        {
            if (dryrun.Checked && !convdryrun.Checked)
            { 
                convruwithtray.Checked = true;
            }
            else
            {
                if (convdryrun.Checked)
                    convdryrun.Checked = false;
                else
                {
                    convruwithtray.Checked = false;
                    MessageBox.Show("Please select dryrun");
                }
            }
        }

        private void convdryrun_CheckedChanged(object sender, EventArgs e)
        {
            if (dryrun.Checked && !convruwithtray.Checked)
            {
                convdryrun.Checked = true;
            }
            else
            {
                if (convruwithtray.Checked)
                    convruwithtray.Checked = false;
                else
                {
                    convdryrun.Checked = false;
                    MessageBox.Show("Please select dryrun");
                }
            }
        }


    }

}
