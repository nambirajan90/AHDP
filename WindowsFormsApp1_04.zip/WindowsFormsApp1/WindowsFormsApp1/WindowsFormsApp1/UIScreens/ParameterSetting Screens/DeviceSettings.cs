﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP
{
    public partial class DeviceSettings : Form
    {
        //  INIFile devices_iNI = new INIFile(Application.StartupPath + "\\device_Config.ini");

        public DeviceSettings()
        {
            InitializeComponent();
        }
        //private void ReadRetentiveFromIni()
        //{
        //    try
        //    {
        //        Globalvariable.Gantry_X_Axis =Convert.ToUInt16(devices_iNI.Read("Gantry","Gantry_X_axis_Number"));
        //       // txt_id_X.Text =  devices_iNI.Read("Gantry", "Gantry_X_axis_Number");
        //        Globalvariable.Gantry_Y_Axis = Convert.ToUInt16(devices_iNI.Read("Gantry","Gantry_Y_axis_Number"));
        //        //txt_id_Y.Text = devices_iNI.Read("Gantry", "Gantry_Y_axis_Number");
        //        Globalvariable.Gantry_X_axis_PPR = int.Parse(devices_iNI.Read("Gantry", "Gantry_X_axis_PPR"));
        //       // txt_id_Z.Text = devices_iNI.Read("Gantry", "Gantry_X_axis_Number");
        //        Globalvariable.Gantry_Y_AXIS_PPR = int.Parse(devices_iNI.Read("Gantry", "Gantry_Y_axis_PPR"));
        //        Globalvariable.Gantry_X_Axis_Pitch = int.Parse(devices_iNI.Read("Gantry", "Gantry_X_axis_Pitch"));
        //        Globalvariable.Gantry_Y_Axis_Pitch = int.Parse(devices_iNI.Read("Gantry", "Gantry_Y_axis_Pitch"));
        //        Globalvariable.FI_X_axis = Convert.ToUInt16(devices_iNI.Read("FI", "FI_X_axis_Number"));
        //        Globalvariable.FI_Y_axis = Convert.ToUInt16(devices_iNI.Read("FI", "FI_Y_axis_Number"));
        //        Globalvariable.FI_X_axis_PPR = int.Parse(devices_iNI.Read("FI", "FI_X_axis_PPR"));
        //        Globalvariable.FI_Y_axis_PPR = int.Parse(devices_iNI.Read("FI", "FI_Y_axis_PPR"));
        //        Globalvariable.FI_X_axis_pitch = int.Parse(devices_iNI.Read("FI", "FI_X_axis_Pitch"));
        //        Globalvariable.FI_Y_axis_pitch = int.Parse(devices_iNI.Read("FI", "FI_Y_axis_Pitch"));
        //        Globalvariable.Roller_X_Axis = Convert.ToUInt16(devices_iNI.Read("Roller", "Roller_X_axis_Number"));
        //        Globalvariable.Roller_Y_Axis = Convert.ToUInt16(devices_iNI.Read("Roller", "Roller_Y_axis_Number"));
        //        Globalvariable.Roller_Z_Axis = Convert.ToUInt16(devices_iNI.Read("Roller", "Roller_Z_axis_Number"));
        //        Globalvariable.Roller_X_axis_PPR = int.Parse(devices_iNI.Read("Roller", "Roller_X_axis_PPR"));
        //        Globalvariable.Roller_Y_axis_PPR = int.Parse(devices_iNI.Read("Roller", "Roller_Y_axis_PPR"));
        //        Globalvariable.Roller_Z_axis_PPR = int.Parse(devices_iNI.Read("Roller", "Roller_Z_axis_PPR"));
        //        Globalvariable.Roller_X_axis_pitch = int.Parse(devices_iNI.Read("Roller", "Roller_X_axis_Pitch"));
        //        Globalvariable.Roller_Y_axis_pitch = int.Parse(devices_iNI.Read("Roller", "Roller_Y_axis_Pitch"));
        //        Globalvariable.Roller_Y_axis_pitch = int.Parse(devices_iNI.Read("Roller", "Roller_Y_axis_Pitch"));


        //    }
        //    catch (Exception ex)
        //    {

        //       // Logger.WriteLog1("General", "LoadTags", "Error", ex.ToString());
        //    }
        //}
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
 (
     int nLeftRect,
     int nTopRect,
     int nRightRect,
     int nBottomRect,
     int nWidthEllipse,
     int nHeightEllipse
 );

        public void Panel_Shape()
        {
            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width,
            panel1.Height, 30, 30));
            panel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel2.Width,
         panel2.Height, 30, 30));
            panel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel3.Width,
         panel3.Height, 30, 30));
            //  panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
            //panel4.Height, 30, 30));
            //  panel5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel5.Width,
            //panel5.Height, 30, 30));
        }

        private void DeviceSettings_Load(object sender, EventArgs e)
        {
            //radioButton1.Enabled = false;
            //radioButton2.Enabled = false;
            //radioButton3.Enabled = false;
            //radioButton4.Enabled = false;
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            checkBox3.Enabled = false;
            checkBox4.Enabled = false;
            //Gantry
            txt_id_X.Text = Globalvariable.Gantry_X_Axis.ToString();
            txt_id_Y.Text = Globalvariable.Gantry_Y_Axis.ToString();
            txt_pitch_X.Text = Globalvariable.Gantry_X_Axis_Pitch.ToString();
            txt_pitch_Y.Text = Globalvariable.Gantry_Y_Axis_Pitch.ToString();
            txt_ppr_X.Text = Globalvariable.Gantry_X_axis_PPR.ToString();
            txt_ppr_Y.Text = Globalvariable.Gantry_Y_AXIS_PPR.ToString();

            //Roller
            R_txt_id_X.Text = Globalvariable.Roller_X_Axis.ToString();
            R_txt_id_Y.Text = Globalvariable.Roller_Y_Axis.ToString();
            R_txt_id_Z.Text = Globalvariable.Roller_Z_Axis.ToString();
            R_txt_PI_X.Text = Globalvariable.Roller_X_axis_pitch.ToString();
            R_txt_PI_Y.Text = Globalvariable.Roller_Y_axis_pitch.ToString();
            R_txt_PI_Z.Text = Globalvariable.Roller_Z_axis_pitch.ToString();
            R_txt_PR_X.Text = Globalvariable.Roller_X_axis_PPR.ToString();
            R_txt_PR_Y.Text = Globalvariable.Roller_Y_axis_PPR.ToString();
            R_txt_PR_Z.Text = Globalvariable.Roller_Z_axis_PPR.ToString();

            //FI
            FI_txt_id_X.Text = Globalvariable.FI_X_axis.ToString();
            FI_txt_id_Y.Text = Globalvariable.FI_Y_axis.ToString();
            FI_txt_PI_X.Text = Globalvariable.FI_X_axis_pitch.ToString();
            FI_txt_PI_Y.Text = Globalvariable.FI_Y_axis_pitch.ToString();
            FI_txt_PPR_X.Text = Globalvariable.FI_X_axis_PPR.ToString();
            FI_txt_PPR_Y.Text = Globalvariable.FI_X_axis_PPR.ToString();

            //DeviceIP
            LabelCCD1.Text = Globalvariable.D_CCD1.ToString();
            LabelCCD3.Text = Globalvariable.D_CCD3.ToString();
            LabelCCD4.Text = Globalvariable.D_CCD4.ToString();
            LabelCCD5.Text = Globalvariable.D_CCD5.ToString();
            lblScannerIP.Text = Globalvariable.D_Scanner.ToString();
            lblSFCIP.Text = Globalvariable.D_SFC.ToString();
            lblPDCAIP.Text = Globalvariable.D_PDCA.ToString();
            lblRoboIP.Text = Globalvariable.D_RObot.ToString();



        }

        private void rdnPosMode_Properties_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnGantry_Click(object sender, EventArgs e)
        {
            Globalvariable.devices_iNI.Write("Gantry", "Gantry_X_axis_Number", txt_id_X.Text);
            Globalvariable.devices_iNI.Write("Gantry", "Gantry_Y_Axis", txt_id_Y.Text);
            Globalvariable.devices_iNI.Write("Gantry", "Gantry_X_axis_PPR", txt_pitch_X.Text);
            Globalvariable.devices_iNI.Write("Gantry", "Gantry_Y_AXIS_PPR", txt_pitch_Y.Text);
            Globalvariable.devices_iNI.Write("Gantry", "Gantry_X_Axis_Pitch", txt_ppr_X.Text);
            Globalvariable.devices_iNI.Write("Gantry", "Gantry_Y_axis_Pitch", txt_ppr_Y.Text);
            Globalvariable.ReadRetentiveFromIni();
        }

        private void Update(String value, string[] value2)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Globalvariable.devices_iNI.Write("Roller", "Roller_X_axis_Number", R_txt_id_X.Text);
            Globalvariable.devices_iNI.Write("Roller", "Roller_Y_axis_Number", R_txt_id_Y.Text);
            Globalvariable.devices_iNI.Write("Roller", "Roller_Z_axis_Number", R_txt_id_Z.Text);
            Globalvariable.devices_iNI.Write("Roller", "Roller_X_axis_PPR", R_txt_PI_X.Text);
            Globalvariable.devices_iNI.Write("Roller", "Roller_Y_axis_PPR", R_txt_PI_Y.Text);
            Globalvariable.devices_iNI.Write("Roller", "Roller_Z_axis_PPR", R_txt_PI_Z.Text);
            Globalvariable.devices_iNI.Write("Roller", "Roller_X_axis_Pitch", R_txt_PR_X.Text);
            Globalvariable.devices_iNI.Write("Roller", "Roller_Y_axis_Pitch", R_txt_PR_Y.Text);
            Globalvariable.devices_iNI.Write("Roller", "Roller_Y_axis_Pitch", R_txt_PR_Z.Text);
            Globalvariable.ReadRetentiveFromIni();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dryrun.Enabled = true;
            productionmode.Enabled = true;
            onlinemode.Enabled = true;
            offlinemode.Enabled = true;
            checkBox1.Enabled = true;
            checkBox2.Enabled = true;
            checkBox3.Enabled = true;
            checkBox4.Enabled = true;
        }


        private void txt_id_Y_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Globalvariable.devices_iNI.Write("FI", "FI_X_axis_Number", FI_txt_id_X.Text);
            Globalvariable.devices_iNI.Write("FI", "FI_Y_axis_Number", FI_txt_id_Y.Text);
            Globalvariable.devices_iNI.Write("FI", "FI_X_axis_PPR", FI_txt_PI_X.Text);
            Globalvariable.devices_iNI.Write("FI", "FI_Y_axis_PPR", FI_txt_PI_Y.Text);
            Globalvariable.devices_iNI.Write("FI", "FI_X_axis_Pitch", FI_txt_PPR_X.Text);
            Globalvariable.devices_iNI.Write("FI", "FI_Y_axis_Pitch", FI_txt_PPR_Y.Text);
            Globalvariable.ReadRetentiveFromIni();
        }

        private void R_txt_PR_X_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            dryrun.Enabled = false;
            productionmode.Enabled = false;
            onlinemode.Enabled = false;
            offlinemode.Enabled = false;
            checkBox1.Enabled = false;
            checkBox2.Enabled = false;
            checkBox3.Enabled = false;
            checkBox4.Enabled = false;
            //if (chk_Scannerbypass.Checked == true)
            //{
            //    Globalvariable.Scanner_Bypass = true;
            //}
            //if (Chk_Safety_Door.Checked == true)
            //{
            //    Globalvariable.Safety_Door_Bypass = true;
            //}
            //if (chk_SFC_Bypass.Checked == true)
            //{
            //    Globalvariable.SFC_Bypass = true;
            //}
            //if (chk_PDCA_Bypass.Checked == true)
            //{
            //    Globalvariable.PDCA_Bypass = true;
            //}

            //for 1st Radio boxes
            bool Dryrun = dryrun.Checked;
            if (Dryrun)
            {
                Globalvariable.Dry_run = true;
                Globalvariable.Production_mode = false;
            }
            else
            {
                Globalvariable.Dry_run = false;
                Globalvariable.Production_mode = true;
            }

            //for 2st Radio boxes
            bool Online_Mode = onlinemode.Checked;
            if (Online_Mode)
            {
                Globalvariable.Online_mode = true;
                Globalvariable.Offline_mode = false;
            }
           else
            {
                Globalvariable.Online_mode = false;
                Globalvariable.Offline_mode = true;
            }
        }



        //private void radioGroup3_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //}

        private void chk_Scannerbypass_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Globalvariable.Scanner_Bypass = true;
            }
            else
            {
                Globalvariable.Scanner_Bypass = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                Globalvariable.Safety_Door_Bypass = true;
            }
            else
            {
                Globalvariable.Safety_Door_Bypass = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                Globalvariable.SFC_Bypass = true;
            }
            else
            {
                Globalvariable.SFC_Bypass = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                Globalvariable.PDCA_Bypass = true;
            }
            else
            {
                Globalvariable.PDCA_Bypass = false;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // The path you want to open in File Explorer

            string path = @"D:\TEAL\NOVA\DLL\";
            // Check if the path exists before attempting to open it
            if (Directory.Exists(path))
            {
                // Open File Explorer with the specified directory
                Process.Start("explorer.exe", path);
            }
            else
            {
                MessageBox.Show("The specified path does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LabelCCD1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        //private void radioButton1_CheckedChanged(object sender, EventArgs e)
        //{

        //}

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void labelControl5_Click(object sender, EventArgs e)
        {

        }

        private void labelControl6_Click(object sender, EventArgs e)
        {

        }
    }
}
