﻿using AHDP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using MessageBox = System.Windows.Forms.MessageBox;


namespace AHDP.UIScreens.ParameterSetting_Screens
{
    public partial class Receipe : Form
    {
        public Receipe()
        {
            try
            {
                if (GlobalVar.User_Mode == "Production")
                {
                    InitializeComponent();
                    //sbNew.Enabled = false;
                    btnEdit.Enabled = false;
                    btnSave.Enabled = false;
                    // btnDelete.Enabled = false;
                    //btnImport.Enabled = false;
                    btnExport.Enabled = false;
                    // btnSaveAs.Enabled = false;
                    comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
                }
                else
                {
                    InitializeComponent();
                }
                this.Load += new EventHandler(Receipe_Load);
                cmbModelName.SelectedIndexChanged += new EventHandler(cmbModelName_SelectedIndexChanged_1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Recipe Screen--Error in this function:Receipe()" + ex);
                return;
            }
        }
        private void Receipe_Load(object sender, EventArgs e)
        {
            XY_Gantry_dataGridView.Enabled = false;
          
            LoadComboBoxData();
            //string connectionString = SQLHelper.get_ConnName(); ;
            DataSet DS = null;
            string SqlQueryScan = "select * from Battery_Pick_Gantry";
            DS = SQLHelper.GetData(SqlQueryScan);
            XY_Gantry_dataGridView.DataSource = DS.Tables[0].DefaultView;

            DataSet DX = null;
            string SqlQueryScan1 = "select * from Roller_Gantry";
            DX = SQLHelper.GetData(SqlQueryScan1);
        
            DataSet DV = null;
            string SqlQueryScan2 = "select * from FI_Gantry";
            DV = SQLHelper.GetData(SqlQueryScan2);
        
            XY_Gantry_dataGridView.Columns["Position"].Frozen = true;
          
        }

        private async void cmbModelName_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            try
            {
                if (cmbModelName.SelectedItem != null)
                {
                    string selectedModel = "AHDP Parameter";
                    await LoadDataInGrid();
                    await LoadDataInRoller();
                    await LoadDataInFI();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Recipe Screen--Error in this function:cmbModelName_SelectedIndexChanged()" + ex);
                return;
            }
        }
        private async void LoadComboBoxData()
        {
            //string connectionString = "Server=TCLHSRPEDLT0737;Database=AAA;User Id=sa;Password=Titan@123;";
            string connectionString = SQLHelper.get_ConnName();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_Recipe_Selecion", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    try
                    {
                        await conn.OpenAsync();
                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            // Clear existing items
                            cmbModelName.Items.Clear();

                            // Check if there are any rows
                            if (!reader.HasRows)
                            {
                                MessageBox.Show("No Model as been set in the Database");
                                return;
                            }

                            // Populate ComboBox
                            while (await reader.ReadAsync())
                            {
                                cmbModelName.Items.Add(reader["Modelname"].ToString());
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Recipe Screen--Error in this function:LoadComboBoxData()" + ex);
                        return;
                    }
                }
            }
        }
        public async Task<object> LoadDataInGrid()
        {
            //string connectionString = "Server=TCLHSRPEDLT0737;Database=AAA;User Id=sa;Password=Titan@123;";
            string connectionString = SQLHelper.get_ConnName();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_Recipe_Details", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    //cmd.Parameters.AddWithValue("@ModelName", modelName);

                    try
                    {
                        await conn.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            // Check if there are any rows to display
                            if (dt.Rows.Count > 1) // Ensure there's at least 2 rows
                            {
                                XY_Gantry_dataGridView.DataSource = dt;
                                XY_Gantry_dataGridView.AutoGenerateColumns = true;

                                // Return the value from the first column of the second row
                                return dt;
                            }
                            else
                            {
                                MessageBox.Show("No data available for the selected Model.");
                                XY_Gantry_dataGridView.DataSource = null;
                                return null; // or handle accordingly
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Recipe Screen--Error in this function:LoadComboBoxData()" + ex);
                        return null;
                    }
                }
            }
        }
        private void tabPage_pick_Click(object sender, EventArgs e)
        {

        }
        private void label74_Click(object sender, EventArgs e)
        {

        }

        private void btnDownload_Click(object sender, EventArgs e)
        {
            if (tabControl.SelectedTab == tabPage_Gantry)
            {

            }
      
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Do you want to enable editing recipe ?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                XY_Gantry_dataGridView.Enabled = true;
             
            }
           
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Do you want to save and download the recipe ?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                if (tabControl.SelectedIndex == 0)
                {
                    XY_Gantry_Save();
                    XY_Gantry_DownloadData();
                }
                if (tabControl.SelectedIndex == 1)
                {
                    XZ_Press_Save();
                    XZ_Press_DownloadData();
                }
                if (tabControl.SelectedIndex == 2)
                {
                    XY_FI_Save();
                    XY_FI_DownloadData();
                }
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (tabControl.SelectedTab == tabPage_Gantry)
            {
                XY_Gantry_Export();
            }
        }

    
        public async void XY_Gantry_DownloadData()
        {
            //DataView dataView = (DataView)XY_Gantry_dataGridView.DataSource;
            //DataTable dataTable = dataView.Table;
            //var data = await LoadDataInGrid();
            DataView dataView = (DataView)XY_Gantry_dataGridView.DataSource;
            DataTable dt = dataView.Table;
            //DataTable dt = new DataTable();
            //XY_Gantry_dataGridView.DataSource = dt;
            if (dt.Rows.Count > 0)
            {
                try
                {

                    // Assigning X Values
                    Globalvariable.Gantry_X_Home = Convert.ToDouble(dt.Rows[0][1]);
                    Globalvariable.Gantry_X_Pick_Position[0] = Convert.ToDouble(dt.Rows[1][1]);
                    Globalvariable.Gantry_X_Pick_Position[1] = Convert.ToDouble(dt.Rows[2][1]);
                    Globalvariable.Gantry_X_Pick_Position[2] = Convert.ToDouble(dt.Rows[3][1]);
                    Globalvariable.Gantry_X_Pick_Position[3] = Convert.ToDouble(dt.Rows[4][1]);
                    Globalvariable.Gantry_X_Pick_Position[4] = Convert.ToDouble(dt.Rows[5][1]);
                    Globalvariable.Gantry_X_Pick_Position[5] = Convert.ToDouble(dt.Rows[6][1]);
                    Globalvariable.Gantry_X_Pick_Position[6] = Convert.ToDouble(dt.Rows[7][1]);
                    Globalvariable.Gantry_X_Pick_Position[7] = Convert.ToDouble(dt.Rows[8][1]);
                    Globalvariable.Gantry_X_Pick_Position[8] = Convert.ToDouble(dt.Rows[9][1]);
                    Globalvariable.Gantry_X_Place_position = Convert.ToDouble(dt.Rows[10][1]);

                    //Assigning Y Values
                    Globalvariable.Gantry_Y_Home = Convert.ToDouble(dt.Rows[0][2]);
                    Globalvariable.Gantry_Y_Pick_Position[0] = Convert.ToDouble(dt.Rows[1][2]);
                    Globalvariable.Gantry_Y_Pick_Position[1] = Convert.ToDouble(dt.Rows[2][2]);
                    Globalvariable.Gantry_Y_Pick_Position[2] = Convert.ToDouble(dt.Rows[3][2]);
                    Globalvariable.Gantry_Y_Pick_Position[3] = Convert.ToDouble(dt.Rows[4][2]);
                    Globalvariable.Gantry_Y_Pick_Position[4] = Convert.ToDouble(dt.Rows[5][2]);
                    Globalvariable.Gantry_Y_Pick_Position[5] = Convert.ToDouble(dt.Rows[6][2]);
                    Globalvariable.Gantry_Y_Pick_Position[6] = Convert.ToDouble(dt.Rows[7][2]);
                    Globalvariable.Gantry_Y_Pick_Position[7] = Convert.ToDouble(dt.Rows[8][2]);
                    Globalvariable.Gantry_Y_Pick_Position[8] = Convert.ToDouble(dt.Rows[9][2]);
                    Globalvariable.Gantry_Y_Place_position = Convert.ToDouble(dt.Rows[10][2]);

                    //Assigning X Acceleration
                    Globalvariable.Gantry_X_Home_Acceleration = Convert.ToDouble(dt.Rows[0][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[0] = Convert.ToDouble(dt.Rows[1][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[1] = Convert.ToDouble(dt.Rows[2][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[2] = Convert.ToDouble(dt.Rows[3][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[3] = Convert.ToDouble(dt.Rows[4][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[4] = Convert.ToDouble(dt.Rows[5][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[5] = Convert.ToDouble(dt.Rows[6][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[6] = Convert.ToDouble(dt.Rows[7][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[7] = Convert.ToDouble(dt.Rows[8][3]);
                    Globalvariable.Gantry_X_Pick_Acceleration[8] = Convert.ToDouble(dt.Rows[9][3]);
                    Globalvariable.Gantry_X_Place_Acceleration = Convert.ToDouble(dt.Rows[10][3]);

                    //Assigning Y Acceleration
                    Globalvariable.Gantry_Y_Home_acceleration = Convert.ToDouble(dt.Rows[0][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[0] = Convert.ToDouble(dt.Rows[1][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[1] = Convert.ToDouble(dt.Rows[2][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[2] = Convert.ToDouble(dt.Rows[3][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[3] = Convert.ToDouble(dt.Rows[4][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[4] = Convert.ToDouble(dt.Rows[5][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[5] = Convert.ToDouble(dt.Rows[6][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[6] = Convert.ToDouble(dt.Rows[7][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[7] = Convert.ToDouble(dt.Rows[8][4]);
                    Globalvariable.Gantry_Y_pick_acceleration[8] = Convert.ToDouble(dt.Rows[9][4]);
                    Globalvariable.Gantry_Y_Place_acceleration = Convert.ToDouble(dt.Rows[10][4]);

                    //Assigning X DeAcceleration
                    Globalvariable.Gantry_X_Home_Deacceleration = Convert.ToDouble(dt.Rows[0][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[0] = Convert.ToDouble(dt.Rows[1][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[1] = Convert.ToDouble(dt.Rows[2][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[2] = Convert.ToDouble(dt.Rows[3][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[3] = Convert.ToDouble(dt.Rows[4][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[4] = Convert.ToDouble(dt.Rows[5][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[5] = Convert.ToDouble(dt.Rows[6][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[6] = Convert.ToDouble(dt.Rows[7][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[7] = Convert.ToDouble(dt.Rows[8][5]);
                    Globalvariable.Gantry_X_Pick_Deacceleration[8] = Convert.ToDouble(dt.Rows[9][5]);
                    Globalvariable.Gantry_X_Place_Deacceleration = Convert.ToDouble(dt.Rows[10][5]);

                    //Assigning Y DeAcceleration
                    Globalvariable.Gantry_Y_Home_Deacceleration = Convert.ToDouble(dt.Rows[0][6]);
                    Globalvariable.Gantry_Y_pick_Deacceleration[0] = Convert.ToDouble(dt.Rows[1][6]);
                    Globalvariable.Gantry_Y_pick_Deacceleration[1] = Convert.ToDouble(dt.Rows[2][6]);
                    Globalvariable.Gantry_Y_pick_Deacceleration[2] = Convert.ToDouble(dt.Rows[3][6]);
                    Globalvariable.Gantry_Y_pick_Deacceleration[3] = Convert.ToDouble(dt.Rows[4][6]);
                    Globalvariable.Gantry_Y_pick_Deacceleration[4] = Convert.ToDouble(dt.Rows[6][6]);
                    Globalvariable.Gantry_Y_pick_Deacceleration[5] = Convert.ToDouble(dt.Rows[7][6]);
                    Globalvariable.Gantry_Y_pick_Deacceleration[6] = Convert.ToDouble(dt.Rows[8][6]);
                    Globalvariable.Gantry_Y_pick_Deacceleration[7] = Convert.ToDouble(dt.Rows[9][6]);
                    Globalvariable.Gantry_Y_Place_Deacceleration = Convert.ToDouble(dt.Rows[10][6]);

                    //Assigning  X Speed
                    Globalvariable.Gantry_X_Home_velocity = Convert.ToDouble(dt.Rows[0][7]);
                    Globalvariable.Gantry_X_Pick_velocity[0] = Convert.ToDouble(dt.Rows[1][7]);
                    Globalvariable.Gantry_X_Pick_velocity[1] = Convert.ToDouble(dt.Rows[2][7]);
                    Globalvariable.Gantry_X_Pick_velocity[2] = Convert.ToDouble(dt.Rows[3][7]);
                    Globalvariable.Gantry_X_Pick_velocity[3] = Convert.ToDouble(dt.Rows[4][7]);
                    Globalvariable.Gantry_X_Pick_velocity[4] = Convert.ToDouble(dt.Rows[5][7]);
                    Globalvariable.Gantry_X_Pick_velocity[5] = Convert.ToDouble(dt.Rows[6][7]);
                    Globalvariable.Gantry_X_Pick_velocity[6] = Convert.ToDouble(dt.Rows[7][7]);
                    Globalvariable.Gantry_X_Pick_velocity[7] = Convert.ToDouble(dt.Rows[8][7]);
                    Globalvariable.Gantry_X_Pick_velocity[8] = Convert.ToDouble(dt.Rows[9][7]);
                    Globalvariable.Gantry_X_Place_velocity = Convert.ToDouble(dt.Rows[10][7]);

                    //Assigning  Y Speed
                    Globalvariable.Gantry_Y_Home_velocity = Convert.ToDouble(dt.Rows[0][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[0] = Convert.ToDouble(dt.Rows[1][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[1] = Convert.ToDouble(dt.Rows[2][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[2] = Convert.ToDouble(dt.Rows[3][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[3] = Convert.ToDouble(dt.Rows[4][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[4] = Convert.ToDouble(dt.Rows[5][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[5] = Convert.ToDouble(dt.Rows[6][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[6] = Convert.ToDouble(dt.Rows[7][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[7] = Convert.ToDouble(dt.Rows[8][8]);
                    Globalvariable.Gantry_Y_Pick_velocity[8] = Convert.ToDouble(dt.Rows[9][8]);
                    Globalvariable.Gantry_Y_place_velocity = Convert.ToDouble(dt.Rows[10][8]);

                    //Assigning  X Offset
                    Globalvariable.Gantry_X_Home_Offset = Convert.ToDouble(dt.Rows[0][7]);
                    Globalvariable.Gantry_X_Offset[0] = Convert.ToDouble(dt.Rows[1][7]);
                    Globalvariable.Gantry_X_Offset[1] = Convert.ToDouble(dt.Rows[2][7]);
                    Globalvariable.Gantry_X_Offset[2] = Convert.ToDouble(dt.Rows[3][7]);
                    Globalvariable.Gantry_X_Offset[3] = Convert.ToDouble(dt.Rows[4][7]);
                    Globalvariable.Gantry_X_Offset[4] = Convert.ToDouble(dt.Rows[5][7]);
                    Globalvariable.Gantry_X_Offset[5] = Convert.ToDouble(dt.Rows[6][7]);
                    Globalvariable.Gantry_X_Offset[6] = Convert.ToDouble(dt.Rows[7][7]);
                    Globalvariable.Gantry_X_Offset[7] = Convert.ToDouble(dt.Rows[8][7]);
                    Globalvariable.Gantry_X_Offset[8] = Convert.ToDouble(dt.Rows[9][7]);
                    Globalvariable.Gantry_X_Place_Offset = Convert.ToDouble(dt.Rows[10][7]);

                    //Assigning  Y Speed
                    Globalvariable.Gantry_Y_Home_Offset = Convert.ToDouble(dt.Rows[0][8]);
                    Globalvariable.Gantry_Y_Offset[0] = Convert.ToDouble(dt.Rows[1][8]);
                    Globalvariable.Gantry_Y_Offset[1] = Convert.ToDouble(dt.Rows[2][8]);
                    Globalvariable.Gantry_Y_Offset[2] = Convert.ToDouble(dt.Rows[3][8]);
                    Globalvariable.Gantry_Y_Offset[3] = Convert.ToDouble(dt.Rows[4][8]);
                    Globalvariable.Gantry_Y_Offset[4] = Convert.ToDouble(dt.Rows[5][8]);
                    Globalvariable.Gantry_Y_Offset[5] = Convert.ToDouble(dt.Rows[6][8]);
                    Globalvariable.Gantry_Y_Offset[6] = Convert.ToDouble(dt.Rows[7][8]);
                    Globalvariable.Gantry_Y_Offset[7] = Convert.ToDouble(dt.Rows[8][8]);
                    Globalvariable.Gantry_Y_Offset[8] = Convert.ToDouble(dt.Rows[9][8]);
                    Globalvariable.Gantry_Y_place_Offset = Convert.ToDouble(dt.Rows[10][8]);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Recipe Screen--Error in this function:XY_Gantry_DownloadData()" + ex);
                    return;
                }
            }
            else
            {
                MessageBox.Show("No data available to Assign.");
                return;
            }
        }

        public void XY_Gantry_Save()
        {
            try
            {

                // Assuming your DataGridView is set up to reflect the structure you provided
                //dataTable = (DataTable)XY_Gantry_dataGridView.DataSource;
                DataView dataView = (DataView)XY_Gantry_dataGridView.DataSource;
                DataTable dataTable = dataView.Table;



                // Loop through the rows in the DataTable
                foreach (DataRow row in dataTable.Rows)
                {
                    // Extract the values from each column
                    string position = row["Position"].ToString();
                    string xGantry = row["X_Axis"].ToString();
                    string yGantry = row["Y_Axis"].ToString();
                    string xAcceleration = row["X_Acceleration"].ToString();
                    string yAcceleration = row["Y_Acceleration"].ToString();
                    string xDeacceleration = row["X_Deacceleration"].ToString();
                    string yDeacceleration = row["Y_Deacceleration"].ToString();
                    string xspeed = row["X_Speed"].ToString();
                    string yspeed = row["Y_Speed"].ToString();
                    string xoffset = row["X_Axis_Offset"].ToString();
                    string yoffset = row["Y_Axis_Offset"].ToString();

                    // Update the database using a SQL command
                    using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
                    {
                        connection.Open();
                        string query = "UPDATE Battery_Pick_Gantry SET " +
                                       "X_Axis = @X_Axis, " +
                                       "Y_Axis = @Y_Axis, " +
                                       "X_Acceleration = @X_Acceleration, " +
                                       "Y_Acceleration = @Y_Acceleration, " +
                                       "X_Deacceleration = @X_Deacceleration, " +
                                       "Y_Deacceleration = @Y_Deacceleration, " +
                                       "X_Speed = @X_Speed," +
                                       "Y_Speed = @Y_Speed," +
                                       "X_Axis_Offset = @X_Axis_Offset," +
                                       "Y_Axis_Offset = @Y_Axis_Offset " +
                                       "WHERE Position = @Position"; // Ensure Position is unique or modify as needed

                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@X_Axis", xGantry);
                            command.Parameters.AddWithValue("@Y_Axis", yGantry);
                            command.Parameters.AddWithValue("@X_Acceleration", xAcceleration);
                            command.Parameters.AddWithValue("@Y_Acceleration", yAcceleration);
                            command.Parameters.AddWithValue("@X_Deacceleration", xDeacceleration);
                            command.Parameters.AddWithValue("@Y_Deacceleration", yDeacceleration);
                            command.Parameters.AddWithValue("@X_Speed", xspeed);
                            command.Parameters.AddWithValue("@Y_Speed", yspeed);
                            command.Parameters.AddWithValue("@X_Axis_Offset", xoffset);
                            command.Parameters.AddWithValue("@Y_Axis_Offset", yoffset);
                            command.Parameters.AddWithValue("@Position", position);

                            command.ExecuteNonQuery();
                        }
                    }
                }

                // Refresh the DataGrid after saving
                RefreshDataGrid();
                MessageBox.Show("Recipe For XY Gantry Saved Successfully !");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Recipe Screen--Error in this function:XY_Gantry_Save()" + ex);
                return;
            }
        }
        private void RefreshDataGrid()
        {
            try
            {
                //using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
                //{
                //    connection.Open();
                //    SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM XY_Pick_Gantry", connection);
                //    DataTable dataTable = new DataTable();
                //    adapter.Fill(dataTable);
                //    XY_Gantry_dataGridView.DataSource = dataTable;
                //}
                DataSet DS = null;
                string SqlQueryScan = "select * from Batter_Pick_Gantry";
                DS = SQLHelper.GetData(SqlQueryScan);
                XY_Gantry_dataGridView.DataSource = DS.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Recipe Screen--Error in this function:RefreshDataGrid()" + ex);
                return;
            }
        }

        //Roller Function
        public async Task<object> LoadDataInRoller()
        {
            string connectionString = SQLHelper.get_ConnName();


            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_Roller_Details", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    //cmd.Parameters.AddWithValue("@ModelName", modelName);

                    try
                    {
                        await conn.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            // Check if there are any rows to display
                            if (dt.Rows.Count > 1) // Ensure there's at least 2 rows
                            {
                                //XYZ_Roller_dataGridView.DataSource = dt;
                                //XYZ_Roller_dataGridView.AutoGenerateColumns = true;

                                // Return the value from the first column of the second row
                                return dt;
                            }
                            else
                            {
                                MessageBox.Show("No data available");
                               // XYZ_Roller_dataGridView.DataSource = null;
                                return null; // or handle accordingly
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Recipe Screen--Error in this function:LoadDataInRoller()" + ex);
                        return null;
                    }
                }
            }
        }
        public async void XZ_Press_DownloadData()
        {

            //var data = await LoadDataInRoller();
           // DataView dataView = (DataView)XYZ_Roller_dataGridView.DataSource;
           // DataTable dt = dataView.Table;
            //if (dt.Rows.Count > 0)
            //{
            //    try
            //    {

            //        // Assigning X Values
            //        Globalvariable.Roller_X_HomePos = Convert.ToDouble(dt.Rows[0][1]);
            //        Globalvariable.Roller_X_Rollposition[0] = Convert.ToDouble(dt.Rows[1][1]);
            //        Globalvariable.Roller_X_Rollposition[1] = Convert.ToDouble(dt.Rows[2][1]);
            //        Globalvariable.Roller_X_Rollposition[2] = Convert.ToDouble(dt.Rows[3][1]);
            //        Globalvariable.Roller_X_Rollposition[3] = Convert.ToDouble(dt.Rows[4][1]);
            //        Globalvariable.Roller_X_Rollposition[4] = Convert.ToDouble(dt.Rows[5][1]);


            //        //Assigning Y Values
            //        Globalvariable.Roller_Y_HomePos = Convert.ToDouble(dt.Rows[0][2]);
            //        Globalvariable.Roller_Y_Rollposition[0] = Convert.ToDouble(dt.Rows[1][2]);
            //        Globalvariable.Roller_Y_Rollposition[1] = Convert.ToDouble(dt.Rows[2][2]);
            //        Globalvariable.Roller_Y_Rollposition[2] = Convert.ToDouble(dt.Rows[3][2]);
            //        Globalvariable.Roller_Y_Rollposition[3] = Convert.ToDouble(dt.Rows[4][2]);
            //        Globalvariable.Roller_Y_Rollposition[4] = Convert.ToDouble(dt.Rows[5][2]);

            //        //Assigning Z Values
            //        Globalvariable.Roller_Z_HomePos = Convert.ToDouble(dt.Rows[0][3]);
            //        Globalvariable.Roller_Z_Rollposition[0] = Convert.ToDouble(dt.Rows[1][3]);
            //        Globalvariable.Roller_Z_Rollposition[1] = Convert.ToDouble(dt.Rows[2][3]);
            //        Globalvariable.Roller_Z_Rollposition[2] = Convert.ToDouble(dt.Rows[3][3]);
            //        Globalvariable.Roller_Z_Rollposition[3] = Convert.ToDouble(dt.Rows[4][3]);
            //        Globalvariable.Roller_Z_Rollposition[4] = Convert.ToDouble(dt.Rows[5][3]);


            //        //Assigning X Acceleration
            //        Globalvariable.Roller_X_Home_Acceleration = Convert.ToDouble(dt.Rows[0][4]);
            //        Globalvariable.Roller_X_Pick_Acceleration[0] = Convert.ToDouble(dt.Rows[1][4]);
            //        Globalvariable.Roller_X_Pick_Acceleration[1] = Convert.ToDouble(dt.Rows[2][4]);
            //        Globalvariable.Roller_X_Pick_Acceleration[2] = Convert.ToDouble(dt.Rows[3][4]);
            //        Globalvariable.Roller_X_Pick_Acceleration[3] = Convert.ToDouble(dt.Rows[4][4]);
            //        Globalvariable.Roller_X_Pick_Acceleration[4] = Convert.ToDouble(dt.Rows[5][4]);


            //        //Assigning Y Acceleration
            //        Globalvariable.Roller_Y_Home_Acceleration = Convert.ToDouble(dt.Rows[0][5]);
            //        Globalvariable.Roller_Y_pick_acceleration[0] = Convert.ToDouble(dt.Rows[1][5]);
            //        Globalvariable.Roller_Y_pick_acceleration[1] = Convert.ToDouble(dt.Rows[2][5]);
            //        Globalvariable.Roller_Y_pick_acceleration[2] = Convert.ToDouble(dt.Rows[3][5]);
            //        Globalvariable.Roller_Y_pick_acceleration[3] = Convert.ToDouble(dt.Rows[4][5]);
            //        Globalvariable.Roller_Y_pick_acceleration[4] = Convert.ToDouble(dt.Rows[5][5]);

            //        //Assigning Z Acceleration
            //        Globalvariable.Roller_Y_Home_Acceleration = Convert.ToDouble(dt.Rows[0][6]);
            //        Globalvariable.Roller_Z_pick_acceleration[0] = Convert.ToDouble(dt.Rows[1][6]);
            //        Globalvariable.Roller_Z_pick_acceleration[1] = Convert.ToDouble(dt.Rows[2][6]);
            //        Globalvariable.Roller_Z_pick_acceleration[2] = Convert.ToDouble(dt.Rows[3][6]);
            //        Globalvariable.Roller_Z_pick_acceleration[3] = Convert.ToDouble(dt.Rows[4][6]);
            //        Globalvariable.Roller_Z_pick_acceleration[4] = Convert.ToDouble(dt.Rows[5][6]);


            //        //Assigning X DeAcceleration
            //        Globalvariable.Roller_X_Home_Deacceleration = Convert.ToDouble(dt.Rows[0][7]);
            //        Globalvariable.Roller_X_Pick_Deacceleration[0] = Convert.ToDouble(dt.Rows[1][7]);
            //        Globalvariable.Roller_X_Pick_Deacceleration[1] = Convert.ToDouble(dt.Rows[2][7]);
            //        Globalvariable.Roller_X_Pick_Deacceleration[2] = Convert.ToDouble(dt.Rows[3][7]);
            //        Globalvariable.Roller_X_Pick_Deacceleration[3] = Convert.ToDouble(dt.Rows[4][7]);
            //        Globalvariable.Roller_X_Pick_Deacceleration[4] = Convert.ToDouble(dt.Rows[5][7]);


            //        //Assigning Y DeAcceleration
            //        Globalvariable.Roller_Y_Home_Deacceleration = Convert.ToDouble(dt.Rows[0][8]);
            //        Globalvariable.Roller_Y_pick_Deacceleration[0] = Convert.ToDouble(dt.Rows[1][8]);
            //        Globalvariable.Roller_Y_pick_Deacceleration[1] = Convert.ToDouble(dt.Rows[2][8]);
            //        Globalvariable.Roller_Y_pick_Deacceleration[2] = Convert.ToDouble(dt.Rows[3][8]);
            //        Globalvariable.Roller_Y_pick_Deacceleration[3] = Convert.ToDouble(dt.Rows[4][8]);
            //        Globalvariable.Roller_Y_pick_Deacceleration[4] = Convert.ToDouble(dt.Rows[4][8]);

            //        //Assigning Y DeAcceleration
            //        Globalvariable.Roller_Z_Home_Deacceleration = Convert.ToDouble(dt.Rows[0][9]);
            //        Globalvariable.Roller_Z_pick_Deacceleration[0] = Convert.ToDouble(dt.Rows[1][9]);
            //        Globalvariable.Roller_Z_pick_Deacceleration[1] = Convert.ToDouble(dt.Rows[2][9]);
            //        Globalvariable.Roller_Z_pick_Deacceleration[2] = Convert.ToDouble(dt.Rows[3][9]);
            //        Globalvariable.Roller_Z_pick_Deacceleration[3] = Convert.ToDouble(dt.Rows[4][9]);
            //        Globalvariable.Roller_Z_pick_Deacceleration[4] = Convert.ToDouble(dt.Rows[4][9]);


            //        //Assigning X Speed
            //        Globalvariable.Roller_X_Home_velocity = Convert.ToDouble(dt.Rows[0][10]);
            //        Globalvariable.Roller_X_Pick_velocity[0] = Convert.ToDouble(dt.Rows[1][10]);
            //        Globalvariable.Roller_X_Pick_velocity[1] = Convert.ToDouble(dt.Rows[2][10]);
            //        Globalvariable.Roller_X_Pick_velocity[2] = Convert.ToDouble(dt.Rows[3][10]);
            //        Globalvariable.Roller_X_Pick_velocity[3] = Convert.ToDouble(dt.Rows[4][10]);
            //        Globalvariable.Roller_X_Pick_velocity[4] = Convert.ToDouble(dt.Rows[5][10]);

            //        //Assigning Y Speed
            //        Globalvariable.Roller_Y_Home_velocity = Convert.ToDouble(dt.Rows[0][11]);
            //        Globalvariable.Roller_Y_pick_velocity[0] = Convert.ToDouble(dt.Rows[1][11]);
            //        Globalvariable.Roller_Y_pick_velocity[1] = Convert.ToDouble(dt.Rows[2][11]);
            //        Globalvariable.Roller_Y_pick_velocity[2] = Convert.ToDouble(dt.Rows[3][11]);
            //        Globalvariable.Roller_Y_pick_velocity[3] = Convert.ToDouble(dt.Rows[4][11]);
            //        Globalvariable.Roller_Y_pick_velocity[4] = Convert.ToDouble(dt.Rows[5][11]);

            //        //Assigning Y Speed
            //        Globalvariable.Roller_Z_Home_velocity = Convert.ToDouble(dt.Rows[0][12]);
            //        Globalvariable.Roller_Z_pick_velocity[0] = Convert.ToDouble(dt.Rows[1][12]);
            //        Globalvariable.Roller_Z_pick_velocity[1] = Convert.ToDouble(dt.Rows[2][12]);
            //        Globalvariable.Roller_Z_pick_velocity[2] = Convert.ToDouble(dt.Rows[3][12]);
            //        Globalvariable.Roller_Z_pick_velocity[3] = Convert.ToDouble(dt.Rows[4][12]);
            //        Globalvariable.Roller_Z_pick_velocity[4] = Convert.ToDouble(dt.Rows[5][12]);
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("Recipe Screen--Error in this function:XYZ_Roller_DownloadData()" + ex);
            //        return;
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("No data available to Assign.");
            //    return;
            //}
        }
   
        private void XZ_Press_Save()
        {

            //// Assuming your DataGridView is set up to reflect the structure you provided
            //// DataTable dataTable = (DataTable)XZ_Press_dataGridView.DataSource;
            //DataView dataView = (DataView)XYZ_Roller_dataGridView.DataSource;
            //DataTable dataTable = dataView.Table;
            //try
            //{
            //    // Loop through the rows in the DataTable
            //    foreach (DataRow row in dataTable.Rows)
            //    {
            //        // Extract the values from each column
            //        string position = row["Position"].ToString();
            //        string xGantry = row["X_Axis"].ToString();
            //        string yGantry = row["Y_Axis"].ToString();
            //        string zGantry = row["Z_Axis"].ToString();
            //        string xAcceleration = row["X_Acceleration"].ToString();
            //        string yAcceleration = row["Y_Acceleration"].ToString();
            //        string zAcceleration = row["Z_Acceleration"].ToString();
            //        string xDeacceleration = row["X_Deacceleration"].ToString();
            //        string yDeacceleration = row["Y_Deacceleration"].ToString();
            //        string zDeacceleration = row["Z_Deacceleration"].ToString();
            //        string xspeed = row["X_Speed"].ToString();
            //        string yspeed = row["Y_Speed"].ToString();
            //        string zspeed = row["Z_Speed"].ToString();
            //        string xOffset = row["X_Axis_Offset"].ToString();
            //        string yOffset = row["Y_Axis_Offset"].ToString();
            //        string zOffset = row["Z_Axis_Offset"].ToString();

            //        // Update the database using a SQL command
            //        using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
            //        {
            //            connection.Open();
            //            string query = "UPDATE Roller_Gantry SET " +
            //                           "X_Axis = @X_Axis, " +
            //                           "Y_Axis = @Y_Axis, " +
            //                           "Z_Axis = @Z_Axis, " +
            //                           "X_Acceleration = @X_Acceleration, " +
            //                           "Y_Acceleration = @Y_Acceleration, " +
            //                           "Z_Acceleration = @Z_Acceleration, " +
            //                           "X_Deacceleration = @X_Deacceleration, " +
            //                           "Y_Deacceleration = @Y_Deacceleration, " +
            //                           "Z_Deacceleration = @Z_Deacceleration, " +
            //                           "X_Speed = @X_Speed," +
            //                           "Y_Speed = @Y_Speed," +
            //                           "Z_Speed = @Z_Speed " +
            //                           "X_Axis_Offset = @X_Axis_Offset," +
            //                           "Y_Axis_Offset = @Y_Axis_Offset," +
            //                           "Z_Axis_Offset = @Z_Axis_Offset " +
            //                           "WHERE Position = @Position"; // Ensure Position is unique or modify as needed

            //            using (SqlCommand command = new SqlCommand(query, connection))
            //            {
            //                command.Parameters.AddWithValue("@X_Axis", xGantry);
            //                command.Parameters.AddWithValue("@Y_Axis", yGantry);
            //                command.Parameters.AddWithValue("@Z_Axis", zGantry);
            //                command.Parameters.AddWithValue("@X_Acceleration", xAcceleration);
            //                command.Parameters.AddWithValue("@Y_Acceleration", yAcceleration);
            //                command.Parameters.AddWithValue("@Z_Acceleration", zAcceleration);
            //                command.Parameters.AddWithValue("@X_Deacceleration", xDeacceleration);
            //                command.Parameters.AddWithValue("@Y_Deacceleration", yDeacceleration);
            //                command.Parameters.AddWithValue("@Z_Deacceleration", zDeacceleration);
            //                command.Parameters.AddWithValue("@X_Speed", xspeed);
            //                command.Parameters.AddWithValue("@Y_Speed", yspeed);
            //                command.Parameters.AddWithValue("@Z_Speed", zspeed);
            //                command.Parameters.AddWithValue("@X_Axis_Offset", xOffset);
            //                command.Parameters.AddWithValue("@Y_Axis_Offset", yOffset);
            //                command.Parameters.AddWithValue("@Z_Axis_Offset", zOffset);
            //                command.Parameters.AddWithValue("@Position", position);

            //                command.ExecuteNonQuery();
            //            }
            //        }
            //    }

            //    // Refresh the DataGrid after saving
            //    RefreshDataGridRoller();
            //    MessageBox.Show("Recipe For Roller Saved Successfully !");
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Recipe Screen--Error in this function:XYZ_Roller_Save()" + ex);
            //    return;
            //}
        }

        //FI Function

        public async Task<object> LoadDataInFI()
        {
            // string connectionString = "Server=TCLHSRPEDLT0737;Database=AAA;User Id=sa;Password=Titan@123;";
            string connectionString = SQLHelper.get_ConnName();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_FI_Details", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    //cmd.Parameters.AddWithValue("@ModelName", modelName);

                    try
                    {
                        await conn.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            // Check if there are any rows to display
                            if (dt.Rows.Count > 1) // Ensure there's at least 2 rows
                            {
                                //XY_FI_dataGridView.DataSource = dt;
                                //XY_FI_dataGridView.AutoGenerateColumns = true;

                                // Return the value from the first column of the second row
                                return dt;
                            }
                            else
                            {
                                MessageBox.Show("No data available");
                               // XY_FI_dataGridView.DataSource = null;
                                return null; // or handle accordingly
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Recipe Screen--Error in this function:LoadDataInFI()" + ex);
                        return null;
                    }
                }
            }
        }
        public async void XY_FI_DownloadData()
        {

            ////var data = await LoadDataInFI();
            //DataView dataView = (DataView)XY_FI_dataGridView.DataSource;
            //DataTable dt = dataView.Table;
            //if (dt.Rows.Count > 0)
            //{
            //    try
            //    {

            //        // Assigning X Values
            //        Globalvariable.FI_X_Home_Pos = Convert.ToDouble(dt.Rows[0][1]);
            //        Globalvariable.FI_X_Move_pos[0] = Convert.ToDouble(dt.Rows[1][1]);
            //        Globalvariable.FI_X_Move_pos[1] = Convert.ToDouble(dt.Rows[2][1]);
            //        Globalvariable.FI_X_Move_pos[2] = Convert.ToDouble(dt.Rows[3][1]);
            //        Globalvariable.FI_X_Move_pos[3] = Convert.ToDouble(dt.Rows[4][1]);
            //        Globalvariable.FI_X_Move_pos[4] = Convert.ToDouble(dt.Rows[5][1]);


            //        //Assigning Y Values
            //        Globalvariable.FI_Y_Home_Pos = Convert.ToDouble(dt.Rows[0][2]);
            //        Globalvariable.FI_Y_Move_pos[0] = Convert.ToDouble(dt.Rows[1][2]);
            //        Globalvariable.FI_Y_Move_pos[1] = Convert.ToDouble(dt.Rows[2][2]);
            //        Globalvariable.FI_Y_Move_pos[2] = Convert.ToDouble(dt.Rows[3][2]);
            //        Globalvariable.FI_Y_Move_pos[3] = Convert.ToDouble(dt.Rows[4][2]);
            //        Globalvariable.FI_Y_Move_pos[4] = Convert.ToDouble(dt.Rows[5][2]);


            //        //Assigning X Acceleration
            //        Globalvariable.FI_X_Home_acc = Convert.ToDouble(dt.Rows[0][3]);
            //        Globalvariable.FI_X_acceleration[0] = Convert.ToDouble(dt.Rows[1][3]);
            //        Globalvariable.FI_X_acceleration[1] = Convert.ToDouble(dt.Rows[2][3]);
            //        Globalvariable.FI_X_acceleration[2] = Convert.ToDouble(dt.Rows[3][3]);
            //        Globalvariable.FI_X_acceleration[3] = Convert.ToDouble(dt.Rows[4][3]);
            //        Globalvariable.FI_X_acceleration[4] = Convert.ToDouble(dt.Rows[5][3]);


            //        //Assigning Y Acceleration
            //        Globalvariable.FI_Y_Home_Acc = Convert.ToDouble(dt.Rows[0][4]);
            //        Globalvariable.FI_Y_acceleration[0] = Convert.ToDouble(dt.Rows[1][4]);
            //        Globalvariable.FI_Y_acceleration[1] = Convert.ToDouble(dt.Rows[2][4]);
            //        Globalvariable.FI_Y_acceleration[2] = Convert.ToDouble(dt.Rows[3][4]);
            //        Globalvariable.FI_Y_acceleration[3] = Convert.ToDouble(dt.Rows[4][4]);
            //        Globalvariable.FI_Y_acceleration[4] = Convert.ToDouble(dt.Rows[5][4]);


            //        ////Assigning X DeAcceleration
            //        Globalvariable.FI_X_Home_Deacc = Convert.ToDouble(dt.Rows[0][5]);
            //        Globalvariable.FI_X_Deacceleration[0] = Convert.ToDouble(dt.Rows[1][5]);
            //        Globalvariable.FI_X_Deacceleration[1] = Convert.ToDouble(dt.Rows[2][5]);
            //        Globalvariable.FI_X_Deacceleration[2] = Convert.ToDouble(dt.Rows[3][5]);
            //        Globalvariable.FI_X_Deacceleration[3] = Convert.ToDouble(dt.Rows[4][5]);
            //        Globalvariable.FI_X_Deacceleration[4] = Convert.ToDouble(dt.Rows[5][5]);

            //        ////Assigning Y DeAcceleration
            //        Globalvariable.FI_Y_Home_Deacc = Convert.ToDouble(dt.Rows[0][6]);
            //        Globalvariable.FI_Y_Deacceleration[0] = Convert.ToDouble(dt.Rows[1][6]);
            //        Globalvariable.FI_Y_Deacceleration[1] = Convert.ToDouble(dt.Rows[2][6]);
            //        Globalvariable.FI_Y_Deacceleration[2] = Convert.ToDouble(dt.Rows[3][6]);
            //        Globalvariable.FI_Y_Deacceleration[3] = Convert.ToDouble(dt.Rows[4][6]);
            //        Globalvariable.FI_Y_Deacceleration[4] = Convert.ToDouble(dt.Rows[4][6]);

            //        //Assigning X Speed
            //        Globalvariable.FI_X_Home_velocity = Convert.ToDouble(dt.Rows[0][7]);
            //        Globalvariable.FI_X_velocity[0] = Convert.ToDouble(dt.Rows[1][7]);
            //        Globalvariable.FI_X_velocity[1] = Convert.ToDouble(dt.Rows[2][7]);
            //        Globalvariable.FI_X_velocity[2] = Convert.ToDouble(dt.Rows[3][7]);
            //        Globalvariable.FI_X_velocity[3] = Convert.ToDouble(dt.Rows[4][7]);
            //        Globalvariable.FI_X_velocity[4] = Convert.ToDouble(dt.Rows[5][7]);

            //        //Assigning Y Speed
            //        Globalvariable.FI_Y_Home_velocity = Convert.ToDouble(dt.Rows[0][8]);
            //        Globalvariable.FI_Y_velocity[0] = Convert.ToDouble(dt.Rows[1][8]);
            //        Globalvariable.FI_Y_velocity[1] = Convert.ToDouble(dt.Rows[2][8]);
            //        Globalvariable.FI_Y_velocity[2] = Convert.ToDouble(dt.Rows[3][8]);
            //        Globalvariable.FI_Y_velocity[3] = Convert.ToDouble(dt.Rows[4][8]);
            //        Globalvariable.FI_Y_velocity[4] = Convert.ToDouble(dt.Rows[5][8]);
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("Recipe Screen--Error in this function:XY_FI_DownloadData()" + ex);
            //        return;
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("No data available to Assign.");
            //    return;
            //}
        }
     
        private void XY_FI_Save()
        {
            //try
            //{
            //    // Assuming your DataGridView is set up to reflect the structure you provided
            //    //DataTable dataTable = (DataTable)XY_FI_dataGridView.DataSource;
            //    DataView dataView = (DataView)XY_FI_dataGridView.DataSource;
            //    DataTable dataTable = dataView.Table;

            //    // Loop through the rows in the DataTable
            //    foreach (DataRow row in dataTable.Rows)
            //    {
            //        // Extract the values from each column
            //        string position = row["Position"].ToString();
            //        string xGantry = row["X_Axis"].ToString();
            //        string yGantry = row["Y_Axis"].ToString();
            //        string xAcceleration = row["X_Acceleration"].ToString();
            //        string yAcceleration = row["Y_Acceleration"].ToString();
            //        string xDeacceleration = row["X_Deacceleration"].ToString();
            //        string yDeacceleration = row["Y_Deacceleration"].ToString();
            //        string xspeed = row["X_Speed"].ToString();
            //        string yspeed = row["Y_Speed"].ToString();
            //        string xOffset = row["X_Axis_Offset"].ToString();
            //        string yOffset = row["Y_Axis_Offset"].ToString();

            //        // Update the database using a SQL command
            //        using (SqlConnection connection = new SqlConnection(SQLHelper.get_ConnName()))
            //        {
            //            connection.Open();
            //            string query = "UPDATE FI_Gantry SET " +
            //                           "X_Axis = @X_Axis, " +
            //                           "Y_Axis = @Y_Axis, " +
            //                           "X_Acceleration = @X_Acceleration, " +
            //                           "Y_Acceleration = @Y_Acceleration, " +
            //                           "X_Deacceleration = @X_Deacceleration, " +
            //                           "Y_Deacceleration = @Y_Deacceleration, " +
            //                           "X_Speed = @X_Speed," +
            //                           "Y_Speed = @Y_Speed," +
            //                           "X_Axis_Offset = @X_Axis_Offset," +
            //                           "Y_Axis_Offset = @Y_Axis_Offset " +
            //                           "WHERE Position = @Position"; // Ensure Position is unique or modify as needed

            //            using (SqlCommand command = new SqlCommand(query, connection))
            //            {
            //                command.Parameters.AddWithValue("@X_Axis_Gantry", xGantry);
            //                command.Parameters.AddWithValue("@Y_Axis_Gantry", yGantry);
            //                command.Parameters.AddWithValue("@X_Acceleration", xAcceleration);
            //                command.Parameters.AddWithValue("@Y_Acceleration", yAcceleration);
            //                command.Parameters.AddWithValue("@X_Deacceleration", xDeacceleration);
            //                command.Parameters.AddWithValue("@Y_Deacceleration", yDeacceleration);
            //                command.Parameters.AddWithValue("@X_Speed", xspeed);
            //                command.Parameters.AddWithValue("@Y_Speed", yspeed);
            //                command.Parameters.AddWithValue("@X_Axis_Offset", xspeed);
            //                command.Parameters.AddWithValue("@Y_Axis_Offset", yspeed);
            //                command.Parameters.AddWithValue("@Position", position);

            //                command.ExecuteNonQuery();
            //            }
            //        }
            //    }

            //    // Refresh the DataGrid after saving
            //    RefreshDataGridFI();

            //    MessageBox.Show("Recipe For Final Inspection Gantry Saved Successfully !");
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Recipe Screen--Error in this function:XY_FI_Save()" + ex);
            //    return;
            //}
        }
    
        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void writeCSV(DataSet paramDset, string fileName)
        {
            StreamWriter sw = new StreamWriter(fileName, false);
            //headers
            try
            {
                for (int i = 0; i < paramDset.Tables[0].Columns.Count; i++)
                {
                    sw.Write(paramDset.Tables[0].Columns[i]);
                    if (i < paramDset.Tables[0].Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
                foreach (DataRow dr in paramDset.Tables[0].Rows)
                {
                    for (int i = 0; i < paramDset.Tables[0].Columns.Count; i++)
                    {
                        if (!Convert.IsDBNull(dr[i]))
                        {
                            string value = dr[i].ToString();
                            if (value.Contains(','))
                            {
                                value = String.Format("\"{0}\"", value);
                                sw.Write(value);
                            }
                            else
                            {
                                sw.Write(dr[i].ToString());
                            }
                        }
                        if (i < paramDset.Tables[0].Columns.Count - 1)
                        {
                            sw.Write(",");
                        }
                    }
                    sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Recipe Screen--Error in this function:writeCSV()" + ex);
                return;
            }
        }

        private async void XY_Gantry_Export()
        {
            string connectionString = SQLHelper.get_ConnName();


            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SP_Roller_Details", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    try
                    {
                        await conn.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            DataSet dt = new DataSet();
                            adapter.Fill(dt);
                            if (dt.Tables[0].Rows.Count > 0)
                            {
                                Thread t = new Thread((ThreadStart)(() =>
                                {
                                    var saveFileDialog1 = new SaveFileDialog();
                                    saveFileDialog1.Filter = "csv files (*.csv)|*.csv";
                                    saveFileDialog1.Title = "Export Recipe";
                                    saveFileDialog1.FilterIndex = 2;
                                    saveFileDialog1.ShowDialog();
                                    saveFileDialog1.RestoreDirectory = true;
                                    if (saveFileDialog1.FileName.Length > 0)
                                    {
                                        writeCSV(dt, saveFileDialog1.FileName.ToString());
                                        // MessageBox.Show("Data Exported Successfully", "Recipe Group Manager Software", MessageBoxButton.OK, MessageBoxImage.Information);
                                    }
                                }));
                                t.SetApartmentState(ApartmentState.STA);
                                t.Start();
                                t.Join();
                            }


                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Recipe Screen--Error in this function:XY_Gantry_Export()" + ex);
                        return;
                    }
                }
            }



        }

        private void Receipe_Load_1(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                label7.Text = "Relative Position (mm)";
            }
            else
            {
                label7.Text = "Absolute Position (mm)";
            }
        }

        private void XY_Gantry_dataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {


            {
                if (e.Button == MouseButtons.Right)
                {
                    // Select the row where the right-click occurred
                    XY_Gantry_dataGridView.Rows[e.RowIndex].Selected = true;

                    // Show the ContextMenuStrip
                    // contextMenuStrip1.Show(XY_Gantry_dataGridView, e.Location);
                    contextMenuStrip1.Show(XY_Gantry_dataGridView, XY_Gantry_dataGridView.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true).Location);

                }
            }
        }


        private void tEACHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to teach the current position ?", "Alert", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                if (tabControl.SelectedIndex == 0)
                {
                    XY_Gantry_dataGridView.Rows[XY_Gantry_dataGridView.CurrentRow.Index].Cells["X_Axis"].Value = Pick_X.Text;
                    XY_Gantry_dataGridView.Rows[XY_Gantry_dataGridView.CurrentRow.Index].Cells["Y_Axis"].Value = Pick_Y.Text;
                }
               
            }

        }

        private void mOVEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to move the gantry to selcted position ?", "Alert", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                if (tabControl.SelectedIndex == 0)
                {
                    try
                    {
                      DataGridViewRow selectedRow = XY_Gantry_dataGridView.SelectedRows[0];
                    int rowindex = selectedRow.Index;
                    string x_pos = selectedRow.Cells["X_Gantry"].Value.ToString();
                    string y_pos = selectedRow.Cells["Y_Gantry"].Value.ToString();
                        if(!Globalvariable.MC_Read_DI[Variables.Gantry_battery_suction_cyl_retraction_sensor])
                        { 
                        LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Pick_X_Axis, 0, Globalvariable.Battery_Pick_X_Speed_Manual, 0, Globalvariable.Battery_Pick_X_Acc_Manual, Convert.ToDouble(x_pos));
                        LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Pick_Y_Axis, 0, Globalvariable.Battery_Pick_Y_Speed_Manual, 0, Globalvariable.Battery_Pick_Y_Acc_Manual, Convert.ToDouble(y_pos));
                        }
                        else
                        {
                            DialogResult dialogResult = MessageBox.Show("Battery Suction Cylinder is Not in Safe Position", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.WriteLog("Manual", "servo_Move", "Station", "Error", ex.ToString());
                    }
                }
                //if (tabControl.SelectedIndex == 1)
                //{
                    //try
                    //{
                    //    DataGridViewRow selectedRow = XYZ_Roller_dataGridView.SelectedRows[0];
                    //    int rowindex = selectedRow.Index;
                    //    string x_pos = selectedRow.Cells["X_Gantry"].Value.ToString();
                    //    string y_pos = selectedRow.Cells["Y_Gantry"].Value.ToString();
                    //    if (LeadShineInterface.Get_Home_status(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Roller_Z_Axis) == "Homing_Done")
                    //    {
                            
                    //        LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Roller_X_Axis, 0, Globalvariable.Battery_Roller_X_Speed_Manual, 0, Globalvariable.Battery_Roller_X_Acc_Manual, Convert.ToDouble(x_pos));
                    //        LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Battery_Roller_Y_Axis, 0, Globalvariable.Battery_Roller_Y_Speed_Manual, 0, Globalvariable.Battery_Roller_Y_Acc_Manual, Convert.ToDouble(y_pos));
                    //    }
                    //    else
                    //    {
                    //        DialogResult dialogResult = MessageBox.Show("Z axis is Not in Safe Position", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    //    }
                    //}
                    //catch (Exception ex)
                    //{
                    //    Logger.WriteLog("Manual", "servo_Move", "Station", "Error", ex.ToString());
                    //}
                //}
                //if (tabControl.SelectedIndex == 2)
                //{
                //    DataGridViewRow selectedRow = XY_FI_dataGridView.SelectedRows[0];
                //    int rowindex = selectedRow.Index;
                //    string x_pos = selectedRow.Cells["X_Gantry"].Value.ToString();
                //    string y_pos = selectedRow.Cells["Y_Gantry"].Value.ToString();
                //    LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Battery_FI_X_Axis, 0, Globalvariable.Battery_FI_X_Speed_Manual, 0, Globalvariable.Battery_FI_X_Acc_Manual, Convert.ToDouble(x_pos));
                //    LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Battery_FI_Y_Axis, 0, Globalvariable.Battery_FI_Y_Speed_Manual, 0, Globalvariable.Battery_FI_Y_Acc_Manual, Convert.ToDouble(y_pos));
                //}
            }
        }



        private void Current_Positions_Tick(object sender, EventArgs e)
        {
            Pick_X.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_X_Axis)).ToString();
            Pick_Y.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Y_Axis)).ToString();

            Roller_X.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Roller_X_Axis)).ToString();
            Roller_Y.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Roller_Y_Axis)).ToString();
            Roller_Z.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Roller_Z_Axis)).ToString();

            FI_X.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.FI_X_axis)).ToString();
            FI_Y.Text = (LeadShineInterface.Get_current_Position_of_Axis(Globalvariable.Leadshine_card_No, Globalvariable.FI_Y_axis)).ToString();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.FI_Y_Axis, 0, Globalvariable.FI_Y_Pick_manual_velocity, 0, Globalvariable.FI_Y_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.FI_Y_Axis, 0, Globalvariable.FI_Y_Pick_manual_velocity, 0, Globalvariable.FI_Y_Pick_manual_acceleration, (Convert.ToDouble(FI_X.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.FI_Y_Axis, 0, Globalvariable.FI_Y_Pick_manual_velocity, 0, Globalvariable.FI_Y_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.FI_Y_Axis, 0, Globalvariable.FI_Y_Pick_manual_velocity, 0, Globalvariable.FI_Y_Pick_manual_acceleration, (Convert.ToDouble(FI_X.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.FI_X_Axis, 0, Globalvariable.FI_Y_Pick_manual_velocity, 0, Globalvariable.FI_Y_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.FI_X_Axis, 0, Globalvariable.FI_Y_Pick_manual_velocity, 0, Globalvariable.FI_Y_Pick_manual_acceleration, (Convert.ToDouble(FI_Y.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void BT_StopMove_Click(object sender, EventArgs e)
        {
            LeadShineInterface.Stop_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_X_Axis);
            LeadShineInterface.Stop_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_Y_Axis);
            LeadShineInterface.Stop_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_X_Axis);
            LeadShineInterface.Stop_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_X_Axis);
            LeadShineInterface.Stop_Axis(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_X_Axis);
            LeadShineInterface.Stop_Axis(Globalvariable.Leadshine_card_No, Globalvariable.FI_X_Axis);
            LeadShineInterface.Stop_Axis(Globalvariable.Leadshine_card_No, Globalvariable.FI_Y_Axis);

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_Y_Axis, 0, Globalvariable.Gantry_Y_Pick_manual_velocity, 0, Globalvariable.Gantry_Y_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_Y_Axis, 0, Globalvariable.Gantry_Y_Pick_manual_velocity, 0, Globalvariable.Gantry_Y_Pick_manual_acceleration, (Convert.ToDouble(Pick_Y.Text) + Convert.ToDouble(Rel_Position.Text)));
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_X_Axis, 0, Globalvariable.Gantry_X_Pick_manual_velocity, 0, Globalvariable.Gantry_X_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_X_Axis, 0, Globalvariable.Gantry_X_Pick_manual_velocity, 0, Globalvariable.Gantry_X_Pick_manual_acceleration, (Convert.ToDouble(Pick_X.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_X_Axis, 0, Globalvariable.Gantry_X_Pick_manual_velocity, 0, Globalvariable.Gantry_X_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_X_Axis, 0, Globalvariable.Gantry_X_Pick_manual_velocity, 0, Globalvariable.Gantry_X_Pick_manual_acceleration, (Convert.ToDouble(Pick_X.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_Y_Axis, 0, Globalvariable.Gantry_Y_Pick_manual_velocity, 0, Globalvariable.Gantry_Y_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Gantry_Pick_Y_Axis, 0, Globalvariable.Gantry_Y_Pick_manual_velocity, 0, Globalvariable.Gantry_Y_Pick_manual_acceleration, (Convert.ToDouble(Pick_Y.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_X_Axis, 0, Globalvariable.Roller_X_Pick_manual_velocity, 0, Globalvariable.Roller_X_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_X_Axis, 0, Globalvariable.Roller_X_Pick_manual_velocity, 0, Globalvariable.Roller_X_Pick_manual_acceleration, (Convert.ToDouble(Roller_X.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_X_Axis, 0, Globalvariable.Roller_X_Pick_manual_velocity, 0, Globalvariable.Roller_X_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_X_Axis, 0, Globalvariable.Roller_X_Pick_manual_velocity, 0, Globalvariable.Roller_X_Pick_manual_acceleration, (Convert.ToDouble(Roller_X.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_Y_Axis, 0, Globalvariable.Roller_Y_Pick_manual_velocity, 0, Globalvariable.Roller_Y_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_Y_Axis, 0, Globalvariable.Roller_Y_Pick_manual_velocity, 0, Globalvariable.Roller_Y_Pick_manual_acceleration, (Convert.ToDouble(Roller_Y.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_Y_Axis, 0, Globalvariable.Roller_Y_Pick_manual_velocity, 0, Globalvariable.Roller_Y_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_Y_Axis, 0, Globalvariable.Roller_Y_Pick_manual_velocity, 0, Globalvariable.Roller_Y_Pick_manual_acceleration, (Convert.ToDouble(Roller_Y.Text) + Convert.ToDouble(Rel_Position.Text)));
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_Z_Axis, 0, Globalvariable.Roller_Z_Pick_manual_velocity, 0, Globalvariable.Roller_Z_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_Z_Axis, 0, Globalvariable.Roller_Z_Pick_manual_velocity, 0, Globalvariable.Roller_Z_Pick_manual_acceleration, (Convert.ToDouble(Roller_Z.Text) + Convert.ToDouble(Rel_Position.Text)));
            }

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_Z_Axis, 0, Globalvariable.Roller_Z_Pick_manual_velocity, 0, Globalvariable.Roller_Z_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.Roller_roll_Z_Axis, 0, Globalvariable.Roller_Z_Pick_manual_velocity, 0, Globalvariable.Roller_Z_Pick_manual_acceleration, (Convert.ToDouble(Roller_Z.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 1)
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.FI_X_Axis, 0, Globalvariable.FI_Y_Pick_manual_velocity, 0, Globalvariable.FI_Y_Pick_manual_acceleration, Convert.ToDouble(Rel_Position.Text));
            }
            else
            {
                LeadShineInterface.Single_Axis_move_abs(Globalvariable.Leadshine_card_No, Globalvariable.FI_X_Axis, 0, Globalvariable.FI_Y_Pick_manual_velocity, 0, Globalvariable.FI_Y_Pick_manual_acceleration, (Convert.ToDouble(FI_Y.Text) + Convert.ToDouble(Rel_Position.Text)));
            }
        }

        private void Pick_Y_TextChanged(object sender, EventArgs e)
        {

        }

        private void XY_Gantry_dataGridView_CellMouseClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
