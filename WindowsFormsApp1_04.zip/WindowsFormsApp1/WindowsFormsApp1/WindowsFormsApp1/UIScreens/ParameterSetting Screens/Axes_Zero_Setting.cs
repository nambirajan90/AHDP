﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

namespace AHDP
{
    public partial class rotary_esd : Form
    {
        public rotary_esd()
        {
            InitializeComponent();
        }
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
   (
       int nLeftRect,
       int nTopRect,
       int nRightRect,
       int nBottomRect,
       int nWidthEllipse,
       int nHeightEllipse
   );

        public void Panel_Shape()
        {
            panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width,
            panel1.Height, 30, 30));

            //panel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel3.Width,
            //panel3.Height, 30, 30));
            //panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
            //panel4.Height, 30, 30));
            //   panel5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel5.Width,
            //panel5.Height, 30, 30));
        }
        private void nozzle_esd_Load(object sender, EventArgs e)
        {
            Panel_Shape();
            txtXhme.Text = GlobalVar.Gantry_X_HomePos.ToString();
            txtYhme.Text = GlobalVar.Gantry_Y_HomePos.ToString();

            //txtNozzle1.Text = GlobalVar.Nozzle_Ref[1].ToString();
            //txtNozzle2.Text = GlobalVar.Nozzle_Ref[2].ToString();
            //txtNozzle3.Text = GlobalVar.Nozzle_Ref[3].ToString();
            //txtNozzle4.Text = GlobalVar.Nozzle_Ref[4].ToString();
            timer1.Enabled = true;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnHmeX_Click(object sender, EventArgs e)
        {

            //double[] pos = Gantry.TogetCurrentPos();
            //GlobalVar.Gantry_X_HomePos = pos[0];
            txtXhme.Text = GlobalVar.Gantry_X_HomePos.ToString();
            //string IQuery= "insert into Axis_Setting (Datetime,Login_User,Changes,New_Value) values ('"+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+ "','" + Sessions.userId + "','HomePosition X Changes','" + txtXhme.Text+"')";
            // SQLHelper.Executequery(IQuery);
        }

        private void btnHmeY_Click(object sender, EventArgs e)
        {
            //double[] pos = Gantry.TogetCurrentPos();
            //GlobalVar.Gantry_Y_HomePos = pos[1];
            txtYhme.Text = GlobalVar.Gantry_Y_HomePos.ToString();
            //string IQuery = "insert into Axis_Setting (Datetime,Login_User,Changes,New_Value) values ('" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + Sessions.userId + "','HomePosition Y Changes','" + GlobalVar.UserCode + "','" + txtYhme.Text + "')";
            //SQLHelper.Executequery(IQuery);

        }
        bool X_trig = false;
        bool Y_trig = false;
        bool Z1_trig = false;
        bool Z2_trig = false;
        bool Z3_trig = false;
        bool Z4_trig = false;
        private void btnZeroX_Click(object sender, EventArgs e)
        {
            // string[] sts= Gantry.TogetCurrentPos_sts(GlobalVar.Gantry_X_axis, GlobalVar.Gantry_Y_axis);
            //if (sts[0] == "STA_AX_READY")
            //{



            //if (Form1.Nozzle_safe[0] > (GlobalVar.Nozzle_Z_Homeposs[1] + 0.5) || Form1.Nozzle_safe[1] > (GlobalVar.Nozzle_Z_Homeposs[2] + 0.5) || Form1.Nozzle_safe[2] > (GlobalVar.Nozzle_Z_Homeposs[3] + 0.5) || Form1.Nozzle_safe[3] > (GlobalVar.Nozzle_Z_Homeposs[4] + 0.5))
            //{

            //        MessageBox.Show("MOVE ALL NOZZLE TO SAFE MM", "Warning Box", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}
            //DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of XY axis and Make sure that X axis in Ahead of Zero Sensor condition ", "Confirmation Box", MessageBoxButtons.YesNo);
            //    if (dialogResult == DialogResult.Yes)
            //    {
            //        //Homing.Pallet_Lifter_Homing = false;
            //        //Homing.Nozzle_Axes_homing = false;
            //        //Homing.X1Y1Gantry_Axes_homing = false;
            //        //Homing.Set_Home_vel(GlobalVar.Gantry_X_axis, 20, GlobalVar.Gantry_X_PPR, GlobalVar.Gantry_X_pitch);
            //        //Homing.Set_Home_vel(GlobalVar.Gantry_Y_axis, 20, GlobalVar.Gantry_Y_PPR, GlobalVar.Gantry_Y_pitch);

            //        //bool process = Interface.Axes_Homing(GlobalVar.Gantry_X_axis, 0);
            //        ////Homing.Homing_step = 5;
            //        ////Homing.Homing_Process_sts = true;
            //        //lblXYhmeSts.BackColor = Color.Red;



            //    }

            //}
        }

        //private void btnZeroY_Click(object sender, EventArgs e)
        //{
        //    string[] sts = Gantry.TogetCurrentPos_sts(GlobalVar.Gantry_X_axis, GlobalVar.Gantry_Y_axis);
        //    if (sts[0] == "STA_AX_READY")
        //    {
        //        if (Form1.Nozzle_safe[0] > (GlobalVar.Nozzle_Z_Homeposs[1] + 0.5) || Form1.Nozzle_safe[1] > (GlobalVar.Nozzle_Z_Homeposs[2] + 0.5) || Form1.Nozzle_safe[2] > (GlobalVar.Nozzle_Z_Homeposs[3] + 0.5) || Form1.Nozzle_safe[3] > (GlobalVar.Nozzle_Z_Homeposs[4] + 0.5))
        //        {

        //            MessageBox.Show("MOVE ALL NOZZLE TO SAFE MM", "Warning Box", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //        }
        //        DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of XY axis and Make sure that X axis in Ahead of Zero Sensor condition ", "Confirmation Box", MessageBoxButtons.YesNo);
        //        if (dialogResult == DialogResult.Yes)
        //        {
        //            Homing.Pallet_Lifter_Homing = false;
        //            Homing.Nozzle_Axes_homing = false;
        //            Homing.X1Y1Gantry_Axes_homing = false;
        //            Homing.Set_Home_vel(GlobalVar.Gantry_X_axis, 20, GlobalVar.Gantry_X_PPR, GlobalVar.Gantry_X_pitch);
        //            Homing.Set_Home_vel(GlobalVar.Gantry_Y_axis, 20, GlobalVar.Gantry_Y_PPR, GlobalVar.Gantry_Y_pitch);

        //            bool process = Interface.Axes_Homing(GlobalVar.Gantry_Y_axis, 0);
        //            //Homing.Homing_step = 5;
        //            //Homing.Homing_Process_sts = true;
        //             lblXYhmeSts.BackColor = Color.Red;



        //        }
        //    }
        //}

        //private void button3_Click(object sender, EventArgs e)
        //{

        //    Nozzle.TogetCurrentPos_Nozzle_1();

        //    if (Nozzle.Nozzle_currentState[0] == "STA_AX_READY")
        //    {
        //        DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of Nozzle -1" + "-Make sure that Nozzle is Ahead of Home_Sensor ", "Confirmation Box", MessageBoxButtons.YesNo);
        //        if (dialogResult == DialogResult.Yes)
        //        {

        //            Homing.Set_Home_vel(GlobalVar.Nozzle_Z_Axis[1], 20, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Z_pitch);
        //            // Homing.Set_Home_vel(GlobalVar.Gantry_Y_axis, 20, GlobalVar.Gantry_Y_PPR, GlobalVar.Gantry_Y_pitch);

        //            bool process = Interface.Axes_Homing(GlobalVar.Nozzle_Z_Axis[1], 0);



        //        }
        //    }

        //}







        private void txtNozzlerefSave_Click(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtNozzle1.Text) && !string.IsNullOrEmpty(txtNozzle2.Text) && !string.IsNullOrEmpty(txtNozzle3.Text) && !string.IsNullOrEmpty(txtNozzle4.Text))
            //{
            //    GlobalVar.Nozzle_Ref[1] = Convert.ToInt32(txtNozzle1.Text);
            //    GlobalVar.Nozzle_Ref[2] = Convert.ToInt32(txtNozzle2.Text);
            //    GlobalVar.Nozzle_Ref[3] = Convert.ToInt32(txtNozzle3.Text);
            //    GlobalVar.Nozzle_Ref[4] = Convert.ToInt32(txtNozzle4.Text);
            //    //Task<bool> read = ToRetain.Write_Device_Sett_Values(GlobalVar.Gantry_X_axis, GlobalVar.Gantry_Y_axis, GlobalVar.Gantry_X_pitch, GlobalVar.Gantry_Y_pitch, GlobalVar.Gantry_X_PPR, GlobalVar.Gantry_Y_PPR, GlobalVar.Nozzle_Z_pitch, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Ang_pitch, GlobalVar.Nozzle_Ang_PPR, GlobalVar.Input_Conv_mot1_nodeid, GlobalVar.Input_Conv_mot2_nodeid, GlobalVar.process_Conv_mot1_nodeid, GlobalVar.process_Conv_mot2_nodeid, GlobalVar.Output_Conv_mot1_nodeid, GlobalVar.Output_Conv_mot2_nodeid, GlobalVar.input_conv_pitch, GlobalVar.input_conv_PPR, GlobalVar.FoamFeeder_LH_ID, GlobalVar.FoamFeeder_RH_ID, GlobalVar.FoamFeeder_PITCH, GlobalVar.FoamFeeder_PPR, GlobalVar.Nozzle_Z_Axis, GlobalVar.Nozzle_Ang_nodeid, GlobalVar.Nozzle_Ref, GlobalVar.Gantry_X_MIDIOConfig.O_axis, GlobalVar.Gantry_Y_MIDIOConfig.O_axis,AxisConfig.TotalAxiscount);

            //    //string IQuery = "insert into Axis_Setting (Datetime,Login_User,Changes,New_Value) values ('" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + GlobalVar.UserCode + "','Nozzle 1 Reff Position Sett','"+GlobalVar.Nozzle_Ref[1].ToString()+"')";
            //    ////SQLHelper.Executequery(IQuery);
            //    // IQuery = "insert into Axis_Setting (Datetime,Login_User,Changes,New_Value) values ('" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + GlobalVar.UserCode + "','Nozzle 2 Reff Position Sett','" + GlobalVar.Nozzle_Ref[2].ToString() + "')";
            //    //SQLHelper.Executequery(IQuery);
            //    // IQuery = "insert into Axis_Setting (Datetime,Login_User,Changes,New_Value) values ('" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + GlobalVar.UserCode + "','Nozzle 3 Reff Position Sett','" + GlobalVar.Nozzle_Ref[3].ToString() + "')";
            //    //SQLHelper.Executequery(IQuery);
            //    // IQuery = "insert into Axis_Setting (Datetime,Login_User,Changes,New_Value) values ('" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "','" + GlobalVar.UserCode + "','Nozzle 4 Reff Position Sett','" + GlobalVar.Nozzle_Ref[4].ToString() + "')";
            //    //SQLHelper.Executequery(IQuery);



            //    MessageBox.Show("KINDLY DO NOZZLE HOMING IN NOZZLE PAGE", "Warning Box", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}
            //else
            //{
            //    MessageBox.Show("please enter Nozzle Ref Degree w.r.to Sensor positon to picking position");
            //}
        }

        //private void btnN2_Zero_Click(object sender, EventArgs e)
        //{
        //    Nozzle.TogetCurrentPos_Nozzle_1();

        //    if (Nozzle.Nozzle_currentState[1] == "STA_AX_READY")
        //    {
        //        DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of Nozzle -2" + "-Make sure that Nozzle is Ahead of Home_Sensor", "Confirmation Box", MessageBoxButtons.YesNo);
        //        if (dialogResult == DialogResult.Yes)
        //        {

        //            Homing.Set_Home_vel(GlobalVar.Nozzle_Z_Axis[2], 20, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Z_pitch);
        //            // Homing.Set_Home_vel(GlobalVar.Gantry_Y_axis, 20, GlobalVar.Gantry_Y_PPR, GlobalVar.Gantry_Y_pitch);

        //            bool process = Interface.Axes_Homing(GlobalVar.Nozzle_Z_Axis[2], 0);


        //        }
        //    }
        //}

        //private void btnN3_Zero_Click(object sender, EventArgs e)
        //{
        //    Nozzle.TogetCurrentPos_Nozzle_1();

        //    if (Nozzle.Nozzle_currentState[2] == "STA_AX_READY")
        //    {
        //        DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of Nozzle -3" + "-Make sure that Nozzle is Ahead of Home_Sensor ", "Confirmation Box", MessageBoxButtons.YesNo);
        //        if (dialogResult == DialogResult.Yes)
        //        {
        //            Homing.Set_Home_vel(GlobalVar.Nozzle_Z_Axis[3], 20, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Z_pitch);
        //            // Homing.Set_Home_vel(GlobalVar.Gantry_Y_axis, 20, GlobalVar.Gantry_Y_PPR, GlobalVar.Gantry_Y_pitch);

        //            bool process = Interface.Axes_Homing(GlobalVar.Nozzle_Z_Axis[3], 0);



        //        }
        //    }
        //}

        //private void btnN4_Zero_Click(object sender, EventArgs e)
        //{
        //    //Nozzle.TogetCurrentPos_Nozzle_1();

        //    if (Nozzle.Nozzle_currentState[3] == "STA_AX_READY")
        //    {
        //        DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of Nozzle -4" + "-Make sure that Nozzle is Ahead of Home_Sensor ", "Confirmation Box", MessageBoxButtons.YesNo);
        //        if (dialogResult == DialogResult.Yes)
        //        {

        //           // Homing.Set_Home_vel(GlobalVar.Nozzle_Z_Axis[4], 20, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Z_pitch);
        //            // Homing.Set_Home_vel(GlobalVar.Gantry_Y_axis, 20, GlobalVar.Gantry_Y_PPR, GlobalVar.Gantry_Y_pitch);

        //          //  bool process = Interface.Axes_Homing(GlobalVar.Nozzle_Z_Axis[4], 0);



        //        }
        //    }
        //}
        bool R1_hme = false;
        bool R2_hme = false;
        bool R3_hme = false;
        bool R4_hme = false;
        private void btnZeroR1_Click(object sender, EventArgs e)
        {
            //    R1_hme = true;
            //    btnZeroR1.Enabled = false;
            //    //Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[1]);
            //    //Nozzle.Rotate_Nozzle_hme(GlobalVar.Nozzle_Ang_nodeid[1], -360);

            //btnZeroR1.Enabled = false;
            //btnZeroR2.Enabled = false;
            //btnZeroR3.Enabled = false;
            //btnZeroR4.Enabled = false;
        }

        private void btnZeroR2_Click(object sender, EventArgs e)
        {

            //    R2_hme = true;
            //    btnZeroR2.Enabled = false;
            //    //Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[2]);
            //    //Nozzle.Rotate_Nozzle_hme(GlobalVar.Nozzle_Ang_nodeid[2], -360);
            //btnZeroR1.Enabled = false;
            //btnZeroR2.Enabled = false;
            //btnZeroR3.Enabled = false;
            //btnZeroR4.Enabled = false;
        }

        private void btnZeroR3_Click(object sender, EventArgs e)
        {

            //    R3_hme = true;
            //    btnZeroR3.Enabled = false;
            ////Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[3]);
            ////Nozzle.Rotate_Nozzle_hme(GlobalVar.Nozzle_Ang_nodeid[3], -360);

            //btnZeroR1.Enabled = false;
            //btnZeroR2.Enabled = false;
            //btnZeroR3.Enabled = false;
            //btnZeroR4.Enabled = false;
        }

        private void btnZeroR4_Click(object sender, EventArgs e)
        {

            //    R4_hme = true;
            //    btnZeroR4.Enabled = false;
            //    //Interface.Set_Zero_Pos(GlobalVar.Nozzle_Ang_nodeid[4]);
            //    //Nozzle.Rotate_Nozzle_hme(GlobalVar.Nozzle_Ang_nodeid[4], -360);
            //btnZeroR1.Enabled = false;
            //btnZeroR2.Enabled = false;
            //btnZeroR3.Enabled = false;
            //btnZeroR4.Enabled = false;
        }
        bool[] X1_Axes_sts = new bool[3];
        bool[] Y1_Axes_sts = new bool[3];
        bool[] Z1_Axes_sts = new bool[3];
        bool[] Z2_Axes_sts = new bool[3];
        bool[] Z3_Axes_sts = new bool[3];
        bool[] Z4_Axes_sts = new bool[3];
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (R1_hme)
            {
                //if(DIOConfig.DI[DIOConfig.I_Rotary_hme1])
                //{
                //    Nozzle.Stop_Nozzle(GlobalVar.Nozzle_Ang_nodeid[1]);
                //    Nozzle.Set_Ref_Angle(GlobalVar.Nozzle_Ang_nodeid[1], GlobalVar.Nozzle_Ref[1]);
                //     R1_hme = false;
                //    Thread.Sleep(500);
                //    Nozzle.Set_Ref_Angle(GlobalVar.Nozzle_Ang_nodeid[1], GlobalVar.Nozzle_Ref[1]);
                //    btnZeroR1.Enabled = true;
                //    btnZeroR2.Enabled = true;
                //    btnZeroR3.Enabled = true;
                //    btnZeroR4.Enabled = true;
                //}
            }
            if (R2_hme)
            {
                //if (DIOConfig.DI[DIOConfig.I_Rotary_hme2])
                //{
                //    Nozzle.Stop_Nozzle(GlobalVar.Nozzle_Ang_nodeid[2]);
                //    Nozzle.Set_Ref_Angle(GlobalVar.Nozzle_Ang_nodeid[2], GlobalVar.Nozzle_Ref[2]);
                //    R2_hme = false;
                //    Thread.Sleep(500);
                //    Nozzle.Set_Ref_Angle(GlobalVar.Nozzle_Ang_nodeid[2], GlobalVar.Nozzle_Ref[2]);
                //    btnZeroR1.Enabled = true;
                //    btnZeroR2.Enabled = true;
                //    btnZeroR3.Enabled = true;
                //    btnZeroR4.Enabled = true;
                //}
            }
            if (R3_hme)
            {
                //    if (DIOConfig.DI[DIOConfig.I_Rotary_hme3])
                //    {
                //        Nozzle.Stop_Nozzle(GlobalVar.Nozzle_Ang_nodeid[3]);
                //        Nozzle.Set_Ref_Angle(GlobalVar.Nozzle_Ang_nodeid[3], GlobalVar.Nozzle_Ref[3]);
                //        R3_hme = false;
                //        btnZeroR3.Enabled = true;
                //        Thread.Sleep(500);
                //        Nozzle.Set_Ref_Angle(GlobalVar.Nozzle_Ang_nodeid[3], GlobalVar.Nozzle_Ref[3]);
                //        btnZeroR1.Enabled = true;
                //        btnZeroR2.Enabled = true;
                //        btnZeroR3.Enabled = true;
                //        btnZeroR4.Enabled = true;
                //    }
            }
            if (R4_hme)
            {
                //if (DIOConfig.DI[DIOConfig.I_Rotary_hme4])
                //{
                //    Nozzle.Stop_Nozzle(GlobalVar.Nozzle_Ang_nodeid[4]);
                //    Nozzle.Set_Ref_Angle(GlobalVar.Nozzle_Ang_nodeid[4], GlobalVar.Nozzle_Ref[4]);
                //    R4_hme = false;
                //    btnZeroR4.Enabled = true;
                //    Thread.Sleep(500);
                //    Nozzle.Set_Ref_Angle(GlobalVar.Nozzle_Ang_nodeid[4], GlobalVar.Nozzle_Ref[4]);
                //    btnZeroR1.Enabled = true;
                //    btnZeroR2.Enabled = true;
                //    btnZeroR3.Enabled = true;
                //    btnZeroR4.Enabled = true;
                //}
            }
            //if(!btnZeroX.Enabled && Homing.X1Y1Gantry_Axes_homing)
            //{
            //    btnZeroX.Enabled = true;
            //    btnZeroX.Text = "Set Zero Pos_XY";
            //    lblXYhmeSts.BackColor = Color.Green;
            //}
            //if (!btnAllAxesZero.Enabled && Homing.X1Y1Gantry_Axes_homing)
            //{
            //    btnAllAxesZero.Enabled = true;
            //    btnAllAxesZero.Text = "Initialize all Axes";
            //    lblZhmeSts.BackColor = Color.Green;
            //}

            //if (Homing.Homing_Process_sts)
            //{
            //    Homing.Homing_Process("");
            //}
            //X1_Axes_sts = Interface.Get_Axes_Home_status(GlobalVar.Gantry_X_axis);
            //Y1_Axes_sts = Interface.Get_Axes_Home_status(GlobalVar.Gantry_Y_axis);
            //Z1_Axes_sts = Interface.Get_Axes_Home_status(GlobalVar.Nozzle_Z_Axis[1]);
            //Z2_Axes_sts = Interface.Get_Axes_Home_status(GlobalVar.Nozzle_Z_Axis[2]);
            //Z3_Axes_sts = Interface.Get_Axes_Home_status(GlobalVar.Nozzle_Z_Axis[3]);
            //Z4_Axes_sts = Interface.Get_Axes_Home_status(GlobalVar.Nozzle_Z_Axis[4]);
            if (X1_Axes_sts[0])
            {
                lblMinX.BackColor = Color.Green;
            }
            else
            {
                lblMinX.BackColor = Color.Maroon;  //Changed 22-10-2024
            }
            if (X1_Axes_sts[1])
            {
                lblOrgX.BackColor = Color.Green;
            }
            else
            {
                lblOrgX.BackColor = Color.Maroon;
            }
            if (X1_Axes_sts[2])
            {
                lblMaxX.BackColor = Color.Green;
            }
            else
            {
                lblMaxX.BackColor = Color.Maroon;  //Changed 22-10-2024
            }
            if (Y1_Axes_sts[0])
            {
                lblMinY.BackColor = Color.Green;
            }
            else
            {
                lblMinY.BackColor = Color.Maroon;  //Changed 22-10-2024
            }
            if (Y1_Axes_sts[1])
            {
                lblOrgY.BackColor = Color.Green;
            }
            else
            {
                lblOrgY.BackColor = Color.Maroon;  //Changed 22-10-2024
            }
            if (Y1_Axes_sts[2])
            {
                lblMaxY.BackColor = Color.Green;
            }
            else
            {
                lblMaxY.BackColor = Color.Maroon;  //Changed 22-10-2024
            }
            if (Z1_Axes_sts[0])
            {
                //lblminZ1.BackColor = Color.Green;
            }
            else
            {
                //  lblminZ1.BackColor = Color.Red;
            }
            if (Z1_Axes_sts[1])
            {
                //lblOrgZ1.BackColor = Color.Green;
            }
            else
            {
                //lblOrgZ1.BackColor = Color.Red;
            }
            if (Z1_Axes_sts[2])
            {
                //lblmaxZ1.BackColor = Color.Green;
            }
            else
            {
                //lblmaxZ1.BackColor = Color.Red;
            }
            if (Z2_Axes_sts[0])
            {
                //lblminZ2.BackColor = Color.Green;
            }
            else
            {
                //lblminZ2.BackColor = Color.Red;
            }
            if (Z2_Axes_sts[1])
            {
                // lblOrgZ2.BackColor = Color.Green;
            }
            else
            {
                //lblOrgZ2.BackColor = Color.Red;
            }
            if (Z2_Axes_sts[2])
            {
                //lblmaxZ2.BackColor = Color.Green;
            }
            else
            {
                //lblmaxZ2.BackColor = Color.Red;
            }
            if (Z3_Axes_sts[0])
            {
                //lblminZ3.BackColor = Color.Green;
            }
            else
            {
                // lblminZ3.BackColor = Color.Red;
            }
            if (Z3_Axes_sts[1])
            {
                //lblOrgZ3.BackColor = Color.Green;
            }
            else
            {
                // lblOrgZ3.BackColor = Color.Red;
            }
            if (Z3_Axes_sts[2])
            {
                // lblmaxZ3.BackColor = Color.Green;
            }
            else
            {
                // lblmaxZ3.BackColor = Color.Red;
            }
            if (Z4_Axes_sts[0])
            {
                // lblminZ4.BackColor = Color.Green;
            }
            else
            {
                // lblminZ4.BackColor = Color.Red;
            }
            if (Z4_Axes_sts[1])
            {
                //lblOrgZ4.BackColor = Color.Green;
            }
            else
            {
                //lblOrgZ4.BackColor = Color.Red;
            }
            if (Z4_Axes_sts[2])
            {
                //lblmaxZ4.BackColor = Color.Green;
            }
            else
            {
                //lblmaxZ4.BackColor = Color.Red;
            }
        }

        //private void btnAllAxesZero_Click(object sender, EventArgs e)
        //{
        //    DialogResult dialogResult = MessageBox.Show("Are you Sure Want to Set the Zero position of XYZ axis and Make sure that lifter and stopper are in down ", "Confirmation Box", MessageBoxButtons.YesNo);
        //    if (dialogResult == DialogResult.Yes)
        //    {
        //        Homing.Set_Home_vel(GlobalVar.Nozzle_Z_Axis[1], 20, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Z_pitch);
        //        Homing.Set_Home_vel(GlobalVar.Nozzle_Z_Axis[2], 20, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Z_pitch);
        //        Homing.Set_Home_vel(GlobalVar.Nozzle_Z_Axis[3], 20, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Z_pitch);
        //        Homing.Set_Home_vel(GlobalVar.Nozzle_Z_Axis[4], 20, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Z_pitch);
        //        Homing.Set_Home_vel(GlobalVar.Gantry_X_axis, 20, GlobalVar.Gantry_X_PPR, GlobalVar.Gantry_X_pitch);
        //        Homing.Set_Home_vel(GlobalVar.Gantry_Y_axis, 20, GlobalVar.Gantry_Y_PPR, GlobalVar.Gantry_Y_pitch);
        //        Homing.Pallet_Lifter_Homing = false;
        //        Homing.Nozzle_Axes_homing = false;
        //        Homing.X1Y1Gantry_Axes_homing = false;
        //        Homing.Homing_step = 1;
        //        Homing.Homing_Process_sts = true;
        //        btnAllAxesZero.Text = "Homing...";
        //        btnAllAxesZero.Enabled = false;
        //        lblXYhmeSts.BackColor = Color.Red;
        //        lblZhmeSts.BackColor = Color.Red;
        //        // timer1.Enabled = true;


        //    }
        //}

        private void label40_Click(object sender, EventArgs e)
        {

        }

        private void label39_Click(object sender, EventArgs e)
        {

        }

        private void label38_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        //private void button1_Click_1(object sender, EventArgs e)
        //{
        //    AutoSequence.Auto_Status = 0;
        //    conveyor_esd.Conv_dryrun = true;
        //    InputConveyorProcess.start_Thread_inp_Convprcss();
        //    ProcessConveyorProcess.start_Thread_Prc_Convprcss();
        //    OutputConveyorProcess.start_Thread_OP_Convprcss();


        //}

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    conveyor_esd.Conv_dryrun = false;
        //    DIOConfig.WriteOPS(false, DIOConfig.O_WC_Inp_Buff_Motor1_2_Strt_Stop_ON);
        //    DIOConfig.WriteOPS(false, DIOConfig.O_WC_Cnvy_Motor1_2_Strt_Stop_ON);
        //    DIOConfig.WriteOPS(false, DIOConfig.O_WC_Outp_Buff_Motor1_2_Strt_Stop_ON);
        //    InputConveyorProcess.Stop_Thread_inp_Convprcss();
        //    ProcessConveyorProcess.Stop_Thread_Prc_Convprcss();
        //    OutputConveyorProcess.Stop_Thread_OP_Convprcss();
        //    InputConveyorProcess.loader_to_inputBuffer = false;
        //    InputConveyorProcess.inputBuffer_to_process = false;
        //    InputConveyorProcess.process_to_outputBuffer = false;
        //    InputConveyorProcess.outputBuffer_to_unloader = false;
        //}

        private void rotary_esd_MouseMove(object sender, MouseEventArgs e)
        {
            if (Form1.isengineeringmode)
            {
                Form1.lastEngineeringactivity = DateTime.Now;
            }
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void lblMinX_Click(object sender, EventArgs e)
        {

        }
    }
}
