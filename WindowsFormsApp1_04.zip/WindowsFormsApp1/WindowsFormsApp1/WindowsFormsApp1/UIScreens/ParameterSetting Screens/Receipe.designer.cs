﻿
using System.Windows.Forms;

namespace AHDP.UIScreens.ParameterSetting_Screens
{
    partial class Receipe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Receipe));
            this.tabPage_Gantry = new System.Windows.Forms.TabPage();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tEACHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mOVEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Current_Positions = new System.Windows.Forms.Timer(this.components);
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnEdit = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Gantry_right = new System.Windows.Forms.Button();
            this.Gantry_Up = new System.Windows.Forms.Button();
            this.Gantry_Down = new System.Windows.Forms.Button();
            this.Gantry_left = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Pick_Y = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Pick_X = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.Roller_Y = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Roller_Z = new System.Windows.Forms.TextBox();
            this.Roller_X = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.FI_Y = new System.Windows.Forms.TextBox();
            this.FI_X = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.BT_StopMove = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.Rel_Position = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnExport = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.cmbModelName = new System.Windows.Forms.ComboBox();
            this.Recipe_btnDownload = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.CCD_Parameters = new System.Windows.Forms.TabPage();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.Pick_Gantry = new System.Windows.Forms.TabPage();
            this.XY_Gantry_dataGridView = new System.Windows.Forms.DataGridView();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.Recipe_Heading = new System.Windows.Forms.Label();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.CCD_Parameters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.Pick_Gantry.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.XY_Gantry_dataGridView)).BeginInit();
            this.tabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage_Gantry
            // 
            this.tabPage_Gantry.Location = new System.Drawing.Point(4, 28);
            this.tabPage_Gantry.Name = "tabPage_Gantry";
            this.tabPage_Gantry.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Gantry.Size = new System.Drawing.Size(1101, 578);
            this.tabPage_Gantry.TabIndex = 0;
            this.tabPage_Gantry.Text = "X Y Gantry";
            this.tabPage_Gantry.UseVisualStyleBackColor = true;
            this.tabPage_Gantry.Click += new System.EventHandler(this.tabPage_pick_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tEACHToolStripMenuItem,
            this.mOVEToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(112, 48);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // tEACHToolStripMenuItem
            // 
            this.tEACHToolStripMenuItem.Name = "tEACHToolStripMenuItem";
            this.tEACHToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.tEACHToolStripMenuItem.Text = "TEACH";
            this.tEACHToolStripMenuItem.Click += new System.EventHandler(this.tEACHToolStripMenuItem_Click);
            // 
            // mOVEToolStripMenuItem
            // 
            this.mOVEToolStripMenuItem.Name = "mOVEToolStripMenuItem";
            this.mOVEToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.mOVEToolStripMenuItem.Text = "MOVE";
            this.mOVEToolStripMenuItem.Click += new System.EventHandler(this.mOVEToolStripMenuItem_Click);
            // 
            // Current_Positions
            // 
            this.Current_Positions.Enabled = true;
            this.Current_Positions.Interval = 50;
            this.Current_Positions.Tick += new System.EventHandler(this.Current_Positions_Tick);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnEdit);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.btnSave);
            this.groupBox5.Location = new System.Drawing.Point(9, 771);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1254, 62);
            this.groupBox5.TabIndex = 66;
            this.groupBox5.TabStop = false;
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.LightGray;
            this.btnEdit.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Edit4;
            this.btnEdit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEdit.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnEdit.ForeColor = System.Drawing.Color.Black;
            this.btnEdit.Location = new System.Drawing.Point(530, 9);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(50, 50);
            this.btnEdit.TabIndex = 56;
            this.btnEdit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(723, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "Save";
            this.label9.Click += new System.EventHandler(this.label1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(496, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Edit";
            this.label8.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.LightGray;
            this.btnSave.BackgroundImage = global::WindowsFormsApp1.Properties.Resources.Save1;
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.Black;
            this.btnSave.Location = new System.Drawing.Point(672, 9);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(50, 50);
            this.btnSave.TabIndex = 57;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Gantry_right);
            this.groupBox1.Controls.Add(this.Gantry_Up);
            this.groupBox1.Controls.Add(this.Gantry_Down);
            this.groupBox1.Controls.Add(this.Gantry_left);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Pick_Y);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Pick_X);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(18, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(374, 159);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Battery Pick Gantry";
            // 
            // Gantry_right
            // 
            this.Gantry_right.BackColor = System.Drawing.Color.Black;
            this.Gantry_right.Image = ((System.Drawing.Image)(resources.GetObject("Gantry_right.Image")));
            this.Gantry_right.Location = new System.Drawing.Point(125, 50);
            this.Gantry_right.Name = "Gantry_right";
            this.Gantry_right.Size = new System.Drawing.Size(60, 50);
            this.Gantry_right.TabIndex = 9;
            this.Gantry_right.UseVisualStyleBackColor = false;
            this.Gantry_right.Click += new System.EventHandler(this.button1_Click);
            // 
            // Gantry_Up
            // 
            this.Gantry_Up.BackColor = System.Drawing.Color.Black;
            this.Gantry_Up.Image = ((System.Drawing.Image)(resources.GetObject("Gantry_Up.Image")));
            this.Gantry_Up.Location = new System.Drawing.Point(66, 22);
            this.Gantry_Up.Name = "Gantry_Up";
            this.Gantry_Up.Size = new System.Drawing.Size(60, 50);
            this.Gantry_Up.TabIndex = 11;
            this.Gantry_Up.UseVisualStyleBackColor = false;
            this.Gantry_Up.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Gantry_Down
            // 
            this.Gantry_Down.BackColor = System.Drawing.Color.Black;
            this.Gantry_Down.Image = ((System.Drawing.Image)(resources.GetObject("Gantry_Down.Image")));
            this.Gantry_Down.Location = new System.Drawing.Point(66, 71);
            this.Gantry_Down.Name = "Gantry_Down";
            this.Gantry_Down.Size = new System.Drawing.Size(60, 50);
            this.Gantry_Down.TabIndex = 10;
            this.Gantry_Down.UseVisualStyleBackColor = false;
            this.Gantry_Down.Click += new System.EventHandler(this.button3_Click);
            // 
            // Gantry_left
            // 
            this.Gantry_left.BackColor = System.Drawing.Color.Black;
            this.Gantry_left.Image = ((System.Drawing.Image)(resources.GetObject("Gantry_left.Image")));
            this.Gantry_left.Location = new System.Drawing.Point(7, 50);
            this.Gantry_left.Name = "Gantry_left";
            this.Gantry_left.Size = new System.Drawing.Size(60, 50);
            this.Gantry_left.TabIndex = 12;
            this.Gantry_left.UseVisualStyleBackColor = false;
            this.Gantry_left.Click += new System.EventHandler(this.button4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(262, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Y Position (mm)";
            // 
            // Pick_Y
            // 
            this.Pick_Y.Enabled = false;
            this.Pick_Y.ForeColor = System.Drawing.Color.Black;
            this.Pick_Y.Location = new System.Drawing.Point(270, 91);
            this.Pick_Y.Name = "Pick_Y";
            this.Pick_Y.Size = new System.Drawing.Size(83, 23);
            this.Pick_Y.TabIndex = 4;
            this.Pick_Y.Text = "--";
            this.Pick_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Pick_Y.TextChanged += new System.EventHandler(this.Pick_Y_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(262, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "X Position (mm)";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Pick_X
            // 
            this.Pick_X.Enabled = false;
            this.Pick_X.ForeColor = System.Drawing.Color.Black;
            this.Pick_X.Location = new System.Drawing.Point(270, 35);
            this.Pick_X.Name = "Pick_X";
            this.Pick_X.Size = new System.Drawing.Size(83, 23);
            this.Pick_X.TabIndex = 1;
            this.Pick_X.Text = "--";
            this.Pick_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Pick_X.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button14);
            this.groupBox2.Controls.Add(this.button13);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.button8);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.Roller_Y);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.Roller_Z);
            this.groupBox2.Controls.Add(this.Roller_X);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(440, 94);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(374, 159);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Roller Gantry";
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Navy;
            this.button14.Image = ((System.Drawing.Image)(resources.GetObject("button14.Image")));
            this.button14.Location = new System.Drawing.Point(191, 81);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(60, 50);
            this.button14.TabIndex = 16;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Navy;
            this.button13.ForeColor = System.Drawing.Color.Black;
            this.button13.Image = ((System.Drawing.Image)(resources.GetObject("button13.Image")));
            this.button13.Location = new System.Drawing.Point(191, 27);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(60, 50);
            this.button13.TabIndex = 15;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Black;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(125, 55);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(60, 50);
            this.button5.TabIndex = 11;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Black;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.Location = new System.Drawing.Point(66, 27);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(60, 50);
            this.button6.TabIndex = 13;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Black;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.Location = new System.Drawing.Point(66, 76);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(60, 50);
            this.button7.TabIndex = 12;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Black;
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.Location = new System.Drawing.Point(7, 55);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(60, 50);
            this.button8.TabIndex = 14;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(262, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Y Position (mm)";
            // 
            // Roller_Y
            // 
            this.Roller_Y.Enabled = false;
            this.Roller_Y.ForeColor = System.Drawing.Color.Black;
            this.Roller_Y.Location = new System.Drawing.Point(270, 79);
            this.Roller_Y.Name = "Roller_Y";
            this.Roller_Y.Size = new System.Drawing.Size(83, 23);
            this.Roller_Y.TabIndex = 9;
            this.Roller_Y.Text = "--";
            this.Roller_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(264, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Z Position (mm)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(262, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "X Position (mm)";
            // 
            // Roller_Z
            // 
            this.Roller_Z.Enabled = false;
            this.Roller_Z.ForeColor = System.Drawing.Color.Black;
            this.Roller_Z.Location = new System.Drawing.Point(272, 128);
            this.Roller_Z.Name = "Roller_Z";
            this.Roller_Z.Size = new System.Drawing.Size(83, 23);
            this.Roller_Z.TabIndex = 5;
            this.Roller_Z.Text = "--";
            this.Roller_Z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Roller_X
            // 
            this.Roller_X.Enabled = false;
            this.Roller_X.ForeColor = System.Drawing.Color.Black;
            this.Roller_X.Location = new System.Drawing.Point(270, 29);
            this.Roller_X.Name = "Roller_X";
            this.Roller_X.Size = new System.Drawing.Size(83, 23);
            this.Roller_X.TabIndex = 6;
            this.Roller_X.Text = "--";
            this.Roller_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.FI_Y);
            this.groupBox3.Controls.Add(this.FI_X);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Controls.Add(this.button11);
            this.groupBox3.Controls.Add(this.button10);
            this.groupBox3.Controls.Add(this.button12);
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(862, 94);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(374, 159);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Final Inspection Gantry";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(261, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Y Position (mm)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(261, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "X Position (mm)";
            // 
            // FI_Y
            // 
            this.FI_Y.Enabled = false;
            this.FI_Y.ForeColor = System.Drawing.Color.Black;
            this.FI_Y.Location = new System.Drawing.Point(269, 90);
            this.FI_Y.Name = "FI_Y";
            this.FI_Y.Size = new System.Drawing.Size(83, 23);
            this.FI_Y.TabIndex = 9;
            this.FI_Y.Text = "--";
            this.FI_Y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FI_X
            // 
            this.FI_X.Enabled = false;
            this.FI_X.ForeColor = System.Drawing.Color.Black;
            this.FI_X.Location = new System.Drawing.Point(269, 34);
            this.FI_X.Name = "FI_X";
            this.FI_X.Size = new System.Drawing.Size(83, 23);
            this.FI_X.TabIndex = 10;
            this.FI_X.Text = "--";
            this.FI_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Black;
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.Location = new System.Drawing.Point(125, 48);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(60, 50);
            this.button9.TabIndex = 5;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Black;
            this.button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            this.button11.Location = new System.Drawing.Point(66, 20);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(60, 50);
            this.button11.TabIndex = 7;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Black;
            this.button10.Image = ((System.Drawing.Image)(resources.GetObject("button10.Image")));
            this.button10.Location = new System.Drawing.Point(66, 69);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(60, 50);
            this.button10.TabIndex = 6;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Black;
            this.button12.Image = ((System.Drawing.Image)(resources.GetObject("button12.Image")));
            this.button12.Location = new System.Drawing.Point(7, 48);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(60, 50);
            this.button12.TabIndex = 8;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Silver;
            this.groupBox4.Controls.Add(this.comboBox1);
            this.groupBox4.Controls.Add(this.BT_StopMove);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.Rel_Position);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(377, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(445, 80);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Move Options";
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Relative",
            "Absolute"});
            this.comboBox1.Location = new System.Drawing.Point(3, 36);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(171, 24);
            this.comboBox1.TabIndex = 30;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // BT_StopMove
            // 
            this.BT_StopMove.BackColor = System.Drawing.Color.Red;
            this.BT_StopMove.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.BT_StopMove.Location = new System.Drawing.Point(346, 14);
            this.BT_StopMove.Name = "BT_StopMove";
            this.BT_StopMove.Size = new System.Drawing.Size(86, 55);
            this.BT_StopMove.TabIndex = 29;
            this.BT_StopMove.Text = "Stop";
            this.BT_StopMove.UseVisualStyleBackColor = false;
            this.BT_StopMove.Click += new System.EventHandler(this.BT_StopMove_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(195, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Relative Position (mm)";
            // 
            // Rel_Position
            // 
            this.Rel_Position.Location = new System.Drawing.Point(216, 36);
            this.Rel_Position.Name = "Rel_Position";
            this.Rel_Position.Size = new System.Drawing.Size(83, 23);
            this.Rel_Position.TabIndex = 3;
            this.Rel_Position.Text = "--";
            this.Rel_Position.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.ForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(6, 504);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1254, 264);
            this.panel1.TabIndex = 65;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.LightGray;
            this.btnExport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnExport.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnExport.Location = new System.Drawing.Point(11, 170);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(67, 71);
            this.btnExport.TabIndex = 65;
            this.btnExport.Text = "Export";
            this.btnExport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Visible = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(0, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 23);
            this.label18.TabIndex = 62;
            // 
            // cmbModelName
            // 
            this.cmbModelName.DropDownHeight = 130;
            this.cmbModelName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbModelName.DropDownWidth = 190;
            this.cmbModelName.FormattingEnabled = true;
            this.cmbModelName.IntegralHeight = false;
            this.cmbModelName.Location = new System.Drawing.Point(3, 3);
            this.cmbModelName.Name = "cmbModelName";
            this.cmbModelName.Size = new System.Drawing.Size(98, 21);
            this.cmbModelName.TabIndex = 61;
            this.cmbModelName.Visible = false;
            this.cmbModelName.SelectedIndexChanged += new System.EventHandler(this.cmbModelName_SelectedIndexChanged_1);
            // 
            // Recipe_btnDownload
            // 
            this.Recipe_btnDownload.BackColor = System.Drawing.Color.LightGray;
            this.Recipe_btnDownload.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Recipe_btnDownload.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.Recipe_btnDownload.Location = new System.Drawing.Point(11, 313);
            this.Recipe_btnDownload.Name = "Recipe_btnDownload";
            this.Recipe_btnDownload.Size = new System.Drawing.Size(81, 71);
            this.Recipe_btnDownload.TabIndex = 66;
            this.Recipe_btnDownload.Text = "Download ";
            this.Recipe_btnDownload.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Recipe_btnDownload.UseVisualStyleBackColor = false;
            this.Recipe_btnDownload.Visible = false;
            this.Recipe_btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.Recipe_btnDownload);
            this.panel2.Controls.Add(this.cmbModelName);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.btnExport);
            this.panel2.Location = new System.Drawing.Point(765, 60);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(107, 389);
            this.panel2.TabIndex = 62;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // CCD_Parameters
            // 
            this.CCD_Parameters.Controls.Add(this.dataGridView6);
            this.CCD_Parameters.Location = new System.Drawing.Point(4, 25);
            this.CCD_Parameters.Name = "CCD_Parameters";
            this.CCD_Parameters.Size = new System.Drawing.Size(1254, 409);
            this.CCD_Parameters.TabIndex = 4;
            this.CCD_Parameters.Text = "CCD Parameters";
            this.CCD_Parameters.UseVisualStyleBackColor = true;
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(5, 3);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(1246, 403);
            this.dataGridView6.TabIndex = 0;
            // 
            // Pick_Gantry
            // 
            this.Pick_Gantry.Controls.Add(this.XY_Gantry_dataGridView);
            this.Pick_Gantry.Location = new System.Drawing.Point(4, 25);
            this.Pick_Gantry.Name = "Pick_Gantry";
            this.Pick_Gantry.Size = new System.Drawing.Size(1254, 409);
            this.Pick_Gantry.TabIndex = 5;
            this.Pick_Gantry.Text = "Battey Pick Gantry";
            this.Pick_Gantry.UseVisualStyleBackColor = true;
            // 
            // XY_Gantry_dataGridView
            // 
            this.XY_Gantry_dataGridView.AllowUserToAddRows = false;
            this.XY_Gantry_dataGridView.AllowUserToDeleteRows = false;
            this.XY_Gantry_dataGridView.BackgroundColor = System.Drawing.Color.White;
            this.XY_Gantry_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.XY_Gantry_dataGridView.GridColor = System.Drawing.Color.Black;
            this.XY_Gantry_dataGridView.Location = new System.Drawing.Point(7, 7);
            this.XY_Gantry_dataGridView.Name = "XY_Gantry_dataGridView";
            this.XY_Gantry_dataGridView.Size = new System.Drawing.Size(1244, 399);
            this.XY_Gantry_dataGridView.TabIndex = 0;
            this.XY_Gantry_dataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.XY_Gantry_dataGridView_CellMouseClick);
            this.XY_Gantry_dataGridView.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.XY_Gantry_dataGridView_CellMouseClick);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.Pick_Gantry);
            this.tabControl.Controls.Add(this.CCD_Parameters);
            this.tabControl.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl.Location = new System.Drawing.Point(2, 60);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1262, 438);
            this.tabControl.TabIndex = 63;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // Recipe_Heading
            // 
            this.Recipe_Heading.BackColor = System.Drawing.Color.Gainsboro;
            this.Recipe_Heading.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold);
            this.Recipe_Heading.ForeColor = System.Drawing.Color.Black;
            this.Recipe_Heading.Location = new System.Drawing.Point(562, 9);
            this.Recipe_Heading.Name = "Recipe_Heading";
            this.Recipe_Heading.Size = new System.Drawing.Size(115, 29);
            this.Recipe_Heading.TabIndex = 64;
            this.Recipe_Heading.Text = "RECIPE";
            this.Recipe_Heading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Recipe_Heading.Click += new System.EventHandler(this.label74_Click);
            // 
            // Receipe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1270, 788);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Recipe_Heading);
            this.Controls.Add(this.panel2);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(6, 140);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1270, 718);
            this.Name = "Receipe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Receipe";
            this.Load += new System.EventHandler(this.Receipe_Load_1);
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.CCD_Parameters.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.Pick_Gantry.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.XY_Gantry_dataGridView)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tabPage_Gantry;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tEACHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mOVEToolStripMenuItem;
        private System.Windows.Forms.Timer Current_Positions;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Pick_X;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Roller_Z;
        private System.Windows.Forms.TextBox Roller_X;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox FI_Y;
        private System.Windows.Forms.TextBox FI_X;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button BT_StopMove;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Rel_Position;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Label label18;
        public System.Windows.Forms.ComboBox cmbModelName;
        private System.Windows.Forms.Button Recipe_btnDownload;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabPage CCD_Parameters;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.TabPage Pick_Gantry;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.Label Recipe_Heading;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Pick_Y;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Roller_Y;
        private System.Windows.Forms.Button Gantry_right;
        private System.Windows.Forms.Button Gantry_Up;
        private System.Windows.Forms.Button Gantry_Down;
        private System.Windows.Forms.Button Gantry_left;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private DataGridView XY_Gantry_dataGridView;
    }
}