﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AHDP.UIScreens.ParameterSetting_Screens
{
    public partial class machine_settings : Form
    {
        public machine_settings()
        {
            InitializeComponent();
        }
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn
   (
       int nLeftRect,
       int nTopRect,
       int nRightRect,
       int nBottomRect,
       int nWidthEllipse,
       int nHeightEllipse
   );

        public void Panel_Shape()
        {
            //panel1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel1.Width,
            //panel1.Height, 30, 30));
            //   panel2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel2.Width,
            //panel2.Height, 30, 30));
            panel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel3.Width,
         panel3.Height, 30, 30));
            //panel4.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel4.Width,
            //panel4.Height, 30, 30));
            //   panel5.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel5.Width,
            //panel5.Height, 30, 30));
        }
        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void formfeeder_esd_Load(object sender, EventArgs e)
        {

            onload();

            Panel_Shape();
            if (Globalvariable.Login_user_mode.ToUpper() == "PRODUCTION")
            {
                panel3.Enabled = false;
            }
            else
            {
                panel3.Enabled = true;
            }
        }
        public void onload()
        {
            //    if(AutoSequence.Nozzle_Active[1])
            //    {
            //        tglN1.IsOn = false;  
            //    }
            //    else
            //    {
            //        tglN1.IsOn = true;
            //    }
            //    if (AutoSequence.Nozzle_Active[2])
            //    {
            //        tglN2.IsOn = false;
            //    }
            //    else
            //    {
            //        tglN2.IsOn = true;
            //    }
            //    if (AutoSequence.Nozzle_Active[3])
            //    {
            //        tglN3.IsOn = false;
            //    }
            //    else
            //    {
            //        tglN3.IsOn = true;
            //    }
            //    if (AutoSequence.Nozzle_Active[4])
            //    {
            //        tglN4.IsOn = false;
            //    }
            //    else
            //    {
            //        tglN4.IsOn = true;
            //    }

            txt_X_Gap_N1.Text = GlobalVar.X_Gap[1].ToString();
            txt_X_Gap_N2.Text = GlobalVar.X_Gap[2].ToString();
            txt_X_Gap_N3.Text = GlobalVar.X_Gap[3].ToString();
            // txt_X_Gap_N4.Text = GlobalVar.X_Gap[4].ToString();

            txt_Y_Gap_N1.Text = GlobalVar.Y_Gap[1].ToString();
            txt_Y_Gap_N2.Text = GlobalVar.Y_Gap[2].ToString();
            txt_Y_Gap_N3.Text = GlobalVar.Y_Gap[3].ToString();
            //txt_Y_Gap_N4.Text = GlobalVar.Y_Gap[4].ToString();

            //txt_Ang_Gap_N1.Text = GlobalVar.Ang_Gap[1].ToString();
            //txt_Ang_Gap_N2.Text = GlobalVar.Ang_Gap[2].ToString();
            //txt_Ang_Gap_N3.Text = GlobalVar.Ang_Gap[3].ToString();
            //txt_Ang_Gap_N4.Text = GlobalVar.Ang_Gap[4].ToString();
            //txtNozzle1.Text = GlobalVar.Nozzle_Ref[1].ToString();
            //txtNozzle2.Text = GlobalVar.Nozzle_Ref[2].ToString();
            //txtNozzle3.Text = GlobalVar.Nozzle_Ref[3].ToString();
            //txtNozzle4.Text = GlobalVar.Nozzle_Ref[4].ToString();
            timer1.Enabled = true;
        }
        private void btnStep_Mode_Click(object sender, EventArgs e)
        {
            //grpbox_stepmode.Enabled = true;
        }

        private void btnDry_Run_Click(object sender, EventArgs e)
        {

        }

        private void btnReset_Allbits_Click(object sender, EventArgs e)
        {

        }

        private void btnCamera_2_Click(object sender, EventArgs e)
        {

        }

        private void btnCamera_1_Click(object sender, EventArgs e)
        {


        }

        private void tglN1_Toggled(object sender, EventArgs e)
        {
            //if(tglN1.EditValue.ToString() == "False")
            //{
            //    //AutoSequence.Nozzle_Active[1] = true;
            //}
            //else
            //{
            //    //AutoSequence.Nozzle_Active[1] = false; 
            //}
            //ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg);
        }

        private void tglN2_Toggled(object sender, EventArgs e)
        {
            //if (tglN2.EditValue.ToString() == "False")
            //{
            //    //AutoSequence.Nozzle_Active[2] = true;
            //}
            //else
            //{
            //    //AutoSequence.Nozzle_Active[2] = false;
            //}
            //ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg);
        }

        private void tglN3_Toggled(object sender, EventArgs e)
        {
            //if (tglN3.EditValue.ToString() == "False")
            //{
            //    //AutoSequence.Nozzle_Active[3] = true;
            //}
            //else
            //{
            //    //AutoSequence.Nozzle_Active[3] = false;
            //}
            // ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg);
        }

        private void tglN4_Toggled(object sender, EventArgs e)
        {
            //if (tglN4.EditValue.ToString() == "False")
            //{
            //    //AutoSequence.Nozzle_Active[4] = true;
            //}
            //else
            //{
            //    //AutoSequence.Nozzle_Active[4] = false;
            //}
            // ToRetain.Write_manual_sett(GlobalVar.input_conv_vel, GlobalVar.input_conv_Acc, GlobalVar.input_conv_DAcc, GlobalVar.process_conv_vel1, GlobalVar.process_conv_vel2, GlobalVar.process_conv_Acc, GlobalVar.process_conv_DAcc, GlobalVar.output_conv_vel, GlobalVar.output_conv_Acc, GlobalVar.output_conv_DAcc, GlobalVar.Gantry_X_Acc, GlobalVar.Gantry_X_DAcc, GlobalVar.Gantry_Y_Acc, GlobalVar.Gantry_Y_DAcc, GlobalVar.Gantry_X_HomeVel, GlobalVar.Gantry_Y_HomeVel, GlobalVar.Gantry_X_ProcessVel, GlobalVar.Gantry_Y_ProcessVel, GlobalVar.Nozzle_Z_Acc, GlobalVar.Nozzle_Z_DAcc, GlobalVar.Nozzle_Ang_Acc, GlobalVar.Nozzle_Ang_DAcc, GlobalVar.Nozzle_Z_HomeVel, GlobalVar.Nozzle_Ang_HomeVel, GlobalVar.Nozzle_Z_ProcessVel, GlobalVar.Nozzle_Ang_ProcessVel, GlobalVar.FoamFeeder_Acc, GlobalVar.FoamFeeder_DAcc, GlobalVar.FoamFeeder_JogSpeed, GlobalVar.FoamFeeder_Speed, GlobalVar.Gantry_X_HomePos, GlobalVar.Gantry_Y_HomePos, GlobalVar.Nozzle_Z_HomePos, GlobalVar.Nozzle_Z2_HomePos, GlobalVar.Nozzle_Z3_HomePos, GlobalVar.Nozzle_Z4_HomePos, GlobalVar.Nozzle_Ang_HomePos, AutoSequence.Nozzle_bypass[1], AutoSequence.Nozzle_bypass[2], AutoSequence.Nozzle_bypass[3], AutoSequence.Nozzle_bypass[4], AutoSequence.Four_plus_two_foam, AutoSequence.Tray_cnt, GlobalVar.Feeder_Delay, AutoSequence.Four_Foams_only, GlobalVar.PulseMode, GlobalVar.PulseLogic, GlobalVar.PostCheck_Delay, GlobalVar.PostCheck_Retrycnt, GlobalVar.Gantry_X_Max_mm, GlobalVar.Gantry_X_Min_mm, GlobalVar.Gantry_Y_Max_mm, GlobalVar.Gantry_Y_Min_mm, GlobalVar.Nozzle_Z_Max_mm, GlobalVar.Nozzle_Z_Min_mm, GlobalVar.Nozzle_Ang_Max_deg, GlobalVar.Nozzle_Ang_Min_deg);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Static_and_Dynamic_test.Dynamic_gantry_test();
            //textBox1.Text = Static_and_Dynamic_test.Trig_cam_Dy.ToString();
            //textBox2.Text = Static_and_Dynamic_test.mst.ToString();
            //if (!AutoSequence.Post_Inspection)
            //{
            //    btn_Stop.Enabled = false;
            //    btn_Start.Enabled = true;
            //    lblPostvalidate.Text = "";
            //}
            //else
            //{
            //    lblPostvalidate.Text = "Final Inspection validation going on don't interupt....";
            //    btn_Stop.Enabled = true;
            //    btn_Start.Enabled = false;
            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            //Static_and_Dynamic_test.DynamicStep = 1;
        }
        public static int Repeatcnt = 0;
        private void txtRepetablitycnt_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtRepetablitycnt.Text))
            //{
            //    Repeatcnt = Convert.ToInt32(txtRepetablitycnt.Text);

            //}
        }

        private void btn_Save_offset_Click(object sender, EventArgs e)
        {

        }

        private void txt_X_Gap_offset_KeyPress(object sender, KeyPressEventArgs e)
        {
            Decimal_Validation(sender, e);
        }
        #region "Decimal Validation"
        public void Decimal_Validation(object sender, KeyPressEventArgs e)
        {
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }

            // checks to make sure only 1 decimal is allowed
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }
        #endregion

        private void btn_Save_Click(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txt_X_Gap_N1.Text) && !string.IsNullOrEmpty(txt_X_Gap_N2.Text) && !string.IsNullOrEmpty(txt_X_Gap_N3.Text) && !string.IsNullOrEmpty(txt_X_Gap_N4.Text) && !string.IsNullOrEmpty(txt_Y_Gap_N1.Text) && !string.IsNullOrEmpty(txt_Y_Gap_N2.Text) && !string.IsNullOrEmpty(txt_Y_Gap_N3.Text) && !string.IsNullOrEmpty(txt_Y_Gap_N4.Text) && !string.IsNullOrEmpty(txt_Ang_Gap_N1.Text) && !string.IsNullOrEmpty(txt_Ang_Gap_N2.Text) && !string.IsNullOrEmpty(txt_Ang_Gap_N3.Text) && !string.IsNullOrEmpty(txt_Ang_Gap_N4.Text)  )
            //{
            // GlobalVar.X_Gap[1]= Convert.ToDouble(txt_X_Gap_N1.Text);
            // GlobalVar.Y_Gap[1] = Convert.ToDouble(txt_Y_Gap_N1.Text);
            // //GlobalVar.Ang_Gap[1] = Convert.ToDouble(txt_Ang_Gap_N1.Text);
            // GlobalVar.X_Gap[2] = Convert.ToDouble(txt_X_Gap_N2.Text);
            // GlobalVar.Y_Gap[2] = Convert.ToDouble(txt_Y_Gap_N2.Text);
            //// GlobalVar.Ang_Gap[2] = Convert.ToDouble(txt_Ang_Gap_N2.Text);
            // GlobalVar.X_Gap[3] = Convert.ToDouble(txt_X_Gap_N3.Text);
            // GlobalVar.Y_Gap[3] = Convert.ToDouble(txt_Y_Gap_N3.Text);
            // //GlobalVar.Ang_Gap[3] = Convert.ToDouble(txt_Ang_Gap_N3.Text);
            // //GlobalVar.X_Gap[4] = Convert.ToDouble(txt_X_Gap_N4.Text);
            // //GlobalVar.Y_Gap[4] = Convert.ToDouble(txt_Y_Gap_N4.Text);
            // //GlobalVar.Ang_Gap[4] = Convert.ToDouble(txt_Ang_Gap_N4.Text);
            // //ToRetain.Write_Offset_sett(GlobalVar.X_Gap, GlobalVar.Y_Gap, GlobalVar.Ang_Gap);
            // MessageBox.Show("Offset Values Saved Successfully");
            //}
            //else
            //{
            //    MessageBox.Show("Kindly Enter All Values in Text Fields");
            //}
        }

        private void txt_X_Gap_N1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //Decimal_Validation(sender, e);
        }

        private void btn_Start_Click(object sender, EventArgs e)
        {
            //if (!AutoSequence.autoProcess && !AutoSequence.Post_Inspection)
            //{
            //    //if ( !DIOConfig.DI[DIOConfig.I_WC_Plt_Lift_Cyl_Up])//!DIOConfig.DI[DIOConfig.I_process_conv_tray_pres] &&
            //    //{
            //    //    MessageBox.Show("Check Tray presence in conveyor and Lift cyl in up position");
            //    //    return;
            //    //}
            //    if (AutoSequence.Ps_Cavity_number == 0 || AutoSequence.Ps_Cavity_number == 1)
            //    {
            //        AutoSequence.Ps_Cavity_number = AutoSequence.Cavity_number;
            //    }
            //    AutoSequence.Post_check_pos = File.ReadAllLines(Environment.CurrentDirectory + @"\Post_Check_Retain_path.txt");
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[1],GlobalVar.Nozzle_Z_Homeposs[1]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[2],GlobalVar.Nozzle_Z_Homeposs[2]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[3],GlobalVar.Nozzle_Z_Homeposs[3]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[4],GlobalVar.Nozzle_Z_Homeposs[4]);
            //    Form1.VisionRecieve_Q_TFC.Clear();
            //    //Array.Clear(Vision.TFC_array, 0, Vision.TFC_array.Length);
            //    AutoSequence.TFC_validation = AutoSequence.Ps_Cavity_number;
            //    ON_Fly_Precondition();
            //    AutoSequence.Post_seq = false;
            //    AutoSequence.Post_seq_step = 1;
            //    AutoSequence.Post_Inspection = true;

            //    AutoSequence.Retest_count = 0;
            //    if (Convert.ToInt32(txtStartCvitynum.Text)==AutoSequence.Total_No_of_Comp_in_col* AutoSequence.Total_No_of_Comp_in_row)
            //    {
            //        AutoSequence.On_Fly_Inspection_Active = true;
            //        AutoSequence.start_Thread_On_Fly_Post_seq_Check();
            //    }
            //    else
            //    {
            //        AutoSequence.start_Thread_Post_seq_Check();
            //    }
            //}

        }
        public static void ON_Fly_Precondition()
        {
            //if (!AutoSequence.autoProcess )
            //{
            //    //if (!DIOConfig.DI[DIOConfig.I_process_conv_tray_pres] && !DIOConfig.DI[DIOConfig.I_WC_Plt_Lift_Cyl_Up])
            //    //{
            //    //    MessageBox.Show("Check Tray presence in conveyor and Lift cyl in up position");
            //    //    return;
            //    //}
            //    if (AutoSequence.Ps_Cavity_number == 0 || AutoSequence.Ps_Cavity_number == 1)
            //    {
            //        AutoSequence.Ps_Cavity_number = AutoSequence.Cavity_number;
            //    }
            //    AutoSequence.Post_check_pos = File.ReadAllLines(Environment.CurrentDirectory + @"\Post_Check_Retain_path.txt");
            //    string[] Pos_Arrays = File.ReadAllLines(Environment.CurrentDirectory + @"\Post_Check_Retain_path.txt");
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[1],GlobalVar.Nozzle_Z_Homeposs[1]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[2],GlobalVar.Nozzle_Z_Homeposs[2]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[3],GlobalVar.Nozzle_Z_Homeposs[3]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[4],GlobalVar.Nozzle_Z_Homeposs[4]);
            //    Form1.VisionRecieve_Q_TFC.Clear();
            //    //Array.Clear(Vision.TFC_array, 0, Vision.TFC_array.Length);
            //    //Array.Clear(Vision.TFC_Onfly_array, 0, Vision.TFC_Onfly_array.Length);
            //    AutoSequence.TFC_validation = AutoSequence.Ps_Cavity_number;
            //    AutoSequence.Final_Cowling_Number = AutoSequence.Ps_Cavity_number;
            //    AutoSequence.Final_Inspection_Cowling = 3;
            //    AutoSequence.Post_seq = false;
            //    AutoSequence.Post_seq_step = 1;
            //    AutoSequence.Post_Inspection = true;
            //    AutoSequence.Row_num = 1;
            //    ////////////////////////////////For Onfly Check////////////////////////////////////////////
            //    string dtm = DateTime.Now.ToString("HHmmssfff");

            //    for (int i = 1; i < 251; i++)
            //    {
            //        string[] split = Pos_Arrays[i].Split(';');
            //        if (i == 26 || i == 51 || i == 76 || i == 101 || i == 126 || i == 151 || i == 176 || i == 201 || i == 226)
            //        {
            //            if (AutoSequence.Curr_pos_state == "ODD")
            //            {
            //                AutoSequence.Curr_pos_state = "EVEN";
            //            }
            //            else
            //            {
            //                AutoSequence.Curr_pos_state = "ODD";
            //            }
            //        }
            //        if (i == 1)
            //        {
            //            AutoSequence.Curr_pos_state = "ODD";
            //            AutoSequence.Row_num = i;
            //            AutoSequence.TFC_Onfly[AutoSequence.Row_num] = "TFC," + AutoSequence.Row_num.ToString() + "," + AutoSequence.Total_No_of_Comp_in_row.ToString() + "," + "TFC+SN1+" + dtm + "," + split[0] + ",Foam+Cowling," + split[1] + "," + split[2] + "," + "0";
            //            AutoSequence.Prev_pos_state = AutoSequence.Curr_pos_state;
            //            AutoSequence.Cowling_pitch = AutoSequence.Arc_Cowling_Horizontal_Gap;
            //            AutoSequence.Onfly_Start_position[AutoSequence.Row_num] = Convert.ToDouble(split[1]) - 5;
            //            AutoSequence.Onfly_Y_position[AutoSequence.Row_num] = Convert.ToDouble(split[2]);
            //        }
            //        else if (AutoSequence.Prev_pos_state == AutoSequence.Curr_pos_state)
            //        {
            //            AutoSequence.TFC_Onfly[AutoSequence.Row_num] = AutoSequence.TFC_Onfly[AutoSequence.Row_num] + "," + "TFC+SN1+" + dtm + "," + split[0] + ",Foam+Cowling," + split[1] + "," + split[2] + "," + "0";
            //        }
            //        else
            //        {

            //            AutoSequence.Row_num += 1;
            //            AutoSequence.TFC_Onfly[AutoSequence.Row_num] = "TFC," + AutoSequence.Row_num.ToString() + "," + AutoSequence.Total_No_of_Comp_in_row.ToString() + "," + "TFC+SN1+" + dtm + "," + split[0] + ",Foam+Cowling," + split[1] + "," + split[2] + "," + "0";
            //            if (AutoSequence.Prev_pos_state.ToUpper() == "ODD")
            //            {
            //                AutoSequence.Onfly_End_position[AutoSequence.Row_num - 1] = Convert.ToDouble(split[1]) + 5;
            //                AutoSequence.Onfly_Start_position[AutoSequence.Row_num] = Convert.ToDouble(split[1]) + 5;
            //            }
            //            else
            //            {
            //                if (AutoSequence.Row_num == 10)
            //                {

            //                }
            //                AutoSequence.Onfly_End_position[AutoSequence.Row_num - 1] = Convert.ToDouble(split[1]) - 5;
            //                AutoSequence.Onfly_Start_position[AutoSequence.Row_num] = Convert.ToDouble(split[1]) - 5;
            //            }
            //            AutoSequence.Onfly_Y_position[AutoSequence.Row_num] = Convert.ToDouble(split[2]);
            //            AutoSequence.Prev_pos_state = AutoSequence.Curr_pos_state;


            //        }
            //    }



            //    //////////////////////////////////////////////////////////////////////////////////////////
            //    AutoSequence.Retest_count = 0;
            //    AutoSequence.Row_num = 1;
            //   // AutoSequence.Onfly_End_position[10] = 254.00;
            //    AutoSequence.Curr_pos_state = "ODD";
            //    AutoSequence.Final_Inspection_vel = 150;
            //    ////if (Convert.ToInt32(txtStartCvitynum.Text) == AutoSequence.Total_No_of_Comp_in_col * AutoSequence.Total_No_of_Comp_in_row)
            //    ////{
            //    ////   // AutoSequence.start_Thread_On_Fly_Post_seq_Check();
            //    ////}
            //    ////else
            //    ////{
            //    ////   // AutoSequence.start_Thread_Post_seq_Check();
            //    ////}
            //}
        }
        public static void ON_Fly_Precondition_1()
        {
            //if (!AutoSequence.autoProcess && !AutoSequence.Post_Inspection)
            //{
            //    //if (!DIOConfig.DI[DIOConfig.I_process_conv_tray_pres] && !DIOConfig.DI[DIOConfig.I_WC_Plt_Lift_Cyl_Up])
            //    //{
            //    //    MessageBox.Show("Check Tray presence in conveyor and Lift cyl in up position");
            //    //    return;
            //    //}
            //    if (AutoSequence.Ps_Cavity_number == 0 || AutoSequence.Ps_Cavity_number == 1)
            //    {
            //        AutoSequence.Ps_Cavity_number = AutoSequence.Cavity_number;
            //    }
            //    AutoSequence.Post_check_pos = File.ReadAllLines(Environment.CurrentDirectory + @"\Post_Check_Retain_path.txt");
            //    string[] Pos_Arrays = File.ReadAllLines(Environment.CurrentDirectory + @"\Post_Check_Retain_path.txt");
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[1], GlobalVar.Nozzle_Z_Homeposs[1]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[2], GlobalVar.Nozzle_Z_Homeposs[2]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[3], GlobalVar.Nozzle_Z_Homeposs[3]);
            //    //Nozzle.Move_Nozzle_Home(GlobalVar.Nozzle_Z_Axis[4], GlobalVar.Nozzle_Z_Homeposs[4]);
            //    Form1.VisionRecieve_Q_TFC.Clear();
            //    //Array.Clear(Vision.TFC_array, 0, Vision.TFC_array.Length);
            //    //Array.Clear(Vision.TFC_Onfly_array, 0, Vision.TFC_Onfly_array.Length);
            //    AutoSequence.TFC_validation = AutoSequence.Ps_Cavity_number;
            //    AutoSequence.Final_Cowling_Number = AutoSequence.Ps_Cavity_number;
            //    AutoSequence.Final_Inspection_Cowling = 3;
            //    AutoSequence.Post_seq = false;
            //    AutoSequence.Post_seq_step = 1;
            //    AutoSequence.Post_Inspection = true;
            //    AutoSequence.Row_num = 1;
            //    ////////////////////////////////For Onfly Check////////////////////////////////////////////
            //    string dtm = DateTime.Now.ToString("HHmmssfff");

            //    for (int i = 1; i < 251; i++)
            //    {
            //        string[] split = Pos_Arrays[i].Split(';');
            //        if (i == 26 || i == 51 || i == 76 || i == 101 || i == 126 || i == 151 || i == 176 || i == 201 || i == 226)
            //        {
            //            if (AutoSequence.Curr_pos_state == "ODD")
            //            {
            //                AutoSequence.Curr_pos_state = "EVEN";
            //            }
            //            else
            //            {
            //                AutoSequence.Curr_pos_state = "ODD";
            //            }
            //        }
            //        if (i == 1)
            //        {
            //            AutoSequence.Curr_pos_state = "ODD";
            //            AutoSequence.Row_num = i;
            //            AutoSequence.TFC_Onfly[AutoSequence.Row_num] = "TFC," + AutoSequence.Row_num.ToString() + "," + AutoSequence.Total_No_of_Comp_in_row.ToString() + "," + "TFC+SN1+" + dtm + "," + split[0] + ",Foam+Cowling," + split[1] + "," + split[2] + "," + "0";
            //            AutoSequence.Prev_pos_state = AutoSequence.Curr_pos_state;
            //            AutoSequence.Cowling_pitch = AutoSequence.Arc_Cowling_Horizontal_Gap;
            //            AutoSequence.Onfly_Start_position[AutoSequence.Row_num] = Convert.ToDouble(split[1]) - 5;
            //            AutoSequence.Onfly_Y_position[AutoSequence.Row_num] = Convert.ToDouble(split[2]);
            //        }
            //        else if (AutoSequence.Prev_pos_state == AutoSequence.Curr_pos_state)
            //        {
            //            AutoSequence.TFC_Onfly[AutoSequence.Row_num] = AutoSequence.TFC_Onfly[AutoSequence.Row_num] + "," + "TFC+SN1+" + dtm + "," + split[0] + ",Foam+Cowling," + split[1] + "," + split[2] + "," + "0";
            //        }
            //        else
            //        {

            //            AutoSequence.Row_num += 1;
            //            AutoSequence.TFC_Onfly[AutoSequence.Row_num] = "TFC," + AutoSequence.Row_num.ToString() + "," + AutoSequence.Total_No_of_Comp_in_row.ToString() + "," + "TFC+SN1+" + dtm + "," + split[0] + ",Foam+Cowling," + split[1] + "," + split[2] + "," + "0";
            //            if (AutoSequence.Prev_pos_state.ToUpper() == "ODD")
            //            {
            //                AutoSequence.Onfly_End_position[AutoSequence.Row_num - 1] = Convert.ToDouble(split[1]) + 5;
            //                AutoSequence.Onfly_Start_position[AutoSequence.Row_num] = Convert.ToDouble(split[1]) + 5;
            //            }
            //            else
            //            {
            //                if (AutoSequence.Row_num == 10)
            //                {

            //                }
            //                AutoSequence.Onfly_End_position[AutoSequence.Row_num - 1] = Convert.ToDouble(split[1]) - 5;
            //                AutoSequence.Onfly_Start_position[AutoSequence.Row_num] = Convert.ToDouble(split[1]) - 5;
            //            }
            //            AutoSequence.Onfly_Y_position[AutoSequence.Row_num] = Convert.ToDouble(split[2]);
            //            AutoSequence.Prev_pos_state = AutoSequence.Curr_pos_state;


            //        }
            //    }



            //    //////////////////////////////////////////////////////////////////////////////////////////
            //    AutoSequence.Retest_count = 0;
            //    AutoSequence.Row_num = 1;
            //    // AutoSequence.Onfly_End_position[10] = 254.00;
            //    AutoSequence.Curr_pos_state = "ODD";
            //    AutoSequence.Final_Inspection_vel = 150;

            //}
        }

        private void btn_Stop_Click(object sender, EventArgs e)
        {
            //if (AutoSequence.Post_seq_step == 1 && AutoSequence.Post_Inspection && AutoSequence.Rej_Seq_step == 0)
            //{
            //    AutoSequence.Stop_Thread_Post_process();
            //}
            //if (AutoSequence.Post_seq_step == 1 && AutoSequence.Post_Inspection && AutoSequence.Rej_Seq_step == 0)
            //{
            //    AutoSequence.Stop_Thread_Post_process();
            //    AutoSequence.Stop_Thread_On_fly_Post_process();
            //    AutoSequence.Post_Inspection = false;


            //}
            //AutoSequence.Stop_Thread_Post_process();
            //AutoSequence.Stop_Thread_On_fly_Post_process();
            //AutoSequence.Post_Inspection = false;
        }

        private void txtStartCvitynum_TextChanged(object sender, EventArgs e)
        {

        }
        // int.TryParse(txt_strtCavityNum.Text,out AutoSequence.Cavity_number);
        private void txtStartCvitynum_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtStartCvitynum.Text))
            //{
            //    int.TryParse(txtStartCvitynum.Text, out AutoSequence.Cavity_number);
            //}
            //else
            //{
            //    MessageBox.Show("please enter cavity num ");
            //}
        }

        private void txtNozzlerefSave_Click(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtNozzle1.Text) && !string.IsNullOrEmpty(txtNozzle2.Text) && !string.IsNullOrEmpty(txtNozzle3.Text) && !string.IsNullOrEmpty(txtNozzle4.Text))
            //{
            //    GlobalVar.Nozzle_Ref[1] = Convert.ToInt32(txtNozzle1.Text);
            //    GlobalVar.Nozzle_Ref[2] = Convert.ToInt32(txtNozzle2.Text);
            //    GlobalVar.Nozzle_Ref[3] = Convert.ToInt32(txtNozzle3.Text);
            //    GlobalVar.Nozzle_Ref[4] = Convert.ToInt32(txtNozzle4.Text);
            //  //  Task<bool> read = ToRetain.Write_Device_Sett_Values(GlobalVar.Gantry_X_axis, GlobalVar.Gantry_Y_axis, GlobalVar.Gantry_X_pitch, GlobalVar.Gantry_Y_pitch, GlobalVar.Gantry_X_PPR, GlobalVar.Gantry_Y_PPR, GlobalVar.Nozzle_Z_pitch, GlobalVar.Nozzle_Z_PPR, GlobalVar.Nozzle_Ang_pitch, GlobalVar.Nozzle_Ang_PPR, GlobalVar.Input_Conv_mot1_nodeid, GlobalVar.Input_Conv_mot2_nodeid, GlobalVar.process_Conv_mot1_nodeid, GlobalVar.process_Conv_mot2_nodeid, GlobalVar.Output_Conv_mot1_nodeid, GlobalVar.Output_Conv_mot2_nodeid, GlobalVar.input_conv_pitch, GlobalVar.input_conv_PPR, GlobalVar.FoamFeeder_LH_ID, GlobalVar.FoamFeeder_RH_ID, GlobalVar.FoamFeeder_PITCH, GlobalVar.FoamFeeder_PPR, GlobalVar.Nozzle_Z_Axis, GlobalVar.Nozzle_Ang_nodeid, GlobalVar.Nozzle_Ref, GlobalVar.Gantry_X_MIDIOConfig.O_axis, GlobalVar.Gantry_Y_MIDIOConfig.O_axis,AxisConfig.TotalAxiscount);

            //    MessageBox.Show("Kindly do Nozzle Homing in Nozzle Page");
            //}
            //else
            //{
            //    MessageBox.Show("please enter Nozzle Ref Degree w.r.to Sensor positon to picking position");
            //}
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (Form1.isengineeringmode)
            {
                Form1.lastEngineeringactivity = DateTime.Now;
            }
        }

        private void txtrpreinspection_fail_cnt_Leave(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(txtrpreinspection_retry_cnt.Text))
            //{
            //    AutoSequence.Preinspection_re_try_cnt = int.Parse(txtrpreinspection_retry_cnt.Text);
            //}
            //else
            //{
            //    AutoSequence.Preinspection_re_try_cnt = 7;
            //}

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void txt_X_Gap_N1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Y_Gap_N1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
