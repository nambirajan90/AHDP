﻿
namespace AHDP
{
    partial class DeviceSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnGantry = new System.Windows.Forms.Button();
            this.txt_id_Y = new System.Windows.Forms.TextBox();
            this.txt_id_X = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_ppr_Y = new System.Windows.Forms.TextBox();
            this.txt_pitch_Y = new System.Windows.Forms.TextBox();
            this.txt_ppr_X = new System.Windows.Forms.TextBox();
            this.txt_pitch_X = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.R_txt_PR_Z = new System.Windows.Forms.TextBox();
            this.R_txt_PI_Z = new System.Windows.Forms.TextBox();
            this.R_txt_id_Z = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.R_txt_id_Y = new System.Windows.Forms.TextBox();
            this.R_txt_id_X = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.R_txt_PR_Y = new System.Windows.Forms.TextBox();
            this.R_txt_PI_Y = new System.Windows.Forms.TextBox();
            this.R_txt_PR_X = new System.Windows.Forms.TextBox();
            this.R_txt_PI_X = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.FI_txt_id_Y = new System.Windows.Forms.TextBox();
            this.FI_txt_id_X = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.FI_txt_PPR_Y = new System.Windows.Forms.TextBox();
            this.FI_txt_PI_Y = new System.Windows.Forms.TextBox();
            this.FI_txt_PPR_X = new System.Windows.Forms.TextBox();
            this.FI_txt_PI_X = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.labelControl13 = new System.Windows.Forms.Label();
            this.labelControl9 = new System.Windows.Forms.Label();
            this.labelControl8 = new System.Windows.Forms.Label();
            this.labelControl7 = new System.Windows.Forms.Label();
            this.labelControl12 = new System.Windows.Forms.Label();
            this.labelControl11 = new System.Windows.Forms.Label();
            this.labelControl10 = new System.Windows.Forms.Label();
            this.labelControl6 = new System.Windows.Forms.Label();
            this.labelControl5 = new System.Windows.Forms.Label();
            this.lblRoboIP = new System.Windows.Forms.Label();
            this.LabelCCD5 = new System.Windows.Forms.Label();
            this.LabelCCD4 = new System.Windows.Forms.Label();
            this.LabelCCD3 = new System.Windows.Forms.Label();
            this.lblPDCAIP = new System.Windows.Forms.Label();
            this.lblSFCIP = new System.Windows.Forms.Label();
            this.lblScannerIP = new System.Windows.Forms.Label();
            this.LabelCCD1 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.offlinemode = new System.Windows.Forms.RadioButton();
            this.onlinemode = new System.Windows.Forms.RadioButton();
            this.productionmode = new System.Windows.Forms.RadioButton();
            this.dryrun = new System.Windows.Forms.RadioButton();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.btnGantry);
            this.panel1.Controls.Add(this.txt_id_Y);
            this.panel1.Controls.Add(this.txt_id_X);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.txt_ppr_Y);
            this.panel1.Controls.Add(this.txt_pitch_Y);
            this.panel1.Controls.Add(this.txt_ppr_X);
            this.panel1.Controls.Add(this.txt_pitch_X);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(47, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(583, 218);
            this.panel1.TabIndex = 58;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnGantry
            // 
            this.btnGantry.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnGantry.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGantry.ForeColor = System.Drawing.Color.White;
            this.btnGantry.Location = new System.Drawing.Point(462, 170);
            this.btnGantry.Name = "btnGantry";
            this.btnGantry.Size = new System.Drawing.Size(99, 35);
            this.btnGantry.TabIndex = 94;
            this.btnGantry.Text = "Save";
            this.btnGantry.UseVisualStyleBackColor = false;
            this.btnGantry.Click += new System.EventHandler(this.btnGantry_Click);
            // 
            // txt_id_Y
            // 
            this.txt_id_Y.Location = new System.Drawing.Point(254, 91);
            this.txt_id_Y.Name = "txt_id_Y";
            this.txt_id_Y.Size = new System.Drawing.Size(71, 20);
            this.txt_id_Y.TabIndex = 51;
            this.txt_id_Y.TextChanged += new System.EventHandler(this.txt_id_Y_TextChanged);
            // 
            // txt_id_X
            // 
            this.txt_id_X.Location = new System.Drawing.Point(148, 91);
            this.txt_id_X.Name = "txt_id_X";
            this.txt_id_X.Size = new System.Drawing.Size(71, 20);
            this.txt_id_X.TabIndex = 50;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label35.Location = new System.Drawing.Point(32, 92);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(24, 18);
            this.label35.TabIndex = 49;
            this.label35.Text = "Id";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(283, 58);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(18, 18);
            this.label16.TabIndex = 47;
            this.label16.Text = "Y";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(175, 58);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(17, 18);
            this.label15.TabIndex = 46;
            this.label15.Text = "X";
            // 
            // txt_ppr_Y
            // 
            this.txt_ppr_Y.Location = new System.Drawing.Point(254, 179);
            this.txt_ppr_Y.Name = "txt_ppr_Y";
            this.txt_ppr_Y.Size = new System.Drawing.Size(71, 20);
            this.txt_ppr_Y.TabIndex = 44;
            // 
            // txt_pitch_Y
            // 
            this.txt_pitch_Y.Location = new System.Drawing.Point(254, 135);
            this.txt_pitch_Y.Name = "txt_pitch_Y";
            this.txt_pitch_Y.Size = new System.Drawing.Size(71, 20);
            this.txt_pitch_Y.TabIndex = 43;
            // 
            // txt_ppr_X
            // 
            this.txt_ppr_X.Location = new System.Drawing.Point(148, 179);
            this.txt_ppr_X.Name = "txt_ppr_X";
            this.txt_ppr_X.Size = new System.Drawing.Size(71, 20);
            this.txt_ppr_X.TabIndex = 40;
            // 
            // txt_pitch_X
            // 
            this.txt_pitch_X.Location = new System.Drawing.Point(148, 135);
            this.txt_pitch_X.Name = "txt_pitch_X";
            this.txt_pitch_X.Size = new System.Drawing.Size(71, 20);
            this.txt_pitch_X.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(32, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 18);
            this.label6.TabIndex = 28;
            this.label6.Text = "Pitch (mm)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(32, 180);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 18);
            this.label8.TabIndex = 29;
            this.label8.Text = "PPR";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(30, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 26);
            this.label1.TabIndex = 32;
            this.label1.Text = "Gantry";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gainsboro;
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.R_txt_PR_Z);
            this.panel2.Controls.Add(this.R_txt_PI_Z);
            this.panel2.Controls.Add(this.R_txt_id_Z);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.R_txt_id_Y);
            this.panel2.Controls.Add(this.R_txt_id_X);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.R_txt_PR_Y);
            this.panel2.Controls.Add(this.R_txt_PI_Y);
            this.panel2.Controls.Add(this.R_txt_PR_X);
            this.panel2.Controls.Add(this.R_txt_PI_X);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(47, 243);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(583, 218);
            this.panel2.TabIndex = 59;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(462, 170);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 35);
            this.button2.TabIndex = 99;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // R_txt_PR_Z
            // 
            this.R_txt_PR_Z.Location = new System.Drawing.Point(359, 179);
            this.R_txt_PR_Z.Name = "R_txt_PR_Z";
            this.R_txt_PR_Z.Size = new System.Drawing.Size(71, 20);
            this.R_txt_PR_Z.TabIndex = 98;
            // 
            // R_txt_PI_Z
            // 
            this.R_txt_PI_Z.Location = new System.Drawing.Point(359, 133);
            this.R_txt_PI_Z.Name = "R_txt_PI_Z";
            this.R_txt_PI_Z.Size = new System.Drawing.Size(71, 20);
            this.R_txt_PI_Z.TabIndex = 97;
            // 
            // R_txt_id_Z
            // 
            this.R_txt_id_Z.Location = new System.Drawing.Point(359, 89);
            this.R_txt_id_Z.Name = "R_txt_id_Z";
            this.R_txt_id_Z.Size = new System.Drawing.Size(71, 20);
            this.R_txt_id_Z.TabIndex = 96;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(376, 58);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(16, 18);
            this.label18.TabIndex = 95;
            this.label18.Text = "Z";
            // 
            // R_txt_id_Y
            // 
            this.R_txt_id_Y.Location = new System.Drawing.Point(254, 91);
            this.R_txt_id_Y.Name = "R_txt_id_Y";
            this.R_txt_id_Y.Size = new System.Drawing.Size(71, 20);
            this.R_txt_id_Y.TabIndex = 51;
            // 
            // R_txt_id_X
            // 
            this.R_txt_id_X.Location = new System.Drawing.Point(148, 91);
            this.R_txt_id_X.Name = "R_txt_id_X";
            this.R_txt_id_X.Size = new System.Drawing.Size(71, 20);
            this.R_txt_id_X.TabIndex = 50;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(32, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 18);
            this.label2.TabIndex = 49;
            this.label2.Text = "Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(283, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 18);
            this.label3.TabIndex = 47;
            this.label3.Text = "Y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(175, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 18);
            this.label4.TabIndex = 46;
            this.label4.Text = "X";
            // 
            // R_txt_PR_Y
            // 
            this.R_txt_PR_Y.Location = new System.Drawing.Point(254, 179);
            this.R_txt_PR_Y.Name = "R_txt_PR_Y";
            this.R_txt_PR_Y.Size = new System.Drawing.Size(71, 20);
            this.R_txt_PR_Y.TabIndex = 44;
            // 
            // R_txt_PI_Y
            // 
            this.R_txt_PI_Y.Location = new System.Drawing.Point(254, 135);
            this.R_txt_PI_Y.Name = "R_txt_PI_Y";
            this.R_txt_PI_Y.Size = new System.Drawing.Size(71, 20);
            this.R_txt_PI_Y.TabIndex = 43;
            // 
            // R_txt_PR_X
            // 
            this.R_txt_PR_X.Location = new System.Drawing.Point(148, 179);
            this.R_txt_PR_X.Name = "R_txt_PR_X";
            this.R_txt_PR_X.Size = new System.Drawing.Size(71, 20);
            this.R_txt_PR_X.TabIndex = 40;
            this.R_txt_PR_X.TextChanged += new System.EventHandler(this.R_txt_PR_X_TextChanged);
            // 
            // R_txt_PI_X
            // 
            this.R_txt_PI_X.Location = new System.Drawing.Point(148, 135);
            this.R_txt_PI_X.Name = "R_txt_PI_X";
            this.R_txt_PI_X.Size = new System.Drawing.Size(71, 20);
            this.R_txt_PI_X.TabIndex = 39;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(32, 136);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 18);
            this.label5.TabIndex = 28;
            this.label5.Text = "Pitch (mm)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(32, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 18);
            this.label7.TabIndex = 29;
            this.label7.Text = "PPR";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(30, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 26);
            this.label9.TabIndex = 32;
            this.label9.Text = "Roller";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.FI_txt_id_Y);
            this.panel3.Controls.Add(this.FI_txt_id_X);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.FI_txt_PPR_Y);
            this.panel3.Controls.Add(this.FI_txt_PI_Y);
            this.panel3.Controls.Add(this.FI_txt_PPR_X);
            this.panel3.Controls.Add(this.FI_txt_PI_X);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Location = new System.Drawing.Point(47, 473);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(583, 218);
            this.panel3.TabIndex = 60;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(462, 170);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 35);
            this.button1.TabIndex = 94;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FI_txt_id_Y
            // 
            this.FI_txt_id_Y.Location = new System.Drawing.Point(254, 91);
            this.FI_txt_id_Y.Name = "FI_txt_id_Y";
            this.FI_txt_id_Y.Size = new System.Drawing.Size(71, 20);
            this.FI_txt_id_Y.TabIndex = 51;
            // 
            // FI_txt_id_X
            // 
            this.FI_txt_id_X.Location = new System.Drawing.Point(148, 91);
            this.FI_txt_id_X.Name = "FI_txt_id_X";
            this.FI_txt_id_X.Size = new System.Drawing.Size(71, 20);
            this.FI_txt_id_X.TabIndex = 50;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(32, 92);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 18);
            this.label10.TabIndex = 49;
            this.label10.Text = "Id";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(283, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 18);
            this.label11.TabIndex = 47;
            this.label11.Text = "Y";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(175, 58);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 18);
            this.label12.TabIndex = 46;
            this.label12.Text = "X";
            // 
            // FI_txt_PPR_Y
            // 
            this.FI_txt_PPR_Y.Location = new System.Drawing.Point(254, 179);
            this.FI_txt_PPR_Y.Name = "FI_txt_PPR_Y";
            this.FI_txt_PPR_Y.Size = new System.Drawing.Size(71, 20);
            this.FI_txt_PPR_Y.TabIndex = 44;
            // 
            // FI_txt_PI_Y
            // 
            this.FI_txt_PI_Y.Location = new System.Drawing.Point(254, 135);
            this.FI_txt_PI_Y.Name = "FI_txt_PI_Y";
            this.FI_txt_PI_Y.Size = new System.Drawing.Size(71, 20);
            this.FI_txt_PI_Y.TabIndex = 43;
            // 
            // FI_txt_PPR_X
            // 
            this.FI_txt_PPR_X.Location = new System.Drawing.Point(148, 179);
            this.FI_txt_PPR_X.Name = "FI_txt_PPR_X";
            this.FI_txt_PPR_X.Size = new System.Drawing.Size(71, 20);
            this.FI_txt_PPR_X.TabIndex = 40;
            // 
            // FI_txt_PI_X
            // 
            this.FI_txt_PI_X.Location = new System.Drawing.Point(148, 135);
            this.FI_txt_PI_X.Name = "FI_txt_PI_X";
            this.FI_txt_PI_X.Size = new System.Drawing.Size(71, 20);
            this.FI_txt_PI_X.TabIndex = 39;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(32, 136);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 18);
            this.label13.TabIndex = 28;
            this.label13.Text = "Pitch (mm)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(32, 180);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(39, 18);
            this.label14.TabIndex = 29;
            this.label14.Text = "PPR";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(30, 13);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(214, 26);
            this.label17.TabIndex = 32;
            this.label17.Text = "Final Inspection";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.White;
            this.groupBox4.Controls.Add(this.labelControl13);
            this.groupBox4.Controls.Add(this.labelControl9);
            this.groupBox4.Controls.Add(this.labelControl8);
            this.groupBox4.Controls.Add(this.labelControl7);
            this.groupBox4.Controls.Add(this.labelControl12);
            this.groupBox4.Controls.Add(this.labelControl11);
            this.groupBox4.Controls.Add(this.labelControl10);
            this.groupBox4.Controls.Add(this.labelControl6);
            this.groupBox4.Controls.Add(this.labelControl5);
            this.groupBox4.Controls.Add(this.lblRoboIP);
            this.groupBox4.Controls.Add(this.LabelCCD5);
            this.groupBox4.Controls.Add(this.LabelCCD4);
            this.groupBox4.Controls.Add(this.LabelCCD3);
            this.groupBox4.Controls.Add(this.lblPDCAIP);
            this.groupBox4.Controls.Add(this.lblSFCIP);
            this.groupBox4.Controls.Add(this.lblScannerIP);
            this.groupBox4.Controls.Add(this.LabelCCD1);
            this.groupBox4.Controls.Add(this.linkLabel1);
            this.groupBox4.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(40, 25);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 487);
            this.groupBox4.TabIndex = 61;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Device IP Details";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // labelControl13
            // 
            this.labelControl13.AutoSize = true;
            this.labelControl13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl13.Location = new System.Drawing.Point(35, 249);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(47, 13);
            this.labelControl13.TabIndex = 37;
            this.labelControl13.Text = "Robot :";
            // 
            // labelControl9
            // 
            this.labelControl9.AutoSize = true;
            this.labelControl9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl9.Location = new System.Drawing.Point(35, 223);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(43, 13);
            this.labelControl9.TabIndex = 36;
            this.labelControl9.Text = "PDCA :";
            // 
            // labelControl8
            // 
            this.labelControl8.AutoSize = true;
            this.labelControl8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl8.Location = new System.Drawing.Point(36, 197);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(33, 13);
            this.labelControl8.TabIndex = 35;
            this.labelControl8.Text = "SFC :";
            // 
            // labelControl7
            // 
            this.labelControl7.AutoSize = true;
            this.labelControl7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl7.Location = new System.Drawing.Point(35, 175);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(59, 13);
            this.labelControl7.TabIndex = 34;
            this.labelControl7.Text = "Scanner :";
            // 
            // labelControl12
            // 
            this.labelControl12.AutoSize = true;
            this.labelControl12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl12.Location = new System.Drawing.Point(36, 152);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(42, 13);
            this.labelControl12.TabIndex = 33;
            this.labelControl12.Text = "CCD5 :";
            // 
            // labelControl11
            // 
            this.labelControl11.AutoSize = true;
            this.labelControl11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl11.Location = new System.Drawing.Point(36, 127);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(42, 13);
            this.labelControl11.TabIndex = 32;
            this.labelControl11.Text = "CCD4 :";
            // 
            // labelControl10
            // 
            this.labelControl10.AutoSize = true;
            this.labelControl10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl10.Location = new System.Drawing.Point(36, 101);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(42, 13);
            this.labelControl10.TabIndex = 31;
            this.labelControl10.Text = "CCD3 :";
            // 
            // labelControl6
            // 
            this.labelControl6.AutoSize = true;
            this.labelControl6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.labelControl6.Location = new System.Drawing.Point(36, 75);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(42, 13);
            this.labelControl6.TabIndex = 30;
            this.labelControl6.Text = "CCD1 :";
            this.labelControl6.Click += new System.EventHandler(this.labelControl6_Click);
            // 
            // labelControl5
            // 
            this.labelControl5.AutoSize = true;
            this.labelControl5.Font = new System.Drawing.Font("Verdana", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.labelControl5.Location = new System.Drawing.Point(36, 39);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(155, 18);
            this.labelControl5.TabIndex = 29;
            this.labelControl5.Text = "Device IP Details";
            this.labelControl5.Click += new System.EventHandler(this.labelControl5_Click);
            // 
            // lblRoboIP
            // 
            this.lblRoboIP.AutoSize = true;
            this.lblRoboIP.Location = new System.Drawing.Point(94, 248);
            this.lblRoboIP.Name = "lblRoboIP";
            this.lblRoboIP.Size = new System.Drawing.Size(44, 17);
            this.lblRoboIP.TabIndex = 28;
            this.lblRoboIP.Text = "label6";
            // 
            // LabelCCD5
            // 
            this.LabelCCD5.AutoSize = true;
            this.LabelCCD5.Location = new System.Drawing.Point(94, 152);
            this.LabelCCD5.Name = "LabelCCD5";
            this.LabelCCD5.Size = new System.Drawing.Size(44, 17);
            this.LabelCCD5.TabIndex = 26;
            this.LabelCCD5.Text = "label6";
            // 
            // LabelCCD4
            // 
            this.LabelCCD4.AutoSize = true;
            this.LabelCCD4.Location = new System.Drawing.Point(94, 127);
            this.LabelCCD4.Name = "LabelCCD4";
            this.LabelCCD4.Size = new System.Drawing.Size(44, 17);
            this.LabelCCD4.TabIndex = 24;
            this.LabelCCD4.Text = "label6";
            // 
            // LabelCCD3
            // 
            this.LabelCCD3.AutoSize = true;
            this.LabelCCD3.Location = new System.Drawing.Point(94, 101);
            this.LabelCCD3.Name = "LabelCCD3";
            this.LabelCCD3.Size = new System.Drawing.Size(44, 17);
            this.LabelCCD3.TabIndex = 22;
            this.LabelCCD3.Text = "label6";
            // 
            // lblPDCAIP
            // 
            this.lblPDCAIP.AutoSize = true;
            this.lblPDCAIP.Location = new System.Drawing.Point(94, 222);
            this.lblPDCAIP.Name = "lblPDCAIP";
            this.lblPDCAIP.Size = new System.Drawing.Size(44, 17);
            this.lblPDCAIP.TabIndex = 20;
            this.lblPDCAIP.Text = "label6";
            // 
            // lblSFCIP
            // 
            this.lblSFCIP.AutoSize = true;
            this.lblSFCIP.Location = new System.Drawing.Point(94, 196);
            this.lblSFCIP.Name = "lblSFCIP";
            this.lblSFCIP.Size = new System.Drawing.Size(44, 17);
            this.lblSFCIP.TabIndex = 19;
            this.lblSFCIP.Text = "label6";
            // 
            // lblScannerIP
            // 
            this.lblScannerIP.AutoSize = true;
            this.lblScannerIP.Location = new System.Drawing.Point(94, 174);
            this.lblScannerIP.Name = "lblScannerIP";
            this.lblScannerIP.Size = new System.Drawing.Size(44, 17);
            this.lblScannerIP.TabIndex = 18;
            this.lblScannerIP.Text = "label6";
            // 
            // LabelCCD1
            // 
            this.LabelCCD1.AutoSize = true;
            this.LabelCCD1.Location = new System.Drawing.Point(94, 75);
            this.LabelCCD1.Name = "LabelCCD1";
            this.LabelCCD1.Size = new System.Drawing.Size(44, 17);
            this.LabelCCD1.TabIndex = 17;
            this.LabelCCD1.Text = "label6";
            this.LabelCCD1.Click += new System.EventHandler(this.LabelCCD1_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Location = new System.Drawing.Point(6, 429);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(296, 45);
            this.linkLabel1.TabIndex = 16;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Note: For Changing device IP go to below path \"D:\\TEAL\\NOVA\\DLL\\ConnectionDetails" +
    ".XML\"";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(182, 545);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 35);
            this.button3.TabIndex = 100;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(40, 545);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(99, 35);
            this.button4.TabIndex = 101;
            this.button4.Text = "Edit";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gainsboro;
            this.panel4.Controls.Add(this.groupBox1);
            this.panel4.Controls.Add(this.button4);
            this.panel4.Controls.Add(this.button3);
            this.panel4.Controls.Add(this.groupBox4);
            this.panel4.Location = new System.Drawing.Point(699, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(741, 679);
            this.panel4.TabIndex = 102;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.offlinemode);
            this.groupBox1.Controls.Add(this.onlinemode);
            this.groupBox1.Controls.Add(this.productionmode);
            this.groupBox1.Controls.Add(this.dryrun);
            this.groupBox1.Controls.Add(this.checkBox4);
            this.groupBox1.Controls.Add(this.checkBox3);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(405, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(270, 482);
            this.groupBox1.TabIndex = 63;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "System Settings";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // offlinemode
            // 
            this.offlinemode.AutoSize = true;
            this.offlinemode.Location = new System.Drawing.Point(13, 140);
            this.offlinemode.Name = "offlinemode";
            this.offlinemode.Size = new System.Drawing.Size(107, 21);
            this.offlinemode.TabIndex = 30;
            this.offlinemode.TabStop = true;
            this.offlinemode.Text = "Offline Mode";
            this.offlinemode.UseVisualStyleBackColor = true;
            // 
            // onlinemode
            // 
            this.onlinemode.AutoSize = true;
            this.onlinemode.Location = new System.Drawing.Point(12, 106);
            this.onlinemode.Name = "onlinemode";
            this.onlinemode.Size = new System.Drawing.Size(105, 21);
            this.onlinemode.TabIndex = 29;
            this.onlinemode.TabStop = true;
            this.onlinemode.Text = "Online Mode";
            this.onlinemode.UseVisualStyleBackColor = true;
            // 
            // productionmode
            // 
            this.productionmode.AutoSize = true;
            this.productionmode.Location = new System.Drawing.Point(12, 73);
            this.productionmode.Name = "productionmode";
            this.productionmode.Size = new System.Drawing.Size(129, 21);
            this.productionmode.TabIndex = 28;
            this.productionmode.TabStop = true;
            this.productionmode.Text = "Production Mode";
            this.productionmode.UseVisualStyleBackColor = true;
            // 
            // dryrun
            // 
            this.dryrun.AutoSize = true;
            this.dryrun.Location = new System.Drawing.Point(12, 41);
            this.dryrun.Name = "dryrun";
            this.dryrun.Size = new System.Drawing.Size(79, 21);
            this.dryrun.TabIndex = 27;
            this.dryrun.TabStop = true;
            this.dryrun.Text = "Dry Run";
            this.dryrun.UseVisualStyleBackColor = true;
            this.dryrun.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(15, 290);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(110, 21);
            this.checkBox4.TabIndex = 26;
            this.checkBox4.Text = "PDCA Bypass";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(15, 249);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(99, 21);
            this.checkBox3.TabIndex = 25;
            this.checkBox3.Text = "SFC Bypass";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(15, 214);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(146, 21);
            this.checkBox2.TabIndex = 24;
            this.checkBox2.Text = "Safety Door Bypass";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(15, 177);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(123, 21);
            this.checkBox1.TabIndex = 23;
            this.checkBox1.Text = "Scanner Bypass";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // DeviceSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 248);
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.Name = "DeviceSettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "DeviceSettings";
            this.Load += new System.EventHandler(this.DeviceSettings_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txt_ppr_Y;
        private System.Windows.Forms.TextBox txt_pitch_Y;
        private System.Windows.Forms.TextBox txt_ppr_X;
        private System.Windows.Forms.TextBox txt_pitch_X;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox txt_id_Y;
        private System.Windows.Forms.TextBox txt_id_X;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button btnGantry;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox R_txt_id_Y;
        private System.Windows.Forms.TextBox R_txt_id_X;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox R_txt_PR_Y;
        private System.Windows.Forms.TextBox R_txt_PI_Y;
        private System.Windows.Forms.TextBox R_txt_PR_X;
        private System.Windows.Forms.TextBox R_txt_PI_X;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox R_txt_PR_Z;
        private System.Windows.Forms.TextBox R_txt_PI_Z;
        private System.Windows.Forms.TextBox R_txt_id_Z;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox FI_txt_id_Y;
        private System.Windows.Forms.TextBox FI_txt_id_X;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox FI_txt_PPR_Y;
        private System.Windows.Forms.TextBox FI_txt_PI_Y;
        private System.Windows.Forms.TextBox FI_txt_PPR_X;
        private System.Windows.Forms.TextBox FI_txt_PI_X;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblPDCAIP;
        private System.Windows.Forms.Label lblSFCIP;
        private System.Windows.Forms.Label lblScannerIP;
        private System.Windows.Forms.Label LabelCCD1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label LabelCCD3;
        private System.Windows.Forms.Label LabelCCD5;
        private System.Windows.Forms.Label LabelCCD4;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label lblRoboIP;
        //private System.Windows.Forms.Label labelControl1;
        //private System.Windows.Forms.Label labelControl2;
        //private System.Windows.Forms.Label labelControl4;
        //private System.Windows.Forms.Label labelControl3;
        //private System.Windows.Forms.Label labelControl5;
        //private System.Windows.Forms.Label labelControl6;
        //private System.Windows.Forms.Label labelControl7;
        //private System.Windows.Forms.Label labelControl8;
        //private System.Windows.Forms.Label labelControl9;
        //private System.Windows.Forms.Label labelControl10;
        //private System.Windows.Forms.Label labelControl11;
        //private System.Windows.Forms.Label labelControl12;
        //private System.Windows.Forms.Label labelControl13;
        private System.Windows.Forms.RadioButton offlinemode;
        private System.Windows.Forms.RadioButton onlinemode;
        private System.Windows.Forms.RadioButton productionmode;
        private System.Windows.Forms.RadioButton dryrun;
        private System.Windows.Forms.Label labelControl5;
        private System.Windows.Forms.Label labelControl10;
        private System.Windows.Forms.Label labelControl6;
        private System.Windows.Forms.Label labelControl9;
        private System.Windows.Forms.Label labelControl8;
        private System.Windows.Forms.Label labelControl7;
        private System.Windows.Forms.Label labelControl12;
        private System.Windows.Forms.Label labelControl11;
        private System.Windows.Forms.Label labelControl13;
    }
    }