﻿
namespace AHDP.UIScreens.ParameterSetting_Screens
{
    partial class machine_settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(machine_settings));
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtrpreinspection_retry_cnt = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.lblPostvalidate = new System.Windows.Forms.Label();
            this.txtStartCvitynum = new System.Windows.Forms.TextBox();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_Start = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_Y_Gap_N3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_X_Gap_N3 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txt_Y_Gap_N2 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txt_X_Gap_N2 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_Y_Gap_N1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_X_Gap_N1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Controls.Add(this.groupBox4);
            this.panel3.Location = new System.Drawing.Point(28, 37);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1555, 584);
            this.panel3.TabIndex = 5;
            this.panel3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel3_MouseMove);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.txtrpreinspection_retry_cnt);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.lblPostvalidate);
            this.groupBox2.Controls.Add(this.txtStartCvitynum);
            this.groupBox2.Controls.Add(this.btn_Stop);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.btn_Start);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(700, 49);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(297, 198);
            this.groupBox2.TabIndex = 92;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Post Check Seq";
            // 
            // txtrpreinspection_retry_cnt
            // 
            this.txtrpreinspection_retry_cnt.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrpreinspection_retry_cnt.Location = new System.Drawing.Point(199, 160);
            this.txtrpreinspection_retry_cnt.Name = "txtrpreinspection_retry_cnt";
            this.txtrpreinspection_retry_cnt.Size = new System.Drawing.Size(66, 26);
            this.txtrpreinspection_retry_cnt.TabIndex = 98;
            this.txtrpreinspection_retry_cnt.Leave += new System.EventHandler(this.txtrpreinspection_fail_cnt_Leave);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(20, 166);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(173, 14);
            this.label38.TabIndex = 97;
            this.label38.Text = "Preinspection Re-try count";
            // 
            // lblPostvalidate
            // 
            this.lblPostvalidate.AutoSize = true;
            this.lblPostvalidate.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPostvalidate.ForeColor = System.Drawing.Color.Red;
            this.lblPostvalidate.Location = new System.Drawing.Point(14, 89);
            this.lblPostvalidate.Name = "lblPostvalidate";
            this.lblPostvalidate.Size = new System.Drawing.Size(0, 14);
            this.lblPostvalidate.TabIndex = 96;
            // 
            // txtStartCvitynum
            // 
            this.txtStartCvitynum.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStartCvitynum.Location = new System.Drawing.Point(177, 44);
            this.txtStartCvitynum.Name = "txtStartCvitynum";
            this.txtStartCvitynum.Size = new System.Drawing.Size(66, 26);
            this.txtStartCvitynum.TabIndex = 92;
            this.txtStartCvitynum.TextChanged += new System.EventHandler(this.txtStartCvitynum_TextChanged);
            this.txtStartCvitynum.Leave += new System.EventHandler(this.txtStartCvitynum_Leave);
            // 
            // btn_Stop
            // 
            this.btn_Stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btn_Stop.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Stop.ForeColor = System.Drawing.Color.White;
            this.btn_Stop.Location = new System.Drawing.Point(154, 102);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(99, 35);
            this.btn_Stop.TabIndex = 95;
            this.btn_Stop.Text = "Stop";
            this.btn_Stop.UseVisualStyleBackColor = false;
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(20, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 14);
            this.label10.TabIndex = 91;
            this.label10.Text = "Start Cavity Num";
            // 
            // btn_Start
            // 
            this.btn_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btn_Start.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Start.ForeColor = System.Drawing.Color.White;
            this.btn_Start.Location = new System.Drawing.Point(23, 101);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(99, 35);
            this.btn_Start.TabIndex = 94;
            this.btn_Start.Text = "Start";
            this.btn_Start.UseVisualStyleBackColor = false;
            this.btn_Start.Click += new System.EventHandler(this.btn_Start_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox4.Controls.Add(this.btn_Save);
            this.groupBox4.Controls.Add(this.groupBox1);
            this.groupBox4.Controls.Add(this.groupBox7);
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.groupBox4.ForeColor = System.Drawing.Color.Black;
            this.groupBox4.Location = new System.Drawing.Point(34, 49);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(628, 402);
            this.groupBox4.TabIndex = 90;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Settings";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btn_Save.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Location = new System.Drawing.Point(497, 317);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(99, 35);
            this.btn_Save.TabIndex = 85;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txt_Y_Gap_N3);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txt_X_Gap_N3);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(18, 199);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(376, 178);
            this.groupBox1.TabIndex = 91;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Final Inspection Settings";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(231, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 14);
            this.label5.TabIndex = 89;
            this.label5.Text = "mm";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(234, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 14);
            this.label7.TabIndex = 90;
            this.label7.Text = "mm";
            // 
            // txt_Y_Gap_N3
            // 
            this.txt_Y_Gap_N3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Y_Gap_N3.Location = new System.Drawing.Point(164, 62);
            this.txt_Y_Gap_N3.Name = "txt_Y_Gap_N3";
            this.txt_Y_Gap_N3.Size = new System.Drawing.Size(66, 26);
            this.txt_Y_Gap_N3.TabIndex = 86;
            this.txt_Y_Gap_N3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_X_Gap_N1_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 67);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 14);
            this.label9.TabIndex = 85;
            this.label9.Text = "Y_Gap_Offset_N3";
            // 
            // txt_X_Gap_N3
            // 
            this.txt_X_Gap_N3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_X_Gap_N3.Location = new System.Drawing.Point(163, 28);
            this.txt_X_Gap_N3.Name = "txt_X_Gap_N3";
            this.txt_X_Gap_N3.Size = new System.Drawing.Size(66, 26);
            this.txt_X_Gap_N3.TabIndex = 84;
            this.txt_X_Gap_N3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_X_Gap_N1_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(7, 33);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 14);
            this.label11.TabIndex = 83;
            this.label11.Text = "X_Gap_Offset_N3";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Transparent;
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Controls.Add(this.textBox1);
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Controls.Add(this.txt_Y_Gap_N2);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.txt_X_Gap_N2);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox7.Location = new System.Drawing.Point(318, 40);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(278, 141);
            this.groupBox7.TabIndex = 92;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Roller Settings";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(231, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 14);
            this.label2.TabIndex = 93;
            this.label2.Text = "mm";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(163, 94);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(66, 26);
            this.textBox1.TabIndex = 92;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 14);
            this.label1.TabIndex = 91;
            this.label1.Text = "Z_Gap_Offset";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(231, 33);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 14);
            this.label24.TabIndex = 89;
            this.label24.Text = "mm";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(231, 67);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 14);
            this.label26.TabIndex = 90;
            this.label26.Text = "mm";
            // 
            // txt_Y_Gap_N2
            // 
            this.txt_Y_Gap_N2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Y_Gap_N2.Location = new System.Drawing.Point(164, 62);
            this.txt_Y_Gap_N2.Name = "txt_Y_Gap_N2";
            this.txt_Y_Gap_N2.Size = new System.Drawing.Size(66, 26);
            this.txt_Y_Gap_N2.TabIndex = 86;
            this.txt_Y_Gap_N2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_X_Gap_N1_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(7, 67);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(91, 14);
            this.label28.TabIndex = 85;
            this.label28.Text = "Y_Gap_Offset";
            // 
            // txt_X_Gap_N2
            // 
            this.txt_X_Gap_N2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_X_Gap_N2.Location = new System.Drawing.Point(163, 28);
            this.txt_X_Gap_N2.Name = "txt_X_Gap_N2";
            this.txt_X_Gap_N2.Size = new System.Drawing.Size(66, 26);
            this.txt_X_Gap_N2.TabIndex = 84;
            this.txt_X_Gap_N2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_X_Gap_N1_KeyPress);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(6, 34);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(92, 14);
            this.label29.TabIndex = 83;
            this.label29.Text = "X_Gap_Offset";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.txt_Y_Gap_N1);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.txt_X_Gap_N1);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold);
            this.groupBox5.Location = new System.Drawing.Point(18, 40);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(278, 141);
            this.groupBox5.TabIndex = 85;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Gantry Settings";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(235, 34);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 14);
            this.label12.TabIndex = 89;
            this.label12.Text = "mm";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(234, 67);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 14);
            this.label14.TabIndex = 90;
            this.label14.Text = "mm";
            // 
            // txt_Y_Gap_N1
            // 
            this.txt_Y_Gap_N1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Y_Gap_N1.Location = new System.Drawing.Point(164, 62);
            this.txt_Y_Gap_N1.Name = "txt_Y_Gap_N1";
            this.txt_Y_Gap_N1.Size = new System.Drawing.Size(66, 26);
            this.txt_Y_Gap_N1.TabIndex = 86;
            this.txt_Y_Gap_N1.TextChanged += new System.EventHandler(this.txt_Y_Gap_N1_TextChanged);
            this.txt_Y_Gap_N1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_X_Gap_N1_KeyPress);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(7, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 14);
            this.label16.TabIndex = 85;
            this.label16.Text = "Y_Gap_Offset";
            // 
            // txt_X_Gap_N1
            // 
            this.txt_X_Gap_N1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_X_Gap_N1.Location = new System.Drawing.Point(163, 28);
            this.txt_X_Gap_N1.Name = "txt_X_Gap_N1";
            this.txt_X_Gap_N1.Size = new System.Drawing.Size(66, 26);
            this.txt_X_Gap_N1.TabIndex = 84;
            this.txt_X_Gap_N1.TextChanged += new System.EventHandler(this.txt_X_Gap_N1_TextChanged);
            this.txt_X_Gap_N1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_X_Gap_N1_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 34);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(92, 14);
            this.label17.TabIndex = 83;
            this.label17.Text = "X_Gap_Offset";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "ServoHome.png");
            this.imageList1.Images.SetKeyName(1, "ServoMove.png");
            this.imageList1.Images.SetKeyName(2, "Stop.png");
            this.imageList1.Images.SetKeyName(3, "Save.png");
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // machine_settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 248);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimizeBox = false;
            this.Name = "machine_settings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "formfeeder_esd";
            this.Load += new System.EventHandler(this.formfeeder_esd_Load);
            this.panel3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_Y_Gap_N1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txt_X_Gap_N1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_Y_Gap_N3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_X_Gap_N3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txt_Y_Gap_N2;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txt_X_Gap_N2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_Stop;
        private System.Windows.Forms.Button btn_Start;
        private System.Windows.Forms.TextBox txtStartCvitynum;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblPostvalidate;
        private System.Windows.Forms.TextBox txtrpreinspection_retry_cnt;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
    }
}