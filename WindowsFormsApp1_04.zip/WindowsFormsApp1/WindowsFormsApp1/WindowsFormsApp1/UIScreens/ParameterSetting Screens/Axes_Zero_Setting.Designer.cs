﻿
namespace AHDP
{
    partial class rotary_esd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.btnAllAxesZero = new System.Windows.Forms.Button();
            this.lblZhmeSts = new System.Windows.Forms.Label();
            this.lblXYhmeSts = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblMinX = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblOrgY = new System.Windows.Forms.Label();
            this.lblMaxY = new System.Windows.Forms.Label();
            this.lblMinY = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblOrgX = new System.Windows.Forms.Label();
            this.btnHmeY = new System.Windows.Forms.Button();
            this.lblMaxX = new System.Windows.Forms.Label();
            this.btnZeroY = new System.Windows.Forms.Button();
            this.btnHmeX = new System.Windows.Forms.Button();
            this.btnZeroX = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtYhme = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtXhme = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(24, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1546, 681);
            this.panel1.TabIndex = 46;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox2.Controls.Add(this.label60);
            this.groupBox2.Controls.Add(this.label59);
            this.groupBox2.Controls.Add(this.label58);
            this.groupBox2.Controls.Add(this.label57);
            this.groupBox2.Controls.Add(this.label56);
            this.groupBox2.Controls.Add(this.label55);
            this.groupBox2.Controls.Add(this.label54);
            this.groupBox2.Controls.Add(this.button16);
            this.groupBox2.Controls.Add(this.button15);
            this.groupBox2.Controls.Add(this.label53);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.label52);
            this.groupBox2.Controls.Add(this.button9);
            this.groupBox2.Controls.Add(this.button10);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.button11);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.button12);
            this.groupBox2.Controls.Add(this.label47);
            this.groupBox2.Controls.Add(this.button13);
            this.groupBox2.Controls.Add(this.button14);
            this.groupBox2.Controls.Add(this.label48);
            this.groupBox2.Controls.Add(this.label49);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.label50);
            this.groupBox2.Controls.Add(this.label51);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(105, 442);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(818, 224);
            this.groupBox2.TabIndex = 106;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Roller XYZ Axis Setting";
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.Maroon;
            this.label60.Location = new System.Drawing.Point(630, 178);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(26, 26);
            this.label60.TabIndex = 143;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.Maroon;
            this.label59.Location = new System.Drawing.Point(583, 179);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(26, 26);
            this.label59.TabIndex = 142;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.Color.Maroon;
            this.label58.Location = new System.Drawing.Point(539, 178);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(26, 26);
            this.label58.TabIndex = 141;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label57.Location = new System.Drawing.Point(635, 154);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(21, 14);
            this.label57.TabIndex = 140;
            this.label57.Text = "EL";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label56.Location = new System.Drawing.Point(584, 154);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(33, 14);
            this.label56.TabIndex = 139;
            this.label56.Text = "ORG";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label55.Location = new System.Drawing.Point(543, 154);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(22, 14);
            this.label55.TabIndex = 138;
            this.label55.Text = "NL";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label54.Location = new System.Drawing.Point(476, 186);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(43, 14);
            this.label54.TabIndex = 137;
            this.label54.Text = "Z Axis";
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button16.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(547, 109);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(153, 37);
            this.button16.TabIndex = 136;
            this.button16.Text = "Set Zero Pos_Z";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button15.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(358, 114);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(130, 32);
            this.button15.TabIndex = 135;
            this.button15.Text = "Set Home Pos_Z";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(253, 119);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(39, 14);
            this.label53.TabIndex = 134;
            this.label53.Text = "(mm)";
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(150, 114);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(90, 26);
            this.textBox5.TabIndex = 133;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label52.Location = new System.Drawing.Point(21, 119);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(106, 14);
            this.label52.TabIndex = 132;
            this.label52.Text = "Z axis Home Pos";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button9.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(751, 168);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(61, 37);
            this.button9.TabIndex = 131;
            this.button9.Text = "Stop";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button10.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(687, 168);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(42, 37);
            this.button10.TabIndex = 130;
            this.button10.Text = "Set Zero Pos_N1";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label34.Location = new System.Drawing.Point(411, 154);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(21, 14);
            this.label34.TabIndex = 129;
            this.label34.Text = "EL";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label35.Location = new System.Drawing.Point(358, 154);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(33, 14);
            this.label35.TabIndex = 128;
            this.label35.Text = "ORG";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label36.Location = new System.Drawing.Point(322, 154);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(22, 14);
            this.label36.TabIndex = 127;
            this.label36.Text = "NL";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label37.Location = new System.Drawing.Point(192, 154);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(21, 14);
            this.label37.TabIndex = 126;
            this.label37.Text = "EL";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label38.Location = new System.Drawing.Point(141, 154);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(33, 14);
            this.label38.TabIndex = 125;
            this.label38.Text = "ORG";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label39.Location = new System.Drawing.Point(95, 154);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(22, 14);
            this.label39.TabIndex = 124;
            this.label39.Text = "NL";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label40.Location = new System.Drawing.Point(249, 185);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(43, 14);
            this.label40.TabIndex = 120;
            this.label40.Text = "Y Axis";
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.Maroon;
            this.label41.Location = new System.Drawing.Point(357, 179);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(26, 26);
            this.label41.TabIndex = 123;
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.Maroon;
            this.label42.Location = new System.Drawing.Point(406, 179);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(26, 26);
            this.label42.TabIndex = 122;
            // 
            // label43
            // 
            this.label43.BackColor = System.Drawing.Color.Maroon;
            this.label43.Location = new System.Drawing.Point(318, 179);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(26, 26);
            this.label43.TabIndex = 121;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label44.Location = new System.Drawing.Point(21, 185);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(44, 14);
            this.label44.TabIndex = 116;
            this.label44.Text = "X Axis";
            // 
            // label45
            // 
            this.label45.BackColor = System.Drawing.Color.Maroon;
            this.label45.Location = new System.Drawing.Point(146, 183);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(26, 26);
            this.label45.TabIndex = 119;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button11.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(358, 70);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(130, 32);
            this.button11.TabIndex = 90;
            this.button11.Text = "Set Home Pos_Y";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.Maroon;
            this.label46.Location = new System.Drawing.Point(191, 184);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(26, 26);
            this.label46.TabIndex = 118;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button12.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(547, 66);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(153, 37);
            this.button12.TabIndex = 89;
            this.button12.Text = "Set Zero Pos_Y";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // label47
            // 
            this.label47.BackColor = System.Drawing.Color.Maroon;
            this.label47.Location = new System.Drawing.Point(91, 183);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(26, 26);
            this.label47.TabIndex = 117;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button13.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(358, 23);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(128, 37);
            this.button13.TabIndex = 88;
            this.button13.Text = "Set Home Pos_X";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button14.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(546, 22);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(153, 37);
            this.button14.TabIndex = 87;
            this.button14.Text = "Set Zero Pos_X";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(253, 77);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(39, 14);
            this.label48.TabIndex = 86;
            this.label48.Text = "(mm)";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label49.Location = new System.Drawing.Point(21, 77);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(106, 14);
            this.label49.TabIndex = 85;
            this.label49.Text = "Y axis Home Pos";
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(150, 72);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(90, 26);
            this.textBox3.TabIndex = 84;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(253, 35);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(39, 14);
            this.label50.TabIndex = 83;
            this.label50.Text = "(mm)";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label51.Location = new System.Drawing.Point(23, 35);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(107, 14);
            this.label51.TabIndex = 82;
            this.label51.Text = "X axis Home Pos";
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(150, 30);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(90, 26);
            this.textBox4.TabIndex = 35;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.button8);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(105, 252);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(818, 174);
            this.groupBox1.TabIndex = 105;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Final Inspection XY Axis Setting";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(751, 126);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(61, 37);
            this.button3.TabIndex = 131;
            this.button3.Text = "Stop";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(687, 126);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(42, 37);
            this.button4.TabIndex = 130;
            this.button4.Text = "Set Zero Pos_N1";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(411, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 14);
            this.label1.TabIndex = 129;
            this.label1.Text = "EL";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(358, 112);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 14);
            this.label15.TabIndex = 128;
            this.label15.Text = "ORG";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label16.Location = new System.Drawing.Point(322, 112);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 14);
            this.label16.TabIndex = 127;
            this.label16.Text = "NL";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(192, 112);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 14);
            this.label17.TabIndex = 126;
            this.label17.Text = "EL";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(141, 112);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(33, 14);
            this.label18.TabIndex = 125;
            this.label18.Text = "ORG";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(95, 112);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(22, 14);
            this.label19.TabIndex = 124;
            this.label19.Text = "NL";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(249, 143);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 14);
            this.label20.TabIndex = 120;
            this.label20.Text = "Y Axis";
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.Maroon;
            this.label21.Location = new System.Drawing.Point(357, 137);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(26, 26);
            this.label21.TabIndex = 123;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Maroon;
            this.label22.Location = new System.Drawing.Point(406, 137);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(26, 26);
            this.label22.TabIndex = 122;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.Maroon;
            this.label23.Location = new System.Drawing.Point(318, 137);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 26);
            this.label23.TabIndex = 121;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label24.Location = new System.Drawing.Point(21, 143);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 14);
            this.label24.TabIndex = 116;
            this.label24.Text = "X Axis";
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.Maroon;
            this.label25.Location = new System.Drawing.Point(146, 141);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(26, 26);
            this.label25.TabIndex = 119;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button5.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(358, 70);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(130, 32);
            this.button5.TabIndex = 90;
            this.button5.Text = "Set Home Pos_Y";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.Maroon;
            this.label26.Location = new System.Drawing.Point(191, 142);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(26, 26);
            this.label26.TabIndex = 118;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button6.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(547, 66);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(153, 37);
            this.button6.TabIndex = 89;
            this.button6.Text = "Set Zero Pos_Y";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.Maroon;
            this.label27.Location = new System.Drawing.Point(91, 142);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(26, 26);
            this.label27.TabIndex = 117;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button7.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(358, 23);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(128, 37);
            this.button7.TabIndex = 88;
            this.button7.Text = "Set Home Pos_X";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button8.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(546, 22);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(153, 37);
            this.button8.TabIndex = 87;
            this.button8.Text = "Set Zero Pos_X";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(253, 88);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(39, 14);
            this.label30.TabIndex = 86;
            this.label30.Text = "(mm)";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label31.Location = new System.Drawing.Point(21, 77);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(106, 14);
            this.label31.TabIndex = 85;
            this.label31.Text = "Y axis Home Pos";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(150, 77);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(90, 26);
            this.textBox1.TabIndex = 84;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(253, 35);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(39, 14);
            this.label32.TabIndex = 83;
            this.label32.Text = "(mm)";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label33.Location = new System.Drawing.Point(23, 35);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(107, 14);
            this.label33.TabIndex = 82;
            this.label33.Text = "X axis Home Pos";
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(150, 30);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(90, 26);
            this.textBox2.TabIndex = 35;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox4.Controls.Add(this.label62);
            this.groupBox4.Controls.Add(this.label61);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.btnAllAxesZero);
            this.groupBox4.Controls.Add(this.lblZhmeSts);
            this.groupBox4.Controls.Add(this.lblXYhmeSts);
            this.groupBox4.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(1206, 58);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(236, 282);
            this.groupBox4.TabIndex = 102;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Homing Status";
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.Maroon;
            this.label62.Location = new System.Drawing.Point(193, 210);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(26, 26);
            this.label62.TabIndex = 140;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label61.Location = new System.Drawing.Point(11, 210);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(117, 14);
            this.label61.TabIndex = 139;
            this.label61.Text = "Roller Homing Sts";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label29.Location = new System.Drawing.Point(9, 161);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(178, 14);
            this.label29.TabIndex = 138;
            this.label29.Text = "Final Inspection Homing Sts";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label28.Location = new System.Drawing.Point(9, 113);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(123, 14);
            this.label28.TabIndex = 133;
            this.label28.Text = "Gantry Homing Sts";
            // 
            // btnAllAxesZero
            // 
            this.btnAllAxesZero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnAllAxesZero.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllAxesZero.ForeColor = System.Drawing.Color.White;
            this.btnAllAxesZero.Location = new System.Drawing.Point(14, 48);
            this.btnAllAxesZero.Name = "btnAllAxesZero";
            this.btnAllAxesZero.Size = new System.Drawing.Size(173, 37);
            this.btnAllAxesZero.TabIndex = 101;
            this.btnAllAxesZero.Text = "Initialize all Axes";
            this.btnAllAxesZero.UseVisualStyleBackColor = false;
            // 
            // lblZhmeSts
            // 
            this.lblZhmeSts.BackColor = System.Drawing.Color.Maroon;
            this.lblZhmeSts.Location = new System.Drawing.Point(193, 161);
            this.lblZhmeSts.Name = "lblZhmeSts";
            this.lblZhmeSts.Size = new System.Drawing.Size(26, 26);
            this.lblZhmeSts.TabIndex = 134;
            // 
            // lblXYhmeSts
            // 
            this.lblXYhmeSts.BackColor = System.Drawing.Color.Maroon;
            this.lblXYhmeSts.Location = new System.Drawing.Point(193, 112);
            this.lblXYhmeSts.Name = "lblXYhmeSts";
            this.lblXYhmeSts.Size = new System.Drawing.Size(26, 26);
            this.lblXYhmeSts.TabIndex = 133;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox3.Controls.Add(this.lblMinX);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.lblOrgY);
            this.groupBox3.Controls.Add(this.lblMaxY);
            this.groupBox3.Controls.Add(this.lblMinY);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.lblOrgX);
            this.groupBox3.Controls.Add(this.btnHmeY);
            this.groupBox3.Controls.Add(this.lblMaxX);
            this.groupBox3.Controls.Add(this.btnZeroY);
            this.groupBox3.Controls.Add(this.btnHmeX);
            this.groupBox3.Controls.Add(this.btnZeroX);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtYhme);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.txtXhme);
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(105, 59);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(818, 174);
            this.groupBox3.TabIndex = 50;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Gantry XY Axis Setting";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // lblMinX
            // 
            this.lblMinX.BackColor = System.Drawing.Color.Maroon;
            this.lblMinX.Location = new System.Drawing.Point(91, 143);
            this.lblMinX.Name = "lblMinX";
            this.lblMinX.Size = new System.Drawing.Size(26, 26);
            this.lblMinX.TabIndex = 132;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(751, 126);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(61, 37);
            this.button2.TabIndex = 131;
            this.button2.Text = "Stop";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.button1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(687, 126);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(42, 37);
            this.button1.TabIndex = 130;
            this.button1.Text = "Set Zero Pos_N1";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(411, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(21, 14);
            this.label12.TabIndex = 129;
            this.label12.Text = "EL";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(358, 112);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 14);
            this.label13.TabIndex = 128;
            this.label13.Text = "ORG";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(322, 112);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(22, 14);
            this.label14.TabIndex = 127;
            this.label14.Text = "NL";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(192, 112);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 14);
            this.label10.TabIndex = 126;
            this.label10.Text = "EL";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(141, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 14);
            this.label8.TabIndex = 125;
            this.label8.Text = "ORG";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(95, 112);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 14);
            this.label7.TabIndex = 124;
            this.label7.Text = "NL";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(249, 143);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 14);
            this.label11.TabIndex = 120;
            this.label11.Text = "Y Axis";
            // 
            // lblOrgY
            // 
            this.lblOrgY.BackColor = System.Drawing.Color.Maroon;
            this.lblOrgY.Location = new System.Drawing.Point(357, 137);
            this.lblOrgY.Name = "lblOrgY";
            this.lblOrgY.Size = new System.Drawing.Size(26, 26);
            this.lblOrgY.TabIndex = 123;
            // 
            // lblMaxY
            // 
            this.lblMaxY.BackColor = System.Drawing.Color.Maroon;
            this.lblMaxY.Location = new System.Drawing.Point(406, 137);
            this.lblMaxY.Name = "lblMaxY";
            this.lblMaxY.Size = new System.Drawing.Size(26, 26);
            this.lblMaxY.TabIndex = 122;
            // 
            // lblMinY
            // 
            this.lblMinY.BackColor = System.Drawing.Color.Maroon;
            this.lblMinY.Location = new System.Drawing.Point(318, 137);
            this.lblMinY.Name = "lblMinY";
            this.lblMinY.Size = new System.Drawing.Size(26, 26);
            this.lblMinY.TabIndex = 121;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(21, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 14);
            this.label5.TabIndex = 116;
            this.label5.Text = "X Axis";
            // 
            // lblOrgX
            // 
            this.lblOrgX.BackColor = System.Drawing.Color.Maroon;
            this.lblOrgX.Location = new System.Drawing.Point(146, 141);
            this.lblOrgX.Name = "lblOrgX";
            this.lblOrgX.Size = new System.Drawing.Size(26, 26);
            this.lblOrgX.TabIndex = 119;
            // 
            // btnHmeY
            // 
            this.btnHmeY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnHmeY.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHmeY.ForeColor = System.Drawing.Color.White;
            this.btnHmeY.Location = new System.Drawing.Point(358, 70);
            this.btnHmeY.Name = "btnHmeY";
            this.btnHmeY.Size = new System.Drawing.Size(130, 32);
            this.btnHmeY.TabIndex = 90;
            this.btnHmeY.Text = "Set Home Pos_Y";
            this.btnHmeY.UseVisualStyleBackColor = false;
            this.btnHmeY.Click += new System.EventHandler(this.btnHmeY_Click);
            // 
            // lblMaxX
            // 
            this.lblMaxX.BackColor = System.Drawing.Color.Maroon;
            this.lblMaxX.Location = new System.Drawing.Point(191, 142);
            this.lblMaxX.Name = "lblMaxX";
            this.lblMaxX.Size = new System.Drawing.Size(26, 26);
            this.lblMaxX.TabIndex = 118;
            // 
            // btnZeroY
            // 
            this.btnZeroY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnZeroY.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZeroY.ForeColor = System.Drawing.Color.White;
            this.btnZeroY.Location = new System.Drawing.Point(547, 66);
            this.btnZeroY.Name = "btnZeroY";
            this.btnZeroY.Size = new System.Drawing.Size(153, 37);
            this.btnZeroY.TabIndex = 89;
            this.btnZeroY.Text = "Set Zero Pos_Y";
            this.btnZeroY.UseVisualStyleBackColor = false;
            // 
            // btnHmeX
            // 
            this.btnHmeX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnHmeX.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHmeX.ForeColor = System.Drawing.Color.White;
            this.btnHmeX.Location = new System.Drawing.Point(358, 23);
            this.btnHmeX.Name = "btnHmeX";
            this.btnHmeX.Size = new System.Drawing.Size(128, 37);
            this.btnHmeX.TabIndex = 88;
            this.btnHmeX.Text = "Set Home Pos_X";
            this.btnHmeX.UseVisualStyleBackColor = false;
            this.btnHmeX.Click += new System.EventHandler(this.btnHmeX_Click);
            // 
            // btnZeroX
            // 
            this.btnZeroX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(94)))), ((int)(((byte)(133)))));
            this.btnZeroX.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnZeroX.ForeColor = System.Drawing.Color.White;
            this.btnZeroX.Location = new System.Drawing.Point(546, 22);
            this.btnZeroX.Name = "btnZeroX";
            this.btnZeroX.Size = new System.Drawing.Size(153, 37);
            this.btnZeroX.TabIndex = 87;
            this.btnZeroX.Text = "Set Zero Pos_X";
            this.btnZeroX.UseVisualStyleBackColor = false;
            this.btnZeroX.Click += new System.EventHandler(this.btnZeroX_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(253, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 14);
            this.label4.TabIndex = 86;
            this.label4.Text = "(mm)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(21, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 14);
            this.label6.TabIndex = 85;
            this.label6.Text = "Y axis Home Pos";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txtYhme
            // 
            this.txtYhme.Enabled = false;
            this.txtYhme.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtYhme.Location = new System.Drawing.Point(150, 77);
            this.txtYhme.Name = "txtYhme";
            this.txtYhme.Size = new System.Drawing.Size(90, 26);
            this.txtYhme.TabIndex = 84;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(253, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 14);
            this.label3.TabIndex = 83;
            this.label3.Text = "(mm)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(23, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 14);
            this.label2.TabIndex = 82;
            this.label2.Text = "X axis Home Pos";
            // 
            // txtXhme
            // 
            this.txtXhme.Enabled = false;
            this.txtXhme.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXhme.Location = new System.Drawing.Point(150, 30);
            this.txtXhme.Name = "txtXhme";
            this.txtXhme.Size = new System.Drawing.Size(90, 26);
            this.txtXhme.TabIndex = 35;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(422, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(693, 26);
            this.label9.TabIndex = 1;
            this.label9.Text = "GANTRY XYZ AXIS ZERO SETTING AND HOME SETTING";
            // 
            // imageList2
            // 
            this.imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList2.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // rotary_esd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1600, 900);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(0, 248);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 900);
            this.MinimizeBox = false;
            this.Name = "rotary_esd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "nozzle_esd";
            this.Load += new System.EventHandler(this.nozzle_esd_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.rotary_esd_MouseMove);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtYhme;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtXhme;
        private System.Windows.Forms.Button btnHmeY;
        private System.Windows.Forms.Button btnZeroY;
        private System.Windows.Forms.Button btnHmeX;
        private System.Windows.Forms.Button btnZeroX;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblOrgY;
        private System.Windows.Forms.Label lblMaxY;
        private System.Windows.Forms.Label lblMinY;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblOrgX;
        private System.Windows.Forms.Label lblMaxX;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAllAxesZero;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblZhmeSts;
        private System.Windows.Forms.Label lblXYhmeSts;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label lblMinX;
    }
}